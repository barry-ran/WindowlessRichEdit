// RichDrawExampleDlg.h : header file
//

#pragma once

#include "RichDrawText.h"

// CRichDrawExampleDlg dialog
class CRichDrawExampleDlg : public CDialog
{
// Construction
public:
	CRichDrawExampleDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_EXAMPLE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

  afx_msg void OnSize(UINT nType, int cx, int cy);

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

  CRichDrawText m_RichText;
};
