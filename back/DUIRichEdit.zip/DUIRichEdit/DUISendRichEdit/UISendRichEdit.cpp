#include "stdafx.h"
#include "UISendRichEdit.h"
#include <vector>
#include <algorithm>
#include "../RichEdit20Base/md5ex.h"
#include "UIScrollBarCom.h"
#include "UIPopupMenuCom.h"
#include "../public/RichItemElement/RichItemElement.h"

#ifndef _EXCLUDE_RESOURCE
#include "../public/RichItemElement/RichItemEditDlg.h"
#endif

//�������ʽ���ָ�����
#define		PARSE_ANCHOR					_T("|")

//�������ʽ����Դ��ͼƬ
#define		PARSE_RESOURCE_PIC				_T("{\\[/[0-9]+?\\]}")
#define		PARSE_RESOURCE_PIC_FORMAT		_T("[/%d]")

//�������ʽ���ļ�·��ͼƬ
#define		PARSE_DEFAULT_PIC				_T("{\\[i.*?\\.([Jj][Pp][Gg])|([Jj][Pp][Ee][Gg])|([Pp][Nn][Gg])|([Ii][Mm][Gg])|([Gg][Ii][Ff])|([Bb][Mm][Pp])\\[width_[0-9]+?\\]\\[height_[0-9]+?\\]\\]}")
#define		PARSE_DEFAULT_PIC_FORMAT		_T("[i%s[width_%d][height_%d]]")
#define		PARSE_DEFAULT_PIC_WIDTH_BEGIN	_T("[width_")
#define		PARSE_DEFAULT_PIC_WIDTH_END		_T("]")
#define		PARSE_DEFAULT_PIC_HEIGHT_BEGIN	_T("[height_")
#define		PARSE_DEFAULT_PIC_HEIGHT_END	_T("]")

//��������ǡ�������ͼƬ
#define		PARSE_COPYDATA_PIC				_T("{\\[c.*?\\.([Jj][Pp][Gg])|([Jj][Pp][Ee][Gg])|([Pp][Nn][Gg])|([Ii][Mm][Gg])|([Gg][Ii][Ff])|([Bb][Mm][Pp])<url_.*?><width_[0-9]+?><height_[0-9]+?>\\]}")
#define		PARSE_COPYDATA_PIC_FORMAT		_T("[c%s<url_%s><width_%d><height_%d>]")


CUISendRichEdit::CUISendRichEdit()
:m_bInit(false)
, m_hCursor(NULL)
, m_dwCurPicCount(0)
, m_bReadOnly(FALSE)
, m_bPainting(false)
, m_bUpdateNow(true)
, m_bEnableSetScrollPos(true)
, m_nLastScrollCommand(-1)
, m_bForbidVertScrollBar(false)
, m_bForbidHorzScrollBar(false)
, m_bExistVertScrollBar(false)
, m_bExistHorzScrollBar(false)
, m_pScrollBarImplVert(NULL)
, m_pScrollBarImplHorz(NULL)
, m_pBorderProp(NULL)
, m_pDrawBorder(NULL)
, m_pDrawBorderColor(NULL)
, m_pBorderWidth(NULL)
, m_bHasFocus(false)
, m_bShowFaceTip(false)
, m_bHasCaptureState(false)
, m_bValidLButtonUp(false)
, m_pPopupMenu(NULL)
, m_hWndDirectUI(NULL)
, m_bLimitByCharRule(false)
, m_pOleElementExModalProp(NULL)
{
	m_bEnableAutoKeyProc = true;
	m_bSetArrowCursor = false;
	m_bPlayGif = true;
	m_nCurEndVisibleIndex = -1;
	m_bForbidFacePaste = false;

	m_nfmtSysFaceID = ::RegisterClipboardFormat(_T("Format_SysFaceID"));
	m_nfmtHtmlID = ::RegisterClipboardFormat(_T("HTML Format"));
	m_nfmtRTFID = ::RegisterClipboardFormat(CF_RTF);
	m_bShowUserDefImage = true;
	m_nlastOverImageChar = -1;

	m_nDrawIdleTick = 0;
	m_nIDTDraw = -1;
	m_bNeedReDraw = FALSE;

	m_dwMouseHotOleID = -1;
	m_bLButtonDownHitOleControl = FALSE;
	m_bRegisterMessage = false;

	m_eState = DUIRICHEDIT_STATE_NORMAL;

	m_nBorderWidth = 0;

	m_bParseEmotionByInput = false;

	m_nIDTPicTips = -1;
	m_nIDTCaret = -1;

	m_nIDTAutoSize = -1;
	m_nLastInputContentLen = 0;
	m_hDCAutoSizeSnapshot = NULL;
	m_hBmpAutoSizeSnapshot = NULL;
	m_nBmpAutoSizeSnapshotWidth = 0;
	m_nBmpAutoSizeSnapshotHeigth = 0;

	m_hClipRgn = NULL;
	m_uUserDefPicMaxWidth = 300;

	memset(&m_rcDUIClient, 0, sizeof(m_rcDUIClient));

	for (int i=0;i<DUIRICHEDIT_STATE_LAST;++i)
	{
		m_pDrawProp[i] = NULL;
		m_pColorBorder[i] = NULL;
		m_pImgBorder[i] = NULL;
	}

	m_pAutoSizeProp = NULL;
	m_pAutoSize = NULL;
	m_pAutoMaxWidth = NULL;
	m_pAutoMaxHeight = NULL;

	for (int i = 0; i < OLE_ELEEX_MODAL_MAX; ++i)
	{
		m_pOleElementExModalArray[i].strEleName = _T("");
		m_pOleElementExModalArray[i].pEditProp = NULL;
		m_pOleElementExModalArray[i].pEleHeight = NULL;
		m_pOleElementExModalArray[i].pEleTextStyle = NULL;
		m_pOleElementExModalArray[i].pElement = NULL;
	}

	memset(&m_curCharFormat, 0, sizeof(m_curCharFormat));
	m_curCharFormat.cbSize = sizeof(m_curCharFormat);
	m_curCharFormat.dwMask = CFM_BOLD | CFM_CHARSET | CFM_COLOR | CFM_ITALIC | CFM_SIZE | CFM_UNDERLINE | CFM_FACE;
	m_curCharFormat.crTextColor = 0;
	m_curCharFormat.yHeight = GetRichEditFontHeight(10);
	m_curCharFormat.dwEffects = 0;
	m_curCharFormat.bPitchAndFamily = FF_DONTCARE;
	m_curCharFormat.bCharSet = DEFAULT_CHARSET;
	_tcsncpy(m_curCharFormat.szFaceName, _T("΢���ź�"), LF_FACESIZE);

	m_fmtetc[0].cfFormat = CF_TEXT;
	m_fmtetc[0].ptd = NULL;
	m_fmtetc[0].dwAspect = DVASPECT_CONTENT;
	m_fmtetc[0].lindex = -1;
	m_fmtetc[0].tymed = TYMED_HGLOBAL;

	m_fmtetc[1].cfFormat = m_nfmtSysFaceID;
	m_fmtetc[1].ptd = NULL;
	m_fmtetc[1].dwAspect = DVASPECT_CONTENT;
	m_fmtetc[1].lindex = -1;
	m_fmtetc[1].tymed = TYMED_HGLOBAL;

	m_fmtetc[2].cfFormat = m_nfmtHtmlID;
	m_fmtetc[2].ptd = NULL;
	m_fmtetc[2].dwAspect = DVASPECT_CONTENT;
	m_fmtetc[2].lindex = -1;
	m_fmtetc[2].tymed = TYMED_HGLOBAL;

	m_fmtetc[3].cfFormat = CF_UNICODETEXT;
	m_fmtetc[3].ptd = NULL;
	m_fmtetc[3].dwAspect = DVASPECT_CONTENT;
	m_fmtetc[3].lindex = -1;
	m_fmtetc[3].tymed = TYMED_HGLOBAL;

	m_stgmed[0].tymed = TYMED_HGLOBAL;
	m_stgmed[0].hGlobal = NULL;
	m_stgmed[0].pUnkForRelease = NULL;

	m_stgmed[1].tymed = TYMED_HGLOBAL;
	m_stgmed[1].hGlobal = NULL;
	m_stgmed[1].pUnkForRelease = NULL;

	m_stgmed[2].tymed = TYMED_HGLOBAL;
	m_stgmed[2].hGlobal = NULL;
	m_stgmed[2].pUnkForRelease = NULL;

	m_stgmed[3].tymed = TYMED_HGLOBAL;
	m_stgmed[3].hGlobal = NULL;
	m_stgmed[3].pUnkForRelease = NULL;
}

CUISendRichEdit::~CUISendRichEdit()
{
	ClearAllOleEleExModal();

	if (m_hClipRgn)
	{
		::DeleteObject(m_hClipRgn);
		m_hClipRgn = NULL;
	}

	DestroyAutoSizeSnapshot();

	DestroyAllTimer();

	if (m_pPopupMenu && m_pPopupMenu->GetOwnerCtrl() == this)
	{
		m_pPopupMenu->SetOwnerCtrl(NULL);
	}
}

LRESULT CUISendRichEdit::OnRichEditMsgProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	if (!m_bInit) return -1;

	switch(message)
	{
	case WM_RICHEDIT_GETVISIBLE:
		{
			BOOL* pVisible = (BOOL*)wParam;
			HWND* pHWnd = (HWND*)lParam;
			if (pVisible)
			{
				*pVisible = IsVisible();
			}
			if (pHWnd)
			{
				*pHWnd = m_hWndDirectUI;
			}
		}
		break;
	case WM_QERYACCPETDATA:
		{
			OnQueryAccpetData(wParam, lParam);
		}
		break;
	case WM_GETCLIPBOARDDATA:
		{
			OnGetClipBoardData(wParam, lParam);
		}
		break;
	case WM_UPDATE_GIF:
		break;
	case WM_KILLFOCUS:
		{
			//InvalidateRect(NULL, TRUE);
			goto serv;
		}
		break;
	case EN_CHANGE:
		{
			OnEnChange();
			return 0;
		}
		break;
	case EN_UPDATE:
		{
			OnEnUpdate();
			return 0;
		}
		break;
	case EN_LINK:
		{
			/*NMHDR* pNM = (NMHDR*)lParam;
			pNM->idFrom = GetDlgCtrlID();
			pNM->hwndFrom = GetSafeHwnd();
			::SendMessage(m_hParent, WM_NOTIFY, 0, lParam);*/
			return 0;
		}
		break;
	case WM_SETCURSOR:
		{
			if (m_bSetArrowCursor)
			{
				return -1;
			}

			LRESULT lr;
			lr = m_FreeWindowlessRE.WindowlessREProc(message, wParam, lParam);
			if (lr != S_MSG_KEY_IGNORED)
			{
				return lr;
			}
		}
		break;
	case WM_MOUSEWHEEL:
		{
			LRESULT lr;
			short zDelta = HIWORD(wParam);
			if (zDelta > 0)
			{
				lr = m_FreeWindowlessRE.WindowlessREProc(WM_VSCROLL, MAKEWPARAM(SB_LINEUP, 0), lParam);
			}
			else
			{
				lr = m_FreeWindowlessRE.WindowlessREProc(WM_VSCROLL, MAKEWPARAM(SB_LINEDOWN, 0), lParam);
			}
			return lr;
		}
		break;
	case WM_PAINT:
		{
			if (!CanUpdateNow())
			{
				return 0;
			}

			return m_FreeWindowlessRE.WindowlessREProc(message, wParam, lParam);
		}
		break;
	case WM_ERASEBKGND:
		{
			if (!CanUpdateNow())
			{
				return 0;
			}

			return m_FreeWindowlessRE.WindowlessREProc(message, wParam, lParam);
		}
		break;
	case WM_ELEMENT_PAINT:
		{
			//do nothing
		}
		break;
	case WM_OLE_PAINT:
		{
			OnOlePaint(wParam, lParam);
		}
		break;
	case WM_SHOWSCROLLBAR:
		{
			UINT nBar = (UINT)wParam;
			BOOL bShow = (BOOL)lParam;
			switch(nBar)
			{
			case SB_VERT:
				{
					ShowScrollBar(bShow, TRUE, FALSE);
					long nScrollWidth = bShow?GetScrollSize():0;
					CRect rcDUI = GetRenderRect();
					WPARAM newSize = MAKEWPARAM(rcDUI.Width()-nScrollWidth, rcDUI.Height());
					m_FreeWindowlessRE.WindowlessREProc(WM_SIZE, 0, newSize);
				}
				break;
			case SB_HORZ:
				{
				}
				break;
			case SB_BOTH:
				{
					ShowScrollBar(lParam, TRUE, FALSE);
					long nScrollWidth = bShow?GetScrollSize():0;
					CRect rcDUI = GetRenderRect();
					WPARAM newSize = MAKEWPARAM(rcDUI.Width()-nScrollWidth, rcDUI.Height());
					m_FreeWindowlessRE.WindowlessREProc(WM_SIZE, 0, newSize);
				}
				break;
			default:
				break;
			}

			DUICtrlNotifyInfo UINotifyInfo;
			memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
			UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_SHOW_SCROLLBAR;
			UINotifyInfo.lParam1 = (DWORD_PTR)(this);
			UINotifyInfo.lParam2 = (DWORD_PTR)(nBar);
			UINotifyInfo.lParam3 = (DWORD_PTR)(bShow);
			::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);

			return 0;
		}
		break;
	case WM_SETSCROLLPOS:
		{
			//�ڲ������ݵĹ����в��ı������λ��
			stSCROLLINFO* pSiex = (stSCROLLINFO*)lParam;
			if (pSiex && m_bEnableSetScrollPos)
			{
				SetScrollPos(pSiex->m_si.nPos, TRUE, FALSE);

				long nScrollLimit = GetScrollLimit(FALSE);
				if (pSiex->m_si.nPos > nScrollLimit)
				{
					m_FreeWindowlessRE.WindowlessREProc(WM_VSCROLL, MAKEWPARAM(DUI_SB_THUMBPOSITION, nScrollLimit), 0);
				}
			}
		}
		break;
	case WM_SETSCROLLRANGE:
	case WM_SETSCROLLINFO:
		{
			stSCROLLINFO* pSiex = (stSCROLLINFO*)lParam;
			if (pSiex)
			{
				DUISCROLLINFO si;
				si.ulSize = sizeof(DUISCROLLINFO);
				si.ulMask = pSiex->m_si.fMask;
				si.nMin = pSiex->m_si.nMin;
				si.nMax = pSiex->m_si.nMax;
				si.nPos = pSiex->m_si.nPos;
				si.ulPage = pSiex->m_si.nPage;
				si.nTrackPos = pSiex->m_si.nTrackPos;
				SetScrollInfo(&si, pSiex->m_bRedraw, (SB_HORZ == wParam)?TRUE:FALSE);
			}

			return 0;
		}
		break;
	case WM_GETCLIENTRECT:
		{
			CRect rcClient = GetRenderRect();
			RECT* pRcClient = (RECT*)wParam;
			if (pRcClient)
			{
				long nScrollWidth = IsVisibleScrollBar(FALSE)?GetScrollSize():0;
				pRcClient->left = 0;
				pRcClient->right = rcClient.Width()-nScrollWidth;
				pRcClient->top = 0;
				pRcClient->bottom = rcClient.Height();
			}
			return 0;
		}
		break;
	case WM_GETDUIRECT:
		{
			CRect rcClient = GetRenderRect();
			RECT* pRcClient = (RECT*)wParam;
			if (pRcClient)
			{
				long nScrollWidth = IsVisibleScrollBar(FALSE)?GetScrollSize():0;
				pRcClient->left = rcClient.left;
				pRcClient->right = rcClient.right-nScrollWidth;
				pRcClient->top = rcClient.top;
				pRcClient->bottom = rcClient.bottom;
			}
		}
		break;
	case WM_SIZE:
		{
			m_rcDUIClient = GetRenderRect();
			m_rcDUIClient.right = m_rcDUIClient.left + LOWORD(lParam);
			m_rcDUIClient.bottom = m_rcDUIClient.top + HIWORD(lParam);

			LRESULT lr = m_FreeWindowlessRE.WindowlessREProc(message, wParam, lParam);

			CaculOleParams();

			if (lr != S_MSG_KEY_IGNORED)
			{
				return lr;
			}

			return 0;
		}
		break;
	case WM_VSCROLL:
	case WM_HSCROLL:
		{
			LRESULT lr;
			lr = m_FreeWindowlessRE.WindowlessREProc(message, wParam, lParam);
			return lr;
		}
		break;
	case WM_MOUSELEAVE:
		{
			return m_FreeWindowlessRE.WindowlessREProc(message, wParam, lParam);
		}
		break;
	case WM_MOUSEMOVE:
		{
			CPoint ptCursor(LOWORD(lParam), HIWORD(lParam));
			CRect rcSkinClient = GetRenderRect();

			BOOL bInClient = rcSkinClient.PtInRect(ptCursor);
			if (bInClient || m_bHasCaptureState)
			{
				if (!bInClient)
				{
					if (ptCursor.y < INVALID_CURSOR_POS_Y)
					{
						if (ptCursor.y > rcSkinClient.bottom)
						{
							m_nLastScrollCommand = SB_LINEDOWN;
							m_FreeWindowlessRE.WindowlessREProc(WM_VSCROLL, (WPARAM)SB_LINEDOWN, (LPARAM)NULL);
						}
						else if (ptCursor.y < rcSkinClient.top)
						{
							m_nLastScrollCommand = SB_LINEUP;
							m_FreeWindowlessRE.WindowlessREProc(WM_VSCROLL, (WPARAM)SB_LINEUP, (LPARAM)NULL);
						}
					}
					else
					{
						if (SB_LINEUP == m_nLastScrollCommand)
						{
							m_FreeWindowlessRE.WindowlessREProc(WM_VSCROLL, (WPARAM)SB_LINEUP, (LPARAM)NULL);
						}
						else if (SB_LINEDOWN == m_nLastScrollCommand)
						{
							m_FreeWindowlessRE.WindowlessREProc(WM_VSCROLL, (WPARAM)SB_LINEDOWN, (LPARAM)NULL);
						}
					}
				}

				LPARAM lPraramNew = MAKELPARAM(ptCursor.x, ptCursor.y);
				return m_FreeWindowlessRE.WindowlessREProc(message, wParam, lPraramNew);
			}
		}
		break;
	case WM_LBUTTONUP:
		{
			CPoint ptCursor(LOWORD(lParam), HIWORD(lParam));
			CRect rcSkinClient = GetRenderRect();
			if (rcSkinClient.PtInRect(ptCursor) || m_bHasCaptureState)
			{
				LPARAM lPraramNew = MAKELPARAM(ptCursor.x, ptCursor.y);
				return m_FreeWindowlessRE.WindowlessREProc(message, wParam, lPraramNew);
			}
		}
		break;
	case WM_LBUTTONDOWN:
	case WM_LBUTTONDBLCLK:
	case WM_RBUTTONDOWN:
	case WM_RBUTTONDBLCLK:
	case WM_MBUTTONDOWN:
	case WM_MBUTTONUP:
	case WM_MBUTTONDBLCLK:
		{
			CPoint ptCursor(LOWORD(lParam), HIWORD(lParam));
			CRect rcSkinClient =  GetRenderRect();
			if (rcSkinClient.PtInRect(ptCursor))
			{
				SetRichEditFocus();
				LPARAM lPraramNew = MAKELPARAM(ptCursor.x, ptCursor.y);
				return m_FreeWindowlessRE.WindowlessREProc(message, wParam, lPraramNew);
			}
		}
		break;
	case WM_RBUTTONUP:
		{
			CPoint ptCursor(LOWORD(lParam), HIWORD(lParam));
			CRect rcSkinClient =  GetRenderRect();
			if (rcSkinClient.PtInRect(ptCursor))
			{
				LPARAM lPraramNew = MAKELPARAM(ptCursor.x, ptCursor.y);
				return m_FreeWindowlessRE.WindowlessREProc(message, wParam, lPraramNew);
			}
		}
		break;
	case WM_ENTERMENULOOP:
	case WM_MENURBUTTONUP:
	case WM_MENUDRAG:
	case WM_MENUGETOBJECT:
	case WM_UNINITMENUPOPUP:
	case WM_MENUCOMMAND:
	case WM_INITMENU:
	case WM_INITMENUPOPUP:
	case WM_MENUSELECT:
	case WM_MENUCHAR:
	case WM_DRAWITEM:
	case WM_MEASUREITEM:
	case WM_CONTEXTMENU:
	case WM_COMMAND:
		{
		}
		break;
	case WM_IME_STARTCOMPOSITION:
		{
			if (m_bReadOnly)
			{
				if (m_hWndDirectUI)
				{
					::PostMessage(m_hWndDirectUI, WM_READONLY_IME_INPUT, wParam, lParam);
				}
			}
			goto serv;
		}
		break;
	case WM_CHAR:
		{
			if (m_bReadOnly)
			{
				// 1ȫѡ 3���� 24����
				if (wParam == 1 || wParam == 3 || wParam == 24)
				{
					goto serv;
				}

				if (m_hWndDirectUI)
				{
					::PostMessage(m_hWndDirectUI, WM_READONLY_INPUT, wParam, lParam);
				}
				return 0;
			}
			else
			{
				//�Զ���������
				if (m_bParseEmotionByInput)
				{
					UINT nChar = static_cast<UINT>(wParam);
					if ('/' == nChar)
					{
						WTL::CString strSendText;
						GetContent(strSendText);

						//��ȡ����λ��
						long lFirstSelPos, lLastSelPos;
						GetSel(lFirstSelPos, lLastSelPos);

						//ͳ���ڵ�����ʾ֮ǰ�������ַ��ĸ���:��EmotionTransTip�ڻ��õ�
						int nBackNumOfChars = strSendText.GetLength() - lLastSelPos;

						if (IsEmotionTipsShouldPopUp(lFirstSelPos, lLastSelPos, strSendText))
						{
							PopUpEmotionTips(lFirstSelPos, nBackNumOfChars);
						}
					}
				}
			}
			goto serv;
		}
		break;
	case WM_KEYDOWN:
		{
			if (!m_bEnableAutoKeyProc)
			{
				if (wParam == VK_RETURN || wParam == VK_ESCAPE)
				{
					return S_OK;
				}
			}
			goto serv;
		}
		break;
	case WM_RICHEDIT_SETCAPTUER:
		{
			m_bHasCaptureState = true;
		}
		break;
	case WM_RICHEDIT_RELEASECAPTUER:
		{
			if (m_bHasCaptureState)
			{
				CPoint ptCursor;
				::GetCursorPos(&ptCursor);
				::ScreenToClient(m_hWndDirectUI, &ptCursor);
				CRect rcClient = GetRenderRect();
				long nScrollWidth = IsVisibleScrollBar(FALSE)?GetScrollSize():0;
				rcClient.right -= nScrollWidth;

				//��겻��client�����������focus״̬, ����ѡ���ı�״̬�²����ٷ�ѡ
				if (!rcClient.PtInRect(ptCursor))
				{
					SetRichEditFocus();
				}
			}
			m_bHasCaptureState = false;
		}
		break;
	case WM_RICHEDIT_ENABLE_CARET_TIMER:
		{
			BOOL bSet = (BOOL)wParam;
			if (bSet)
			{
				if (GetDirectUI())
				{
					if (!IsVisible() || GetDirectUI()->GetFocusObject() != this)
					{
						return S_FALSE;
					}

					if (-1 == m_nIDTCaret)
					{
						m_nIDTCaret = GetDirectUI()->SetTimer(this, 500, NULL);
					}
				}
			}
			else
			{
				if (GetDirectUI())
				{
					if (m_nIDTCaret != -1)
					{
						GetDirectUI()->KillTimer(m_nIDTCaret);
						m_nIDTCaret = -1;
					}
				}
			}
		}
		break;
	case WM_RICHEDIT_SET_FOCUS:
		{
			SetRichEditFocus();
		}
		break;
	case WM_RICHEDIT_REG_DRAGDROP:
		{
			RegisterDragDrop();
		}
		break;
	case WM_RICHEDIT_UNREG_DRAGDROP:
		{
			RevokeDragDrop();
		}
		break;
	default:
		{
serv:
			LRESULT lr;
			lr = m_FreeWindowlessRE.WindowlessREProc(message, wParam, lParam);
			if (lr != S_MSG_KEY_IGNORED)
			{
				return lr;
			}
		}
	}

	return S_OK;
}

LRESULT CUISendRichEdit::OnRichEditInsideRedraw(bool bIgnoreThreadSafe)
{
	if (!CanUpdateNow())
	{
		return S_FALSE;
	}

	RECT rcUpdate;
	rcUpdate.left = m_rcDUIClient.left;
	rcUpdate.right = m_rcDUIClient.right;
	rcUpdate.top = m_rcDUIClient.top;
	rcUpdate.bottom = m_rcDUIClient.bottom;

	::InvalidateRect(m_hWndDirectUI, &rcUpdate, TRUE);

	return S_OK;
}

CPoint CUISendRichEdit::PosFromChar(UINT nChar) const
{
	if (!m_bInit) return CPoint(0, 0);

	return m_FreeWindowlessRE.PosFromChar(nChar);
}

int CUISendRichEdit::CharFromPos(CPoint pt) const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.CharFromPos(pt);
}

void CUISendRichEdit::LineScroll(int nLines, int nChars)
{
	if (!m_bInit) return;

	return m_FreeWindowlessRE.LineScroll(nLines, nChars);
}

long CUISendRichEdit::LineFromChar(long nIndex) const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.LineFromChar(nIndex);
}

int CUISendRichEdit::GetFirstVisibleLine() const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetFirstVisibleLine();
}

int CUISendRichEdit::GetLineCount()
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetLineCount();
}

int CUISendRichEdit::LineIndex(int nLine) const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.LineIndex(nLine);
}

int CUISendRichEdit::LineLength(int nLine) const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.LineLength(nLine);
}

void CUISendRichEdit::GetSel(CHARRANGE& cr) const
{
	if (!m_bInit) return;

	return m_FreeWindowlessRE.GetSel(cr);
}

void CUISendRichEdit::SetSel(CHARRANGE& cr, bool bHideCaret)
{
	if (!m_bInit) return;

	return m_FreeWindowlessRE.SetSel(cr, bHideCaret);
}

POINT CUISendRichEdit::GetCaretPos()
{
	CHARRANGE selRange = {0,0};
	GetSel(selRange);
	return PosFromChar(selRange.cpMax);
}

void CUISendRichEdit::HideSelection(BOOL bHide, BOOL bPerm)
{
	if (!m_bInit) return;

	return m_FreeWindowlessRE.HideSelection(bHide, bPerm);
}

WORD CUISendRichEdit::GetSelectionType() const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetSelectionType();
}

long CUISendRichEdit::GetSelText(LPSTR lpBuf) const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetSelText(lpBuf);
}

WTL::CString CUISendRichEdit::GetSelText() const
{
	if (!m_bInit) return _T("");

	return m_FreeWindowlessRE.GetSelText();
}

int CUISendRichEdit::GetTextRange(int nFirst, int nLast, WTL::CString& refString) const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetTextRange(nFirst, nLast, refString);
}

void CUISendRichEdit::GetIRichEditOle(IRichEditOle** pResult) const
{
	if (!pResult)
	{
		return;
	}

	if (!m_bInit)
	{
		return;
	}

	m_FreeWindowlessRE.GetIRichEditOle(pResult);
}

BOOL CUISendRichEdit::SetOLECallback(IRichEditOleCallback* pCallback)
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.SetOLECallback(pCallback);
}

DWORD CUISendRichEdit::GetDefaultCharFormat(CHARFORMAT& cf)
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetDefaultCharFormat(cf);
}

DWORD CUISendRichEdit::GetDefaultCharFormat(CHARFORMAT2& cf) const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetDefaultCharFormat(cf);
}

DWORD CUISendRichEdit::GetParaFormat(PARAFORMAT& pf) const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetParaFormat(pf);
}

DWORD CUISendRichEdit::GetSelectionCharFormat(CHARFORMAT& cf)
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetSelectionCharFormat(cf);
}

DWORD CUISendRichEdit::GetSelectionCharFormat(CHARFORMAT2& cf)
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetSelectionCharFormat(cf);
}

BOOL CUISendRichEdit::SetDefaultCharFormat(CHARFORMAT& cf)
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.SetDefaultCharFormat(cf);
}

BOOL CUISendRichEdit::SetDefaultCharFormat(CHARFORMAT2& cf)
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.SetDefaultCharFormat(cf);
}

BOOL CUISendRichEdit::SetParaFormat(PARAFORMAT& pf)
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.SetParaFormat(pf);
}

BOOL CUISendRichEdit::SetSelectionCharFormat(CHARFORMAT& cf)
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.SetSelectionCharFormat(cf);
}

BOOL CUISendRichEdit::SetSelectionCharFormat(CHARFORMAT2& cf)
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.SetSelectionCharFormat(cf);
}

BOOL CUISendRichEdit::SetWordCharFormat(CHARFORMAT& cf)
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.SetWordCharFormat(cf);
}

BOOL CUISendRichEdit::SetWordCharFormat(CHARFORMAT2& cf)
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.SetWordCharFormat(cf);
}

BOOL CUISendRichEdit::CanPaste(UINT nFormat) const
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.CanPaste(nFormat);
}

BOOL CUISendRichEdit::CanRedo() const
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.CanRedo();
}

BOOL CUISendRichEdit::CanUndo() const
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.CanUndo();
}

void CUISendRichEdit::EmptyUndoBuffer()
{
	if (!m_bInit) return;

	return m_FreeWindowlessRE.EmptyUndoBuffer();
}

UINT CUISendRichEdit::SetUndoLimit(UINT nLimit)
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.SetUndoLimit(nLimit);
}

BOOL CUISendRichEdit::Redo()
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.Redo();
}

BOOL CUISendRichEdit::Undo()
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.Undo();
}

void CUISendRichEdit::SetOptions(WORD wOp, DWORD dwFlags)
{
	if (!m_bInit) return;

	return m_FreeWindowlessRE.SetOptions(wOp, dwFlags);
}

UINT CUISendRichEdit::GetOptions() const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetOptions();
}

long CUISendRichEdit::GetLimitText() const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetLimitText();
}

void CUISendRichEdit::LimitText(long nChars)
{
	if (!m_bInit) return;

	return m_FreeWindowlessRE.LimitText(nChars);
}

BOOL CUISendRichEdit::SetAutoURLDetect(BOOL bEnable)
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.SetAutoURLDetect(bEnable);
}

DWORD CUISendRichEdit::SetEventMask(DWORD dwEventMask)
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.SetEventMask(dwEventMask);
}

long CUISendRichEdit::GetEventMask() const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetEventMask();
}

long CUISendRichEdit::StreamIn(int nFormat, EDITSTREAM& es)
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.StreamIn(nFormat, es);
}

long CUISendRichEdit::StreamOut(int nFormat, EDITSTREAM& es)
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.StreamOut(nFormat, es);
}

COLORREF CUISendRichEdit::SetBackgroundColor(BOOL bSysColor, COLORREF cr)
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.SetBackgroundColor(bSysColor, cr);
}

long CUISendRichEdit::GetTextLengthEx(DWORD dwFlags, UINT uCodePage) const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetTextLengthEx(dwFlags, uCodePage);
}

DWORD CUISendRichEdit::AddOleData(IOleProcesser* pOleProcesser, DWORD dwID)
{
	if (!pOleProcesser)
	{
		return -1;
	}

	RichOleMap::iterator it_ole = m_richOleMap.find(dwID);
	if (it_ole != m_richOleMap.end())
	{
		RemoveOleData(dwID);
	}

	stOleData data;
	data.dwID = dwID;
	data.pProcesser = pOleProcesser;
	m_richOleMap.insert(std::make_pair(dwID, data));

	return dwID;
}

void CUISendRichEdit::RemoveOleData(DWORD dwID)
{
	RichOleMap::iterator it_ole = m_richOleMap.find(dwID);
	if (it_ole != m_richOleMap.end())
	{
		if (it_ole->second.pProcesser)
		{
			SAFE_DELETE(it_ole->second.pProcesser);
		}

		m_richOleMap.erase(it_ole);
	}

	if (dwID == m_dwMouseHotOleID)
	{
		m_dwMouseHotOleID = -1;
	}
}

BOOL CUISendRichEdit::CheckOlesByAdd(LONG lInsertChar, LONG lCharCount)
{
	// do nothing
	return TRUE;
}

BOOL CUISendRichEdit::CheckOlesByDel(LONG lStartChar, LONG lEndChar)
{
	if (!m_bInit)
	{
		return FALSE;
	}

	if (lEndChar < lStartChar)
	{
		return FALSE;
	}

	CComPtr<IRichEditOle> pReo;
	GetIRichEditOle(&pReo);
	if(NULL == pReo)
	{
		return FALSE;
	}

	int nCount = pReo->GetObjectCount();
	for (int i = nCount - 1; i >= 0; --i)
	{
		REOBJECT reObject;
		memset(&reObject, 0, sizeof(REOBJECT));
		reObject.cbStruct = sizeof(REOBJECT);
		pReo->GetObject(i, &reObject, REO_GETOBJ_NO_INTERFACES);

		if (reObject.cp >= lStartChar && reObject.cp <= lEndChar)
		{
			RemoveOleData(reObject.dwUser);
		}
	}

	return TRUE;
}

DWORD CUISendRichEdit::GetOleID()
{
	if (-1 == m_dwCurPicCount)
	{
		m_dwCurPicCount = 0;
	}

	return m_dwCurPicCount++;
}

IOleProcesser* CUISendRichEdit::GetOleProcesser(DWORD dwID)
{
	RichOleMap::iterator it_ole = m_richOleMap.find(dwID);
	if (it_ole != m_richOleMap.end())
	{
		return it_ole->second.pProcesser;
	}

	return NULL;
}

void CUISendRichEdit::GetOleTextUBB(DWORD dwID, bool bFaceCharExpression, bool bOleControlExpression, WTL::CString& strResult, bool bCopyData)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwID);
	if (!pOleProcesser)
	{
		return;
	}

	if (OleProcesser_Control == pOleProcesser->GetType())
	{
		if (bOleControlExpression)
		{
			GetOleTextExpression_Control(dwID, pOleProcesser, strResult);
		}
		else
		{
			GetOleTextDesc_Control(dwID, pOleProcesser, strResult);
		}
	}
	else if (OleProcesser_Gif == pOleProcesser->GetType())
	{
		GetOleTextExpression_Gif(dwID, pOleProcesser, bFaceCharExpression, strResult, bCopyData);
	}
}

void CUISendRichEdit::GetOleTextExpression(DWORD dwID, bool bFaceCharExpression, WTL::CString& strResult, bool bCopyData)
{
	strResult = _T("");

	IOleProcesser* pOleProcesser = GetOleProcesser(dwID);
	if (!pOleProcesser)
	{
		return;
	}

	if (OleProcesser_Control == pOleProcesser->GetType())
	{
		GetOleTextExpression_Control(dwID, pOleProcesser, strResult);
	}
	else if (OleProcesser_Gif == pOleProcesser->GetType())
	{
		GetOleTextExpression_Gif(dwID, pOleProcesser, bFaceCharExpression, strResult, bCopyData);
	}
}

void CUISendRichEdit::GetOleTextExpression_Gif(DWORD dwID, IOleProcesser* pOleProcesser, bool bFaceCharExpression, WTL::CString& strResult, bool bCopyData)
{
	CIMGifProcesser* pGifProcesser = (CIMGifProcesser*)pOleProcesser;
	if (!pGifProcesser)
	{
		return;
	}

	// �ļ���ת��
	if (!pGifProcesser->IsLoadFromRes())
	{
		if (bCopyData)
		{
			BOOL bExistURL = pGifProcesser->IsExistFileURL();
			int nImgWidth = bExistURL ? pGifProcesser->GetFileURLImageWidth() : (int)pGifProcesser->GetSize().cx;
			int nImgHeight = bExistURL ? pGifProcesser->GetFileURLImageHeight() : (int)pGifProcesser->GetSize().cy;
			strResult.Format(PARSE_COPYDATA_PIC_FORMAT, pGifProcesser->GetFilePathName(), 
				bExistURL ? pGifProcesser->GetFileURL() : _T(""), nImgWidth, nImgHeight);
		}
		else if (pGifProcesser->IsExistFileURL() && m_regExpImgURL.strRegExpFormat.GetLength() > 0)
		{
			int nImgWidth = pGifProcesser->GetFileURLImageWidth();
			int nImgHeight = pGifProcesser->GetFileURLImageWidth();
			strResult.Format(m_regExpImgURL.strRegExpFormat, pGifProcesser->GetFileURL(), nImgWidth, nImgHeight);
		}
		else if (m_regExpImgFile.strRegExpFormat.GetLength() > 0)
		{
			int nImgWidth = (int)pGifProcesser->GetSize().cx;
			int nImgHeight = (int)pGifProcesser->GetSize().cy;
			strResult.Format(m_regExpImgFile.strRegExpFormat, pGifProcesser->GetFilePathName(), nImgWidth, nImgHeight);
		}
		else
		{
			int nImgWidth = (int)pGifProcesser->GetSize().cx;
			int nImgHeight = (int)pGifProcesser->GetSize().cy;
			strResult.Format(PARSE_DEFAULT_PIC_FORMAT, pGifProcesser->GetFilePathName(), nImgWidth, nImgHeight);
		}
		return;
	}

	// �ַ�ת��
	FaceTextExpressionMap::iterator it_face = m_faceTextExpressionMap.find(pGifProcesser->GetResID());
	if (it_face != m_faceTextExpressionMap.end() && bFaceCharExpression)
	{
		strResult = it_face->second.strTextExpression;
		return;
	}

	// ��ԴIDת��
	strResult.Format(PARSE_RESOURCE_PIC_FORMAT, pGifProcesser->GetResID());
}

void CUISendRichEdit::GetOleTextExpression_Control(DWORD dwID, IOleProcesser* pOleProcesser, WTL::CString& strResult)
{
	CIMControlProcesser* pControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pControlProcesser)
	{
		return;
	}

	TCHAR tszResult[MAX_PATH + 1] = {0};
	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_OLE_CONTROL_GET_TEXT_EXPRESSION;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	UINotifyInfo.lParam2 = (DWORD_PTR)dwID;
	UINotifyInfo.lParam3 = (DWORD_PTR)tszResult;
	UINotifyInfo.lParam4 = (DWORD_PTR)MAX_PATH;
	::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&UINotifyInfo, 0);

	strResult = tszResult;
}

void CUISendRichEdit::GetOleTextDesc(DWORD dwID, WTL::CString& strResult)
{
	strResult = _T("");

	IOleProcesser* pOleProcesser = GetOleProcesser(dwID);
	if (!pOleProcesser)
	{
		return;
	}

	if (OleProcesser_Control == pOleProcesser->GetType())
	{
		GetOleTextDesc_Control(dwID, pOleProcesser, strResult);
	}
	else if (OleProcesser_Gif == pOleProcesser->GetType())
	{
		GetOleTextDesc_Gif(dwID, pOleProcesser, strResult);
	}
}

void CUISendRichEdit::GetOleTextDesc_Gif(DWORD dwID, IOleProcesser* pOleProcesser, WTL::CString& strResult)
{
	CIMGifProcesser* pGifProcesser = (CIMGifProcesser*)pOleProcesser;
	if (!pGifProcesser)
	{
		return;
	}

	if (pGifProcesser->IsLoadFromRes())
	{
		FaceTextExpressionMap::iterator it_face = m_faceTextExpressionMap.find(pGifProcesser->GetResID());
		if (it_face != m_faceTextExpressionMap.end())
		{
			strResult.Format(_T("[/%s]"), it_face->second.strTextHint);
		}
	}
	else if (pGifProcesser->GetFilePathName())
	{
		strResult = _T("[/ͼƬ]");
	}
}

void CUISendRichEdit::GetOleTextDesc_Control(DWORD dwID, IOleProcesser* pOleProcesser, WTL::CString& strResult)
{
	CIMControlProcesser* pControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pControlProcesser)
	{
		return;
	}

	TCHAR tszResult[MAX_PATH + 1] = {0};
	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_OLE_CONTROL_GET_TEXT_DESC;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	UINotifyInfo.lParam2 = (DWORD_PTR)dwID;
	UINotifyInfo.lParam3 = (DWORD_PTR)tszResult;
	UINotifyInfo.lParam4 = (DWORD_PTR)MAX_PATH;
	::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&UINotifyInfo, 0);

	strResult = tszResult;
}

bool CUISendRichEdit::OnHitTestOleControl(UINT nHitMessage, CPoint& pt)
{
	CRect rcResultOle(0,0,0,0);
	DWORD dwResultOleID = -1;
	HitTestOleByPoint(pt, dwResultOleID, rcResultOle);

	BOOL bRetInvalidate = FALSE;
	BOOL bSetHandCuror = FALSE;
	BOOL bHitRet = FALSE;
	switch (nHitMessage)
	{
	case WM_LBUTTONUP:
		{
			CRichElementBase* pOleLButtonUp = NULL;
			if (dwResultOleID != -1)
			{
				IOleProcesser* pOleProsser = GetOleProcesser(dwResultOleID);
				if (pOleProsser && pOleProsser->GetType() == OleProcesser_Control)
				{
					bHitRet = TRUE;

					CIMControlProcesser* pOleControl = (CIMControlProcesser*)pOleProsser;

					CPoint ptHitOle = pt;
					ptHitOle.Offset(-rcResultOle.left, -rcResultOle.top);

					CRichElementBase* pOleMouseLeave = NULL;
					pOleControl->OnLButtonUp(ptHitOle, bRetInvalidate, &pOleLButtonUp, &pOleMouseLeave);

					if (pOleMouseLeave)
					{
						OnMouseLeaveOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
							pOleMouseLeave, pOleControl->GetUserData());
					}
					if (pOleLButtonUp)
					{
						OnLButtonUpOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
							pOleLButtonUp, pOleControl->GetUserData());
					}
				}
			}

			//�������
			while (pOleLButtonUp)
			{
				if (pOleLButtonUp->IsDisposeMouse() && 
					pOleLButtonUp->IsEnabled())
				{
					break;
				}

				pOleLButtonUp = pOleLButtonUp->GetParentElement();
			}
			if (!m_bHasCaptureState && pOleLButtonUp)
			{
				bSetHandCuror = TRUE;
			}
		}
		break;
	case WM_RBUTTONUP:
		{
			if (dwResultOleID != -1)
			{
				IOleProcesser* pOleProsser = GetOleProcesser(dwResultOleID);
				if (pOleProsser && pOleProsser->GetType() == OleProcesser_Control)
				{
					bHitRet = TRUE;
				}
			}
		}
		break;
	case WM_MOUSEMOVE:
		{
			//MouseLeave
			if (dwResultOleID != m_dwMouseHotOleID && m_dwMouseHotOleID != -1)
			{
				IOleProcesser* pOleMouseLeave = GetOleProcesser(m_dwMouseHotOleID);
				if (pOleMouseLeave && pOleMouseLeave->GetType() == OleProcesser_Control)
				{
					CIMControlProcesser* pOleControl = (CIMControlProcesser*)pOleMouseLeave;

					CRichElementBase* pRetElement = NULL;
					pOleControl->OnMouseLeave(bRetInvalidate, &pRetElement);

					if (pRetElement)
					{
						OnMouseLeaveOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
							pRetElement, pOleControl->GetUserData());
					}
				}
			}

			//����MouseHot��
			m_dwMouseHotOleID = dwResultOleID;

			//MouseEnter
			CRichElementBase* pRetHitElement = NULL;
			if (m_dwMouseHotOleID != -1)
			{
				IOleProcesser* pOleMouseHot = GetOleProcesser(m_dwMouseHotOleID);
				if (pOleMouseHot && pOleMouseHot->GetType() == OleProcesser_Control)
				{
					bHitRet = TRUE;

					CIMControlProcesser* pOleControl = (CIMControlProcesser*)pOleMouseHot;

					CPoint ptHitOle = pt;
					ptHitOle.Offset(-rcResultOle.left, -rcResultOle.top);

					CRichElementBase* pRetHotElement = NULL;
					CRichElementBase* pRetLeaveElement = NULL;
					pOleControl->OnMouseMove(ptHitOle, bRetInvalidate, &pRetHotElement, &pRetLeaveElement, &pRetHitElement);

					if (pRetLeaveElement)
					{
						OnMouseLeaveOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
							pRetLeaveElement, pOleControl->GetUserData());
					}
					if (pRetHotElement)
					{
						OnMouseEnterOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
							pRetHotElement, pOleControl->GetUserData());
					}
				}
			}

			//�������
			while (pRetHitElement)
			{
				if (pRetHitElement->IsDisposeMouse() && 
					pRetHitElement->IsEnabled())
				{
					break;
				}

				pRetHitElement = pRetHitElement->GetParentElement();
			}
			if (!m_bHasCaptureState && pRetHitElement)
			{
				bSetHandCuror = TRUE;
			}
		}
		break;
	case WM_LBUTTONDOWN:
		{
			CRichElementBase* pOleLButtonDown = NULL;
			if (dwResultOleID != -1)
			{
				IOleProcesser* pOleProsser = GetOleProcesser(dwResultOleID);
				if (pOleProsser && pOleProsser->GetType() == OleProcesser_Control)
				{
					bHitRet = TRUE;

					CIMControlProcesser* pOleControl = (CIMControlProcesser*)pOleProsser;

					CPoint ptHitOle = pt;
					ptHitOle.Offset(-rcResultOle.left, -rcResultOle.top);

					CRichElementBase* pOleMouseLeave = NULL;
					pOleControl->OnLButtonDown(ptHitOle, bRetInvalidate, &pOleLButtonDown, &pOleMouseLeave);

					if (pOleMouseLeave)
					{
						OnMouseLeaveOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
							pOleMouseLeave, pOleControl->GetUserData());
					}
					if (pOleLButtonDown)
					{
						OnLButtonDownOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
							pOleLButtonDown, pOleControl->GetUserData());
					}
				}
			}

			//�������
			while (pOleLButtonDown)
			{
				if (pOleLButtonDown->IsDisposeMouse() && 
					pOleLButtonDown->IsEnabled())
				{
					break;
				}

				pOleLButtonDown = pOleLButtonDown->GetParentElement();
			}
			if (pOleLButtonDown)
			{
				bSetHandCuror = TRUE;
			}
		}
		break;
	case WM_RBUTTONDOWN:
		{
			//do nothing
		}
		break;
	case WM_SETCURSOR:
		{
			//do nothing
		}
		break;
	default:
		break;
	}

	if (bSetHandCuror)
	{
		// do nothing
	}

	if (bRetInvalidate)
	{
		DirectRedraw2(NULL);
	}

	return bHitRet ? true : false;
}

bool CUISendRichEdit::HitTestOleByPoint(POINT pt, DWORD& dwResultOleID, CRect& rcResultOle)
{
	dwResultOleID = -1;
	rcResultOle.SetRectEmpty();

	if (!m_bInit)
	{
		return false;
	}

	CComPtr<IRichEditOle> pReo;
	GetIRichEditOle(&pReo);
	if (!pReo)
	{
		return false;
	}

	//���ж�����Ƿ��ڵ�ǰ�ؼ�����
	long nScrollWidth = IsVisibleScrollBar(FALSE)?GetScrollSize():0;
	CRect rcClient = GetRect();
	if (rcClient.Width() > nScrollWidth)
	{
		rcClient.right -= nScrollWidth;
	}
	if (!rcClient.PtInRect(pt))
	{
		return false;
	}

	//���ȿ��ٶ�λһ���ɼ�ole����
	REOBJECT reObject;
	int nCount = pReo->GetObjectCount();
	int nEndIndex = 0;

	HDC hDC = ::GetDC(m_hWndDirectUI);
	LONG xPerInch = ::GetDeviceCaps(hDC, LOGPIXELSX);
	LONG yPerInch = ::GetDeviceCaps(hDC, LOGPIXELSY);
	GetOneOleUpdateIndex(pReo, reObject, xPerInch, yPerInch, rcClient, nCount, nEndIndex);
	::ReleaseDC(m_hWndDirectUI, hDC);

	//�ӵ�ǰ�ɼ�ole��������λ�ã������˷�ɢ��ʼƥ��
	CPoint ptObjPos;
	LONG li_Width = 0, li_Height = 0;

	//���ϼ���ƥ�����
	for (int i = nEndIndex; i >= 0; i--)
	{
		if (!GetOleObjPos(pReo, reObject, i, ptObjPos, xPerInch, yPerInch, li_Width, li_Height))
		{
			return false;
		}

		//ole�����ڵ�ǰ�ͻ�����
		bool bInClientRc = false;
		if (ptObjPos.x < rcClient.right && ptObjPos.x + li_Width > rcClient.left && 
			ptObjPos.y < rcClient.bottom && ptObjPos.y + li_Height > rcClient.top)
		{
			bInClientRc = true;
		}
		else
		{
			bInClientRc = false;
		}

		if (!bInClientRc)
		{
			break;
		}

		if (pt.x >= ptObjPos.x && pt.x <= ptObjPos.x + li_Width && 
			pt.y >= ptObjPos.y && pt.y <= ptObjPos.y + li_Height)
		{
			dwResultOleID =  reObject.dwUser;
			rcResultOle.left = ptObjPos.x;
			rcResultOle.right = ptObjPos.x + li_Width;
			rcResultOle.top = ptObjPos.y;
			rcResultOle.bottom = ptObjPos.y + li_Height;
			return true;
		}
	}

	//���¼�����ƶ���
	for (int i = nEndIndex + 1; i < nCount; i++)
	{
		if (!GetOleObjPos(pReo, reObject, i, ptObjPos, xPerInch, yPerInch, li_Width, li_Height))
		{
			return false;
		}

		//ole�����ڵ�ǰ�ͻ�����
		bool bInClientRc = false;
		if (ptObjPos.x < rcClient.right && ptObjPos.x + li_Width > rcClient.left && 
			ptObjPos.y < rcClient.bottom && ptObjPos.y + li_Height > rcClient.top)
		{
			bInClientRc = true;
		}
		else
		{
			bInClientRc = false;
		}

		if (!bInClientRc)
		{
			break;
		}

		if (pt.x >= ptObjPos.x && pt.x <= ptObjPos.x + li_Width && 
			pt.y >= ptObjPos.y && pt.y <= ptObjPos.y + li_Height)
		{
			dwResultOleID =  reObject.dwUser;
			rcResultOle.left = ptObjPos.x;
			rcResultOle.right = ptObjPos.x + li_Width;
			rcResultOle.top = ptObjPos.y;
			rcResultOle.bottom = ptObjPos.y + li_Height;
			return true;
		}
	}

	return false;
}

DWORD CUISendRichEdit::InsertImage(LPCTSTR picPath, DWORD userID)
{
	CIMGifProcesser* pGifProcesser = new CIMGifProcesser;
	if (!pGifProcesser->Load(picPath, (IRichEditMsgProc*)this))
	{
		delete pGifProcesser;
		pGifProcesser = NULL;
		return -1;
	}

	// ʹ�ÿ���ģʽ
	BOOL bOpenSnapshot = TRUE;
	if (pGifProcesser->IsGIF())
	{
		bOpenSnapshot = FALSE;
	}
	pGifProcesser->EnableAutoSize(TRUE);
	pGifProcesser->EnableSnapshot(bOpenSnapshot);

	DWORD dwRetID = InsertImageImpl(pGifProcesser, userID, true);
	if (-1 == dwRetID)
	{
		delete pGifProcesser;
		pGifProcesser = NULL;
		return -1;
	}

	return dwRetID;
}

DWORD CUISendRichEdit::InsertImage(HINSTANCE hInstance, UINT nIDResource, const char* lpszType, DWORD userID)
{
	CIMGifProcesser* pGifProcesser = new CIMGifProcesser;
	if (!pGifProcesser->Load(hInstance, nIDResource, lpszType, (IRichEditMsgProc*)this))
	{
		delete pGifProcesser;
		pGifProcesser = NULL;
		return -1;
	}

	// ʹ�ÿ���ģʽ
	BOOL bOpenSnapshot = TRUE;
	if (pGifProcesser->IsGIF())
	{
		bOpenSnapshot = FALSE;
	}
	pGifProcesser->EnableAutoSize(TRUE);
	pGifProcesser->EnableSnapshot(bOpenSnapshot);

	DWORD dwRetID = InsertImageImpl(pGifProcesser, userID, false);
	if (-1 == dwRetID)
	{
		delete pGifProcesser;
		pGifProcesser = NULL;
		return -1;
	}

	return dwRetID;
}

DWORD CUISendRichEdit::InsertImageImpl(CIMGifProcesser* pImageProcesser, DWORD dwUserID, bool bAutoScale)
{
	if (!pImageProcesser)
	{
		return -1;
	}

	// S_OK��ʼ���ɹ���S_FALSE�ظ���ʼ����RPC_E_CHANGED_MODE
	HRESULT hr = ::CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
	if (FAILED(hr))
	{
		return -1;
	}

	CComPtr<IRichEditOle> pReo;
	GetIRichEditOle(&pReo);
	if (!pReo)
	{
		return -1;
	}

	CComPtr<IOleClientSite> lpClientSite;
	pReo->GetClientSite(&lpClientSite);

	REOBJECT reobject;
	ZeroMemory(&reobject, sizeof(REOBJECT));
	reobject.cbStruct = sizeof(REOBJECT);

	HDC hDC = ::GetDC(m_hWndDirectUI);
	LONG xPerInch = GetDeviceCaps(hDC, LOGPIXELSX); 
	LONG yPerInch =	GetDeviceCaps(hDC, LOGPIXELSY); 
	::ReleaseDC(m_hWndDirectUI, hDC);

	LONG li_Width = 0;
	LONG li_Height = 0;
	SIZE szScale = pImageProcesser->GetSize();
	if (bAutoScale)
	{
		CRect rcClient = GetRect();
		LONG nClientHeight = rcClient.Height();
		ScaleSize(szScale, m_uUserDefPicMaxWidth, nClientHeight);

		li_Width = DXtoHimetricX(szScale.cx, xPerInch);
		li_Height = DYtoHimetricY(szScale.cy, yPerInch);
	}
	else
	{
		li_Width = DXtoHimetricX(szScale.cx, xPerInch);
		li_Height = DYtoHimetricY(szScale.cy, yPerInch);
	}

	//	reobject.clsid = clsid;
	reobject.cp = REO_CP_SELECTION;
	reobject.dvaspect = DVASPECT_CONTENT;
	reobject.poleobj = NULL;
	reobject.polesite = lpClientSite;
	reobject.pstg = NULL;
	reobject.sizel.cx = li_Width; 
	reobject.sizel.cy = li_Height;
	reobject.dwUser = AddOleData(pImageProcesser, dwUserID);
	if (m_bReadOnly)
	{
		reobject.dwFlags = REO_BELOWBASELINE;
	}

	if (pReo->InsertObject(&reobject) != S_OK)
	{
		RemoveOleData(reobject.dwUser);
	}
	else
	{
		pImageProcesser->Draw();
	}

	return reobject.dwUser;
}

void CUISendRichEdit::InsertContentBegin()
{
	if (!m_bInit) return;

	SetCanUpdateNow(false);
	SetEnableSetScrollPos(false);
}

void CUISendRichEdit::InsertContentEnd()
{
	if (!m_bInit) return;

	SetCanUpdateNow(true);
	SetEnableSetScrollPos(true);
	CaculOleParams();
	DirectRedraw2(NULL);
}

void CUISendRichEdit::InsertTopSpace()
{
}

int CUISendRichEdit::GetLineHeight(long lCharIndex)
{
	CPoint pt;
	pt = m_FreeWindowlessRE.PosFromChar(lCharIndex);

	long lIndex = LineFromChar(lCharIndex);
	if (lIndex == -1)
	{
		return 0;
	}

	CPoint ptNetxLineChar;
	int nNetxLineChar;
	// ���һ����Ҫ�������ַ����м���
	if (GetLineCount()-1 == lIndex)
	{
		return ptNetxLineChar.y;
	}
	else
	{
		nNetxLineChar = LineIndex(lIndex+1);
		ptNetxLineChar = m_FreeWindowlessRE.PosFromChar(nNetxLineChar);
	}

	return ptNetxLineChar.y - pt.y;
}

int CUISendRichEdit::GetImageTop(long lCharIndex, int nImageHeight)
{
	return GetLineBottom(lCharIndex) - nImageHeight;
}

int CUISendRichEdit::GetLineBottom(long lCharIndex)
{
	CPoint point = m_FreeWindowlessRE.PosFromChar(lCharIndex);

	long lIndex = LineFromChar(lCharIndex);

	if (lIndex != -1)
	{
		std::map<long, long>::iterator itHeight = m_vecOleLineHeight.find(lIndex);
		if (itHeight != m_vecOleLineHeight.end())
		{
			point.y += itHeight->second;
		}
	}

	return point.y;
}

void CUISendRichEdit::ClearOleDatas(UINT uResetCount/* = 0*/)
{
	RichOleMap::iterator it_ole = m_richOleMap.begin();
	for (; it_ole != m_richOleMap.end(); ++it_ole)
	{
		if (it_ole->second.pProcesser)
		{
			SAFE_DELETE(it_ole->second.pProcesser);
		}
	}
	m_richOleMap.clear();
}

void CUISendRichEdit::CaculOleParams()
{
	m_vecOleLineHeight.clear();

	CComPtr<IRichEditOle> pReo;
	GetIRichEditOle(&pReo);
	if(pReo == NULL)
	{
		return;
	}

	HDC hDC = ::GetDC(m_hWndDirectUI);
	if (NULL == hDC) return;
	LONG xPerInch = GetDeviceCaps(hDC, LOGPIXELSX); 
	LONG yPerInch =	GetDeviceCaps(hDC, LOGPIXELSY);
	::ReleaseDC(m_hWndDirectUI, hDC);

	long lCount = pReo->GetObjectCount();
	for (long i = 0; i < lCount; ++i)
	{
		REOBJECT reObject;
		memset(&reObject, 0, sizeof(REOBJECT));
		reObject.cbStruct = sizeof(REOBJECT);
		pReo->GetObject(i, &reObject, REO_GETOBJ_NO_INTERFACES);

		LONG li_Height = HimetricYtoDY(reObject.sizel.cy, yPerInch);

		long nLine = LineFromChar(reObject.cp);
		if (nLine == -1)
		{
			return;
		}

		std::map<long, long>::iterator it = m_vecOleLineHeight.find(nLine);
		if (it != m_vecOleLineHeight.end())
		{
			if (it->second < li_Height)
			{
				it->second = li_Height;
			}
		}
		else
		{
			m_vecOleLineHeight.insert(std::make_pair(nLine, li_Height));
		}
	}
}

void CUISendRichEdit::GetOneOleUpdateIndex(
	IRichEditOle* pReo, 
	REOBJECT& reObject, 
	LONG xPerInch,
	LONG yPerInch,
	RECT& rcClient, 
	int nAllCount, 
	int& nStart)
{
	nStart = 0;
	if (pReo && nAllCount > 0)
	{
		//�Ȳ鿴�ϴα���Ľ��, ��ֻ���������
		if (m_bReadOnly && m_nCurEndVisibleIndex >= 0 && m_nCurEndVisibleIndex < nAllCount)
		{
			memset(&reObject, 0, sizeof(REOBJECT));
			reObject.cbStruct = sizeof(REOBJECT);
			pReo->GetObject(m_nCurEndVisibleIndex, &reObject, REO_GETOBJ_NO_INTERFACES);
			CPoint pt = m_FreeWindowlessRE.PosFromChar(reObject.cp);

			LONG li_Width = HimetricXtoDX(reObject.sizel.cx, xPerInch);
			LONG li_Height = HimetricYtoDY(reObject.sizel.cy, yPerInch);

			if (m_bReadOnly)
			{
				pt.y = GetImageTop(reObject.cp, li_Height);
			}
			else
			{
				long lIndex = LineFromChar(reObject.cp);
				if (lIndex == -1)
				{
					nStart = 0;
					return;
				}

				std::map<long, long>::iterator itHeight = m_vecOleLineHeight.find(lIndex);
				if (itHeight != m_vecOleLineHeight.end())
				{
					if (itHeight->second > li_Height)
					{
						pt.y += itHeight->second - li_Height;
					}
				}
				else //���ݲ������¼���
				{
					CaculOleParams();

					nStart = 0;
					return;
				}
			}

			//ole�����ڵ�ǰ�ͻ�����
			if (pt.x < rcClient.right && pt.x + li_Width > rcClient.left && 
				pt.y <rcClient.bottom && pt.y + li_Height > rcClient.top)
			{
				nStart = m_nCurEndVisibleIndex;
				return;
			}
		}

		int nCurIndex = nAllCount - 1;
		while (nCurIndex >= 0)
		{
			memset(&reObject, 0, sizeof(REOBJECT));
			reObject.cbStruct = sizeof(REOBJECT);
			pReo->GetObject(nCurIndex, &reObject, REO_GETOBJ_NO_INTERFACES);
			CPoint pt;
			pt = m_FreeWindowlessRE.PosFromChar(reObject.cp);

			LONG li_Width = HimetricXtoDX(reObject.sizel.cx, xPerInch);
			LONG li_Height = HimetricYtoDY(reObject.sizel.cy, yPerInch);

			if (m_bReadOnly)
			{
				pt.y = GetImageTop(reObject.cp, li_Height);
			}
			else
			{
				long lIndex = LineFromChar(reObject.cp);
				if (lIndex == -1)
				{
					nStart = 0;
					return;
				}

				std::map<long, long>::iterator itHeight = m_vecOleLineHeight.find(lIndex);
				if (itHeight != m_vecOleLineHeight.end())
				{
					if (itHeight->second > li_Height)
					{
						pt.y += itHeight->second - li_Height;
					}
				}
				else //���ݲ������¼���
				{
					CaculOleParams();

					nStart = 0;
					return;
				}
			}

			//ole�����ڵ�ǰ�ͻ�����
			if (pt.x < rcClient.right && pt.x + li_Width > rcClient.left && 
				pt.y < rcClient.bottom && pt.y + li_Height > rcClient.top)
			{
				nStart = nCurIndex;
				return;
			}

			nCurIndex--;
		}
	}
}

bool CUISendRichEdit::GetOleObjPos(
								   IRichEditOle* pReo,
								   REOBJECT& reObject,
								   int OleObjIndex,
								   CPoint& ptOlePoint,
								   LONG xPerInch,
								   LONG yPerInch,
								   LONG& li_Width,
								   LONG& li_Height)
{
	ptOlePoint.x = ptOlePoint.y = 0;
	li_Width = li_Height = 0;

	if (!pReo) return false;

	memset(&reObject, 0, sizeof(REOBJECT));
	reObject.cbStruct = sizeof(REOBJECT);
	pReo->GetObject(OleObjIndex, &reObject, REO_GETOBJ_NO_INTERFACES);

	ptOlePoint = m_FreeWindowlessRE.PosFromChar(reObject.cp);

	li_Width = HimetricXtoDX(reObject.sizel.cx, xPerInch);
	li_Height = HimetricYtoDY(reObject.sizel.cy, yPerInch);

	ptOlePoint.y = GetImageTop(reObject.cp, li_Height);

	return true;
}

void CUISendRichEdit::GetContent(WTL::CString& strContent)
{
	long len = m_FreeWindowlessRE.GetTextLengthEx();
	LPTSTR pBuffer = strContent.GetBuffer(len+1);
	m_FreeWindowlessRE.GetTextEx(pBuffer, len+1);
	strContent.ReleaseBuffer();

	//�Ƴ�'r'��Χ����ʱ����'r'���ַ�����ʱ������, ���϶���
	strContent.Remove('\r');
}

void CUISendRichEdit::GetCharFormat(CHARFORMAT& charFormat, DWORD dwMask/* = CFM_COLOR | CFM_FACE | CFM_SIZE | CFM_BOLD | CFM_ITALIC | CFM_UNDERLINE*/)
{
	charFormat.cbSize = sizeof(CHARFORMAT);
	charFormat.dwMask = dwMask;
	GetSelectionCharFormat(charFormat);
}

void CUISendRichEdit::ReplaceSel(LPCTSTR lpszNewText, BOOL bCanUndo /* = FALSE */)
{
	if (!m_bInit)
		return;

	return m_FreeWindowlessRE.ReplaceSel(lpszNewText, bCanUndo);
}

void CUISendRichEdit::SetAutoParseEmotionByInput(bool bAutoParse)
{
	m_bParseEmotionByInput = bAutoParse;
}

HRESULT CUISendRichEdit::OnBorderPaint(WPARAM wParam, LPARAM lParam)
{
	if (!IsBorderVisible())
	{
		return 0;
	}

	HDC hDrawDC = (HDC)wParam;
	if (!hDrawDC)
	{
		return 0;
	}

	LPRECT lpUpdate = (LPRECT)lParam;
	if (!lpUpdate)
	{
		return 0;
	}

	//�ж��Ƿ���Ҫ����
	if (!CanUpdateNow())
	{
		return 0;
	}

	CRect rcClient = GetRect();
	long nScrollWidth = IsVisibleScrollBar(FALSE)?GetScrollSize():0;
	rcClient.right -= nScrollWidth;

	CRect rcControlPaint;
	if (!rcControlPaint.IntersectRect(&rcClient, lpUpdate))
	{
		return 0;
	}

	//���òü�����
	bool bNeedClip = true;
	if (::EqualRect(&rcControlPaint, &rcClient))
	{
		bNeedClip = false;
	}

	CRgn rgnOriginal;
	HRGN hClipRgn = NULL;
	int nSetRgnResult = -1;
	if (bNeedClip)
	{
		nSetRgnResult = ::GetClipRgn(hDrawDC, (HRGN)rgnOriginal);
		if (nSetRgnResult != -1)
		{
			hClipRgn = ::CreateRectRgn(rcControlPaint.left, rcControlPaint.top, rcControlPaint.right, rcControlPaint.bottom);
			::SelectClipRgn(hDrawDC, hClipRgn);
		}
	}

	//����
	if (m_pDrawBorderColor && m_pDrawBorderColor->GetValue2())
	{
		if (m_pColorBorder[m_eState])
		{
			GetStatePrivate();

			HDC hDCDraw = (HDC)wParam;
			CRect rcDraw = GetRect();

			OLE_COLOR clrColor = m_pColorBorder[m_eState]->GetValue();
			COLORREF colorBorder;
			::OleTranslateColor(clrColor,NULL,&colorBorder);

			Graphics graphics((HDC)(hDCDraw));
			Pen clrPen(Color(GetRValue(colorBorder),GetGValue(colorBorder),GetBValue(colorBorder)));
			graphics.DrawRectangle(&clrPen,rcDraw.left,rcDraw.top,rcDraw.Width()-1,rcDraw.Height()-1);
		}
	}
	else
	{
		if (m_pImgBorder[m_eState])
		{
			HDC hDCDraw = (HDC)wParam;
			CRect rcDraw = GetRect();
			m_pImgBorder[m_eState]->Draw(hDCDraw, rcDraw);
		}
	}

	//��ԭ�ü�����
	if (bNeedClip)
	{
		switch (nSetRgnResult)
		{
		case 0: //ԭ��û�вü�����
			::SelectClipRgn(hDrawDC, NULL);
			break;
		case 1: //ԭ���ɲü�����
			::SelectClipRgn(hDrawDC, (HRGN)rgnOriginal);
			break;
		default:
			break;
		}
		if (hClipRgn)
		{
			::DeleteObject(hClipRgn);
		}
	}

	return 0;
}

HRESULT CUISendRichEdit::OnContentPaint(WPARAM wParam, LPARAM lParam)
{
	HDC hDrawDC = (HDC)wParam;
	if (!hDrawDC)
	{
		return 0;
	}

	LPRECT lpUpdate = (LPRECT)lParam;
	if (!lpUpdate)
	{
		return 0;
	}

	if (!CanUpdateNow())
	{
		return 0;
	}

	//�ж��Ƿ���Ҫ����
	RECT rcDUI = GetRenderRect();
	CRect rcClient = CRect(rcDUI.left, rcDUI.top, rcDUI.right, rcDUI.bottom);
	long nScrollWidth = IsVisibleScrollBar(FALSE)?GetScrollSize():0;
	rcClient.right -= nScrollWidth;

	CRect rcControlPaint;
	if (!rcControlPaint.IntersectRect(&rcClient, lpUpdate))
	{
		return FALSE;
	}

	//���òü�����
	CRgn rgnOriginal;
	int nSetRgnResult = ::GetClipRgn(hDrawDC, (HRGN)rgnOriginal);
	if (nSetRgnResult != -1)
	{
		RECT rcUpdateClient;
		::IntersectRect(&rcUpdateClient, &rcControlPaint, &rcClient);

		if (m_hClipRgn)
		{
			CRect rcClip(0, 0, 0, 0);
			::GetRgnBox(m_hClipRgn, &rcClip);
			if (!::EqualRect(&rcUpdateClient, &rcClip))
			{
				::DeleteObject(m_hClipRgn);
				m_hClipRgn = NULL;
			}
		}

		if (!m_hClipRgn)
		{
			m_hClipRgn = ::CreateRectRgn(rcUpdateClient.left, rcUpdateClient.top, rcUpdateClient.right, rcUpdateClient.bottom);
		}
		::SelectClipRgn(hDrawDC, m_hClipRgn);
	}

	//��������
	m_FreeWindowlessRE.WindowlessREProc(WM_PAINT, (WPARAM)hDrawDC, (LPARAM)&rcControlPaint);

	//��ԭ�ü�����
	switch (nSetRgnResult)
	{
	case 0: //ԭ��û�вü�����
		{
			::SelectClipRgn(hDrawDC, NULL);
		}
		break;
	case 1: //ԭ���вü�����
		{
			::SelectClipRgn(hDrawDC, (HRGN)rgnOriginal);
		}
		break;
	default:
		break;
	}

	return 0;
}

LRESULT CUISendRichEdit::OnOlePaint(WPARAM wParam, LPARAM lParam)
{
	if (!m_bInit) return -1;

	CComPtr<IRichEditOle> pReo;
	GetIRichEditOle(&pReo);
	if(pReo == NULL)
	{
		return -1;
	}

	CHARRANGE charrange;
	m_FreeWindowlessRE.GetSel(charrange);

	HDC hDC = (HDC)wParam;

	CRect rcUpdate = CRect((RECT*)lParam);
	CRect rcDUI = GetRenderRect();
	if (IsVisibleScrollBar(FALSE))
	{
		long nScrollBarWidth = GetScrollSize();
		rcDUI.right -= nScrollBarWidth;
	}

	bool bOleVisible = false;
	LONG xPerInch = GetDeviceCaps(hDC, LOGPIXELSX); 
	LONG yPerInch =	GetDeviceCaps(hDC, LOGPIXELSY);

	int nCount = pReo->GetObjectCount();
	bool bInClientRc = false;
	bool bInUpdateRc = false;
	int nEndIndex = 0;
	REOBJECT reObject;
	GetOneOleUpdateIndex(pReo, reObject, xPerInch, yPerInch, rcDUI, nCount, nEndIndex);

	//���ϼ�����ƶ���
	RECT rcPaint, rcClip;
	memset(&rcPaint, 0, sizeof(rcPaint));
	memset(&rcClip, 0, sizeof(rcClip));
	bool bHasMatched = false;
	bool bResultPlayAni = false;
	UINT uAniTick = 0;
	for (int i = nEndIndex; i >= 0; i--)
	{
		memset(&reObject, 0, sizeof(REOBJECT));
		reObject.cbStruct = sizeof(REOBJECT);
		pReo->GetObject(i, &reObject, REO_GETOBJ_NO_INTERFACES);
		CPoint pt;
		pt = m_FreeWindowlessRE.PosFromChar(reObject.cp);

		LONG li_Width = HimetricXtoDX(reObject.sizel.cx, xPerInch);
		LONG li_Height = HimetricYtoDY(reObject.sizel.cy, yPerInch);

		if (m_bReadOnly)
		{
			pt.y = GetImageTop(reObject.cp, li_Height);
		}
		else
		{
			long lIndex = LineFromChar(reObject.cp);
			if (lIndex == -1)
			{
				return -1;
			}

			std::map<long, long>::iterator itHeight = m_vecOleLineHeight.find(lIndex);
			if (itHeight != m_vecOleLineHeight.end())
			{
				if (itHeight->second > li_Height)
				{
					pt.y += itHeight->second - li_Height;
				}
			}
			else	// ���ݲ������¼���
			{
				CaculOleParams();
				return 0;
			}
		}

		//ole��������Ч��������
		if (pt.x < rcUpdate.right && pt.x + li_Width > rcUpdate.left && 
			pt.y < rcUpdate.bottom  && pt.y + li_Height > rcUpdate.top)
		{
			bInUpdateRc = true;
		}
		else
		{
			bInUpdateRc = false;
		}

		//ole�����ڵ�ǰ�ͻ�����
		if (pt.x < rcDUI.right && pt.x + li_Width > rcDUI.left && 
			pt.y < rcDUI.bottom && pt.y + li_Height > rcDUI.top)
		{
			bInClientRc = true;
		}
		else
		{
			bInClientRc = false;
		}

		if (!bInClientRc)
		{
			//���ö��������д��ڿɼ����������ϼ���
			if (bHasMatched && 
				(pt.y == rcPaint.top || pt.y + li_Height == rcPaint.bottom))
			{
				//do nothing
			}
			else
			{
				break;
			}
		}


		IOleProcesser* pOleProcesser = GetOleProcesser(reObject.dwUser);
		if (!pOleProcesser)
		{
			continue;
		}

		//����ole����ɼ�״̬
		pOleProcesser->SetVisibleInside(bInClientRc ? TRUE : FALSE);

		if (bInUpdateRc || bInClientRc)
		{
			bHasMatched = true;

			rcPaint.left = pt.x;
			rcPaint.right = pt.x + li_Width;
			rcPaint.top = pt.y;
			rcPaint.bottom = pt.y + li_Height;

			bool bNeedClip = false;
			if (rcPaint.left < rcDUI.left || rcPaint.right > rcDUI.right ||
				rcPaint.top < rcDUI.top || rcPaint.bottom > rcDUI.bottom)
			{
				bNeedClip = true;
				rcClip.left = max(rcPaint.left, rcDUI.left);
				rcClip.right = min(rcPaint.right, rcDUI.right);
				rcClip.top = max(rcPaint.top, rcDUI.top);
				rcClip.bottom = min(rcPaint.bottom, rcDUI.bottom);
			}

			//��¼���һ���ɼ�ole����
			m_nCurEndVisibleIndex = i;

			//�����鴦��ѡ������,��ԭ������������ı���ɫ(����ole����������·�ѡ)
			if (charrange.cpMax - charrange.cpMin > 1)
			{
				if (reObject.cp >= charrange.cpMin
					&& reObject.cp < charrange.cpMax)
				{
					::InvertRect(hDC, bNeedClip?&rcClip:&rcPaint);
				}
			}

			//���Ʊ���
			pOleProcesser->OnPaint(hDC, &rcPaint, bResultPlayAni, uAniTick, bNeedClip?&rcClip:NULL, false);

			//�����鴦��ѡ������,��ѡ������������
			if (1 == charrange.cpMax - charrange.cpMin)
			{
				if (reObject.cp == charrange.cpMin)
				{
					if (bNeedClip)
					{
						HPEN hPen = ::CreatePen(PS_ALTERNATE|PS_COSMETIC, 1, 0);
						HPEN hOldPen = (HPEN)::SelectObject(hDC, hPen);

						//���Ͻ�--->���Ͻ�
						if (rcClip.top > rcDUI.top)
						{
							::MoveToEx(hDC, max(rcClip.left,rcDUI.left), rcClip.top, NULL);
							::LineTo(hDC, min(rcClip.right,rcDUI.right), rcClip.top);
						}

						//���Ͻ�--->���½�
						if (rcClip.right < rcDUI.right)
						{
							::MoveToEx(hDC, rcClip.right, max(rcClip.top,rcDUI.top), NULL);
							::LineTo(hDC, rcClip.right, min(rcClip.bottom,rcDUI.bottom));
						}

						//���½�--->���½�
						if (rcClip.bottom < rcDUI.bottom)
						{
							::MoveToEx(hDC, min(rcClip.right, rcDUI.right), rcClip.bottom, NULL);
							::LineTo(hDC, max(rcClip.left, rcDUI.left), rcClip.bottom);
						}

						//���½�--->���Ͻ�
						if (rcClip.left >= rcDUI.left)
						{
							::MoveToEx(hDC, rcClip.left, min(rcClip.bottom,rcDUI.bottom), NULL);
							::LineTo(hDC, rcClip.left, max(rcClip.top,rcDUI.top));
						}

						::SelectObject(hDC, hOldPen);
						::DeleteObject(hPen);
					}
					else
					{
						HBRUSH hbrush = ::CreateSolidBrush(0);
						::FrameRect(hDC, &rcPaint, hbrush);
						::DeleteObject(hbrush);
					}
				}
			}
			else if (charrange.cpMax - charrange.cpMin > 1)
			{
				if (reObject.cp >= charrange.cpMin
					&& reObject.cp < charrange.cpMax)
				{
					::InvertRect(hDC, bNeedClip?&rcClip:&rcPaint);
				}
			}
		}
	}

	//���¼�����ƶ���
	bHasMatched = false;
	memset(&rcPaint, 0, sizeof(rcPaint));
	memset(&rcClip, 0, sizeof(rcClip));
	for (int i = nEndIndex + 1; i < nCount; i++)
	{
		memset(&reObject, 0, sizeof(REOBJECT));
		reObject.cbStruct = sizeof(REOBJECT);
		pReo->GetObject(i, &reObject, REO_GETOBJ_NO_INTERFACES);
		CPoint pt;
		pt = m_FreeWindowlessRE.PosFromChar(reObject.cp);

		LONG li_Width = HimetricXtoDX(reObject.sizel.cx, xPerInch);
		LONG li_Height = HimetricYtoDY(reObject.sizel.cy, yPerInch);

		if (m_bReadOnly)
		{
			pt.y = GetImageTop(reObject.cp, li_Height);
		}
		else
		{
			long lIndex = LineFromChar(reObject.cp);
			if (lIndex == -1)
			{
				return -1;
			}

			std::map<long, long>::iterator itHeight = m_vecOleLineHeight.find(lIndex);
			if (itHeight != m_vecOleLineHeight.end())
			{
				if (itHeight->second > li_Height)
				{
					pt.y += itHeight->second - li_Height;
				}
			}
			else	// ���ݲ������¼���
			{
				CaculOleParams();
				return 0;
			}
		}

		//ole��������Ч��������
		if (pt.x < rcUpdate.right && pt.x + li_Width > rcUpdate.left && 
			pt.y < rcUpdate.bottom  && pt.y + li_Height > rcUpdate.top)
		{
			bInUpdateRc = true;
		}
		else
		{
			bInUpdateRc = false;
		}

		//ole�����ڵ�ǰ�ͻ�����
		if (pt.x < rcDUI.right && pt.x + li_Width > rcDUI.left && 
			pt.y < rcDUI.bottom && pt.y + li_Height > rcDUI.top)
		{
			bInClientRc = true;
		}
		else
		{
			bInClientRc = false;
		}

		if (!bInClientRc)
		{
			//���ö��������д��ڿɼ����������ϼ���
			if (bHasMatched && 
				(pt.y == rcPaint.top || pt.y + li_Height == rcPaint.bottom))
			{
				//do nothing
			}
			else
			{
				break;
			}
		}

		IOleProcesser* pOleProcesser = GetOleProcesser(reObject.dwUser);
		if (!pOleProcesser)
		{
			continue;
		}

		//����ole����ɼ�״̬
		pOleProcesser->SetVisibleInside(bInClientRc ? TRUE : FALSE);

		if (bInUpdateRc || bInClientRc)
		{
			bHasMatched = true;

			rcPaint.left = pt.x;
			rcPaint.right = pt.x + li_Width;
			rcPaint.top = pt.y;
			rcPaint.bottom = pt.y + li_Height;

			bool bNeedClip = false;
			if (rcPaint.left < rcDUI.left || rcPaint.right > rcDUI.right ||
				rcPaint.top < rcDUI.top || rcPaint.bottom > rcDUI.bottom)
			{
				bNeedClip = true;
				rcClip.left = max(rcPaint.left, rcDUI.left);
				rcClip.right = min(rcPaint.right, rcDUI.right);
				rcClip.top = max(rcPaint.top, rcDUI.top);
				rcClip.bottom = min(rcPaint.bottom, rcDUI.bottom);
			}

			//��¼���һ���ɼ�ole����
			m_nCurEndVisibleIndex = i;

			//�����鴦��ѡ������,��ԭ������������ı���ɫ(����ole����������·�ѡ)
			if (charrange.cpMax - charrange.cpMin > 1)
			{
				if (reObject.cp >= charrange.cpMin
					&& reObject.cp < charrange.cpMax)
				{
					::InvertRect(hDC, bNeedClip?&rcClip:&rcPaint);
				}
			}

			//���Ʊ���
			pOleProcesser->OnPaint(hDC, &rcPaint, bResultPlayAni, uAniTick, bNeedClip?&rcClip:NULL, false);

			//�����鴦��ѡ������,��ѡ������������
			if (1 == charrange.cpMax - charrange.cpMin)
			{
				if (reObject.cp == charrange.cpMin)
				{
					if (bNeedClip)
					{
						HPEN hPen = ::CreatePen(PS_ALTERNATE|PS_COSMETIC, 1, 0);
						HPEN hOldPen = (HPEN)::SelectObject(hDC, hPen);

						//���Ͻ�--->���Ͻ�
						if (rcClip.top > rcDUI.top)
						{
							::MoveToEx(hDC, max(rcClip.left,rcDUI.left), rcClip.top, NULL);
							::LineTo(hDC, min(rcClip.right,rcDUI.right), rcClip.top);
						}

						//���Ͻ�--->���½�
						if (rcClip.right < rcDUI.right)
						{
							::MoveToEx(hDC, rcClip.right, max(rcClip.top,rcDUI.top), NULL);
							::LineTo(hDC, rcClip.right, min(rcClip.bottom,rcDUI.bottom));
						}

						//���½�--->���½�
						if (rcClip.bottom < rcDUI.bottom)
						{
							::MoveToEx(hDC, min(rcClip.right, rcDUI.right), rcClip.bottom, NULL);
							::LineTo(hDC, max(rcClip.left, rcDUI.left), rcClip.bottom);
						}

						//���½�--->���Ͻ�
						if (rcClip.left >= rcDUI.left)
						{
							::MoveToEx(hDC, rcClip.left, min(rcClip.bottom,rcDUI.bottom), NULL);
							::LineTo(hDC, rcClip.left, max(rcClip.top,rcDUI.top));
						}

						::SelectObject(hDC, hOldPen);
						::DeleteObject(hPen);
					}
					else
					{
						HBRUSH hbrush = ::CreateSolidBrush(0);
						::FrameRect(hDC, &rcPaint, hbrush);
						::DeleteObject(hbrush);
					}
				}
			}
			else if (charrange.cpMax - charrange.cpMin > 1)
			{
				if (reObject.cp >= charrange.cpMin
					&& reObject.cp < charrange.cpMax)
				{
					::InvertRect(hDC, bNeedClip?&rcClip:&rcPaint);
				}
			}
		}
	}

	//���ø���ole����ɼ�״̬
	RichOleMap::iterator it_ole = m_richOleMap.begin();
	for (; it_ole != m_richOleMap.end(); ++it_ole)
	{
		if (it_ole->second.pProcesser)
		{
			it_ole->second.pProcesser->SyncVisible();
		}
	}

	m_bPainting = false;

	return S_OK;
}

LRESULT CUISendRichEdit::OnGetClipBoardData(WPARAM wParam, LPARAM lParam)
{
	stClipBoardData* pData = (stClipBoardData*)wParam;
	if (!pData)
	{
		return -1;
	}

	switch(pData->m_reco)
	{
	case RECO_CUT:
	case RECO_COPY:
		{
			//�ڶ�ջ���������ռ�, ������COM����, ���ﲻ�е��ͷŹ���, ������detach�ö���ʱ���Զ�����release�ӿ�
			IDataObject* pDataObject = NULL;
			CreateOleDataObject(m_fmtetc, m_stgmed, 4, &pDataObject);

			if (GetAsyncKeyState(VK_LBUTTON) & 0x8000) // ��ק
			{
				if (OnCopy(pDataObject, *(pData->m_lpchrg), false))
				{
					*pData->m_lplpdataobj = (LPDATAOBJECT)pDataObject;
				}
			}
			else
			{
				CHARRANGE cr;
				GetSel(cr);
				OnCopy(pDataObject, cr);
			}
			return 0;
		}
		break;
	default:
		break;
	}

	return 0;
}

LRESULT CUISendRichEdit::OnQueryAccpetData(WPARAM wParam, LPARAM lParam)
{
	stAccpetData* pData = (stAccpetData*)wParam;
	if (!pData)
	{
		return -1;
	}

	switch(pData->m_reco)
	{
	case RECO_DROP:
		OnPaste(pData->m_lpdataobj, pData->m_lpcformat, false);
		return 0;
	case RECO_PASTE:
		OnPaste(pData->m_lpdataobj, pData->m_lpcformat, true);
		return 0;
	}

	return 0;
}

LRESULT CUISendRichEdit::OnRButtonUp(int nFlags, CPoint pt)
{
	if (OnHitTestOleControl(WM_RBUTTONUP, pt))
	{
		return 0;
	}

	if (NULL == m_pPopupMenu)
	{
		m_pPopupMenu = (CUIPopupMenuCom*) (GetDUIRes()->GetResObject(DUIControlType_PopupMenu, _T("PopMenuEdit"), NULL, TRUE));
	}

	if (m_pPopupMenu)
	{
		CPoint ptMenu = pt;
		::ClientToScreen(m_hWndDirectUI,&ptMenu);
		m_pPopupMenu->RemoveAllMenu();

		int nOverChar = CharFromPos(pt) - 1;
		if (nOverChar >= 0 && TestClickOnImage(pt))
		{
			CHARRANGE cr;
			cr.cpMin = nOverChar;
			cr.cpMax = nOverChar + 1;
			GetSendImagePath(cr);

			m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_CUT,_T("MenuCommon_Cut"),_T("MenuCommon_Cut"),-1,MENUITEMSTYLE_NORMAL,FALSE,TRUE);
			m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_COPY,_T("MenuCommon_Copy"),_T("MenuCommon_Copy"),-1,MENUITEMSTYLE_NORMAL,FALSE,TRUE);
			m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_PASTE,_T("MenuCommon_Paste"),_T("MenuCommon_Paste"),-1,MENUITEMSTYLE_NORMAL,FALSE,TRUE);
			m_pPopupMenu->AppendMenu2(-1,_T(""),_T(""),-1,MENUITEMSTYLE_SEPARATOR,FALSE,TRUE);
			m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_SAVE_AS,_T("MenuCommon_SaveAs"),_T("MenuCommon_SaveAs"),-1,MENUITEMSTYLE_NORMAL,FALSE,TRUE);
			//m_pPopupMenu->AppendMenu2(ID_MENU_EDIT_ADD_TO_FACE,_T("���ӵ�����"),_T("���ӵ�����"),-1,MENUITEMSTYLE_NORMAL,FALSE,TRUE);
			m_pPopupMenu->AppendMenu2(-2,_T(""),_T(""),-1,MENUITEMSTYLE_SEPARATOR,FALSE,TRUE);
			m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_SEL_ALL,_T("MenuCommon_SelAll"),_T("MenuCommon_SelAll"),-1,MENUITEMSTYLE_NORMAL,FALSE,TRUE);

			//CHARRANGE cr;
			//GetSel(cr);
			//if (GetSendImagePath(cr))
			//{
			//m_pPopupMenu->EnableMenuItem(ID_MENU_EDIT_ADD_TO_FACE,FALSE,FALSE);
			//}
		}
		else
		{
			m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_UNDO,_T("MenuCommon_Undo"),_T("MenuCommon_Undo"),-1,MENUITEMSTYLE_NORMAL,FALSE,TRUE);
			m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_REDO,_T("MenuCommon_Redo"),_T("MenuCommon_Redo"),-1,MENUITEMSTYLE_NORMAL,FALSE,TRUE);
			m_pPopupMenu->AppendMenuByTextCaption(-1,_T(""),_T(""),-1,MENUITEMSTYLE_SEPARATOR,FALSE,TRUE);
			m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_CUT,_T("MenuCommon_Cut"),_T("MenuCommon_Cut"),-1,MENUITEMSTYLE_NORMAL,FALSE,TRUE);
			m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_COPY,_T("MenuCommon_Copy"),_T("MenuCommon_Copy"),-1,MENUITEMSTYLE_NORMAL,FALSE,TRUE);
			m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_PASTE,_T("MenuCommon_Paste"),_T("MenuCommon_Paste"),-1,MENUITEMSTYLE_NORMAL,FALSE,TRUE);
			m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_CLEAR,_T("MenuCommon_Clear"),_T("MenuCommon_Clear"),-1,MENUITEMSTYLE_NORMAL,FALSE,TRUE);
			m_pPopupMenu->AppendMenuByTextCaption(-2,_T(""),_T(""),-1,MENUITEMSTYLE_SEPARATOR,FALSE,TRUE);
			m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_SEL_ALL,_T("MenuCommon_SelAll"),_T("MenuCommon_SelAll"),-1,MENUITEMSTYLE_NORMAL,FALSE,TRUE);

			BOOL bUndo=CanUndo();
			m_pPopupMenu->EnableMenuItem(ID_MENU_EDIT_UNDO,FALSE,bUndo);

			BOOL bRedo=CanRedo();
			m_pPopupMenu->EnableMenuItem(ID_MENU_EDIT_REDO,FALSE,bRedo);

			BOOL bSel=((GetSelectionType() != SEL_EMPTY) ? TRUE : FALSE) ;
			m_pPopupMenu->EnableMenuItem(ID_MENU_EDIT_CUT,FALSE,bSel);
			m_pPopupMenu->EnableMenuItem(ID_MENU_EDIT_COPY,FALSE,bSel);

			BOOL bCanPaste = FALSE;
			if (CanPaste(CF_UNICODETEXT) || CanPaste(CF_BITMAP) || 
				CanPaste(CF_DIB) || CanPaste(CF_METAFILEPICT) || 
				CanPaste(m_nfmtSysFaceID) || CanPaste(m_nfmtHtmlID))
			{
				bCanPaste = TRUE;
			}
			if (!bCanPaste)
			{
				if (::IsClipboardFormatAvailable(m_nfmtSysFaceID) ||
					::IsClipboardFormatAvailable(m_nfmtHtmlID) || 
					::IsClipboardFormatAvailable(CF_BITMAP) || 
					::IsClipboardFormatAvailable(CF_DIB) || 
					::IsClipboardFormatAvailable(CF_METAFILEPICT) || 
					::IsClipboardFormatAvailable(CF_UNICODETEXT) || 
					::IsClipboardFormatAvailable(CF_HDROP))
				{
					bCanPaste = TRUE;
				}
			}
			m_pPopupMenu->EnableMenuItem(ID_MENU_EDIT_PASTE,FALSE,bCanPaste);
		}

		m_pPopupMenu->TrackPopupMenu(DUI_TPM_LEFTALIGN,(SHORT)ptMenu.x,(SHORT)ptMenu.y,m_hWndDirectUI,this);
	}

	return 0;
}

LRESULT CUISendRichEdit::OnLButtonDown(int nFlags, CPoint pt)
{
	int nHitTest = -1;

	if (OnHitTestOleControl(WM_LBUTTONDOWN, pt))
	{
		nHitTest = 0;
		SetLButtonDownHitOleControl(TRUE);
	}
	else
	{
		SetLButtonDownHitOleControl(FALSE);
	}

	return nHitTest;
}

LRESULT CUISendRichEdit::OnLButtonUp(int nFlags, CPoint pt)
{
	if (IsLButtonDownHitOleControl() && OnHitTestOleControl(WM_LBUTTONUP, pt))
	{
		return 0;
	}

	return -1;
}

LRESULT CUISendRichEdit::OnLButtonDbClick(int nFlags, CPoint pt)
{
	if (!TestClickOnImage(pt))
	{
		return -1;
	}

	CHARRANGE cr;
	GetSel(cr);
	GetSendImagePath(cr);

	DUICtrlNotifyInfo duiNotifyInfo;
	memset(&duiNotifyInfo, 0, sizeof(DUICtrlNotifyInfo));
	duiNotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_VIEW_IMAGE;
	duiNotifyInfo.lParam1 = (DWORD_PTR)(this);
	duiNotifyInfo.lParam2 = (DWORD_PTR)m_imgProcessData.bSysFace ? 1 : 0;
	if (m_imgProcessData.bSysFace)
	{
		int nIndex = m_imgProcessData.strImagePath.Find(_T("eim_sysFace_"));
		if (nIndex != -1)
		{
			DWORD dwFaceID = _tcstoul(m_imgProcessData.strImagePath.Mid(nIndex+12, m_imgProcessData.strImagePath.GetLength()-1), 0, 10);
			duiNotifyInfo.lParam3 = (DWORD_PTR)dwFaceID;
		}
		else
		{
			duiNotifyInfo.lParam3 = (DWORD_PTR)0;
		}
	}
	else
	{
		duiNotifyInfo.lParam3 = (DWORD_PTR)(LPCTSTR)m_imgProcessData.strImagePath;
		duiNotifyInfo.lParam4 = (DWORD_PTR)(LPCTSTR)m_imgProcessData.strImageURL;
	}
	::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&duiNotifyInfo, 0);

	return 0;
}

LRESULT CUISendRichEdit::OnMenuCommond(UINT nID)
{
	switch(nID)
	{
	case ID_MENU_EDIT_CUT:
		{
			OnMenuCut();
		}
		break;
	case ID_MENU_EDIT_COPY:
		{
			OnMenuCopy();
		}
		break;
	case ID_MENU_EDIT_PASTE:
		{
			OnMenuPaste();
		}
		break;
	case ID_MENU_EDIT_SEL_ALL:
		{
			OnMenuSelAll();
		}
		break;
	case ID_MENU_EDIT_UNDO:
		{
			OnMenuUnDo();
		}
		break;
	case ID_MENU_EDIT_REDO:
		{
			OnMenuReDo();
		}
		break;
	case ID_MENU_EDIT_CLEAR:
		{
			OnMenuClear();
		}
		break;
	case ID_MENU_EDIT_SAVE_AS:
		{
			OnMenuSaveAs();
		}
		break;
	case ID_MENU_EDIT_ADD_TO_FACE:
		{
			OnMenuAddFace();
		}
		break;
	default:
		break;
	}
	return 0;
}

LRESULT CUISendRichEdit::OnMouseMove(UINT nFlags, CPoint point)
{
	if (this->IsLButtonDowned() && !IsLButtonDownHitOleControl())
	{
		return -1;
	}

	///////////////////////////////////////////////////////////
	//����OleControl����
	BOOL bHitOleControl = FALSE;
	if (OnHitTestOleControl(WM_MOUSEMOVE, point))
	{
		bHitOleControl = TRUE;
	}

	///////////////////////////////////////////////////////////
	//��ʾ����������ʾ
	if (!m_bShowFaceTip)
	{
		return -1;
	}

	int nOverChar = CharFromPos(point) - 1;
	if (nOverChar == m_nlastOverImageChar && nOverChar != -1)
	{
		return -1;
	}
	if (-1 == nOverChar)
	{
		m_nlastOverImageChar = nOverChar;
		return -1;
	}

	CRect rcImage;
	rcImage.SetRectEmpty();
	if (TestClickOnImage(point,&rcImage))
	{
		CHARRANGE cr;
		cr.cpMin = nOverChar;
		cr.cpMax = nOverChar + 1;
		GetSendImagePath(cr);

		DUICtrlNotifyInfo UINotifyInfo;
		memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
		UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_PIC_OP_TIPS;
		UINotifyInfo.lParam1 = (DWORD_PTR)(this);
		UINotifyInfo.lParam2 = (DWORD_PTR)0; //��ʾ������ʾ
		UINotifyInfo.lParam3 = (DWORD_PTR)&rcImage;
		UINotifyInfo.lParam4 = (DWORD_PTR)m_imgProcessData.bSysFace ? 1 : 0;
		if(m_imgProcessData.bSysFace)
		{
			int nIndex = m_imgProcessData.strImagePath.Find(_T("eim_sysFace_"));
			if (nIndex != -1)
			{
				DWORD dwFaceID = _tcstoul(m_imgProcessData.strImagePath.Mid(nIndex+12, m_imgProcessData.strImagePath.GetLength()-1), 0, 10);
				UINotifyInfo.lParam5 = (DWORD_PTR)dwFaceID;
			}
			else
			{
				UINotifyInfo.lParam5 = (DWORD_PTR)0;
			}
		}
		else
		{
			UINotifyInfo.lParam5 = (DWORD_PTR)(LPCTSTR)m_imgProcessData.strImagePath;
			UINotifyInfo.lParam6 = (DWORD_PTR)(LPCTSTR)m_imgProcessData.strImageURL;
		}

		::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);

		m_nlastOverImageChar = nOverChar;
		if (GetDirectUI())
		{
			m_nIDTPicTips = GetDirectUI()->SetTimer(this,500,NULL);
		}
	}

	return bHitOleControl ? 0 : -1;
}

LRESULT CUISendRichEdit::OnEnChange()
{
	if (CanUpdateNow())
	{
		CaculOleParams();
	}

	//������������
	if (m_bLimitByCharRule)
	{
		WTL::CString strContent;
		GetContent(strContent);

		long lLimitNum = GetLimitText();
		int nContentLen = strContent.GetLength();
		if (nContentLen * 2 > lLimitNum)
		{
			CHARRANGE rgSel;
			GetSel(rgSel);

			int nCurNum = 0;
			int nRetLen = 0;
			LPTSTR lpContent = strContent.GetBuffer(-1);
			for (int i = 0;  i < nContentLen && nCurNum < lLimitNum; ++i)
			{
#ifdef _UNICODE
				int nHitLen = WideCharToMultiByte(CP_UTF8, NULL, 
					(LPCTSTR)&lpContent[i], 1, NULL, 0,NULL,FALSE);
#else
				int nHitLen = 1;
#endif
				if (nHitLen > 1)
				{
					nCurNum += 2;
				}
				else
				{
					nCurNum += 1;
				}

				if (nCurNum <= lLimitNum)
				{
					nRetLen += 1;
				}
			}

			if (nRetLen > nContentLen)
			{
				nRetLen = nContentLen;
			}

			WTL::CString strNewContent = strContent.Mid(0, nRetLen);
			SetContent(strNewContent);

			if (rgSel.cpMax > nRetLen)
			{
				rgSel.cpMax = nRetLen;
			}
			if (rgSel.cpMin > nRetLen)
			{
				rgSel.cpMin = nRetLen;
			}
			SetSel(rgSel, false);
		}
	}

	//���ñ仯�����ݵ�������ʽ
	SetCharFormat(m_curCharFormat);

	//�������Ӧ����
	CheckAutoSize();

	//֪ͨӦ�ò�EnChange�¼�
	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_EN_CHANGE;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);

	return 0;
}

LRESULT CUISendRichEdit::OnEnUpdate()
{
	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_EN_UPDATE;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);

	return 0;
}

void CUISendRichEdit::OnMenuCut()
{
	OnMenuCopy();
	ReplaceSel(_T(""));
}

void CUISendRichEdit::OnMenuCopy()
{
	OnRichEditMsgProc(WM_COPY, 0, 0);
}

void CUISendRichEdit::OnMenuPaste()
{
	OnRichEditMsgProc(WM_PASTE, 0, 0);
}

void CUISendRichEdit::OnMenuReDo()
{
	Redo();
}

void CUISendRichEdit::OnMenuUnDo()
{
	Undo();
}

void CUISendRichEdit::OnMenuSelAll() 
{ 
	SetSel(0, -1, false); 
}

void CUISendRichEdit::OnMenuClear()  
{ 
	SetSel(0, -1, false); 
	Clear();
}

void CUISendRichEdit::OnMenuSaveAs()
{
	SaveImageAs();
}

void CUISendRichEdit::OnMenuAddFace()
{
	AddImageToMgr();
}

bool CUISendRichEdit::OnCopy(IDataObject* pOleDataSource, CHARRANGE& cr, bool bCopyToClipBoard)
{
	WTL::CString strUBB = _T("");
	bool bHaseImage = GetEncodeUBB(strUBB, cr.cpMin, cr.cpMax, false, false, false, true);

	if (bHaseImage)
	{
		/******************************Ole˽�м��а�**************************************/
		DoCopyInfo(pOleDataSource, strUBB);

		/**********************************��ͳ���а�**************************************/
		std::string strHtml = "";
		WTL::CString strUniText = _T("");
		GetClipBoardUBB(strHtml, strUniText, cr.cpMin, cr.cpMax);

		int nDataCount = strHtml.length() + 1;
		int nDataSize = nDataCount * sizeof(BYTE);

		HGLOBAL hText = ::GlobalAlloc(GMEM_NODISCARD, nDataSize);
		if (hText)
		{
			LPVOID pData = ::GlobalLock(hText);
			if (pData)
			{
				memset(pData, 0, nDataSize);
				strncpy((LPSTR)pData, strHtml.c_str(), nDataCount);
				::GlobalUnlock(hText);
			}
		}

		m_stgmed[2].hGlobal = hText;
		pOleDataSource->SetData(&(m_fmtetc[2]), &(m_stgmed[2]), FALSE);

		//ʹ�ú�, ��չ�������
		::GlobalFree(m_stgmed[2].hGlobal);
		m_stgmed[2].hGlobal = NULL;

		/**********************************��������,Ϊ�����ı�**************************************/
		// С�ڿ�͸�ʽ����
		strUniText.Replace(_T("\n"), _T("\r\n"));
		nDataSize = (strUniText.GetLength()+1) * sizeof(TCHAR); 

		hText = ::GlobalAlloc(GMEM_NODISCARD, nDataSize);
		if (hText)
		{
			LPVOID pData = ::GlobalLock(hText);
			if (pData)
			{
				memset(pData, 0, nDataSize);
				_tcsncpy((TCHAR*)pData, strUniText, strUniText.GetLength()+1);
				::GlobalUnlock(hText);
			}
		}

		m_stgmed[3].hGlobal = hText;
		pOleDataSource->SetData(&(m_fmtetc[3]), &(m_stgmed[3]), FALSE);

		//ʹ�ú�, ��չ�������
		::GlobalFree(m_stgmed[3].hGlobal);
		m_stgmed[3].hGlobal = NULL;
	}
	else
	{
		/**********************************����ֻ������**************************************/
		// С�ڿ�͸�ʽ����
		strUBB.Replace(_T("\n"), _T("\r\n"));
		int nDataSize = (strUBB.GetLength()+1) * sizeof(TCHAR);

		HGLOBAL hText = ::GlobalAlloc(GMEM_NODISCARD, nDataSize);
		if (hText)
		{
			LPVOID pData = ::GlobalLock(hText);
			if (pData)
			{
				memset(pData, 0, nDataSize);
				_tcsncpy((TCHAR*)pData, strUBB, strUBB.GetLength()+1 );
				::GlobalUnlock(hText);
			}
		}

		m_stgmed[3].hGlobal = hText;
		pOleDataSource->SetData(&(m_fmtetc[3]), &(m_stgmed[3]), FALSE);

		//ʹ�ú�, ��չ�������
		::GlobalFree(m_stgmed[3].hGlobal);
		m_stgmed[3].hGlobal = NULL;
	}

	if (bCopyToClipBoard)
	{
		::OleSetClipboard((LPDATAOBJECT)pOleDataSource);
		pOleDataSource->Release();
	}

	return true;
}

void CUISendRichEdit::OnPaste(LPDATAOBJECT lpDataObject, CLIPFORMAT* lpcfFormat, bool bFromClipBoard)
{
	//�Ӽ��а��ڽ��������и�ʽ������Ӧ�Ĳ������
	COleDataRecvObject oleObject((IDataObject*)lpDataObject);

	SetCanUpdateNow(FALSE);

	UINT ePasetFormat = 0;
	STGMEDIUM stgm;
	HGLOBAL hData = NULL;

	//�Զ����ʽ
	if (oleObject.IsDataAvailable(m_nfmtSysFaceID, bFromClipBoard?TRUE:FALSE))
	{
		hData = oleObject.GetGlobalData(m_nfmtSysFaceID);
		if (hData)
		{
			LPCTSTR pText = (LPCTSTR)::GlobalLock(hData);
			PasteSelfInfo(&oleObject,pText);
			::GlobalUnlock(hData);
			::GlobalFree(hData);
		}
		if (lpcfFormat)
		{
			*lpcfFormat = m_nfmtSysFaceID;
		}
	}
	//Html��ʽ
	else if (oleObject.IsDataAvailable(m_nfmtHtmlID, bFromClipBoard?TRUE:FALSE))
	{
		hData = oleObject.GetGlobalData(m_nfmtHtmlID);
		if (hData)
		{
			int nSize = ::GlobalSize(hData);
			LPCSTR pText = (LPCSTR)::GlobalLock(hData);
			std::vector<char> vecTextBuffer;
			vecTextBuffer.resize(nSize+1, '\0');
			memcpy(&vecTextBuffer[0], pText, nSize);
			::GlobalUnlock(hData);
			::GlobalFree(hData);
			m_htmlFormatParser.PaserHtml(&vecTextBuffer[0]);
			::GlobalUnlock(hData);
			::GlobalFree(hData);

			//��������ͼƬԪ�ص�����, �����ȴ���λͼ��ʽ����
			//����Excel�����е�����, ���Ƚ�����ͼƬ��ʽ������
			if (!m_htmlFormatParser.IsExistImageElement() && 
				oleObject.IsDataAvailable(CF_BITMAP, bFromClipBoard?TRUE:FALSE))
			{
				if (oleObject.GetData(CF_BITMAP, &stgm))
				{
					if (stgm.tymed == TYMED_GDI && stgm.hBitmap)
					{
						SaveTempBitmapWithMD5(stgm.hBitmap);
					}
				}
				::ReleaseStgMedium(&stgm);
				if (lpcfFormat)
				{
					*lpcfFormat = CF_BITMAP;
				}
			}
			else
			{
				//�����޷�������λͼ����, ����ʹ��DIB���ݲ���
				if (m_htmlFormatParser.IsDIBBitmap())
				{
					if (oleObject.IsDataAvailable(CF_DIB, bFromClipBoard?TRUE:FALSE))
					{
						hData = oleObject.GetGlobalData(CF_DIB);
						if (hData)
						{	
							IXXImageEx* pxxPictureEx = CSysHelper::GetXXImageDll().CreateImageObj();
							if (pxxPictureEx)
							{
								HBITMAP hBitmap = pxxPictureEx->CreateBitmapFromHandle(hData);
								if (hBitmap)
								{
									SaveTempBitmapWithMD5(hBitmap);
									DeleteObject(hBitmap);
								}
								pxxPictureEx->Destroy();
							}
						}
						if (lpcfFormat)
						{
							*lpcfFormat = CF_DIB;
						}
						::GlobalFree(hData);
					}
				}
				//����������ʹ��HTML���ݵĽ������
				else
				{
					PasteHtmlInfo();
					if (lpcfFormat)
					{
						*lpcfFormat = m_nfmtHtmlID;
					}
				}
			}
		}
	}
	//ͼƬBITMAP��ʽ
	else if (oleObject.IsDataAvailable(CF_BITMAP, bFromClipBoard?TRUE:FALSE))
	{
		if (oleObject.GetData(CF_BITMAP, &stgm))
		{
			if (stgm.tymed == TYMED_GDI && stgm.hBitmap)
			{
				SaveTempBitmapWithMD5(stgm.hBitmap);
			}
		}
		::ReleaseStgMedium(&stgm);
		if (lpcfFormat)
		{
			*lpcfFormat = CF_BITMAP;
		}
	}
	//ͼƬdib��ʽ
	else if (oleObject.IsDataAvailable(CF_DIB, bFromClipBoard?TRUE:FALSE))
	{
		hData = oleObject.GetGlobalData(CF_DIB);
		if (hData)
		{	
			IXXImageEx* pxxPictureEx = NULL;
			pxxPictureEx = CSysHelper::GetXXImageDll().CreateImageObj();
			if (pxxPictureEx)
			{
				HBITMAP hBitmap = pxxPictureEx->CreateBitmapFromHandle(hData);
				if (hBitmap)
				{
					SaveTempBitmapWithMD5(hBitmap);
					DeleteObject(hBitmap);
				}
				pxxPictureEx->Destroy();
			}
		}
		if (lpcfFormat)
		{
			*lpcfFormat = CF_DIB;
		}
		::GlobalFree(hData);
	}
	//ͼԪ��ʽ
	else if (oleObject.IsDataAvailable(CF_METAFILEPICT, bFromClipBoard?TRUE:FALSE))
	{
		if (oleObject.GetData(CF_METAFILEPICT, &stgm))
		{
			if (stgm.tymed == TYMED_MFPICT)
			{
				if (stgm.hGlobal)
				{
					LPMETAFILEPICT lpMFP = (LPMETAFILEPICT)GlobalLock(stgm.hGlobal);

					HDC hDC = ::GetDC(m_hWndDirectUI);
					HDC hMemDC = ::CreateCompatibleDC(hDC);

					// �����豸ͼƬ�ߴ�
					::SetMapMode(hMemDC, MM_HIMETRIC);
					CPoint ptSize;
					ptSize.x = lpMFP->xExt;
					ptSize.y = lpMFP->yExt;
					LPtoDP(hMemDC, &ptSize, 1);
					ptSize.y = labs(ptSize.y);

					// ����metalfile
					HBITMAP hBitmap = (HBITMAP)::CreateCompatibleBitmap(hDC, ptSize.x, ptSize.y);
					HBITMAP hOldBitmap = (HBITMAP)::SelectObject(hMemDC, hBitmap);
					::SetMapMode(hMemDC, lpMFP->mm);
					::SetViewportExtEx(hMemDC, ptSize.x, ptSize.y, NULL);
					::SetViewportOrgEx(hMemDC, 0, 0, NULL);

					::PlayMetaFile(hMemDC, lpMFP->hMF);
					::SelectObject(hMemDC, hOldBitmap);
					::GlobalUnlock(stgm.hGlobal);

					::ReleaseDC(m_hWndDirectUI, hDC);
					::DeleteDC(hMemDC);

					SaveTempBitmapWithMD5(hBitmap);
				}
			}
		}
		::ReleaseStgMedium(&stgm);
		if (lpcfFormat)
		{
			*lpcfFormat = CF_METAFILEPICT;
		}
	}
	//�����ָ�ʽ
	else if (oleObject.IsDataAvailable(CF_UNICODETEXT, bFromClipBoard?TRUE:FALSE))
	{
		if (lpcfFormat)
		{
			*lpcfFormat = CF_UNICODETEXT;
		}
	}
	//΢��˽�и�ʽ
	else if (oleObject.IsDataAvailable(m_nfmtRTFID, bFromClipBoard?TRUE:FALSE))
	{
		//ִ�е�����˵����ǰ��֧�ֵ����ݸ�ʽ�ж�û��ƥ����
		//����Ŀǰ��Ҫ�Զ������ͼƬ�Ļ���, ԭRTF��ʽ�����ݲ�ֱ�Ӵ��ݸ�RichEdit
		//�������Զ�RTF��ʽ������ϸ����, Ȼ��ת�����Զ����ʽ
		//donoting
	}
	//�ļ�
	else if (oleObject.IsDataAvailable(CF_HDROP, bFromClipBoard?TRUE:FALSE))
	{
		HDROP hDropInfo = (HDROP)oleObject.GetGlobalData(CF_HDROP);
		if (hDropInfo)
		{
			DUICtrlNotifyInfo UINotifyInfo;
			memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
			UINotifyInfo.uMsgID = bFromClipBoard ? RICHEDIT_NOTIFYMSG_HDROP_BY_PASTE : RICHEDIT_NOTIFYMSG_HDROP_BY_DRAG;
			UINotifyInfo.lParam1 = (DWORD_PTR)(this);
			UINotifyInfo.lParam2 = (DWORD_PTR)(hDropInfo);
			::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);

			::GlobalFree(hDropInfo);

			if (lpcfFormat)
			{
				*lpcfFormat = CF_HDROP;
			}
		}
	}

	SetCanUpdateNow(TRUE);
	CaculOleParams();
}

void CUISendRichEdit::PasteSelfInfo(COleDataRecvObject* pObject,LPCTSTR text)
{
	if (pObject)
	{
		// ��ƥ��ı���ʽ
		WTL::CString strParseElement = PARSE_RESOURCE_PIC;
		strParseElement += PARSE_ANCHOR;
		strParseElement += PARSE_COPYDATA_PIC;
		if (m_regExpFace.strRegExpString.GetLength())
		{
			strParseElement += PARSE_ANCHOR;
			strParseElement += m_regExpFace.strRegExpString;
		}

		// ����ƥ�䴦��
		CHARFORMAT cf;
		GetCharFormat(cf);
		WTL::CString string = text;
		while( string.GetLength()>0)
		{
			// �й��������ʽ�����ⲻҪ����,�Լ���MSDN:
			//ms-help://MS.MSDNQTR.v80.chs/MS.MSDN.v80/MS.VisualStudio.v80.chs/dv_vclib/html/7423717b-b3d5-42a7-af98-46b0e6356449.htm
			CAtlRegExp<CAtlRECharTraits> reg;
			REParseError status = reg.Parse(strParseElement);
			if (REPARSE_ERROR_OK != status)
			{
				// Unexpected error.
				break ;
			}
			CAtlREMatchContext<CAtlRECharTraits> mc;
			if (!reg.Match( string, &mc))
			{
				SetSelectionCharFormat(cf);
				ReplaceSel( (LPCTSTR)string ,TRUE);
				break;
			}

			// ϵͳ��Դ����
			bool bMatched = PasteSelfResPic(mc, string, 0, cf);
			if (bMatched)
			{
				continue;
			}

			// ������ͼƬ
			bMatched = PasteSelfCopyDataPic(mc, string, 1, cf);
			if (bMatched)
			{
				continue;
			}

			// �ַ�ת�����
			if (m_regExpFace.strRegExpString.GetLength() > 0)
			{
				bMatched = PasteSelfFace(mc, string, 2, cf);
				if (bMatched)
				{
					continue;
				}
			}
		}

		OnRichEditInsideRedraw(true);
	}
}

bool CUISendRichEdit::PasteSelfResPic(CAtlREMatchContext<CAtlRECharTraits>& mc, WTL::CString& strContent, int mcIndex, CHARFORMAT& charFormat)
{
	if (mcIndex < 0)
	{
		return false;
	}

	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szStart = strContent;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szMatch = 0;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szEnd   = 0;
	mc.GetMatch(mcIndex, &szMatch, &szEnd);
	if (0 == szMatch)
	{
		return false;
	}

	ptrdiff_t nLength = szEnd - szMatch;
	ptrdiff_t nHead = szMatch - szStart;

	WTL::CString strFormat;
	strFormat.Format(_T("%%.%ds"), nLength);

	WTL::CString strEmot;
	strEmot.Format(strFormat, szMatch);

	SetSelectionCharFormat(charFormat);
	ReplaceSel((LPCTSTR)strContent.Mid(0, nHead) ,TRUE);

	WTL::CString strNum = strEmot.Mid(2, nLength - 3);
	int index = _ttoi( (LPCTSTR)strNum );

	if (m_sysHelper.SysImgIsPng(index))
	{
		if (!m_bForbidFacePaste)
		{
			this->InsertSystemPng(index, true);
		}
	}
	else
	{
		//����ϵͳ����
		if (!m_bForbidFacePaste)
		{
			this->InsertSystemFace(index, false);
		}
	}

	strContent.Format(_T("%s"), szEnd);
	return true;
}

bool CUISendRichEdit::PasteSelfCopyDataPic(CAtlREMatchContext<CAtlRECharTraits>& mc, WTL::CString& strContent, int mcIndex, CHARFORMAT& charFormat)
{
	if (mcIndex < 0)
	{
		return false;
	}

	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szStart = strContent;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szMatch = 0;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szEnd   = 0;
	mc.GetMatch(mcIndex, &szMatch, &szEnd);
	if (0 == szMatch)
	{
		return false;
	}

	ptrdiff_t nLength = szEnd - szMatch;
	ptrdiff_t nHead = szMatch - szStart;

	WTL::CString strFormat;
	strFormat.Format(_T("%%.%ds"), nLength);

	WTL::CString strImage;
	strImage.Format(strFormat, szMatch);

	WTL::CString strCopyDataPic = strImage.Mid(2, nLength - 3);

	SetSelectionCharFormat(charFormat);
	ReplaceSel( (LPCTSTR)strContent.Mid( 0, nHead) ,TRUE);

	if (!m_bForbidFacePaste)
	{
		//�����Զ���ͼƬ
		int nURLBegin = strCopyDataPic.Find(_T("<url_"));
		WTL::CString strImgFile = strCopyDataPic.Mid(0, nURLBegin);

		int nWidthBegin = strCopyDataPic.Find(_T("<width_"));
		WTL::CString strPicURL = strCopyDataPic.Mid(nURLBegin + 5, nWidthBegin - nURLBegin - 6);

		int nHeightBegin = strCopyDataPic.Find(_T("<height_"));
		WTL::CString strWidth = strCopyDataPic.Mid(nWidthBegin + 7, nHeightBegin - nWidthBegin - 8);
		WTL::CString strHeight = strCopyDataPic.Mid(nHeightBegin + 8, strCopyDataPic.GetLength() - nHeightBegin - 9);

		DWORD dwOleID = this->InsertUserDefPic2(strImgFile, false);
		if (dwOleID != -1)
		{
			IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
			if (pOleProcesser && OleProcesser_Gif == pOleProcesser->GetType())
			{
				CIMGifProcesser* pIMGifProcesser = (CIMGifProcesser*)pOleProcesser;
				pIMGifProcesser->SetFileURL(strPicURL);
				pIMGifProcesser->SetFileURLImageSize(_tcstol(strWidth, '\0', 10), _tcstol(strHeight, '\0', 10));
			}
		}
	}

	strContent.Format(_T("%s"), szEnd);
	return true;
}

bool CUISendRichEdit::PasteSelfFace(CAtlREMatchContext<CAtlRECharTraits>& mc, WTL::CString& strContent, int mcIndex, CHARFORMAT& charFormat)
{
	if (mcIndex < 0)
	{
		return false;
	}

	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szStart = strContent;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szMatch = 0;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szEnd   = 0;
	mc.GetMatch(mcIndex, &szMatch, &szEnd);
	if (0 == szMatch)
	{
		return false;
	}

	ptrdiff_t nLength = szEnd - szMatch;
	ptrdiff_t nHead = szMatch - szStart;

	WTL::CString strFormat;
	strFormat.Format(_T("%%.%ds"), nLength);

	WTL::CString strEmot;
	strEmot.Format(strFormat, szMatch);

	FaceIDExpressionMap::iterator it_face = m_faceIDExpressionMap.find(strEmot);
	if (it_face != m_faceIDExpressionMap.end())
	{
		SetSelectionCharFormat(charFormat);
		ReplaceSel((LPCTSTR)strContent.Mid(0, nHead) ,TRUE);

		UINT nFaceID = it_face->second;
		if (m_sysHelper.SysImgIsPng(nFaceID))
		{
			if (!m_bForbidFacePaste)
			{
				this->InsertSystemPng(nFaceID, true);
			}
		}
		else
		{
			//����ϵͳ����
			if (!m_bForbidFacePaste)
			{
				this->InsertSystemFace(nFaceID, false);
			}
		}
	}
	else
	{
		SetSelectionCharFormat(charFormat);
		ReplaceSel((LPCTSTR)strContent.Mid(0, nHead + nLength) ,TRUE);
	}

	strContent.Format(_T("%s"), szEnd);
	return true;
}

void CUISendRichEdit::PasteHtmlInfo()
{
	CHARFORMAT cf;
	GetCharFormat(cf);

	WTL::CString strInfo;
	int nCode, nSysFace;

	if (m_htmlFormatParser.GetFirstElem(strInfo, nCode, nSysFace))
	{
		do
		{
			if (nCode == 0 || nCode == 2)
			{
				SetSelectionCharFormat(cf);
				ReplaceSel((LPCTSTR)strInfo, TRUE);
				continue;
			}
			else if (nCode == 1)
			{
				if ((nSysFace > -1 && nSysFace < (int)m_sysHelper.GetAllSysAnimaFaceNum()) || m_sysHelper.IsSysImg(nSysFace))
				{
					if (m_sysHelper.SysImgIsPng(nSysFace))
					{
						if (!m_bForbidFacePaste)
						{
							this->InsertSystemPng(nSysFace, true);
						}
					}
					else
					{
						if (!m_bForbidFacePaste)
						{
							this->InsertSystemFace(nSysFace, false); //����ϵͳ����
						}
					}

					continue;
				}
				else
				{
					if (!PathFileExists(strInfo))
					{
						if (!m_bForbidFacePaste)
						{
							InsertSystemPng(m_sysHelper.GetSysHintImageID(IMAGE_TYPE_NO_IMAGE_PNG), true);
						}
						continue;
					}
					WTL::CString strPath = SaveTempBitmapWithMD5((LPCTSTR)strInfo);
					if (strPath.GetLength() != 0)
					{
						if (!m_bForbidFacePaste)
						{
							this->InsertUserDefPic2(strPath, false); //�����Զ���ͼƬ
						}
					}
					else
					{
						if (!m_bForbidFacePaste)
						{
							this->InsertUserDefPic2(strInfo, false); //�����Զ���ͼƬ
						}
					}
					continue;
				}
			}	
		} while(m_htmlFormatParser.GetNextElem(strInfo, nCode, nSysFace));

		OnRichEditInsideRedraw(true);
	}
}

CRect CUISendRichEdit::GetRenderRect()
{
	CRect rcDUIRichEdit = GetRect();

	LONG nMinDelta = 2*m_nBorderWidth;
	if (rcDUIRichEdit.Width() > nMinDelta && 
		rcDUIRichEdit.Height() > nMinDelta)
	{
		rcDUIRichEdit.left += m_nBorderWidth;
		rcDUIRichEdit.right -= m_nBorderWidth;
		rcDUIRichEdit.top += m_nBorderWidth;
		rcDUIRichEdit.bottom -= m_nBorderWidth;
	}
	return rcDUIRichEdit;
}

DUIRICHEDIT_STATE CUISendRichEdit::GetStatePrivate()
{
	//���ģʽ��ֱ�ӷ���
	if (!GetDUIRes() || GetDUIRes()->IsDesignStatus())
	{
		return m_eState;
	}

	if (!CUIControlBaseCom::IsEnable())
	{
		// Disable״̬
		m_eState = DUIRICHEDIT_STATE_DISABLED;
	}

	return m_eState;
}

void CUISendRichEdit::CheckAutoSize()
{
	if (!m_pAutoSize || !m_pAutoSize->GetValue2())
	{
		return;
	}

	if (!m_hDCAutoSizeSnapshot || !m_hBmpAutoSizeSnapshot)
	{
		HDC hDC = ::GetDC(m_hWndDirectUI);
		RecordAutoSizeSnapshot(hDC);
		::ReleaseDC(m_hWndDirectUI, hDC);
	}

	ForbidScrollBarShow(false, true);
	StartAutoSizeTimer();
}

void CUISendRichEdit::CheckAutoSizeProc()
{
	if (CheckAutoSizeLayoutH())
	{
		return;
	}

	if (CheckAutoSizeLayoutV())
	{
		return;
	}

	ForbidScrollBarShow(false, false);
	DestroyAutoSizeSnapshot();

	StopAutoSizeTimer();

	//�ػ����������
	CSkinObjResBaseCom* pParent = CUIControlBaseCom::GetParent();
	if (pParent)
	{
		((CUIControlBaseCom*)pParent)->DirectDraw(NULL);
	}

	//֪ͨӦ�ò�
	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_AUTO_RELAYOUT_END;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
}

BOOL CUISendRichEdit::CheckAutoSizeLayoutH()
{
	CSkinObjResBaseCom* pParent = CUIControlBaseCom::GetParent();
	if (!pParent)
	{
		return FALSE;
	}

	int nPreCharWidth = 30;

	//��ȡ��������λ����Ϣ
	CRect rcOldTextEdit = GetRect();
	CRect rcCurTextEdit = rcOldTextEdit;

	//��ȡ���ؼ�λ����Ϣ
	CRect rcDrawClient(0,0,0,0);
	pParent->GetRect(&rcDrawClient);

	//���¼������򲼾�
	int nTextLen = GetContentLength();
	if (nTextLen < m_nLastInputContentLen)
	{
		CRect rcReset = rcCurTextEdit;
		rcReset.bottom = rcReset.top + nPreCharWidth;
		SetRect(rcReset);
	}
	m_nLastInputContentLen = nTextLen;

	//��ȡ������ʾ��������п���
	CPoint ptPreHit(-1,-1);
	int nLineMaxWidth = 0;
	int nLineWidthing = 0;
	int nLastestLine = 0;
	for (int i = 0; i < nTextLen; ++i)
	{
		WTL::CString strHitChar;
		strHitChar.GetBuffer(10);
		m_FreeWindowlessRE.GetTextRange(i, i + 1, strHitChar);
		strHitChar.ReleaseBuffer();

		int nCurLine = m_FreeWindowlessRE.LineFromChar(i);
		CPoint ptHit = m_FreeWindowlessRE.PosFromChar(i);
		if (ptHit.x >= ptPreHit.x && ptPreHit.x >= 0)
		{
			int nCharWidth = (ptHit.x - ptPreHit.x);
			if (nCharWidth < 20 && nCurLine != nLastestLine)
			{
				nCharWidth = 20;
			}
			nLineWidthing += nCharWidth;

			nPreCharWidth = nCharWidth + 5;
			if (nPreCharWidth < 20)
			{
				nPreCharWidth = 20;
			}
		}
		else
		{
			nLineWidthing += (ptHit.x - rcCurTextEdit.left + nPreCharWidth);
		}

		ptPreHit = ptHit;
		nLastestLine = nCurLine;

		if (_T("\r") == strHitChar || _T("\r\n") == strHitChar ||  _T("\n") == strHitChar)
		{
			if (nLineWidthing > nLineMaxWidth)
			{
				nLineMaxWidth = nLineWidthing;
			}
			nLineWidthing = 0;
		}
	}

	if (nLineMaxWidth <= 0)
	{
		nLineMaxWidth = nLineWidthing + nPreCharWidth;
	}
	else if (nLineWidthing + nPreCharWidth > nLineMaxWidth)
	{
		nLineMaxWidth = nLineWidthing + nPreCharWidth;
	}

	//������򲼾�
	if (nLineMaxWidth < 40)
	{
		nLineMaxWidth = 40;
	}

	int nBorderWidth = 0;
	if (m_pBorderWidth)
	{
		nBorderWidth = m_pBorderWidth->GetValue();
	}

	rcCurTextEdit.right = rcCurTextEdit.left + nLineMaxWidth + nBorderWidth * 2;
	if (rcCurTextEdit.right > rcDrawClient.right - 10)
	{
		rcCurTextEdit.right = rcDrawClient.right - 10;
	}
	if (m_pAutoMaxWidth && rcCurTextEdit.Width() > m_pAutoMaxWidth->GetValue())
	{
		rcCurTextEdit.right = rcCurTextEdit.left + m_pAutoMaxWidth->GetValue();
	}

	//���򲼾�û�б仯
	if (rcCurTextEdit.Width() == rcOldTextEdit.Width())
	{
		return FALSE;
	}

	//�������򲼾�, ͬʱ����ֱ��������
	rcCurTextEdit.bottom = rcCurTextEdit.top + 20;
	SetRect(rcCurTextEdit);

	return TRUE;
}

BOOL CUISendRichEdit::CheckAutoSizeLayoutV()
{
	CSkinObjResBaseCom* pParent = CUIControlBaseCom::GetParent();
	if (!pParent)
	{
		return FALSE;
	}

	//��ȡ��������λ����Ϣ
	CRect rcOldTextEdit = GetRect();
	CRect rcCurTextEdit = rcOldTextEdit;

	//��ȡ���ؼ�λ����Ϣ
	CRect rcDrawClient(0,0,0,0);
	pParent->GetRect(&rcDrawClient);

	//��ȡTextEdit�Ĺ�������Ϣ
	DUISCROLLINFO duiScrollInfo;
	memset(&duiScrollInfo, 0, sizeof(duiScrollInfo));
	duiScrollInfo.ulSize = sizeof(DUISCROLLINFO);
	BOOL bRet = GetScrollInfo(&duiScrollInfo, DUISB_SIF_ALL);
	if (!bRet)
	{
		return FALSE;
	}

	//���㴹ֱ����
	int nBorderWidth = 0;
	if (m_pBorderWidth)
	{
		nBorderWidth = m_pBorderWidth->GetValue();
	}

	rcCurTextEdit.bottom = rcCurTextEdit.top + duiScrollInfo.nMax + nBorderWidth * 2;
	if (rcCurTextEdit.bottom > rcDrawClient.bottom - 10)
	{
		rcCurTextEdit.bottom = rcDrawClient.bottom - 10;
	}

	if (m_pAutoMaxHeight && rcCurTextEdit.Height() > m_pAutoMaxHeight->GetValue())
	{
		rcCurTextEdit.bottom = rcCurTextEdit.top + m_pAutoMaxHeight->GetValue();
	}

	//��ֱ����û�б仯
	if (rcCurTextEdit.Height() == rcOldTextEdit.Height())
	{
		return FALSE;
	}

	//���ô�ֱ����
	SetRect(rcCurTextEdit);

	return TRUE;
}

void CUISendRichEdit::StartAutoSizeTimer()
{
	if (m_nIDTAutoSize != -1)
	{
		return;
	}

	if (GetDirectUI())
	{
		m_nIDTAutoSize = GetDirectUI()->SetTimer(this, 5, NULL);
	}
}

void CUISendRichEdit::StopAutoSizeTimer()
{
	if (-1 == m_nIDTAutoSize)
	{
		return;
	}

	if (GetDirectUI())
	{
		GetDirectUI()->KillTimer(m_nIDTAutoSize);
		m_nIDTAutoSize = -1;
	}
}

BOOL CUISendRichEdit::IsAutoSizeLayouting()
{
	if (m_nIDTAutoSize != -1)
	{
		return TRUE;
	}

	return FALSE;
}

void CUISendRichEdit::RecordAutoSizeSnapshot(HDC hDC)
{
	if (!m_pAutoSize || !m_pAutoSize->GetValue2())
	{
		return;
	}

	if (!m_hDCAutoSizeSnapshot)
	{
		m_hDCAutoSizeSnapshot = ::CreateCompatibleDC(hDC);
	}

	CRect rcClient = GetRect();
	if (m_hBmpAutoSizeSnapshot)
	{
		if (rcClient.Width() != m_nBmpAutoSizeSnapshotWidth || 
			rcClient.Height() != m_nBmpAutoSizeSnapshotHeigth)
		{
			SAFE_DELETEOBJECT(m_hBmpAutoSizeSnapshot);
		}
	}
	if (!m_hBmpAutoSizeSnapshot)
	{
		m_hBmpAutoSizeSnapshot = ::CreateCompatibleBitmap(hDC, rcClient.Width(), rcClient.Height());
		m_nBmpAutoSizeSnapshotWidth = rcClient.Width();
		m_nBmpAutoSizeSnapshotHeigth = rcClient.Height();
	}

	HBITMAP hBmpOld = (HBITMAP)::SelectObject(m_hDCAutoSizeSnapshot, m_hBmpAutoSizeSnapshot);
	::BitBlt(m_hDCAutoSizeSnapshot, 0, 0, rcClient.Width(), rcClient.Height(), hDC, rcClient.left, rcClient.top, SRCCOPY);
	::SelectObject(m_hDCAutoSizeSnapshot, hBmpOld);
}

void CUISendRichEdit::DrawAutoSizeSnapshot(HDC hDC)
{
	if (!m_hDCAutoSizeSnapshot || !m_hBmpAutoSizeSnapshot)
	{
		return;
	}

	CRect rcClient = GetRect();

	HBITMAP hBmpOld = (HBITMAP)::SelectObject(m_hDCAutoSizeSnapshot, m_hBmpAutoSizeSnapshot);
	::BitBlt(hDC, rcClient.left, rcClient.top, rcClient.Width(), rcClient.Height(), m_hDCAutoSizeSnapshot, 0, 0, SRCCOPY);
	::SelectObject(m_hDCAutoSizeSnapshot, hBmpOld);
}

void CUISendRichEdit::DestroyAutoSizeSnapshot()
{
	SAFE_DELETEOBJECT(m_hBmpAutoSizeSnapshot);
	SAFE_DELETEOBJECT(m_hDCAutoSizeSnapshot);
}

DWORD CUISendRichEdit::CStringFormatToRTF(DWORD dwCookie, LPBYTE pbBuff, LONG cb, LONG *pcb)
{
	return 0;
}

DWORD CUISendRichEdit::RTFFormatToCString(DWORD dwCookie, LPBYTE pbBuff, LONG cb, LONG *pcb)
{
	return 0;
}

bool CUISendRichEdit::TestClickOnImage(CPoint point,RECT* pImageRc)
{
	//���ж�����Ƿ��ڵ�ǰ�ؼ�����
	long nScrollWidth = IsVisibleScrollBar(FALSE)?GetScrollSize():0;
	CRect rcClient = GetRect();
	if (rcClient.Width() > nScrollWidth)
	{
		rcClient.right -= nScrollWidth;
	}
	if (!rcClient.PtInRect(point))
	{
		return false;
	}

	int nClickChar = CharFromPos(point) - 1;

	CComPtr<IRichEditOle> pReo;
	GetIRichEditOle(&pReo);
	if(pReo == NULL)
	{
		return false;
	}

	long lCount = pReo->GetObjectCount();

	for (long i = 0; i < lCount; ++i)
	{
		REOBJECT reObject;
		memset(&reObject, 0, sizeof(REOBJECT));
		reObject.cbStruct = sizeof(REOBJECT);
		pReo->GetObject(i, &reObject, REO_GETOBJ_NO_INTERFACES);

		if (reObject.cp == nClickChar)
		{
			IOleProcesser* pOleProcesser = GetOleProcesser(reObject.dwUser);
			if (pOleProcesser && OleProcesser_Control == pOleProcesser->GetType())
			{
				return false;
			}

			HDC hDC = ::GetDC(m_hWndDirectUI);

			LONG xPerInch = ::GetDeviceCaps(hDC, LOGPIXELSX);
			LONG yPerInch = ::GetDeviceCaps(hDC, LOGPIXELSY);

			::ReleaseDC(m_hWndDirectUI, hDC);

			LONG li_Width = HimetricXtoDX(reObject.sizel.cx, xPerInch);
			LONG li_Height = HimetricYtoDY(reObject.sizel.cy, yPerInch);

			CPoint ptImageTopLeft;
			ptImageTopLeft.x = PosFromChar(reObject.cp).x;			// ��λ��x������
			ptImageTopLeft.y = GetImageTop(reObject.cp, li_Height);	// ��λ�õײ�y������

			if (ptImageTopLeft.x < point.x && 
				ptImageTopLeft.x + li_Width > point.x &&
				ptImageTopLeft.y < point.y && 
				ptImageTopLeft.y + li_Height > point.y)
			{
				//SetSel(nClickChar, nClickChar+1);
				if(pImageRc)
				{
					pImageRc->left = ptImageTopLeft.x;
					pImageRc->right = ptImageTopLeft.x + li_Width;
					pImageRc->top = ptImageTopLeft.y;
					pImageRc->bottom = ptImageTopLeft.y + li_Height;
				}
				return true;
			}

			return false;
		}
	}

	return false;
}

bool CUISendRichEdit::GetEncodeUBB(WTL::CString& string, int first, int last, bool bAppendCharFormat, bool bFaceCharExpression, bool bOleControlExpression, bool bCopyData)
{
	bool bHasImage = false;
	WTL::CString text;
	GetContent(text);
	WTL::CString textW;
	if (first >= 0 && last >= first)
	{
		textW = text.Mid(first,last-first);
	}
	else if (last == -1)
	{
		textW = text;
	}
	else
	{
		//�쳣
	}

	//��Ϊ����ı�ǻ�ı�Ole�Ķ������ʱλ����Ϣ����ÿ��һ����Ҫ�ۼ�һ��ƫ��ֵ
	int oleObjOffset = 0;
	CComPtr<IRichEditOle> pRichOleObj;
	GetIRichEditOle(&pRichOleObj);
	if (!pRichOleObj)
	{
		return false;
	}

	//��������Ole����
	for (int i = 0; i < pRichOleObj->GetObjectCount(); i++)
	{
		REOBJECT object;
		memset(&object,0,sizeof(REOBJECT));
		object.cbStruct = sizeof(REOBJECT);
		pRichOleObj->GetObject(i,&object,REO_GETOBJ_NO_INTERFACES);

		//���󳬹���ѡ��ķ�Χ��ֱ������
		if (last != -1 && object.cp > last)
		{
			break;
		}
		//����ȸ÷�Χ����С
		else if (last != -1)
		{
			if (object.cp < first || object.cp >= last)
			{
				continue;
			}
		}

		//ƫ�ƺ��Ole�����λ��Ϊ, ԭ����λ��-��Χ��ʼ��+���ƫ��
		int oleObjPos = object.cp + oleObjOffset - first;

		//���
		WTL::CString strTag = _T("");
		GetOleTextUBB(object.dwUser, bFaceCharExpression, bOleControlExpression, strTag, bCopyData);

		//ɾ��ƫ�ƺ��Ole�����λ�õĿո��ַ�
		textW.Delete(oleObjPos);

		//�������ַ�
		textW.Insert(oleObjPos, CStringW(strTag));

		//�ۼ�ƫ��ֵ
		oleObjOffset += strTag.GetLength() - 1;

		bHasImage = true;
	}

	//�������ָ�ʽ
	if (bAppendCharFormat)
	{
		CHARFORMAT cf;
		GetDefaultCharFormat(cf);
		WTL::CString str(textW);
		string.Format(_T("%32s%4d%8d%3d%3d%10d%10d%s"),
			cf.szFaceName,
			cf.yHeight,
			cf.crTextColor,
			cf.bCharSet,
			cf.bPitchAndFamily,
			cf.dwEffects,
			cf.dwMask,str);
	}
	else
	{
		string = textW;
	}

	return bHasImage;
}

bool CUISendRichEdit::GetProfileContent(WTL::CString& string, int first, int last)
{
	WTL::CString text;
	GetContent(text);

	WTL::CString textW;
	if (first >= 0 && last >= first)
	{
		textW = text.Mid(first,last-first);
	}
	else if (last == -1)
	{
		textW = text;
	}
	else
	{
		//�쳣
	}

	//��Ϊ����ı�ǻ�ı�Ole�Ķ������ʱλ����Ϣ����ÿ��һ����Ҫ�ۼ�һ��ƫ��ֵ
	int oleObjOffset = 0;
	CComPtr<IRichEditOle> pRichOleObj;
	GetIRichEditOle(&pRichOleObj);
	if (!pRichOleObj)
	{
		return false;
	}

	//��������Ole����
	for (int i = 0; i < pRichOleObj->GetObjectCount(); i++)
	{
		REOBJECT object;
		memset(&object,0,sizeof(REOBJECT));
		object.cbStruct = sizeof(REOBJECT);
		pRichOleObj->GetObject(i,&object,REO_GETOBJ_NO_INTERFACES);

		//���󳬹���ѡ��ķ�Χ��ֱ������
		if (last != -1 && object.cp > last)
		{
			break;
		}
		//����ȸ÷�Χ����С
		else if (last != -1)
		{
			if (object.cp < first || object.cp >= last)
			{
				continue;
			}
		}

		//ƫ�ƺ��Ole�����λ��Ϊ, ԭ����λ��-��Χ��ʼ��+���ƫ��
		int oleObjPos = object.cp + oleObjOffset - first;

		WTL::CString strTag = _T("");
		GetOleTextDesc(object.dwUser, strTag);

		//ɾ��ƫ�ƺ��Ole�����λ�õĿո��ַ�
		textW.Delete(oleObjPos);

		//�������ַ�
		textW.Insert(oleObjPos, CStringW(strTag));

		//�ۼ�ƫ��ֵ
		oleObjOffset += strTag.GetLength() - 1;
	}

	string = textW;
	return true;
}

bool CUISendRichEdit::GetClipBoardUBB(std::string& strHtml, WTL::CString& strUnitext, int first, int last)
{
	strHtml = "";
	strUnitext = _T("");

	bool bHasImage = false;
	WTL::CString text;
	GetContent(text);
	WTL::CString textW;
	if (first >= 0 && last >= first)
	{
		textW = text.Mid(first,last-first);
	}
	else if (last == -1)
	{
		textW = text;
	}
	else
	{
		//�쳣
	}

	if (!m_htmlFormatParser.BeginProduceHtml())
	{
		return false;
	}

	//��Ϊ����ı�ǻ�ı�Ole�Ķ������ʱλ����Ϣ����ÿ��һ����Ҫ�ۼ�һ��ƫ��ֵ
	int oleObjOffset = 0;
	CComPtr<IRichEditOle> pRichOleObj;
	GetIRichEditOle(&pRichOleObj);
	if (!pRichOleObj)
	{
		return false;
	}
	//��������Ole����
	for (int i = 0; i < pRichOleObj->GetObjectCount(); i++)
	{
		REOBJECT object;
		memset(&object,0,sizeof(REOBJECT));
		object.cbStruct = sizeof(REOBJECT);
		pRichOleObj->GetObject(i,&object,REO_GETOBJ_NO_INTERFACES);

		//���󳬹���ѡ��ķ�Χ��ֱ������
		if (last != -1 && object.cp > last)
		{
			break;
		}
		//����ȸ÷�Χ����С
		else if (last != -1)
		{
			if (object.cp < first || object.cp >= last)
			{
				continue;
			}
		}

		//ƫ�ƺ��Ole�����λ��Ϊ, ԭ����λ��-��Χ��ʼ��+���ƫ��
		int oleObjPos = object.cp + oleObjOffset - first;
		m_htmlFormatParser.AddTextToHtml(textW.Left(oleObjPos));

		IOleProcesser* pOleProcesser = GetOleProcesser(object.dwUser);
		if (pOleProcesser && OleProcesser_Gif == pOleProcesser->GetType())
		{
			CIMGifProcesser* pGifProcesser = (CIMGifProcesser*)pOleProcesser;
			if (pGifProcesser->IsLoadFromRes())
			{
				TCHAR tszDirPath[MAX_PATH+1] = {0};
				GetTempPath(MAX_PATH, tszDirPath);

				UINT nResID = m_sysHelper.GetSysFaceResouceID(pGifProcesser->GetResID());
				bool bSysImgIsPng = m_sysHelper.SysImgIsPng(nResID);

				IXXImageEx* pImage = CSysHelper::GetXXImageDll().CreateImageObj();
				if (pImage)
				{
					pImage->LoadAnimation(m_sysHelper.GetRcFaceDll(), nResID, bSysImgIsPng ? "PNG" : "GIF");
					if (!pImage->IsNull())
					{
						WTL::CString strFileName = _T("");
						if (bSysImgIsPng)
						{
							strFileName.Format(_T("%seim_sysimage_%u.png"), tszDirPath, nResID);
						}
						else
						{
							strFileName.Format(_T("%seim_sysface_%u.gif"), tszDirPath, nResID);
						}

						char szFile[MAX_PATH+1] = {0};
						WideCharToMultiByte(CP_OEMCP, NULL, strFileName, -1, szFile, MAX_PATH+1, NULL, FALSE);
						pImage->Save(szFile, bSysImgIsPng ? XXIMAGE_FORMAT_PNG : XXIMAGE_FORMAT_GIF);
						m_htmlFormatParser.AddImageToHtmlBySrc(strFileName, true, nResID);
						pImage->Destroy();
					}
					pImage->Release();
				}
			}
			else if (pGifProcesser->IsExistFileURL())
			{
				m_htmlFormatParser.AddImageToHtmlByURL(pGifProcesser->GetFileURL());
			}
			else
			{
				m_htmlFormatParser.AddImageToHtmlBySrc(pGifProcesser->GetFilePathName());
			}
		}

		strUnitext += textW.Left(oleObjPos) + ' ';

		//ɾ����������ַ�
		textW.Delete(0, oleObjPos+1);

		//�ۼ�ƫ��ֵ
		oleObjOffset -= oleObjPos+1;

		bHasImage = true;
	}

	if (bHasImage)
	{
		strUnitext += textW;
		m_htmlFormatParser.AddTextToHtml(textW);
		if (m_htmlFormatParser.EndProduceHtmlA(strHtml))
		{
			return bHasImage;
		}
		else
		{
			return false;
		}	
	}
	else
	{
		strUnitext = textW;
	}

	return bHasImage;
}

long CUISendRichEdit::SelEnd(bool bHideCaret)
{
	SetSel(-1, -1, bHideCaret);

	long nStartChar, nEndChar;
	GetSel(nStartChar, nEndChar);
	//SetSel(nEndChar, nEndChar);

	return nEndChar;
}

void CUISendRichEdit::AddImageToMgr()
{
	if (m_imgProcessData.bSysFace)
	{
		return;
	}

	//֪ͨ�ϲ�
	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_ADD_FACE;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	UINotifyInfo.lParam2 = (DWORD_PTR)(LPCTSTR)m_imgProcessData.strImagePath; //�Զ���ͼƬ·��
	UINotifyInfo.lParam3 = (DWORD_PTR)(LPCTSTR)m_imgProcessData.strImageURL;
	::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
}

void CUISendRichEdit::SaveImageAs()
{
	//GIF�ļ�����IMG�ļ������⴦��
	if (m_imgProcessData.bSysFace)
	{
		int nIndex = m_imgProcessData.strImagePath.Find(_T("eim_sysFace_"));
		if (nIndex != -1)
		{
			DWORD dwFaceID = _tcstoul(m_imgProcessData.strImagePath.Mid(nIndex+12, m_imgProcessData.strImagePath.GetLength()-1), 0, 10);

			//֪ͨ�ϲ�
			DUICtrlNotifyInfo UINotifyInfo;
			memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
			UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_SAVE_PICTURE;
			UINotifyInfo.lParam1 = (DWORD_PTR)(this);
			UINotifyInfo.lParam2 = (DWORD_PTR)TRUE; //�Ƿ���ϵͳ����
			UINotifyInfo.lParam3 = (DWORD_PTR)m_sysHelper.GetSysFaceResouceID(dwFaceID);//������ԴID
			UINotifyInfo.lParam4 = (DWORD_PTR)(LPCTSTR)_T(""); //�Զ���ͼƬ·��
			::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
		}
	}
	//������ʽ�ļ��Ĵ���
	else
	{
		//֪ͨ�ϲ�
		DUICtrlNotifyInfo UINotifyInfo;
		memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
		UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_SAVE_PICTURE;
		UINotifyInfo.lParam1 = (DWORD_PTR)(this);
		UINotifyInfo.lParam2 = (DWORD_PTR)FALSE; //�Ƿ���ϵͳ����
		UINotifyInfo.lParam3 = (DWORD_PTR)0;//������ԴID
		UINotifyInfo.lParam4 = (DWORD_PTR)(LPCTSTR)m_imgProcessData.strImagePath; //�Զ���ͼƬ·��
		UINotifyInfo.lParam5 = (DWORD_PTR)(LPCTSTR)m_imgProcessData.strImageURL;
		::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
	}
}

void CUISendRichEdit::DoCopyInfo(IDataObject* pOleDataSource, LPCTSTR text)
{
	if (pOleDataSource)
	{
		WTL::CString strUBB = text;
		int dataSize = (strUBB.GetLength()+1) * (sizeof(TCHAR)/sizeof(BYTE)); 

		HGLOBAL hText = ::GlobalAlloc(GMEM_NODISCARD, dataSize);
		LPVOID pData = ::GlobalLock(hText);
		_tcsncpy( (TCHAR*)pData, strUBB, strUBB.GetLength()+1 );
		::GlobalUnlock(hText);

		m_stgmed[1].hGlobal = hText;
		pOleDataSource->SetData(&(m_fmtetc[1]), &(m_stgmed[1]), FALSE);

		//ʹ�ú�, ��չ�������
		::GlobalFree(m_stgmed[1].hGlobal);
		m_stgmed[1].hGlobal = NULL;
	}
}

bool CUISendRichEdit::GetSendImagePath(CHARRANGE cr)
{
	//���û�������
	m_imgProcessData.bSysFace = false;
	m_imgProcessData.strImagePath = _T("");
	m_imgProcessData.strImageURL = _T("");
	m_imgProcessData.nImageURLWidth = 0;
	m_imgProcessData.nImageURLHeight = 0;

	//��õ�ǰѡ�еķ�Χ�ڵ�Ԫ�ر�����Ϣ
	WTL::CString strUBB = _T("");
	GetEncodeUBB(strUBB, cr.cpMin, cr.cpMax, false, false, false, true);

	//������ͼƬ��ID,����ID�õ�ͼƬ·��, ����һ�ݵ�SRImageĿ¼��
	while (strUBB.GetLength() > 0)
	{
		CAtlRegExp<CAtlRECharTraits> reg;
		REParseError status = reg.Parse(PARSE_COPYDATA_PIC);
		if (REPARSE_ERROR_OK != status)
		{
			// Unexpected error.
			break ;
		}
		CAtlREMatchContext<CAtlRECharTraits> mc;
		if (!reg.Match(strUBB, &mc))
		{
			int nLength = strUBB.GetLength();
			WTL::CString strDef = strUBB.Mid(2,nLength - 3) + _T(".gif");
			WTL::CString tempPath;
			tempPath.Format(_T("eim_sysFace_"));

			m_imgProcessData.bSysFace = true;
			m_imgProcessData.strImagePath = tempPath + strDef;
			m_imgProcessData.strImageURL = _T("");
			m_imgProcessData.nImageURLWidth = 0;
			m_imgProcessData.nImageURLHeight = 0;
			return true;
		}

		const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szStart = strUBB;
		const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szMatch = 0;
		const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szEnd   = 0;

		mc.GetMatch(0, &szMatch, &szEnd);
		{
			ptrdiff_t nLength = szEnd - szMatch;
			ptrdiff_t nHead = szMatch - szStart;

			WTL::CString strFormat;
			strFormat.Format(_T("%%.%ds"), nLength);

			WTL::CString strImageInfo;
			strImageInfo.Format(strFormat, szMatch);

			//�õ�ImageFilePath
			WTL::CString strCopyImg = strImageInfo.Mid(2, nLength - 3);

			int nImgURLBegin = strCopyImg.Find(_T("<url_"));
			WTL::CString strImgFile = strCopyImg.Mid(0, nImgURLBegin);

			int nWidthBegin = strCopyImg.Find(_T("<width_"));
			WTL::CString strImgURL = strCopyImg.Mid(nImgURLBegin + 5, nWidthBegin - nImgURLBegin - 6);

			int nHeightBegin = strCopyImg.Find(_T("<height_"));
			WTL::CString strWidth = strCopyImg.Mid(nWidthBegin + 7, nHeightBegin - nWidthBegin - 8);
			WTL::CString strHeight = strCopyImg.Mid(nHeightBegin + 8, strCopyImg.GetLength() - nHeightBegin - 9);

			m_imgProcessData.bSysFace = false;
			m_imgProcessData.strImagePath = strImgFile;
			m_imgProcessData.strImageURL = strImgURL;
			m_imgProcessData.nImageURLWidth = _tcstol(strWidth, '\0', 0);
			m_imgProcessData.nImageURLHeight = _tcstol(strHeight, '\0', 0);

			//ʣ���UBB��Ϣ
			strUBB = szEnd;

			return true;
		}
	}
	return false;
}

WTL::CString CUISendRichEdit::SaveTempBitmapWithMD5(LPCTSTR lpszPath)
{
	WTL::CString strFilePath = lpszPath ? lpszPath : _T("");

	char chFile[MAX_PATH + 1] = {0};
#ifdef _UNICODE
	WideCharToMultiByte(CP_OEMCP, NULL, strFilePath, -1, chFile, MAX_PATH, NULL, FALSE);
#else
	strncpy(chFile, strFilePath, MAX_PATH);
#endif

	//��ȡ��ʾ�ñ����ļ���md5��
	unsigned char md5FileName[MAX_MD5_LEN];
	memset(md5FileName, 0, sizeof(md5FileName));
	if (!MD5File(chFile, md5FileName))
	{
		//AssertFatal(FALSE, "����ͼԪMD5�����");
		return _T("");
	}

	TCHAR tszmd5FileName[MAX_MD5_LEN+1];
#ifdef _UNICODE
	MultiByteToWideChar(CP_OEMCP, MB_ERR_INVALID_CHARS, (LPCSTR)md5FileName, -1, 
		tszmd5FileName, MAX_MD5_LEN);
#else
	strncpy(tszmd5FileName, md5FileName, MAX_MD5_LEN+1);
#endif

	WTL::CString strExt = _T(".png");
	int nExtBegin = strFilePath.ReverseFind(_T('.'));
	if (nExtBegin != -1 && strFilePath.GetLength() - nExtBegin < 10)
	{
		strExt = strFilePath.Mid(nExtBegin, strFilePath.GetLength() - nExtBegin);
	}

	WTL::CString strDesPath;
	WTL::CString strFileName = WTL::CString(tszmd5FileName) + strExt;
	m_sysHelper.GetSRPicPath(strFileName,strDesPath);

	if (PathFileExists(strFilePath))
	{
		CopyFile(strFilePath, strDesPath, TRUE);
	}

	return strDesPath;
}

WTL::CString CUISendRichEdit::SaveTempBitmapWithMD5(HBITMAP hbmp)
{
	if (!hbmp)
	{
		return _T("");
	}

	IXXImageEx* pIXXImageEx = CSysHelper::GetXXImageDll().CreateImageObj();
	if (pIXXImageEx && pIXXImageEx->LoadBitmap(hbmp))
	{
		WTL::CString strPath;
		m_sysHelper.GetPicRcvPath(strPath);
		strPath += _T("___eimsoft___temp___.png");
		if (PathFileExists(strPath)) DeleteFile(strPath);

		char szSavePath[MAX_PATH];
		memset(szSavePath, 0, sizeof(szSavePath));
#ifdef _UNICODE
		WideCharToMultiByte(CP_OEMCP, NULL, strPath, -1,
			szSavePath, MAX_PATH, NULL, FALSE );
#else
		strncpy(szSavePath, strPath, MAX_PATH);
#endif

		pIXXImageEx->Save(szSavePath, XXIMAGE_FORMAT_PNG);
		pIXXImageEx->Destroy();
		pIXXImageEx->Release();

		CHARFORMAT cf;
		cf.cbSize = sizeof(CHARFORMAT);
		GetDefaultCharFormat(cf);

		WTL::CString strInsertPath = SaveTempBitmapWithMD5(strPath);
		if (strInsertPath.GetLength() > 0)
		{
			if (!m_bForbidFacePaste)
			{
				InsertUserDefPic2(strInsertPath, true);
			}
			DeleteFile(strPath);
		}
		else
		{
			if (!m_bForbidFacePaste)
			{
				InsertUserDefPic2(strPath, true);
			}
			strInsertPath = strPath;
		}
		return strInsertPath;
	}

	return _T("");
}

bool CUISendRichEdit::IsEmotionTipsShouldPopUp(long lFirstSelPos, long lLastSelPos, WTL::CString& strSendText)
{
	//��ȡ�����ǰ���ַ���
	std::string strSendTextA = static_cast<CT2CA>(strSendText);
	std::string strSendTextRange(strSendTextA, 0, lLastSelPos);

	//ȫ������Сд��Ϊ��ʹ��ƥ����Case Unsensitive
	std::transform(strSendTextRange.begin(), strSendTextRange.end(),
		strSendTextRange.begin(),
		tolower);

	//����Ҫ���ӷָ�����������ǰ׺, ֻ��Ҫ�������������, �ں������Ӽ���
	//ע�⣺Ҫ�ҵ��ַ���ͳһΪСд
	typedef std::string::size_type s_size;

	std::vector<s_size> vecSpliter;
	vecSpliter.push_back(strSendTextRange.rfind(" "));
	vecSpliter.push_back(strSendTextRange.rfind("\n"));
	vecSpliter.push_back(strSendTextRange.rfind("//"));	// �Ϳ�����������
	vecSpliter.push_back(strSendTextRange.rfind("..")); // As above

	std::vector<s_size> vecSpePre;
	vecSpePre.push_back(strSendTextRange.rfind("http:"));
	vecSpePre.push_back(strSendTextRange.rfind("ftp:"));
	vecSpePre.push_back(strSendTextRange.rfind("ftp."));
	vecSpePre.push_back(strSendTextRange.rfind("file:"));
	vecSpePre.push_back(strSendTextRange.rfind("www."));
	vecSpePre.push_back(strSendTextRange.rfind("dd:"));

	//���˵�û���ҵ���
	typedef std::vector<s_size>::const_iterator sIter;
	vecSpliter.erase(std::remove(vecSpliter.begin(), vecSpliter.end(), std::string::npos), vecSpliter.end());

	//���ҵ������ҳ�����(���ߵ�)
	sIter maxSpliterIter = std::max_element(vecSpliter.begin(), vecSpliter.end());

	//���˵�û���ҵ���
	vecSpePre.erase(std::remove(vecSpePre.begin(), vecSpePre.end(), std::string::npos), vecSpePre.end());

	//���ҵ������ҳ�����(���ߵ�)
	sIter maxSpePreIter = std::max_element(vecSpePre.begin(), vecSpePre.end());

	if (!vecSpePre.empty())
	{
		//û�� ' ' '\n'
		if (vecSpliter.empty())
		{
			return false;
		}
		//������һ��
		else if (*maxSpePreIter > *maxSpliterIter)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	else
	{
		return true;
	}

	return false;
}

void CUISendRichEdit::PopUpEmotionTips(long lLastSelPos, int nBackNumOfChars)
{
	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_SHOW_EMOTION_TIPS;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	UINotifyInfo.lParam2 = (DWORD_PTR)lLastSelPos;
	UINotifyInfo.lParam3 = (DWORD_PTR)nBackNumOfChars;
	::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
}

void CUISendRichEdit::ProcessPicTipsOnTimer()
{
	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_PIC_OP_TIPS;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);

	//��ȡ��ǰ������ʾ״̬
	BYTE byShow = 0;
	UINotifyInfo.lParam2 = (DWORD_PTR)1;
	UINotifyInfo.lParam3 = (DWORD_PTR)&byShow;
	::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
	if (byShow)
	{
		//��ǰ����Ƿ���������ʾ��
		BYTE byCurInTips = 0;
		UINotifyInfo.lParam2 = (DWORD_PTR)2;
		UINotifyInfo.lParam3 = (DWORD_PTR)&byCurInTips;
		::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
		if (byCurInTips)
		{
			//�ж�������ʾ�ı����Ƿ񻹴��� �ɱ༭ʱ�����ɾ�������
			if (m_nlastOverImageChar >= 0)
			{	
				CHARRANGE cr;
				cr.cpMin = m_nlastOverImageChar;
				cr.cpMax = m_nlastOverImageChar+1;

				GetSendImagePath(cr);
				if (m_imgProcessData.strImagePath.GetLength() <= 0)
				{
					//����������ʾ
					UINotifyInfo.lParam2 = (DWORD_PTR)3;
					::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
					if (GetDirectUI())
					{
						GetDirectUI()->KillTimer(m_nIDTPicTips);
						m_nIDTPicTips = -1;
					}
					m_nlastOverImageChar = -1;
				}
			}
		}
		else
		{
			CPoint ptCursor;
			GetCursorPos(&ptCursor);
			::ScreenToClient(m_hWndDirectUI, &ptCursor);
			if (!(TestClickOnImage(ptCursor)))
			{
				//����������ʾ
				UINotifyInfo.lParam2 = (DWORD_PTR)3;
				::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
				if (GetDirectUI())
				{
					GetDirectUI()->KillTimer(m_nIDTPicTips);
					m_nIDTPicTips = -1;
				}
				m_nlastOverImageChar = -1;
			}
		}
	}
	else
	{
		if (GetDirectUI())
		{
			GetDirectUI()->KillTimer(m_nIDTPicTips);
			m_nIDTPicTips = -1;
		}
		m_nlastOverImageChar = -1;
	}
}

void CUISendRichEdit::RegisterDragDrop()
{
	if (!IsVisible())
	{
		return;
	}

	if (m_FreeWindowlessRE.GetReadOnly())
	{
		return;
	}

	m_FreeWindowlessRE.RegisterDragDrop();
}

void CUISendRichEdit::RevokeDragDrop()
{
	m_FreeWindowlessRE.RevokeDragDrop();
}

void CUISendRichEdit::ScaleSize(SIZE& szScale, LONG nMaxCX, LONG nMaxCY)
{
	if (szScale.cx > nMaxCX)
	{
		FLOAT fScale = ((FLOAT)nMaxCX)/((FLOAT)szScale.cx);
		szScale.cx = nMaxCX;
		szScale.cy = (int)((FLOAT)(fScale*((FLOAT)szScale.cy)));
	}

	if (szScale.cy > nMaxCY)
	{
		FLOAT fScale = ((FLOAT)nMaxCY)/((FLOAT)szScale.cy);
		szScale.cy = nMaxCY;
		szScale.cx = (int)((FLOAT)(fScale*((FLOAT)szScale.cx)));
	}
}

POINT CUISendRichEdit::GetEmotionParseTipsPos(LONG lLastSelPos)
{
	POINT ptTipsPos;
	ptTipsPos.x = PosFromChar(lLastSelPos).x + 10;
	ptTipsPos.y = GetLineBottom(lLastSelPos) + 10;
	return ptTipsPos;
}

void CUISendRichEdit::GetSel(long& nStartChar, long& nEndChar)
{
	if (!m_bInit) return;

	return m_FreeWindowlessRE.GetSel(nStartChar, nEndChar);
}

void CUISendRichEdit::SetSel(long nStartChar, long nEndChar, bool bHideCaret)
{
	if (!m_bInit) return;

	return m_FreeWindowlessRE.SetSel(nStartChar, nEndChar, bHideCaret);
}

void CUISendRichEdit::CreateVertScrollBar()
{
	if (m_pScrollBarImplVert != NULL) return;

	int nCount = GetChildCount();
	for (SHORT i=0;i<nCount;i++)
	{
		CUIControlBaseCom* pSubObj = (CUIControlBaseCom*)GetSubObject(i);
		TCHAR strName[MAX_PATH];
		pSubObj->GetControlTypeName(strName,MAX_PATH);
		if (_wcsicmp(strName,_T("ScrollBar")) == 0)
		{
			if (!((CUIScrollBarCom*)pSubObj)->IsHorz())
			{
				m_pScrollBarImplVert = (CUIScrollBarCom*)pSubObj;
				break;
			}
		}
	}

	if (m_pScrollBarImplVert == NULL) return;

	m_pScrollBarImplVert->SetOwnerCtrl(this);

	m_pScrollBarImplVert->Dock2(UIDock_Right, TRUE);
	UIPosition objPos = GetPosition(m_pScrollBarImplVert);
	objPos.horzPos.nWidth_Height = GetScrollSize();
	objPos.horzPos.nRight_Bottom = m_nBorderWidth;
	objPos.vertPos.nLeft_Top = m_nBorderWidth;
	objPos.vertPos.nRight_Bottom = m_nBorderWidth;
	objPos.vertPos.nWidth_Height = m_nBorderWidth;
	SetPosition(objPos,m_pScrollBarImplVert);
	m_pScrollBarImplVert->SetHorz(FALSE);
	m_pScrollBarImplVert->SetVisible2(FALSE, FALSE, FALSE);
	m_pScrollBarImplVert->SetMouseWheelParam(8, 10, 20, 10, 50);
	ResizeThis();
}

void CUISendRichEdit::CreateHorzScrollBar()
{
	if (m_pScrollBarImplHorz != NULL) return;

	int nCount = GetChildCount();
	for (int i=0;i<nCount;i++)
	{
		CUIControlBaseCom* pSubObj = (CUIControlBaseCom*)GetSubObject(i);
		TCHAR strName[MAX_PATH];
		pSubObj->GetControlTypeName(strName,MAX_PATH);
		if (_wcsicmp(strName,_T("ScrollBar")) == 0)
		{
			if (((CUIScrollBarCom*)pSubObj)->IsHorz())
			{
				m_pScrollBarImplHorz = (CUIScrollBarCom*)pSubObj;
				break;
			}		
		}
	}

	if (m_pScrollBarImplHorz == NULL) return;

	m_pScrollBarImplHorz->SetOwnerCtrl(this);

	m_pScrollBarImplHorz->Dock2(UIDock_Bottom, TRUE);
	UIPosition objPos = GetPosition(m_pScrollBarImplHorz);
	objPos.vertPos.nWidth_Height = GetScrollSize();
	objPos.vertPos.nRight_Bottom = m_nBorderWidth;
	objPos.horzPos.nRight_Bottom = m_nBorderWidth;
	objPos.horzPos.nLeft_Top = m_nBorderWidth;
	objPos.horzPos.nWidth_Height = m_nBorderWidth;
	SetPosition(objPos,m_pScrollBarImplHorz);
	m_pScrollBarImplHorz->SetHorz(TRUE);
	m_pScrollBarImplHorz->SetMouseWheelParam(8, 10, 20, 10, 50);
	ResizeThis();
}

long CUISendRichEdit::GetScrollSize()
{
	if (m_pScrollBarImplVert)
	{
		CRect rcScroll = m_pScrollBarImplVert->GetRect();
		return rcScroll.Width();
	}

	if (m_pScrollBarImplHorz)
	{
		CRect rcScroll = m_pScrollBarImplHorz->GetRect();
		return rcScroll.Height();
	}

	return 0;
}

LONG CUISendRichEdit::GetScrollPos(BOOL bHorz/* = FALSE*/)
{
	LONG nPos = 0;
	if (bHorz)
	{
		if (m_pScrollBarImplHorz == NULL) return 0;

		if (m_pScrollBarImplHorz->IsVisible())
			nPos = m_pScrollBarImplHorz->GetScrollPos();
	}
	else
	{
		if (m_pScrollBarImplVert == NULL) return 0;
		nPos = m_pScrollBarImplVert->GetScrollPos();
	}
	return nPos;
}

LONG CUISendRichEdit::SetScrollPos(LONG nPos,BOOL bRedraw,BOOL bHorz/* = FALSE*/)
{
	LONG nResult = 0;

	if (bHorz)
	{
		if (m_pScrollBarImplHorz == NULL) return nResult;
		nResult = m_pScrollBarImplHorz->SetScrollPos(nPos,bRedraw);
	}
	else
	{
		if (m_pScrollBarImplVert == NULL) return nResult;
		nResult = m_pScrollBarImplVert->SetScrollPos(nPos,bRedraw);
	}

	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_SCROLL_POS_CHANGE;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	UINotifyInfo.lParam2 = (DWORD_PTR)nPos;
	UINotifyInfo.lParam3 = (DWORD_PTR)(bHorz ? SB_HORZ : SB_VERT);
	::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&UINotifyInfo, 0);

	return nResult;
}
LONG CUISendRichEdit::GetScrollLimit(BOOL bHorz/* = FALSE*/)
{
	LONG nLimit = 0;

	if (bHorz)
	{
		if (m_pScrollBarImplHorz == NULL) return 0;

		nLimit = m_pScrollBarImplHorz->GetScrollLimit();
	}
	else
	{
		if (m_pScrollBarImplVert == NULL) return 0;

		nLimit = m_pScrollBarImplVert->GetScrollLimit();
	}

	return nLimit;
}

BOOL CUISendRichEdit::GetScrollInfo(DUISCROLLINFO *pSBInfo,DUISB_MASK sifMask,BOOL bHorz/* = FALSE*/)
{
	BOOL bResult = FALSE;

	if (bHorz)
	{
		if (m_pScrollBarImplHorz == NULL) return FALSE;

		bResult = m_pScrollBarImplHorz->GetScrollInfo(pSBInfo,sifMask);
	}
	else
	{
		if (m_pScrollBarImplVert == NULL) return FALSE;

		bResult = m_pScrollBarImplVert->GetScrollInfo(pSBInfo,sifMask);
	}

	return bResult;
}

BOOL CUISendRichEdit::SetScrollInfo(DUISCROLLINFO *pSBInfo,BOOL bRedraw,BOOL bHorz/* = FALSE*/)
{
	BOOL bResult = FALSE;
	if (bHorz)
	{
		if (m_pScrollBarImplHorz == NULL) return FALSE;

		bResult = m_pScrollBarImplHorz->SetScrollInfo(pSBInfo,bRedraw);
	}
	else
	{
		if (m_pScrollBarImplVert == NULL) return FALSE;

		bResult = m_pScrollBarImplVert->SetScrollInfo(pSBInfo,bRedraw);
	}

	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_SCROLL_INFO;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	UINotifyInfo.lParam2 = (DWORD_PTR)pSBInfo;
	UINotifyInfo.lParam3 = (DWORD_PTR)(bHorz ? SB_HORZ : SB_VERT);
	::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);

	return bResult;
}

void CUISendRichEdit::ShowScrollBar(BOOL bShow,BOOL bRedraw,BOOL bHorz/* = FALSE*/)
{
	if (bHorz)
	{
		m_bExistHorzScrollBar = bShow ? TRUE : FALSE;
		if (bShow && !m_bForbidHorzScrollBar)
		{
			if (m_pScrollBarImplHorz)
			{
				m_pScrollBarImplHorz->SetVisible2(TRUE,bRedraw,FALSE);
			}
		}
		else
		{
			if (m_pScrollBarImplHorz)
			{
				m_pScrollBarImplHorz->SetVisible2(FALSE,bRedraw,FALSE);
			}
		}

	}
	else
	{
		m_bExistVertScrollBar = bShow ? TRUE : FALSE;
		if (bShow && !m_bForbidVertScrollBar)
		{
			if (m_pScrollBarImplVert)
			{
				m_pScrollBarImplVert->SetVisible2(TRUE,bRedraw,FALSE);
			}
		}
		else
		{
			if (m_pScrollBarImplVert)
			{
				m_pScrollBarImplVert->SetVisible2(FALSE,bRedraw,FALSE);
			}
		}
	}
}

BOOL CUISendRichEdit::IsShowScrollBar(BOOL bHorz/* = FALSE*/)
{
	if (bHorz)
	{
		return m_bExistHorzScrollBar;
	}

	return m_bExistVertScrollBar;
}

void CUISendRichEdit::EnableScrollBarCtrl(BOOL bEnabled,BOOL bRedraw,BOOL bHorz/* = FALSE*/)
{
	if (bHorz)
	{
		if (NULL == m_pScrollBarImplHorz)
		{
			return;
		}

		m_pScrollBarImplHorz->EnableScrollBar(bEnabled);
		if (bRedraw)
		{
			m_pScrollBarImplHorz->Redraw();
		}
	}
	else
	{
		if (NULL == m_pScrollBarImplVert)
		{
			return;
		}

		m_pScrollBarImplVert->EnableScrollBar(bEnabled);
		if (bRedraw)
		{
			m_pScrollBarImplVert->Redraw();
		}
	}

}

BOOL CUISendRichEdit::IsVisibleScrollBar(BOOL bHorz/* = FALSE*/)
{
	BOOL bResult = FALSE;
	if (bHorz)
	{
		if (NULL == m_pScrollBarImplHorz)
		{
			return FALSE;
		}
		bResult = m_pScrollBarImplHorz->IsVisible();
	}
	else
	{
		if (NULL == m_pScrollBarImplVert)
		{
			return FALSE;
		}

		bResult = m_pScrollBarImplVert->IsVisible();
	}

	return bResult;
}

//////////////////////////////////////////////////////////////////////////
void CUISendRichEdit::CreateProps()
{
	//Border
	m_pBorderProp = CreateGroupProp(NULL,_T("Border"),TRUE);
	m_pDrawBorder = (CUIBOOLProp*)CreateProp(m_pBorderProp,_PROPTYPE_BOOL,L"IsDrawBorder",L"",TRUE,NULL);
	if (m_pDrawBorder) m_pDrawBorder->SetValue2(FALSE);
	m_pDrawBorderColor = (CUIBOOLProp*)CreateProp(m_pBorderProp,_PROPTYPE_BOOL,L"DrawBorderColor",L"",TRUE,NULL);
	if (m_pDrawBorderColor) m_pDrawBorderColor->SetValue2(TRUE);
	m_pBorderWidth = (CUINumberLongProp*)CreateProp(m_pBorderProp,_PROPTYPE_INT,L"BorderWidth",L"",TRUE,NULL);
	if (m_pBorderWidth) m_pBorderWidth->SetValue(0);

	tstringex strKey[] = {_T("Normal"),_T("Disabled"),_T("Hot")};
	for (int i=0;i<DUIRICHEDIT_STATE_LAST;++i)
	{
		m_pDrawProp[i] = CreateGroupProp(m_pBorderProp,strKey[i].c_str(),TRUE);
		m_pColorBorder[i] = (CUIColorProp*)CreateProp((m_pDrawProp[i]),_PROPTYPE_COLOR,L"Color",L"",TRUE,NULL);
		m_pImgBorder[i] = (CUIImageSecProp*)CreateProp((m_pDrawProp[i]),_PROPTYPE_IMAGESECTION,L"Image",L"",TRUE,NULL);

		if (DUIRICHEDIT_STATE_NORMAL == i)
		{
			m_pColorBorder[i]->SetValue(0xffe7c9a3);
		}
		else if (DUIRICHEDIT_STATE_DISABLED == i)
		{
			m_pColorBorder[i]->SetValue(0xc0c0c0);
		}
		else if (DUIRICHEDIT_STATE_HOT == i)
		{
			m_pColorBorder[i]->SetValue(0xf7d051);
		}
	}

	//AutoSize
	m_pAutoSizeProp = CreateGroupProp(NULL,_T("AutoSize"),TRUE);
	if (m_pAutoSizeProp)
	{
		m_pAutoSize = (CUIBOOLProp*)CreateProp(m_pAutoSizeProp,_PROPTYPE_BOOL,L"AutoSize",L"",TRUE,NULL);
		if (m_pAutoSize)
		{
			m_pAutoSize->SetValue2(FALSE);
		}

		m_pAutoMaxWidth = (CUINumberLongProp*)CreateProp(m_pAutoSizeProp,_PROPTYPE_INT,L"AutoMaxWidth",L"",TRUE,NULL);
		if (m_pAutoMaxWidth)
		{
			m_pAutoMaxWidth->SetValue(1000);
		}

		m_pAutoMaxHeight = (CUINumberLongProp*)CreateProp(m_pAutoSizeProp,_PROPTYPE_INT,L"AutoMaxHeight",L"",TRUE,NULL);
		if (m_pAutoMaxHeight)
		{
			m_pAutoMaxHeight->SetValue(1000);
		}
	}

	//RichElement
	m_pOleElementExModalProp = CreateGroupProp(NULL, _T("RichElement"), TRUE);

	WTL::CString strModalText = _T("");
	for (int i = 0; i < OLE_ELEEX_MODAL_MAX; ++i)
	{
		//item height
		strModalText.Format(_T("ItemHeight%d"), i + 1);
		m_pOleElementExModalArray[i].pEleHeight = (CUINumberLongProp*)CreateProp(m_pOleElementExModalProp, _PROPTYPE_LONG, strModalText, _T(""), TRUE, NULL);

		//item text style
		strModalText.Format(_T("ItemTextStyle%d"), i + 1);
		m_pOleElementExModalArray[i].pEleTextStyle = (CUITextStyleProp*)CreateProp(m_pOleElementExModalProp, _PROPTYPE_TEXTSTYLE, strModalText, _T(""), TRUE, NULL);

		//item modal
		strModalText.Format(_T("ItemModal%d"), i + 1);
		m_pOleElementExModalArray[i].pEditProp = (CUIPluginProp*)CreateProp(m_pOleElementExModalProp, _PROPTYPE_PLUGIN, strModalText, _T(""), TRUE, NULL);
		m_pOleElementExModalArray[i].pEditProp->SetPropID(ID_OLE_ELEMENTEX_EDIT_BEGIN + i);
	}
}

BOOL CUISendRichEdit::DrawObject(CUIObjectDraw* pObjDraw,RECT sknrc)
{
	if (!pObjDraw)
	{
		return FALSE;
	}

	if (!CanUpdateNow())
	{
		return FALSE;
	}

	if (IsAutoSizeLayouting())
	{
		DrawAutoSizeSnapshot(pObjDraw->GetDC(FALSE));
	}
	else
	{
		//���Ʊ߿�
		OnBorderPaint((WPARAM)pObjDraw->GetDC(FALSE), (LPARAM)&sknrc);

		//��������
		OnContentPaint((WPARAM)pObjDraw->GetDC(FALSE), (LPARAM)&sknrc);
	}

	return TRUE;
}

BOOL CUISendRichEdit::EventNotify(UINotify *peVentNotify)
{
	BOOL bResult = FALSE;

	switch (peVentNotify->eWinMsgId)
	{
	case WM_SETCURSOR:
		{
			if (m_hWndDirectUI)
			{
				CPoint ptCursor;
				::GetCursorPos(&ptCursor);
				::ScreenToClient(m_hWndDirectUI, &ptCursor);
				CRect rcClient = GetRenderRect();
				long nScrollWidth = IsVisibleScrollBar(FALSE)?GetScrollSize():0;
				rcClient.right -= nScrollWidth;

				CUIEngineCom* pUIEngine = GetDirectUI();
				if (rcClient.PtInRect(ptCursor) && pUIEngine && pUIEngine->GetFocusObject() == this)
				{
					OnRichEditMsgProc(WM_SETCURSOR, (WPARAM)peVentNotify->lParam1, (LPARAM)peVentNotify->lParam2);
					bResult = FALSE;
					return bResult;
				}
			}
			bResult = TRUE;
			return bResult;
		}
		break;
	case WM_MOUSEWHEEL:
		{
			CUIEngineCom* pUIEngine = GetDirectUI();
			if (pUIEngine && pUIEngine->GetHotObject() == this)
			{
				if (m_pScrollBarImplVert && m_pScrollBarImplVert->IsVisible())
				{
					short zDelta = HIWORD(peVentNotify->lParam1);
					m_pScrollBarImplVert->StartMouseWheel(zDelta);
				}
			}

			bResult = TRUE;
		}
		break;
	case WM_LBUTTONDOWN:
		{
			m_bValidLButtonUp = true;
			CPoint pt(LOWORD(peVentNotify->lParam2), HIWORD(peVentNotify->lParam2));
			CRect rcDUI = GetRect();
			long nScrollWidth = IsVisibleScrollBar(FALSE)?GetScrollSize():0;
			rcDUI.right -= nScrollWidth;

			CUIEngineCom* pUIEngine = GetDirectUI();
			if (rcDUI.PtInRect(pt) && pUIEngine && pUIEngine->GetHotObject() == this)
			{
				int nHitTest = OnLButtonDown((int)peVentNotify->lParam1, pt);
				if (-1 == nHitTest)
				{
					OnRichEditMsgProc(WM_LBUTTONDOWN, (WPARAM)peVentNotify->lParam1, (LPARAM)peVentNotify->lParam2);
				}
			}

			bResult = TRUE;
			return bResult;
		}
		break;
	case WM_LBUTTONUP:
		{
			CUIEngineCom* pUIEngine = GetDirectUI();
			if (pUIEngine && pUIEngine->GetFocusObject() == this)
			{
				bool bMouseHitTest = false;
				CPoint ptCursor(LOWORD(peVentNotify->lParam2), HIWORD(peVentNotify->lParam2));
				CRect rcSkinClient = GetRect();
				if (m_bValidLButtonUp && rcSkinClient.PtInRect(ptCursor))
				{
					bMouseHitTest = true;
				}

				bool bMouseCapured = false;
				if (m_bValidLButtonUp && m_bHasCaptureState && IsVisible())
				{
					bMouseCapured = true;
				}

				m_bValidLButtonUp = false;

				if (bMouseHitTest || bMouseCapured)
				{
					OnLButtonUp((int)peVentNotify->lParam1, ptCursor);
					OnRichEditMsgProc(WM_LBUTTONUP, (WPARAM)peVentNotify->lParam1, (LPARAM)peVentNotify->lParam2);
				}
			}

			bResult = TRUE;
			return bResult;
		}
		break;
	case WM_MOUSEMOVE:
		{
			CPoint pt(LOWORD(peVentNotify->lParam2), HIWORD(peVentNotify->lParam2));
			CRect rcDUI = GetRenderRect();
			long nScrollWidth = IsVisibleScrollBar(FALSE)?GetScrollSize():0;
			rcDUI.right -= nScrollWidth;

			CUIEngineCom* pUIEngine = GetDirectUI();
			if (rcDUI.PtInRect(pt))
			{
				LRESULT lHitTest = OnMouseMove((WPARAM)peVentNotify->lParam1, (LPARAM)peVentNotify->lParam2);
				if (lHitTest != -1 && pUIEngine && pUIEngine->GetHotObject() == this)
				{
					bResult = TRUE;
					return bResult;
				}
			}

			OnRichEditMsgProc(WM_MOUSEMOVE, (WPARAM)peVentNotify->lParam1, (LPARAM)peVentNotify->lParam2);
			bResult = TRUE;
			return bResult;
		}
		break;
	case WM_CAPTURECHANGED:
		{
			if((HWND)peVentNotify->lParam2 != m_hWndDirectUI )
			{
				if (m_bHasCaptureState)
				{
					m_FreeWindowlessRE.GetWinHost()->TxSetCapture(FALSE);
				}
			}

			bResult = TRUE;
			return bResult;
		}
		break;
	case UISM_SBMSG_VSCROLL:
		{
			OnRichEditMsgProc(WM_VSCROLL, MAKEWPARAM((WORD)peVentNotify->lParam1, (WORD)peVentNotify->lParam2), NULL);

			bResult = FALSE;
			return bResult;
		}
		break;
	case UISM_SBMSG_HSCROLL:
		{
			//���������������
		}
		break;
	case UISM_PM_COMMAND:
		{
			OnMenuCommond((UINT)peVentNotify->lParam1);
		}
		break;
	case WM_IME_STARTCOMPOSITION:
	case WM_IME_CHAR:
		{
			CUIEngineCom* pDirectUI = GetDirectUI();
			if (pDirectUI && pDirectUI->GetFocusObject() == this)
			{
				if(OnRichEditMsgProc(peVentNotify->eWinMsgId, (WPARAM)peVentNotify->lParam1, (LPARAM)peVentNotify->lParam2) == S_OK)
				{
					return FALSE;
				}
			}
			return TRUE;
		}
		break;
	case WM_IME_COMPOSITION:
		{
			CUIEngineCom* pDirectUI = GetDirectUI();
			if (pDirectUI && pDirectUI->GetFocusObject() == this)
			{
				if(OnRichEditMsgProc(peVentNotify->eWinMsgId, (WPARAM)peVentNotify->lParam1, (LPARAM)peVentNotify->lParam2) == S_OK)
				{
					// ���΢�����뷨λ���쳣������
					HIMC hIMC = ImmGetContext(pDirectUI->GetWindowHandle());
					if (hIMC) 
					{
						// Set composition window position near caret position
						POINT point;
						m_FreeWindowlessRE.GetCaretPos(&point);

						COMPOSITIONFORM Composition;
						Composition.dwStyle = CFS_POINT;
						Composition.ptCurrentPos.x = point.x;
						Composition.ptCurrentPos.y = point.y;
						ImmSetCompositionWindow(hIMC, &Composition);
						ImmReleaseContext(pDirectUI->GetWindowHandle(),hIMC);
					}

					return FALSE;
				}
			}
			return TRUE;
		}
		break;
	case WM_IME_ENDCOMPOSITION:
		{
			CUIEngineCom* pDirectUI = GetDirectUI();
			if (pDirectUI && pDirectUI->GetFocusObject() == this)
			{
				OnRichEditMsgProc(peVentNotify->eWinMsgId, (WPARAM)peVentNotify->lParam1, (LPARAM)peVentNotify->lParam2);
				HIMC hIMC = ImmGetContext(pDirectUI->GetWindowHandle());
				if (hIMC)
				{
					COMPOSITIONFORM form;
					form.dwStyle = CFS_DEFAULT;
					ImmSetCompositionWindow(hIMC,&form);

					CANDIDATEFORM candform;
					candform.dwStyle = CFS_DEFAULT;
					ImmSetCandidateWindow(hIMC,&candform);

					ImmReleaseContext(pDirectUI->GetWindowHandle(),hIMC);
				}	
				return FALSE;
			}
			return TRUE;
		}
		break;
	default:
		break;
	}

	switch(peVentNotify->eDuiMsgId)
	{
	case UISM_TIMER:
		{
			UINT nIDEvent = (UINT)peVentNotify->lParam1;

			//ˢ��
			if (nIDEvent == m_nIDTDraw)
			{
				OnDrawTimerProc();
			}
			//�����˸
			else if (nIDEvent == m_nIDTCaret)
			{
				m_FreeWindowlessRE.UpdateCaretInTimer();
			}
			//ͼƬ������ʾ
			else if (nIDEvent == m_nIDTPicTips)
			{
				ProcessPicTipsOnTimer();
			}
			//����Ӧ����
			else if (nIDEvent == m_nIDTAutoSize)
			{
				CheckAutoSizeProc();
			}

			bResult = FALSE;
		}
		break;

	case UISM_SIZE:
		{
			bResult = FALSE;

			long nScrollWidth = IsVisibleScrollBar(FALSE)?GetScrollSize():0;
			CRect rcClient = GetRenderRect();
			WORD wdWidth = (WORD)(rcClient.Width()-nScrollWidth);
			WORD wdHeight = rcClient.Height();
			OnRichEditMsgProc(WM_SIZE, 0, MAKELPARAM(wdWidth, wdHeight));
		}
		break;

	case UISM_VISIBLE:
		{
			BOOL bVisible = (BOOL)peVentNotify->lParam1;
			if (bVisible)
			{
				RegisterDragDrop();
			}
			else
			{
				RevokeDragDrop();
			}
		}
		break;

	case UISM_ONSETFOCUS:
		{
			LONG x = peVentNotify->lParam1;
			LONG y = peVentNotify->lParam2;
			LONG* pnResult = (LONG*)peVentNotify->lParam3;

			SetFocus();

			bResult = FALSE;
		}
		break;

	case UISM_SETFOCUS:
		{
			//����ֵ
			BOOL *pbSetFocusResult = (BOOL*)peVentNotify->lParam1;
			*pbSetFocusResult = FALSE;
			bResult = FALSE;

			OnRichEditMsgProc(WM_SETFOCUS, NULL, 0);

			m_bHasFocus = true;
		}
		break;

	case UISM_ONKILLFOCUS:
		{
			bResult = FALSE;

			m_FreeWindowlessRE.ShowCaret(false);

			OnRichEditMsgProc(WM_KILLFOCUS, NULL, 0);

			OnRichEditMsgProc(WM_IME_ENDCOMPOSITION, 0, 0);
			CUIEngineCom* pDirectUI = GetDirectUI();
			if (pDirectUI)
			{
				HIMC hIMC = ImmGetContext(pDirectUI->GetWindowHandle());
				if (hIMC)
				{
					COMPOSITIONFORM form;
					form.dwStyle = CFS_DEFAULT;
					ImmSetCompositionWindow(hIMC,&form);

					CANDIDATEFORM candform;
					candform.dwStyle = CFS_DEFAULT;
					ImmSetCandidateWindow(hIMC,&candform);

					ImmReleaseContext(pDirectUI->GetWindowHandle(),hIMC);
				}	
			}

			DirectRedraw2(NULL);

			m_bHasFocus = false;
		}
		break;

	case UISM_MOUSELEAVE:
		{
			LONG* pnResult = (LONG*)peVentNotify->lParam1;

			CUIEngineCom* pDirectUI = GetDirectUI();
			if (pDirectUI && m_bRegisterMessage)
			{
				pDirectUI->UnRegisterMessage(WM_MOUSEWHEEL,this);
				m_bRegisterMessage = false;
			}

			if (!m_bHasCaptureState)
			{
				OnRichEditMsgProc(WM_MOUSELEAVE, 0, 0);
			}

			if (CUIControlBaseCom::IsEnable() && IsBorderVisible())
			{
				if (CUIControlBaseCom::IsEnable())
				{
					m_eState = DUIRICHEDIT_STATE_NORMAL;

					//���������ؼ�����, �����ǽ�����������
					CRect rcDUIControl = GetRect();
					RECT rcUpdate;
					rcUpdate.left = rcDUIControl.left;
					rcUpdate.right = rcDUIControl.right;
					rcUpdate.top = rcDUIControl.top;
					rcUpdate.bottom = rcDUIControl.bottom;
					::InvalidateRect(m_hWndDirectUI, &rcUpdate, TRUE);
				}
			}

			bResult = FALSE;
		}
		break;

	case UISM_LBUTTONUP:
		{
			LONG nHitTest = peVentNotify->lParam1;
			LONG x = peVentNotify->lParam2;
			LONG y = peVentNotify->lParam3;
			LONG* pnResult = (LONG*)peVentNotify->lParam4;

			bResult = FALSE;
		}
		break;

	case UISM_LBUTTONDBCLICK:
		{
			LONG nHitTest = peVentNotify->lParam1;
			LONG x = peVentNotify->lParam2;
			LONG y = peVentNotify->lParam3;
			LONG* pnResult = (LONG*)peVentNotify->lParam4;

			LPARAM lParam = MAKELPARAM(x, y);
			if (-1 == OnLButtonDbClick((WPARAM)nHitTest, (LPARAM)lParam))
			{
				OnRichEditMsgProc(WM_LBUTTONDBLCLK, (WPARAM)nHitTest, (LPARAM)lParam);
			}

			bResult = FALSE;
		}
		break;

	case UISM_LBUTTONDOWN:
		{
			LONG nHitTest = peVentNotify->lParam1;
			LONG x = peVentNotify->lParam2;
			LONG y = peVentNotify->lParam3;
			LONG* pnResult = (LONG*)peVentNotify->lParam4;

			bResult = FALSE;
		}
		break;

	case UISM_RBUTTONDOWN:
		{
			LONG nHitTest = peVentNotify->lParam1;
			LONG x = peVentNotify->lParam2;
			LONG y = peVentNotify->lParam3;
			LONG* pnResult = (LONG*)peVentNotify->lParam4;

			LPARAM lParam = MAKELPARAM(x, y);
			OnRichEditMsgProc(WM_RBUTTONDOWN, (WPARAM)nHitTest, (LPARAM)lParam);

			OnHitTestOleControl(WM_RBUTTONDOWN, CPoint(x, y));

			bResult = FALSE;
		}
		break;

	case UISM_RBUTTONUP:
		{
			LONG nHitTest = peVentNotify->lParam1;
			LONG x = peVentNotify->lParam2;
			LONG y = peVentNotify->lParam3;
			LONG* pnResult = (LONG*)peVentNotify->lParam4;

			LPARAM lParam = MAKELPARAM(x, y);
			OnRichEditMsgProc(WM_RBUTTONUP, (WPARAM)nHitTest, (LPARAM)lParam);

			OnRButtonUp(nHitTest, CPoint(x,y));

			bResult = FALSE;
		}
		break;

	case UISM_MOUSEENTER:
		{
			LONG nHitTest = peVentNotify->lParam1;
			LONG x = peVentNotify->lParam2;
			LONG y = peVentNotify->lParam3;
			LONG* pnResult = (LONG*)peVentNotify->lParam4;
			CUIEngineCom* pDirectUI = GetDirectUI();
			if (pDirectUI && !m_bRegisterMessage)
			{
				m_bRegisterMessage = true;
				pDirectUI->RegisterMessage(WM_MOUSEWHEEL,this,FALSE);
			}

			if (IsBorderVisible())
			{
				if (CUIControlBaseCom::IsEnable())
				{
					m_eState = DUIRICHEDIT_STATE_HOT;

					//���������ؼ�����, �����ǽ�����������
					RECT rcUpdate = GetRect();
					::InvalidateRect(m_hWndDirectUI, &rcUpdate, TRUE);
				}
			}

			bResult = FALSE;
		}
		break;

	case UISM_MOUSEMOVE:
		{
			LONG nHitTest = peVentNotify->lParam1;
			LONG x = peVentNotify->lParam2;
			LONG y = peVentNotify->lParam3;
			LONG* pnResult = (LONG*)peVentNotify->lParam4;

			bResult = FALSE;
		}
		break;

	case UISM_DRAWPREVIEW:
		{
			bResult = FALSE;
		}
		break;

	case UISM_PROPCHANGEDNOTIFY:
		{
			CUIPropBase *pProp = (CUIPropBase*)peVentNotify->lParam1;

			bResult = FALSE;
		}
		break;

	case UISM_ISDRAGABLED:
		{
			BOOL* pbIsDragabled = (BOOL*)peVentNotify->lParam1;

			*pbIsDragabled = FALSE;

			bResult = TRUE;
		}
		break;

	case UISM_IMPORTCONFIG:
		{
			bResult = FALSE;
		}
		break;

	case UISM_FINALCREATE:
		{
			CUIEngineCom* pDirectUI = GetDirectUI();
			if (pDirectUI)
			{
				m_hWndDirectUI = pDirectUI->GetWindowHandle();
				//ע����ƺ��¼�
				pDirectUI->RegistFinalPaintObject(this);

				//ע��WM_SETCURSOR��Ϣ
				pDirectUI->RegisterMessage(WM_SETCURSOR, this, FALSE);

				//ע��WM_LBUTTONDOWN��Ϣ
				pDirectUI->RegisterMessage(WM_LBUTTONDOWN,this,FALSE);

				//ע��WM_LBUTTONUP��Ϣ
				pDirectUI->RegisterMessage(WM_LBUTTONUP,this,FALSE);

				//ע��WM_MOUSEMOVE��Ϣ
				pDirectUI->RegisterMessage(WM_MOUSEMOVE,this,FALSE);

				//ע��WM_CAPTURECHANGED��Ϣ
				pDirectUI->RegisterMessage(WM_CAPTURECHANGED,this,FALSE);

				//ע��IME��Ϣ
				pDirectUI->RegisterMessage(WM_IME_STARTCOMPOSITION,this,FALSE);
				pDirectUI->RegisterMessage(WM_IME_COMPOSITION,this,FALSE);
				pDirectUI->RegisterMessage(WM_IME_ENDCOMPOSITION,this,FALSE);
				pDirectUI->RegisterMessage(WM_IME_CHAR,this,FALSE);
			}

			CreateVertScrollBar();
			CreateHorzScrollBar();

			//����xml��oleԪ����չ����
			for (int i = 0; i < OLE_ELEEX_MODAL_MAX; ++i)
			{
				AccessOleEleExModalConfig((XMLNodePtr)GetXMLNode(), i, TRUE);

#ifndef _EXCLUDE_RESOURCE
				if (!m_pOleElementExModalArray[i].pEditProp)
				{
					continue;
				}

				if (m_pOleElementExModalArray[i].pElement)
				{
					m_pOleElementExModalArray[i].pEditProp->SetValue2(m_pOleElementExModalArray[i].pElement->GetName());
				}
				else
				{
					m_pOleElementExModalArray[i].pEditProp->SetValue2(_T("None"));
				}
#endif
			}

			//��ʼ��
			InitRichEdit(DEFAULT_EDIT_OPT);

			bResult = TRUE;
		}
		break;

	case UISM_DESIGNSTATUSCHANGED:
		{
			BOOL bDesign = (BOOL)peVentNotify->lParam1;

			bResult = FALSE;
		}
		break;

	case UISM_CALLPROP:
		{
			long lPropId = peVentNotify->lParam1;
			LPTSTR pstrResult = (LPTSTR)peVentNotify->lParam2;
			int nMaxCount = (int)peVentNotify->lParam3;

			EditOleEleExModal(lPropId - ID_OLE_ELEMENTEX_EDIT_BEGIN, pstrResult, nMaxCount, bResult);
		}
		break;

	case UISM_DESTROYBMPPERPIXEL:
		{

			bResult = TRUE;
		}
		break;

	case UISM_GETDRAGCURSOR:
		{
			bResult = TRUE;
		}
		break;

	case UISM_GETCONTROLICON:
		{
			bResult = TRUE;
		}
		break;

	case UISM_GETCATEGORYNAME:
		{
			LPTSTR pstrResult = (LPTSTR)peVentNotify->lParam1;
			_stprintf(pstrResult,_T("UIControls"));
			bResult = TRUE;
		}
		break;

	case UISM_GETAUTHORINFO:
		{
			AuthorInfo* pAI = (AuthorInfo*)peVentNotify->lParam1;
			_stprintf(pAI->strAuthorName,_T("DirectUI_EIM"));
			_stprintf(pAI->strCompany,_T("EIMSoft"));
			_stprintf(pAI->strUrl,_T("eim.soft.com"));
			_stprintf(pAI->strVersion,_T("1.0.0"));
			bResult = TRUE;
		}
		break;

	case UISM_INITOBJECT:
		{
			CUIEngineCom* pDirectUI = GetDirectUI();
			if (pDirectUI)
			{
				m_hWndDirectUI = pDirectUI->GetWindowHandle();
			}

			//��ʼ��
			InitRichEdit(DEFAULT_EDIT_OPT);

			bResult = TRUE;
		}
		break;

	case UISM_INITDIALOG:
		{
			//��ʼ��
			InitRichEdit(DEFAULT_EDIT_OPT);
		}
		break;

	case UISM_ACCESSCONFIGED:
		{
			CUIEngineCom* pDirectUI = GetDirectUI();
			if (pDirectUI)
			{
				m_hWndDirectUI = pDirectUI->GetWindowHandle();
			}
			BOOL bRead = (BOOL)peVentNotify->lParam1;

			if (bRead)
			{
				if (m_pBorderWidth)
				{
					m_nBorderWidth = (USHORT)m_pBorderWidth->GetValue();
				}
			}

			//��ʼ��
			InitRichEdit(DEFAULT_EDIT_OPT);
		}
		break;

	case UISM_CLONE_END:
		{
			CUISendRichEdit* pUIShowRichEdit = (CUISendRichEdit*)peVentNotify->lParam1;
			if (pUIShowRichEdit)
			{
				for (int i = 0; i < OLE_ELEEX_MODAL_MAX; ++i)
				{
					this->CloneOleEleExModal(i, pUIShowRichEdit->GetOleEleExModalByIndex(i));
#ifndef _EXCLUDE_RESOURCE
					this->SaveOleEleExModalXmlNode();
#endif
				}
			}
		}
		break;

	case UISM_DESTROYING:
		{
			CUIEngineCom* pDirectUI = GetDirectUI();
			if (pDirectUI)
			{
				DestroyAllTimer();
				SetCanUpdateNow(false);
				ClearOleDatas();

				if (m_hCursor)
				{
					DestroyCursor(m_hCursor);
				}
				//ȡ�����ƺ��¼���ע��
				pDirectUI->UnRegistFinalPaintObject(this);

				//ȡ��WM_SETCURSOR��Ϣע��
				pDirectUI->UnRegisterMessage(WM_SETCURSOR, this);

				//ȡ��WM_MOUSEWHEELע��
				if (m_bRegisterMessage)
				{
					pDirectUI->UnRegisterMessage(WM_MOUSEWHEEL,this);
				}

				//ȡ��WM_LBUTTONDOWNע��
				pDirectUI->UnRegisterMessage(WM_LBUTTONDOWN,this);

				//ȡ��WM_LBUTTONUPע��
				pDirectUI->UnRegisterMessage(WM_LBUTTONUP,this);

				//ȡ��WM_MOUSEMOVEע��
				pDirectUI->UnRegisterMessage(WM_MOUSEMOVE,this);

				//ȡ��WM_CAPTURECHANGEDע��
				pDirectUI->UnRegisterMessage(WM_CAPTURECHANGED,this);

				//ȡ��IMEע��
				pDirectUI->UnRegisterMessage(WM_IME_STARTCOMPOSITION,this);
				pDirectUI->UnRegisterMessage(WM_IME_COMPOSITION,this);
				pDirectUI->UnRegisterMessage(WM_IME_ENDCOMPOSITION,this);
				pDirectUI->UnRegisterMessage(WM_IME_CHAR,this);

			}
		}
		break;

	case UISM_GETTABINFO://��ȡTab��Ϣ
		{
			//ָ���ؼ��Ƿ�TabStop
			BOOL *pbTabStop = (BOOL*)peVentNotify->lParam1;
			*pbTabStop = TRUE;

			//ָ���ؼ��Ƿ����Tab���
			BOOL *pbTabDraw = (BOOL*)peVentNotify->lParam2;
			*pbTabDraw = TRUE;

			bResult = TRUE;
		}
		break;

	case UISM_CHAR:
		{
			UINT nChar = peVentNotify->lParam1;
			UINT nRepCnt = peVentNotify->lParam2;
			UINT nFlags = peVentNotify->lParam3;

			OnRichEditMsgProc(WM_CHAR, nChar, MAKELPARAM((WORD)nRepCnt, (WORD)nFlags));

			bResult = TRUE;
		}
		break;
	case UISM_KEYDOWN:
		{
			UINT nChar = peVentNotify->lParam1;
			UINT nRepCnt = peVentNotify->lParam2;
			UINT nFlags = peVentNotify->lParam3;

			OnRichEditMsgProc(WM_KEYDOWN, nChar, MAKELPARAM((WORD)nRepCnt, (WORD)nFlags));

			bResult = TRUE;
		}
		break;
	default:
		break;
	}

	return bResult;
}

LONG CUISendRichEdit::GetRichEditFontHeight(LONG nPound)
{
	const LONG dTwipsPerInch = 1440;
	return MulDiv(nPound, dTwipsPerInch, 72);
}

void CUISendRichEdit::DestroyAllTimer()
{
	if (!GetDirectUI())
	{
		return;
	}

	if (m_nIDTPicTips != -1)
	{
		GetDirectUI()->KillTimer(m_nIDTPicTips);
		m_nIDTPicTips = -1;
	}

	if (m_nIDTCaret != -1)
	{
		GetDirectUI()->KillTimer(m_nIDTCaret);
		m_nIDTCaret = -1;
	}

	StopDrawTimer();
	StopAutoSizeTimer();
}

void CUISendRichEdit::BufferedReDraw()
{
	m_bNeedReDraw = TRUE;
	UpdateDrawTimer();
}

void CUISendRichEdit::UpdateDrawTimer()
{
	CUIEngineCom* pDirectUI = GetDirectUI();
	if (!pDirectUI)
	{
		return;
	}

	if (-1 == m_nIDTDraw)
	{
		m_nIDTDraw = pDirectUI->SetTimer(this, 200, NULL);
	}
}

void CUISendRichEdit::StopDrawTimer()
{
	CUIEngineCom* pDirectUI = GetDirectUI();
	if (!pDirectUI)
	{
		return;
	}

	m_bNeedReDraw = FALSE;
	m_nDrawIdleTick = 0;
	if (m_nIDTDraw != -1)
	{
		pDirectUI->KillTimer(m_nIDTDraw);
		m_nIDTDraw = -1;
	}
}

void CUISendRichEdit::OnDrawTimerProc()
{
	if (!m_bNeedReDraw)
	{
		m_nDrawIdleTick += 1;
		if (m_nDrawIdleTick > 10)
		{
			StopDrawTimer();
		}
		return;
	}

	m_nDrawIdleTick = 0;
	m_bNeedReDraw = FALSE;
	DirectRedraw2(NULL);
}

void CUISendRichEdit::InitRichEdit(DWORD dwFlags/* = DEFAULT_EDIT_OPT*/)
{
	if (!m_hWndDirectUI || !::IsWindow(m_hWndDirectUI))
	{
		return;
	}

	if (!m_bInit)
	{
		m_hCursor = ::LoadCursor(GetModuleHandle(0), IDC_ARROW);

		m_FreeWindowlessRE.SetRichEditMsgProc((IRichEditMsgProc*)this);
		m_FreeWindowlessRE.SetREParentHwnd(m_hWndDirectUI);

		if (m_pBorderWidth)
		{
			m_nBorderWidth = (USHORT)m_pBorderWidth->GetValue();
		}

		m_rcDUIClient = GetRenderRect();
		RECT rcRichEdit;
		rcRichEdit.left = m_rcDUIClient.left;
		rcRichEdit.right = m_rcDUIClient.right;
		rcRichEdit.top = m_rcDUIClient.top;
		rcRichEdit.bottom = m_rcDUIClient.bottom;
		m_FreeWindowlessRE.CreateHost(dwFlags, rcRichEdit);

		m_IRichEditOleCallback.SetHwnd(m_hWndDirectUI);
		m_IRichEditOleCallback.SetRichEditMsgProc((IRichEditMsgProc*)this);
		m_FreeWindowlessRE.SetOLECallback(&m_IRichEditOleCallback);

		//ȱʡ����ַ�����Ϊ64000
		m_FreeWindowlessRE.LimitText(RICHEDIT_TEXT_MAX_COUNT);

		m_hParent = m_hWndDirectUI;

		m_bInit = true;

		SetEventMask(ENM_CHANGE | ENM_LINK);

		//ע����ק�¼�
		RegisterDragDrop();

		//��ʼ������
		CHARFORMAT charFormat;
		memset(&charFormat, 0, sizeof(charFormat));
		charFormat.cbSize = sizeof(charFormat);
		GetDefaultCharFormat(charFormat);
		charFormat.dwMask = CFM_BOLD | CFM_CHARSET | CFM_COLOR | CFM_ITALIC | CFM_SIZE | CFM_UNDERLINE | CFM_FACE;
		charFormat.crTextColor = 0;
		charFormat.yHeight = GetRichEditFontHeight(10);
		charFormat.dwEffects = 0;
		charFormat.bPitchAndFamily = FF_DONTCARE;
		charFormat.bCharSet = DEFAULT_CHARSET;
		_tcsncpy(charFormat.szFaceName, _T("΢���ź�"), LF_FACESIZE);
		SetCharFormat(charFormat);

		//��������
		InsertTopSpace();
	}
}

bool CUISendRichEdit::IsRichEditInited()
{
	return m_bInit;
}

void CUISendRichEdit::SetRichEditFocus()
{
	if (!m_bInit) return;

	SetFocus();
	m_FreeWindowlessRE.SetFocus();

	//OnRichEditMsgProc(WM_SETFOCUS, 0, 0);
}

void CUISendRichEdit::SetReadOnly(BOOL bReadOnly/* = TRUE*/)
{
	if (!m_bInit) return;

	m_bReadOnly = bReadOnly;

	m_FreeWindowlessRE.SetReadOnly(bReadOnly);
}

void CUISendRichEdit::Clear()
{
	if (!m_bInit) return;

	DestroyAutoSizeSnapshot();

	CHARRANGE chrng;
	GetSel(chrng);
	if (chrng.cpMax == -1
		&& chrng.cpMin == 0)
	{
		m_dwCurPicCount = 0;
	}

	m_FreeWindowlessRE.Clear();

	ClearOleDatas();

	InsertTopSpace();
}

void CUISendRichEdit::AppendStringToEnd(LPCTSTR strNewText, BOOL bCanUndo/* = FALSE*/)
{
	if (!m_bInit) return;

	SetSel(-1, -1, false);
	m_FreeWindowlessRE.ReplaceSel(strNewText, bCanUndo);
}

DWORD CUISendRichEdit::InsertUserDefPic2(LPCTSTR lpszPicPath, bool bUpdate)
{
	if (!m_bShowUserDefImage)
	{
		return -1;
	}

	DWORD dwOleIDRet = InsertImage(lpszPicPath, GetOleID());
	if (-1 == dwOleIDRet)
	{
		return -1;
	}

	OnRichEditInsideRedraw(bUpdate);

	return dwOleIDRet;
}

DWORD CUISendRichEdit::InsertSystemFace(DWORD faceID,  bool bUpdate)
{
	DWORD dwID = GetOleID();
	UINT uResID = m_sysHelper.GetSysFaceResouceID(faceID);

	DWORD dwIndex = this->InsertImage(m_sysHelper.GetRcFaceDll(), uResID, "GIF", dwID);
	OnRichEditInsideRedraw(bUpdate);

	return dwIndex;
}

DWORD CUISendRichEdit::InsertSystemBmp(DWORD faceID,  bool bUpdate)
{
	DWORD dwID = GetOleID();
	UINT uResID = m_sysHelper.GetSysFaceResouceID(faceID);

	DWORD dwIndex = this->InsertImage(m_sysHelper.GetRcFaceDll(), uResID, RT_FREE_BITMAP, dwID);
	OnRichEditInsideRedraw(bUpdate);

	return dwIndex;
}

DWORD CUISendRichEdit::InsertSystemPng(DWORD faceID, bool bUpdate)
{
	DWORD dwID = GetOleID();
	UINT uResID = m_sysHelper.GetSysFaceResouceID(faceID);

	DWORD dwIndex = this->InsertImage(m_sysHelper.GetRcFaceDll(), uResID, "PNG", dwID);

	OnRichEditInsideRedraw(bUpdate);

	return dwIndex;
}

void CUISendRichEdit::SetShowUserDefImageFlag(bool bFlag)
{
	m_bShowUserDefImage = bFlag;
}

void CUISendRichEdit::RestroeMemory()
{
	EmptyUndoBuffer();
	ClearOleDatas();
}

void CUISendRichEdit::InsertHtmlString2(LPCTSTR strHtmlText)
{
	m_htmlFormatParser.PaserHtml(strHtmlText);

	PasteHtmlInfo();
}

void CUISendRichEdit::ChangeLine()
{
	SelEnd(true);

	ReplaceSel(_TEXT("\r\n"));
}

void CUISendRichEdit::ForbidFacePaste(bool bForbid)
{
	m_bForbidFacePaste = bForbid;
}

void CUISendRichEdit::ScrollToBottom()
{
	OnRichEditMsgProc(WM_VSCROLL, SB_BOTTOM, 0);
}

void CUISendRichEdit::ScrollToTop()
{
	OnRichEditMsgProc(WM_VSCROLL, SB_TOP, 0);
}

void CUISendRichEdit::ForbidScrollBarShow(bool bHorz, bool bForbid)
{
	if (bHorz)
	{
		m_bForbidHorzScrollBar = bForbid;
		ShowScrollBar(m_bExistHorzScrollBar, TRUE, TRUE);
	}
	else
	{
		m_bForbidVertScrollBar = bForbid;
		ShowScrollBar(m_bExistVertScrollBar, TRUE, FALSE);
	}
}

void CUISendRichEdit::SetFontSize(LONG nPointSize)
{
	CHARFORMAT cf;
	GetCharFormat(cf, CFM_COLOR | CFM_FACE | CFM_SIZE | CFM_BOLD | CFM_ITALIC | CFM_UNDERLINE);
	nPointSize *= 20;
	cf.yHeight = nPointSize;
	cf.dwMask = CFM_SIZE;
	SetSelectionCharFormat(cf);
}

void CUISendRichEdit::SetFontName2(LPCTSTR strFontName)
{
	WTL::CString sFontName = strFontName;

	CHARFORMAT cf;
	GetCharFormat(cf, CFM_COLOR | CFM_FACE | CFM_SIZE | CFM_BOLD | CFM_ITALIC | CFM_UNDERLINE);
	// Set the font name.
	for (int i = 0; i <= sFontName.GetLength()-1; i++)
		cf.szFaceName[i] = sFontName[i];
	cf.dwMask = CFM_FACE;
	SetSelectionCharFormat(cf);
}

void CUISendRichEdit::SetCharStyle(LONG lMask, LONG lStyle, LONG nStart, LONG nEnd)
{
	CHARFORMAT cf;
	cf.cbSize = sizeof(CHARFORMAT);
	//cf.dwMask = MASK;
	GetSelectionCharFormat(cf);
	if (cf.dwMask & lMask)	// selection is all the same
	{
		cf.dwEffects ^= lStyle; 
	}
	else
	{
		cf.dwEffects |= lStyle;
	}
	cf.dwMask = lMask;
	SetSelectionCharFormat(cf);
}

void CUISendRichEdit::GetContent(LPTSTR lpContent, int nMaxCount)
{
	m_FreeWindowlessRE.GetTextEx(lpContent, nMaxCount);
}

void CUISendRichEdit::SetContent(LPCTSTR lpContent)
{
	m_FreeWindowlessRE.SetText(lpContent);
}

long CUISendRichEdit::GetContentLength()
{
	return m_FreeWindowlessRE.GetTextLengthEx();
}

OLE_COLOR CUISendRichEdit::GetContentColor()
{
	CHARFORMAT cf;
	GetCharFormat(cf, CFM_COLOR | CFM_FACE | CFM_SIZE | CFM_BOLD | CFM_ITALIC | CFM_UNDERLINE);
	return (OLE_COLOR)cf.crTextColor;
}

LONG CUISendRichEdit::GetSelectionFontSize()
{
	CHARFORMAT cf;
	GetCharFormat(cf, CFM_COLOR | CFM_FACE | CFM_SIZE | CFM_BOLD | CFM_ITALIC | CFM_UNDERLINE);
	return cf.yHeight/20;
}

void CUISendRichEdit::GetSelectionFontName(LPTSTR pFontName,int nMaxCount)
{
	if(NULL == pFontName)
		return;
	CHARFORMAT cf;
	GetCharFormat(cf, CFM_COLOR | CFM_FACE | CFM_SIZE | CFM_BOLD | CFM_ITALIC | CFM_UNDERLINE);
	memset(pFontName, 0, sizeof(TCHAR)*nMaxCount);
	_tcsncpy(pFontName, cf.szFaceName, nMaxCount-1);
}

void CUISendRichEdit::SetCharFormat(CHARFORMAT& cf)
{
	if (!m_bInit)
		return;

	CTxtWinHost* pTxtWinHost = GetWinHost();
	if (!pTxtWinHost)
		return;

	ITextServices* pTextServices = pTxtWinHost->GetTextServices();
	if (!pTextServices)
		return;

	m_curCharFormat = cf;
	m_FreeWindowlessRE.SetAllCharFormat(cf);

	LRESULT lr = 0;
	pTextServices->TxSendMessage(EM_SETFONTSIZE, 0, 0, &lr);

	CaculOleParams();
}

void CUISendRichEdit::SetRTF(LPCTSTR strRTF)
{
	return;
}

void CUISendRichEdit::GetRTF(LPTSTR pRTF,int nMaxCount)
{
	return;
}

void CUISendRichEdit::SetShowFaceTips(bool bShow)
{
	m_bShowFaceTip = bShow;
}

BOOL CUISendRichEdit::SetParaFormat(PARAFORMAT2& pf)
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.SetParaFormat(pf);
}

DWORD CUISendRichEdit::GetParaFormat(PARAFORMAT2& pf)
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetParaFormat(pf);
}

void CUISendRichEdit::SetSysImgParam(UINT nSysImgPngStart, UINT nSysImgPngEnd, UINT nSysImgGifStart, UINT nSysImgGifEnd)
{
	m_sysHelper.SetSysImgParam(nSysImgPngStart, nSysImgPngEnd, nSysImgGifStart, nSysImgGifEnd);
	m_htmlFormatParser.SetSysImgParam(nSysImgPngStart, nSysImgPngEnd, nSysImgGifStart, nSysImgGifEnd);
}

void CUISendRichEdit::SetSysSpecialImgResID(UINT nResID_LoadingGif, UINT nResID_BlockingGif, UINT nResID_ImgNotExistPng, UINT nResID_CommonHintPng)
{
	m_sysHelper.SetSysSpecialImgResID(nResID_LoadingGif, nResID_BlockingGif, nResID_ImgNotExistPng, nResID_CommonHintPng);
}

void CUISendRichEdit::SetSysFaceParam(BYTE bySysFaceType, UINT nSysFaceIDBase, UINT nSysFaceNum)
{
	m_sysHelper.SetSysFaceParam(bySysFaceType, nSysFaceIDBase, nSysFaceNum);
}

void CUISendRichEdit::SetSysFaceResourceDll(HMODULE hFaceDll)
{
	m_sysHelper.SetRcFaceDll(hFaceDll);
}

void CUISendRichEdit::SetSysFaceCharRegExpression(LPCTSTR lpRegExpression, int nRegBeginCharCount, int nRegEndCharCount)
{
	m_regExpFace.strRegExpString = lpRegExpression;
}

void CUISendRichEdit::AddSysFaceTextExpression(UINT nSysFaceID, LPCTSTR lpTextExpression, LPCTSTR lpTextHint)
{
	FaceTextExpressionMap::iterator it_char = m_faceTextExpressionMap.find(nSysFaceID);
	if (it_char != m_faceTextExpressionMap.end())
	{
		it_char->second.strTextExpression = lpTextExpression;
		it_char->second.strTextHint = lpTextHint;
	}
	else
	{
		stFaceTextExpression data;
		data.strTextExpression = lpTextExpression;
		data.strTextHint = lpTextHint;
		m_faceTextExpressionMap.insert(std::make_pair(nSysFaceID, data));
	}

	FaceIDExpressionMap::iterator it_id = m_faceIDExpressionMap.find(lpTextExpression);
	if (it_id != m_faceIDExpressionMap.end())
	{
		it_id->second = nSysFaceID;
	}
	else
	{
		m_faceIDExpressionMap.insert(std::make_pair(lpTextExpression, nSysFaceID));
	}
}

void CUISendRichEdit::SetPicRcvPath2(LPCTSTR strPicPath)
{
	m_sysHelper.SetPicRcvPath(strPicPath);
	m_htmlFormatParser.SetHttpFileSavePath(strPicPath);
}

void CUISendRichEdit::GetSendUBB(
								 OLE_SENDIMAGEINFO* pSendImageInfo,
								 UINT nMaxSendInfoCount,
								 UINT* pSendInfoCount,
								 BSTR* pUBBContent,
								 bool bAppendCharFormat,
								 bool bFaceCharExpression)
{
	if (pSendInfoCount)
	{
		*pSendInfoCount = 0;
	}

	WTL::CString strUBB = _T("");
	GetEncodeUBB(strUBB, 0, -1, bAppendCharFormat, bFaceCharExpression, true, false);

	int nRegExpBeginCharCount = 2;
	int nRegExpEndCharCount = 1;
	WTL::CString strRegExp = PARSE_DEFAULT_PIC;
	if (m_regExpImgFile.strRegExpString.GetLength() > 0)
	{
		nRegExpBeginCharCount = m_regExpImgFile.nRegBeginCharCount;
		nRegExpEndCharCount = m_regExpImgFile.nRegEndCharCount;
		strRegExp = m_regExpImgFile.strRegExpString;
	}

	//������ͼƬ��ID,����ID�õ�ͼƬ·��, ����һ�ݵ�SRImageĿ¼��
	WTL::CString strSendUBB = _T("");
	while (strUBB.GetLength() > 0)
	{
		CAtlRegExp<CAtlRECharTraits> reg;
		REParseError status = reg.Parse(strRegExp);
		if (REPARSE_ERROR_OK != status)
		{
			// Unexpected error.
			break ;
		}
		CAtlREMatchContext<CAtlRECharTraits> mc;
		if (!reg.Match(strUBB, &mc))	 
		{
			strSendUBB += strUBB;
			break;
		}

		const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szStart = strUBB;
		const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szMatch = 0;
		const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szEnd   = 0;

		mc.GetMatch(0, &szMatch, &szEnd);
		{
			ptrdiff_t nLength = szEnd - szMatch;
			ptrdiff_t nHead = szMatch - szStart;

			WTL::CString strFormat;
			strFormat.Format(_T("%%.%ds"), nLength);

			WTL::CString strImageInfo;
			strImageInfo.Format(strFormat, szMatch);

			//�õ�ͼƬ·��
			WTL::CString strFilePathName = _T("");
			WTL::CString strFilePathResult = strImageInfo.Mid(nRegExpBeginCharCount, nLength - nRegExpBeginCharCount - nRegExpEndCharCount);

			int nImageWidth = 0;
			int nImageHeight = 0;
			if (m_regExpImgFile.strRegExpString.GetLength() > 0)
			{
				if (m_expImgFileSize.strExpWidthBegin.GetLength() > 0 && m_expImgFileSize.strExpWidthEnd.GetLength() && 
					m_expImgFileSize.strExpHeightBegin.GetLength() > 0 && m_expImgFileSize.strExpHeightEnd.GetLength())
				{
					int nWidthBegin = strFilePathResult.Find(m_expImgURLSize.strExpWidthBegin);
					strFilePathName = strFilePathResult.Mid(0, nWidthBegin);

					int nHeightBegin = strFilePathResult.Find(m_expImgURLSize.strExpHeightBegin);

					int nWidthExpBeginCount = (int)m_expImgURLSize.strExpWidthBegin.GetLength();
					int nWidthExpEndCount = (int)m_expImgURLSize.strExpWidthEnd.GetLength();
					int nHeightExpBeginCount = (int)m_expImgURLSize.strExpHeightBegin.GetLength();
					int nHeightExpEndCount = (int)m_expImgURLSize.strExpHeightEnd.GetLength();

					WTL::CString strWidth = strFilePathResult.Mid(nWidthBegin + nWidthExpBeginCount, nHeightBegin - nWidthBegin - nWidthExpBeginCount - nWidthExpEndCount);
					WTL::CString strHeight = strFilePathResult.Mid(nHeightBegin + nHeightExpBeginCount, strFilePathResult.GetLength() - nHeightBegin - nHeightExpBeginCount - nHeightExpEndCount);
					nImageWidth = (int)_tcstol(strWidth, '\0', 10);
					nImageHeight = (int)_tcstol(strHeight, '\0', 10);
				}
				else
				{
					strFilePathName = strFilePathResult;
					nImageWidth = 0;
					nImageHeight = 0;
				}
			}
			else
			{
				int nWidthBegin = strFilePathResult.Find(PARSE_DEFAULT_PIC_WIDTH_BEGIN);
				strFilePathName = strFilePathResult.Mid(0, nWidthBegin);
				
				int nHeightBegin = strFilePathResult.Find(PARSE_DEFAULT_PIC_WIDTH_END);

				WTL::CString strWidth = strFilePathResult.Mid(nWidthBegin + 8, nHeightBegin - nWidthBegin - 9);
				WTL::CString strHeight = strFilePathResult.Mid(nHeightBegin + 8, strFilePathResult.GetLength() - nHeightBegin - 9);
				nImageWidth = (int)_tcstol(strWidth, '\0', 10);
				nImageHeight = (int)_tcstol(strHeight, '\0', 10);
			}
			
			strSendUBB += strUBB.Mid(0,nHead);
			if (!PathFileExists(strFilePathName))
			{
				return;
			}

			WTL::CString strExt = _T(".png");
			int nExtBegin = strFilePathName.ReverseFind(_T('.'));
			if (nExtBegin != -1 && strFilePathName.GetLength() - nExtBegin < 10)
			{
				strExt = strFilePathName.Mid(nExtBegin, strFilePathName.GetLength() - nExtBegin);
			}

			//��ȡ��ʾ�ñ����ļ���md5��
			unsigned char md5FileName[MAX_MD5_LEN] = {0};
			char tempFilePathName[MAX_PATH+1] = {0};
#ifdef _UNICODE
			WideCharToMultiByte(CP_OEMCP, NULL, strFilePathName, -1,
				tempFilePathName, MAX_PATH, NULL, FALSE );
#else
			strncpy(tempFilePathName, strFilePathName, MAX_PATH);
#endif
			if (!MD5File(tempFilePathName, md5FileName))
			{
				return;
			}

			//�����ļ�
			WTL::CString strSaveFileName = WTL::CString(md5FileName) + strExt;

			WTL::CString strNewFilePath;
			m_sysHelper.GetSRPicPath(strSaveFileName, strNewFilePath);

			if (0 != strFilePathName.Compare(strNewFilePath))//�����Ƿ�ͬһ��ͼƬ, �����򿽱�
			{
                //�����ļ����涨��·����
                ::CopyFile(strFilePathName,strNewFilePath,FALSE);
			}

            //ѹ�뵽�ļ�������Ϣ��
            if(pSendImageInfo && pSendInfoCount&& (*pSendInfoCount) < nMaxSendInfoCount)
            {
                _tcsncpy(pSendImageInfo[*pSendInfoCount].tszNewFilePath,strNewFilePath,MAX_PATH-1);
                _tcsncpy(pSendImageInfo[*pSendInfoCount].tszOrgFilePath,strFilePathName,MAX_PATH-1);
                (*pSendInfoCount) += 1;
            }

			//�����ӵ�UBB��Ϣ
			WTL::CString newUBBInfo;
			if (m_regExpImgFile.strRegExpFormat.GetLength() > 0)
			{
				newUBBInfo.Format(m_regExpImgFile.strRegExpFormat, strNewFilePath, nImageWidth, nImageHeight);
			}
			else
			{
				newUBBInfo.Format(PARSE_DEFAULT_PIC_FORMAT, strNewFilePath, nImageWidth, nImageHeight);
			}
			strSendUBB += newUBBInfo;		

			strUBB = szEnd; //ʣ���UBB��Ϣ
		}
	}

	if (pUBBContent)
	{
		*pUBBContent = strSendUBB.AllocSysString();
	}
}

void CUISendRichEdit::GetSendProfileContent(BSTR* pProfleContent)
{
	WTL::CString strProfileContent = _T("");
	GetProfileContent(strProfileContent, 0, -1);

	if (pProfleContent)
	{
		*pProfleContent = strProfileContent.AllocSysString();
	}
}

long CUISendRichEdit::GetOleDataCount()
{
	CComPtr<IRichEditOle> pRichOleObj;
	GetIRichEditOle(&pRichOleObj);
	if (pRichOleObj)
	{
		return pRichOleObj->GetObjectCount();
	}

	return 0;
}

LONG CUISendRichEdit::GetLimitTextLength()
{
	LONG nLimitLen = GetLimitText();
	if (m_bLimitByCharRule)
	{
		nLimitLen /= 2;
	}

	return nLimitLen;
}

void CUISendRichEdit::LimitTextLength(LONG nMaxLen, BOOL bLimitByChar/* = FALSE*/)
{
	m_bLimitByCharRule = bLimitByChar ? true : false;
	if (m_bLimitByCharRule)
	{
		nMaxLen *= 2;
	}

	LimitText(nMaxLen);
}

long CUISendRichEdit::GetTextLength()
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetTextLength();
}

void CUISendRichEdit::GetSelText(LPTSTR pResult, int nMaxLen)
{
	if (!m_bInit)
	{
		return;
	}

	if (!pResult || nMaxLen <= 0)
	{
		return;
	}

	WTL::CString strResult = m_FreeWindowlessRE.GetSelText();
	_tcsncpy(pResult, strResult, nMaxLen);
	pResult[nMaxLen - 1] = _T('\0');
}

void CUISendRichEdit::GetRangeText(long nStartChar, long nEndChar, LPTSTR pResult, int nMaxLen)
{
	if (!m_bInit)
	{
		return;
	}

	if (!pResult || nMaxLen <= 0)
	{
		return;
	}
	memset((void*)pResult, 0, sizeof(TCHAR) * nMaxLen);

	WTL::CString strResult = _T("");
	int nLen = nEndChar - nStartChar;
	if (nLen < 0)
	{
		long nLen = m_FreeWindowlessRE.GetTextLengthEx();
		LPTSTR pBuffer = strResult.GetBuffer(nLen + 1);
		m_FreeWindowlessRE.GetTextEx(pBuffer, nLen + 1);
		strResult.ReleaseBuffer();
	}
	else
	{
		strResult.GetBuffer(nLen + 1);
		m_FreeWindowlessRE.GetTextRange(nStartChar, nEndChar, strResult);
		strResult.ReleaseBuffer();
	}

	_tcsncpy(pResult, strResult, nMaxLen);
}

bool CUISendRichEdit::HasOleInRange(long nStartChar, long nEndChar)
{
	if (nStartChar == nEndChar || nEndChar == 0 || nStartChar > nEndChar)
	{
		return false;
	}

	CComPtr<IRichEditOle> pRichOleObj;
	GetIRichEditOle(&pRichOleObj);
	if (!pRichOleObj)
	{
		return false;
	}

	//��������Ole����
	for (int i = 0; i < pRichOleObj->GetObjectCount(); i++)
	{
		REOBJECT object;
		memset(&object,0,sizeof(REOBJECT));
		object.cbStruct = sizeof(REOBJECT);
		pRichOleObj->GetObject(i,&object,REO_GETOBJ_NO_INTERFACES);

		if (object.cp >= nStartChar && object.cp <= nEndChar)
		{
			return true;
		}
	}

	return false;
}

void CUISendRichEdit::SetCharInputState(UINT wParam, UINT lParam)
{
	if (22 == wParam)
	{
		OnRichEditMsgProc(WM_PASTE, 0, 0);
	}
	else
	{
		OnRichEditMsgProc(WM_CHAR, wParam, lParam);
	}
}

void CUISendRichEdit::SetIMEInputState(UINT wParam, UINT lParam)
{
	OnRichEditMsgProc(WM_IME_STARTCOMPOSITION, wParam, lParam);
}

void CUISendRichEdit::SetGetExistSRImagePathFn( DWORD_PTR pFn )
{
	m_sysHelper.SetGetExistSRImagePathFn((FnGetExistSRImagePath)pFn);
}

void CUISendRichEdit::SetImageFileExpFormat(LPCTSTR lpImgFileExpFormat)
{
	m_regExpImgFile.strRegExpFormat = lpImgFileExpFormat;
}

void CUISendRichEdit::SetImageFileRegString(LPCTSTR lpImgFileRegString, int nRegBeginCharCount, int nRegEndCharCount, 
											LPCTSTR lpImgFileWidthBegin, LPCTSTR lpImgFileWidthEnd, LPCTSTR lpImgFileHeightBegin, LPCTSTR lpImgFileHeightEnd)
{
	m_regExpImgFile.nRegBeginCharCount = nRegBeginCharCount;
	m_regExpImgFile.nRegEndCharCount = nRegEndCharCount;
	m_regExpImgFile.strRegExpString = lpImgFileRegString;
	m_expImgFileSize.strExpWidthBegin = lpImgFileWidthBegin;
	m_expImgFileSize.strExpWidthEnd = lpImgFileWidthEnd;
	m_expImgFileSize.strExpHeightBegin = lpImgFileHeightBegin;
	m_expImgFileSize.strExpHeightEnd = lpImgFileHeightEnd;
}

void CUISendRichEdit::SetImageURLExpFormat(LPCTSTR lpImgURLExpFormat)
{
	m_regExpImgURL.strRegExpFormat = lpImgURLExpFormat;
}

void CUISendRichEdit::SetImageURLRegString(LPCTSTR lpImgURLRegString, int nRegBeginCharCount, int nRegEndCharCount, 
										   LPCTSTR lpImgURLWidthBegin, LPCTSTR lpImgURLWidthEnd, LPCTSTR lpImgURLHeightBegin, LPCTSTR lpImgURLHeightEnd)
{
	m_regExpImgURL.nRegBeginCharCount = nRegBeginCharCount;
	m_regExpImgURL.nRegEndCharCount = nRegEndCharCount;
	m_regExpImgURL.strRegExpString = lpImgURLRegString;
	m_expImgURLSize.strExpWidthBegin = lpImgURLWidthBegin;
	m_expImgURLSize.strExpWidthEnd = lpImgURLWidthEnd;
	m_expImgURLSize.strExpHeightBegin = lpImgURLHeightBegin;
	m_expImgURLSize.strExpHeightEnd = lpImgURLHeightEnd;
}

void CUISendRichEdit::EnableWordBreak( bool bEnable )
{
	if (!m_bInit) return;

	return m_FreeWindowlessRE.EnableWordBreak(bEnable);
}

void CUISendRichEdit::SetUserDefPicMaxWidth(UINT nMaxWidth)
{
	m_uUserDefPicMaxWidth = nMaxWidth;
}

void CUISendRichEdit::SetBorderVisible(bool bVisible)
{
	if (m_pDrawBorder)
	{
		m_pDrawBorder->SetValue2(bVisible?TRUE:FALSE);
	}
}

bool CUISendRichEdit::IsBorderVisible()
{
	if (m_pDrawBorder && m_pDrawBorder->GetValue2())
	{
		return true;
	}
	return false;
}

void CUISendRichEdit::EnableAutoRelayout(bool bEnable)
{
	if (m_pAutoSize)
	{
		m_pAutoSize->SetValue2(bEnable?TRUE:FALSE);
	}

	if (!bEnable && IsAutoSizeLayouting())
	{
		ForbidScrollBarShow(false, false);
		DestroyAutoSizeSnapshot();
		StopAutoSizeTimer();
	}
}

bool CUISendRichEdit::IsAutoRelayout()
{
	if (m_pAutoSize && m_pAutoSize->GetValue2())
	{
		return true;
	}

	return false;
}

void CUISendRichEdit::ReAutoLayout()
{
	CheckAutoSize();
}

DWORD CUISendRichEdit::InsertOleControl(LPCTSTR lpOleEleName, int nWidth, int nHeight)
{
	return InsertOleControl(lpOleEleName, nWidth, nHeight, GetOleID());
}

void CUISendRichEdit::SetOleControlUserData(DWORD dwOleID, DWORD_PTR dwUserData)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser)
	{
		return;
	}

	pOleProcesser->SetUserData(dwUserData);
}

DWORD_PTR CUISendRichEdit::GetOleControlUserData(DWORD dwOleID)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser)
	{
		return 0;
	}

	return pOleProcesser->GetUserData();
}

LPCTSTR CUISendRichEdit::GetOleControlElementNameByCursor(DWORD dwOleID)
{
	CPoint ptCursor(0, 0);
	::GetCursorPos(&ptCursor);
	return GetOleControlElementNameByPos(dwOleID, ptCursor);
}

LPCTSTR CUISendRichEdit::GetOleControlElementNameByPos(DWORD dwOleID, POINT pt)
{
	CPoint ptHitTest = pt;

	DWORD dwResultOleID = -1;
	CRect rcResultOle(0,0,0,0);
	bool bRet = HitTestOleByPoint(ptHitTest, dwResultOleID, rcResultOle);
	if (!bRet)
	{
		return _T("");
	}

	if (dwResultOleID != dwOleID)
	{
		return _T("");
	}

	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return _T("");
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return _T("");
	}

	CRichElementBase* pMainElement = pOleControlProcesser->GetControlElement();
	if (NULL == pMainElement)
	{
		return _T("");
	}

	ptHitTest.Offset(-rcResultOle.left, -rcResultOle.top);

	CRichElementBase* pHitElement = pMainElement->HitTest(ptHitTest);
	if (NULL == pHitElement)
	{
		return _T("");
	}

	return pHitElement->GetName();
}

void CUISendRichEdit::SetOleControlElementVisible(DWORD dwOleID, LPCTSTR lpName, BOOL bVisible)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return;
	}

	pOleControlProcesser->SetElementVisible(lpName, bVisible);

	BufferedReDraw();
}

BOOL CUISendRichEdit::IsOleControlElementVisible(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	return pOleControlProcesser->IsElementVisible(lpName);
}

void CUISendRichEdit::SetOleControlElementEnabled(DWORD dwOleID, LPCTSTR lpName, BOOL bEnabled)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return;
	}

	pOleControlProcesser->SetElementEnabled(lpName, bEnabled);

	BufferedReDraw();
}

BOOL CUISendRichEdit::IsOleControlElementEnabled(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	return pOleControlProcesser->IsElementEnabled(lpName);
}

void CUISendRichEdit::SetOleControlElementDisposeMouse(DWORD dwOleID, LPCTSTR lpName, BOOL bDispose)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return;
	}

	pOleControlProcesser->SetElementDisposeMouse(lpName, bDispose);

	BufferedReDraw();
}

BOOL CUISendRichEdit::IsOleControlElementDisposeMouse(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	return pOleControlProcesser->IsElementDisposeMouse(lpName);
}

void CUISendRichEdit::SetOleControlElementTooltip(DWORD dwOleID, LPCTSTR lpName, LPCTSTR lpTooltip)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return;
	}

	pOleControlProcesser->SetElementTooltip(lpName, lpTooltip);
}

void CUISendRichEdit::SetOleControlElementTooltipByStringCaption(DWORD dwOleID, LPCTSTR lpName, LPCTSTR lpStringCaption)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return;
	}

	pOleControlProcesser->SetElementTooltipByStringCaption(lpName, lpStringCaption);
}

BOOL CUISendRichEdit::IsOleControlElementStatic(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	return pOleControlProcesser->IsElementStatic(lpName);
}

BOOL CUISendRichEdit::SetOleControlElementStaticText(DWORD dwOleID, LPCTSTR lpName, LPCTSTR lpText)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	BOOL bRet = pOleControlProcesser->SetElementStaticText(lpName, lpText);
	BufferedReDraw();
	return bRet;
}

BOOL CUISendRichEdit::SetOleControlElementStaticTextByStringCaption(DWORD dwOleID, LPCTSTR lpName, LPCTSTR lpStringCaption)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	BOOL bRet = pOleControlProcesser->SetElementStaticTextByStringCaption(lpName, lpStringCaption);
	BufferedReDraw();
	return bRet;
}

LPCTSTR CUISendRichEdit::GetOleControlElementStaticText(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return _T("");
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return _T("");
	}

	return pOleControlProcesser->GetElementStaticText(lpName);
}

BOOL CUISendRichEdit::SetOleControlElementStaticTextColor(DWORD dwOleID, LPCTSTR lpName, COLORREF clrTextNormal, COLORREF clrTextHot, COLORREF clrTextPress, COLORREF clrTextDisabled)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	BOOL bRet = pOleControlProcesser->SetElementStaticTextColor(lpName, clrTextNormal, clrTextHot, clrTextPress, clrTextDisabled);
	BufferedReDraw();
	return bRet;
}

COLORREF CUISendRichEdit::GetOleControlElementStaticTextNormalColor(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return 0;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return 0;
	}

	return pOleControlProcesser->GetElementStaticTextNormalColor(lpName);
}

COLORREF CUISendRichEdit::GetOleControlElementStaticTextHotColor(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return 0;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return 0;
	}

	return pOleControlProcesser->GetElementStaticTextHotColor(lpName);
}

COLORREF CUISendRichEdit::GetOleControlElementStaticTextPressColor(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return 0;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return 0;
	}

	return pOleControlProcesser->GetElementStaticTextPressColor(lpName);
}

COLORREF CUISendRichEdit::GetOleControlElementStaticTextDisabledColor(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return 0;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return 0;
	}

	return pOleControlProcesser->GetElementStaticTextDisabledColor(lpName);
}

CUITextStyleCom* CUISendRichEdit::GetOleControlElementStaticTextStyle(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return NULL;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return NULL;
	}

	return pOleControlProcesser->GetElementStaticTextStyle(lpName);
}

void CUISendRichEdit::SetOleControlElementStaticTextStyle(DWORD dwOleID, LPCTSTR lpName, CUITextStyleCom* pTextStyle)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return;
	}

	pOleControlProcesser->SetElementStaticTextStyle(lpName, pTextStyle);
}

BOOL CUISendRichEdit::IsOleControlElementLogo(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	return pOleControlProcesser->IsElementLogo(lpName);
}

BOOL CUISendRichEdit::SetOleControlElementLogoImage(DWORD dwOleID, LPCTSTR lpName, CUIImageBaseCom* pLogo)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	BOOL bRet = pOleControlProcesser->SetElementLogoImage(lpName, pLogo);
	BufferedReDraw();
	return bRet;
}

CUIImageBaseCom* CUISendRichEdit::GetOleControlElementLogoImageBase(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return NULL;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return NULL;
	}

	return pOleControlProcesser->GetElementLogoImageBase(lpName);
}

BOOL CUISendRichEdit::SetOleControlElementLogoImage(DWORD dwOleID, LPCTSTR lpName, CUIImageListCom* pImagList, int nLogoIndex)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	BOOL bRet = pOleControlProcesser->SetElementLogoImage(lpName, pImagList, nLogoIndex);
	BufferedReDraw();
	return bRet;
}

CUIImageListCom* CUISendRichEdit::GetOleControlElementLogoImageList(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return NULL;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return NULL;
	}

	return pOleControlProcesser->GetElementLogoImageList(lpName);
}

int CUISendRichEdit::GetOleControlElementLogoImageIndex(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return -1;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return -1;
	}

	return pOleControlProcesser->GetElementLogoImageIndex(lpName);
}

BOOL CUISendRichEdit::SetOleControlElementLogoImageBmp(DWORD dwOleID, LPCTSTR lpName, HBITMAP hBmpLogo, BOOL bTemporySource)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	BOOL bRet = pOleControlProcesser->SetElementLogoImageBmp(lpName, (HBITMAP)hBmpLogo, bTemporySource);
	BufferedReDraw();
	return bRet;
}

HBITMAP CUISendRichEdit::GetOleControlElementLogoImageBmp(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return NULL;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return NULL;
	}

	return pOleControlProcesser->GetItemElementLogoImageBmp(lpName);
}

void CUISendRichEdit::SetOleControlElementFixedWidth(DWORD dwOleID, LPCTSTR lpName, int nWidth)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return;
	}

	pOleControlProcesser->SetElementFixedWidth(lpName, nWidth);
	BufferedReDraw();
}

int CUISendRichEdit::GetOleControlElementFixedWidth(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return 0;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return 0;
	}

	return pOleControlProcesser->GetElementFixedWidth(lpName);
}

void CUISendRichEdit::SetOleControlElementFixedHeight(DWORD dwOleID, LPCTSTR lpName, int nHeight)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return;
	}

	pOleControlProcesser->SetElementFixedHeight(lpName, nHeight);
	BufferedReDraw();
}

int CUISendRichEdit::GetOleControlElementFixedHeight(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return 0;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return 0;
	}

	return pOleControlProcesser->GetElementFixedHeight(lpName);
}

RECT CUISendRichEdit::GetOleControlItemElementRect(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return CRect(0,0,0,0);
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return CRect(0,0,0,0);
	}

	return pOleControlProcesser->GetItemElementRect(lpName);
}

void CUISendRichEdit::AutoRelayoutOleControl(DWORD dwOleID, int nMaxWidth, int nMaxHeight)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return;
	}

	// ��������Ӧ�ߴ�
	HDC hDC = ::GetDC(m_hWndDirectUI);
	SIZE szTransfer = {0,0};
	SIZE szAuto = pOleControlProcesser->CalcSizeByAutoLayout(hDC, nMaxWidth, nMaxHeight);
	LONG xPerInch = GetDeviceCaps(hDC, LOGPIXELSX); 
	LONG yPerInch =	GetDeviceCaps(hDC, LOGPIXELSY);
	szTransfer.cx = DXtoHimetricX(szAuto.cx, xPerInch);
	szTransfer.cy = DYtoHimetricY(szAuto.cy, yPerInch);
	::ReleaseDC(m_hWndDirectUI, hDC);

	// ����ole����ߴ�
	CComPtr<IRichEditOle> pReo;
	GetIRichEditOle(&pReo);
	if(NULL == pReo)
	{
		return;
	}

	long lCount = pReo->GetObjectCount();
	for (long i = 0; i < lCount; ++i)
	{
		REOBJECT reObject;
		memset(&reObject, 0, sizeof(REOBJECT));
		reObject.cbStruct = sizeof(REOBJECT);
		pReo->GetObject(i, &reObject, REO_GETOBJ_NO_INTERFACES);

		if (reObject.dwUser != dwOleID)
		{
			continue;
		}

		CPoint ptObject = m_FreeWindowlessRE.PosFromChar(reObject.cp);
		if (ptObject.x < 0)
		{
			continue;
		}

		CComPtr<IOleClientSite> lpClientSite;
		pReo->GetClientSite(&lpClientSite);

		//��¼ԭ��ѡ������
		CHARRANGE curSelRange;
		GetSel(curSelRange);

		//ѡ���޸Ķ���
		m_FreeWindowlessRE.SetSel(reObject.cp, reObject.cp + 1, false);

		//����Ole����
		REOBJECT reModify;
		memset(&reModify, 0, sizeof(REOBJECT));
		reModify.cbStruct = sizeof(REOBJECT);
		reModify.cp = REO_CP_SELECTION;
		reModify.dvaspect = DVASPECT_CONTENT;
		reModify.poleobj = NULL;
		reModify.polesite = lpClientSite;
		reModify.pstg = NULL;
		reModify.sizel = szTransfer;
		reModify.dwUser = reObject.dwUser;
		reModify.dwFlags = REO_BELOWBASELINE;

		if (S_OK == pReo->InsertObject(&reModify))
		{
			reObject.sizel = reModify.sizel;
		}

		//��ԭԭ��ѡ������
		SetSel(curSelRange, true);

		break;
	}

	BufferedReDraw();
}

DWORD CUISendRichEdit::InsertOleControl(LPCTSTR lpOleEleName, int nWidth, int nHeight, DWORD dwOleID)
{
	HRESULT hr;
	hr = ::CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
	if (FAILED(hr)) //S_OK��ʼ���ɹ���S_FALSE�ظ���ʼ����RPC_E_CHANGED_MODE
	{
		return -1;
	}

	CComPtr<IRichEditOle> pReo;
	GetIRichEditOle(&pReo);
	if (!pReo)
	{
		return -1;
	}

	CIMControlProcesser* pOleControlProcesser = new CIMControlProcesser;
	if (!pOleControlProcesser)
	{
		return -1;
	}

	//��ʼ��Ole��չ�ؼ�
	pOleControlProcesser->EnableAutoSize(FALSE);
	pOleControlProcesser->SetSize(nWidth, nHeight);

	CRichElementBase* pOleControlEle = GetOleEleExModalByName(lpOleEleName);
	if (pOleControlEle)
	{
		pOleControlProcesser->SetControlElement(pOleControlEle);
	}

	//Pixels��Ӣ��ı�������
	HDC hDC = ::GetDC(m_hWndDirectUI);
	LONG xPerInch = GetDeviceCaps(hDC, LOGPIXELSX); 
	LONG yPerInch =	GetDeviceCaps(hDC, LOGPIXELSY); 
	::ReleaseDC(m_hWndDirectUI, hDC);

	//��������(��λΪ�, 1�Ϊ1440Ӣ��, xPerInchˮƽ���ص�Ϊ1Ӣ��)
	PARAFORMAT2 paraFormat;
	paraFormat.cbSize = sizeof(PARAFORMAT2);
	paraFormat.dwMask = PFM_ALIGNMENT|PFM_STARTINDENT|PFM_OFFSETINDENT|PFM_RIGHTINDENT;
	m_FreeWindowlessRE.GetParaFormat(paraFormat);

	//Pixelsת��ΪӢ��
	SIZE szTransfer;
	szTransfer.cx = DXtoHimetricX(nWidth, xPerInch);
	szTransfer.cy = DYtoHimetricY(nHeight, yPerInch);

	//����Ole����
	CComPtr<IOleClientSite> lpClientSite;
	pReo->GetClientSite(&lpClientSite);

	REOBJECT reobject;
	ZeroMemory(&reobject, sizeof(REOBJECT));
	reobject.cbStruct = sizeof(REOBJECT);
	reobject.cp = REO_CP_SELECTION;
	reobject.dvaspect = DVASPECT_CONTENT;
	reobject.poleobj = NULL;
	reobject.polesite = lpClientSite;
	reobject.pstg = NULL;
	reobject.sizel = szTransfer;
	reobject.dwUser = AddOleData(pOleControlProcesser, dwOleID);
	reobject.dwFlags = REO_BELOWBASELINE;

	if (pReo->InsertObject(&reobject) != S_OK)
	{
		RemoveOleData(dwOleID);
	}

	return dwOleID;
}

void CUISendRichEdit::OnMouseEnterOleControlElement(DWORD dwOleID, LPCTSTR lpOleControlName, CRichElementBase* pMouseEnterEle, DWORD_PTR dwUserData)
{
	if (!pMouseEnterEle)
	{
		return;
	}

	WTL::CString strToolTips = pMouseEnterEle->GetToolTips();
	if (strToolTips.GetLength() > 0 && m_hWndDirectUI)
	{
		::SendMessage(m_hWndDirectUI, WM_SETTOOPTIP, (WPARAM)(LPCTSTR)strToolTips, (LPARAM)this);
	}

	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_OLE_CONTROL_MOUSEENTER_ELEMENT;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	UINotifyInfo.lParam2 = (DWORD_PTR)dwOleID;
	UINotifyInfo.lParam3 = (DWORD_PTR)lpOleControlName;
	UINotifyInfo.lParam4 = (DWORD_PTR)pMouseEnterEle->GetName();
	UINotifyInfo.lParam5 = (DWORD_PTR)dwUserData;
	::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&UINotifyInfo, 0);
}

void CUISendRichEdit::OnMouseLeaveOleControlElement(DWORD dwOleID, LPCTSTR lpOleControlName, CRichElementBase* pMouseLeaveEle, DWORD_PTR dwUserData)
{
	if (!pMouseLeaveEle)
	{
		return;
	}

	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_OLE_CONTROL_MOUSELEAVE_ELEMENT;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	UINotifyInfo.lParam2 = (DWORD_PTR)dwOleID;
	UINotifyInfo.lParam3 = (DWORD_PTR)lpOleControlName;
	UINotifyInfo.lParam4 = (DWORD_PTR)pMouseLeaveEle->GetName();
	UINotifyInfo.lParam5 = (DWORD_PTR)dwUserData;
	::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&UINotifyInfo, 0);
}

void CUISendRichEdit::OnLButtonDownOleControlElement(DWORD dwOleID, LPCTSTR lpOleControlName, CRichElementBase* pClickedEle, DWORD_PTR dwUserData)
{
	if (!pClickedEle)
	{
		return;
	}

	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_OLE_CONTROL_LBUTTONDOWN_ELEMENT;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	UINotifyInfo.lParam2 = (DWORD_PTR)dwOleID;
	UINotifyInfo.lParam3 = (DWORD_PTR)lpOleControlName;
	UINotifyInfo.lParam4 = (DWORD_PTR)pClickedEle->GetName();
	UINotifyInfo.lParam5 = (DWORD_PTR)dwUserData;
	::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&UINotifyInfo, 0);
}

void CUISendRichEdit::OnLButtonUpOleControlElement(DWORD dwOleID, LPCTSTR lpOleControlName, CRichElementBase* pClickedEle, DWORD_PTR dwUserData)
{
	if (!pClickedEle)
	{
		return;
	}

	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_OLE_CONTROL_LBUTTONUP_ELEMENT;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	UINotifyInfo.lParam2 = (DWORD_PTR)dwOleID;
	UINotifyInfo.lParam3 = (DWORD_PTR)lpOleControlName;
	UINotifyInfo.lParam4 = (DWORD_PTR)pClickedEle->GetName();
	UINotifyInfo.lParam5 = (DWORD_PTR)dwUserData;
	::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&UINotifyInfo, 0);
}

void CUISendRichEdit::ClearAllOleEleExModal()
{
	for (int i = 0; i < OLE_ELEEX_MODAL_MAX; ++i)
	{
		m_pOleElementExModalArray[i].strEleName = _T("");
		m_pOleElementExModalArray[i].pEditProp = NULL;
		SAFE_DELETE(m_pOleElementExModalArray[i].pElement);
	}
}

CRichElementBase* CUISendRichEdit::GetOleEleExModalByName(LPCTSTR lpEleName)
{
	if (!lpEleName)
	{
		return NULL;
	}

	for (int i = 0; i < OLE_ELEEX_MODAL_MAX; ++i)
	{
		if (lpEleName == m_pOleElementExModalArray[i].strEleName)
		{
			return m_pOleElementExModalArray[i].pElement;
		}
	}

	return NULL;
}

CRichElementBase* CUISendRichEdit::GetOleEleExModalByIndex(int nIndex)
{
	if (nIndex < 0 || nIndex >= OLE_ELEEX_MODAL_MAX)
	{
		return NULL;
	}

	return m_pOleElementExModalArray[nIndex].pElement;
}

void CUISendRichEdit::CloneOleEleExModal(int nIndex, CRichElementBase* pElementFrom)
{
	if (nIndex < 0 || nIndex >= OLE_ELEEX_MODAL_MAX)
	{
		return;
	}

	if (!pElementFrom)
	{
		return;
	}

	if (m_pOleElementExModalArray[nIndex].pElement)
	{
		SAFE_DELETE(m_pOleElementExModalArray[nIndex].pElement);
	}

	m_pOleElementExModalArray[nIndex].pElement = pElementFrom->Clone();
	m_pOleElementExModalArray[nIndex].strEleName = pElementFrom->GetName();
}

BOOL CUISendRichEdit::AccessOleEleExModalConfig(XMLNodePtr pXmlNode, int nIndex, BOOL bRead)
{
	if (nIndex < 0 || nIndex >= OLE_ELEEX_MODAL_MAX)
	{
		return FALSE;
	}

	if(NULL == pXmlNode)
	{
		return FALSE;
	}

	char szXmlEleName[256] = {0};
#if (_MSC_VER > 1310) && !defined(_MSVCVER60) // VS2005
	sprintf_s(szXmlEleName, "ItemElementInfo%d", nIndex);
#else
	sprintf(szXmlEleName, "ItemElementInfo%d", nIndex);
#endif

	XMLNodePtr pItemEleXMLInfo = (XMLNodePtr)pXmlNode->FirstChild(szXmlEleName);
	if (NULL == pItemEleXMLInfo && GetDUIRes() && GetDUIRes()->IsDesignStatus())
	{
		pItemEleXMLInfo = new TiXmlElement(szXmlEleName);
		pXmlNode->InsertEndChild(*pItemEleXMLInfo);
	}
	if (NULL == pItemEleXMLInfo)
	{
		return FALSE;
	}

	if (bRead)
	{
		TiXmlNode* pNodeChild = pItemEleXMLInfo->FirstChild();
		if (NULL == pNodeChild)
		{
			return FALSE;
		}

		XMLNodePtr pItemEleMainNode = pNodeChild->ToElement();
		if (NULL == pItemEleMainNode)
		{
			return FALSE;
		}

		if (m_pOleElementExModalArray[nIndex].pElement)
		{
			SAFE_DELETE(m_pOleElementExModalArray[nIndex].pElement);
		}
		m_pOleElementExModalArray[nIndex].pElement = CRichElementBase::CreateElementByXml(GetDUIRes(), pItemEleMainNode);
		if (NULL == m_pOleElementExModalArray[nIndex].pElement)
		{
			return FALSE;
		}

		CUITextStyleCom* pTextStyle = NULL;
		if (m_pOleElementExModalArray[nIndex].pEleTextStyle)
		{
			pTextStyle = m_pOleElementExModalArray[nIndex].pEleTextStyle->GetValue2();
		}
		m_pOleElementExModalArray[nIndex].pElement->AccessConfig(pTextStyle, pItemEleMainNode, TRUE);

		m_pOleElementExModalArray[nIndex].strEleName = m_pOleElementExModalArray[nIndex].pElement->GetName();
	}
	else
	{
		TiXmlNode* pNodeChild = pItemEleXMLInfo->FirstChild();
		while (pNodeChild)
		{
			pItemEleXMLInfo->RemoveChild(pNodeChild);
			pNodeChild = pItemEleXMLInfo->FirstChild();
		}

		if (NULL == m_pOleElementExModalArray[nIndex].pElement)
		{
			return FALSE;
		}

		XMLNodePtr pItemEleMainNode = new TiXmlElement(m_pOleElementExModalArray[nIndex].pElement->GetName());
		pItemEleXMLInfo->InsertEndChild(*pItemEleMainNode);

		if (NULL == pItemEleMainNode)
		{
			return FALSE;
		}

		CUITextStyleCom* pTextStyle = NULL;
		if (m_pOleElementExModalArray[nIndex].pEleTextStyle)
		{
			pTextStyle = m_pOleElementExModalArray[nIndex].pEleTextStyle->GetValue2();
		}
		m_pOleElementExModalArray[nIndex].pElement->AccessConfig(pTextStyle, pItemEleMainNode, FALSE);
	}

	return TRUE;
}

void CUISendRichEdit::EditOleEleExModal(int nIndex, LPTSTR lpResultEleName, int nMaxCount, BOOL& bResult)
{
#ifndef _EXCLUDE_RESOURCE
	if (lpResultEleName)
	{
		memset(lpResultEleName, 0, sizeof(TCHAR)*nMaxCount);
	}

	if (nIndex < 0 || nIndex >= OLE_ELEEX_MODAL_MAX)
	{
		return;
	}

	//��Ϣ�������
	bResult = TRUE;

	//��ǰԪ�ص�����
	CUITextStyleCom* pItemTextStyle = NULL;
	if (m_pOleElementExModalArray[nIndex].pEleTextStyle)
	{
		pItemTextStyle = m_pOleElementExModalArray[nIndex].pEleTextStyle->GetValue2();
	}

	//��ǰԪ�ظ߶�
	int nItemHeight = 60;
	if (m_pOleElementExModalArray[nIndex].pEleHeight)
	{
		nItemHeight = m_pOleElementExModalArray[nIndex].pEleHeight->GetValue();
	}

	//���õ�ǰԪ�����ݵ��༭����
	CRichTreeItemElementEditDlg dlg;
	dlg.SetUIRes(GetDUIRes());
	dlg.SetTextStyle(pItemTextStyle);
	dlg.SetItemHeight(nItemHeight);
	if (m_pOleElementExModalArray[nIndex].pElement)
	{
		dlg.SetRootElement(m_pOleElementExModalArray[nIndex].pElement->Clone());
	}
	else
	{
		dlg.SetRootElement(NULL);
	}

	//���±༭�������ǰԪ����
	if (IDOK == dlg.DoModal())
	{
		// ɾ��ԭ���ĸ��ڵ�Ԫ��ģ��
		SAFE_DELETE(m_pOleElementExModalArray[nIndex].pElement);

		// �����µĸ��ڵ�Ԫ��ģ��
		CRichElementBase* pResultElement = dlg.GetResultElement();
		if (pResultElement)
		{
			m_pOleElementExModalArray[nIndex].pElement = pResultElement->Clone();
		}
		else
		{
			m_pOleElementExModalArray[nIndex].pElement = NULL;
		}

		AccessOleEleExModalConfig((XMLNodePtr)GetXMLNode(), nIndex, FALSE);
	}

	//����Ԫ�����Ƶ��༭������
	WTL::CString strItemPropDesc = _T("None");
	if (m_pOleElementExModalArray[nIndex].pElement)
	{
		strItemPropDesc = m_pOleElementExModalArray[nIndex].pElement->GetName();
	}
	_tcsncpy(lpResultEleName, strItemPropDesc, nMaxCount);
#endif
}

void CUISendRichEdit::SaveOleEleExModalXmlNode()
{
	for (int i = 0; i < OLE_ELEEX_MODAL_MAX; ++i)
	{
		AccessOleEleExModalConfig((XMLNodePtr)GetXMLNode(), i, FALSE);
	}
}