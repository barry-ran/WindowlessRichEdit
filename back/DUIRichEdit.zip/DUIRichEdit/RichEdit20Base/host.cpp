#include "stdafx.h"
#include <imm.h>
#include <tchar.h>
#include <windows.h>
#include <stddef.h>
#include <windowsx.h>
#include "richedit.h"
#include <memory.h>
#include "tstxtsrv.h"
#include "host.h"

#define HOST_BORDER 0

BOOL fInAssert = FALSE;

// HIMETRIC units per inch (used for conversion)
#define HIMETRIC_PER_INCH 2540

// Convert Himetric along the X axis to X pixels
LONG HimetricXtoDX(LONG xHimetric, LONG xPerInch)
{
	return (LONG) MulDiv(xHimetric, xPerInch, HIMETRIC_PER_INCH);
}

// Convert Himetric along the Y axis to Y pixels
LONG HimetricYtoDY(LONG yHimetric, LONG yPerInch)
{
	return (LONG) MulDiv(yHimetric, yPerInch, HIMETRIC_PER_INCH);
}

// Convert Pixels on the X axis to Himetric
LONG DXtoHimetricX(LONG dx, LONG xPerInch)
{
	return (LONG) MulDiv(dx, HIMETRIC_PER_INCH, xPerInch);
}

// Convert Pixels on the Y axis to Himetric
LONG DYtoHimetricY(LONG dy, LONG yPerInch)
{
	return (LONG) MulDiv(dy, HIMETRIC_PER_INCH, yPerInch);
}


// These constants are for backward compatibility. They are the 
// sizes used for initialization and reset in RichEdit 1.0

const LONG cInitTextMax = (32 * 1024) - 1;
const LONG cResetTextMax = (64 * 1024);


#define ibPed 0
#define SYS_ALTERNATE 0x20000000

INT	cxBorder, cyBorder;	    // GetSystemMetricx(SM_CXBORDER)...
INT	cxDoubleClk, cyDoubleClk;   // Double click distances
INT	cxHScroll, cxVScroll;	    // Width/height of scrlbar arw bitmap
INT	cyHScroll, cyVScroll;	    // Width/height of scrlbar arw bitmap
INT	dct;			    // Double Click Time in milliseconds
INT     nScrollInset;
COLORREF crAuto = 0;

LONG CTxtWinHost::xWidthSys = 0;    		            // average char width of system font
LONG CTxtWinHost::yHeightSys = 0;				// height of system font
LONG CTxtWinHost::yPerInch = 0;				// y pixels per inch
LONG CTxtWinHost::xPerInch = 0;				// x pixels per inch

EXTERN_C const IID IID_ITextServices = { /* 8d33f740-cf58-11ce-a89d-00aa006cadc5 */
	0x8d33f740,
	0xcf58,
	0x11ce,
	{0xa8, 0x9d, 0x00, 0xaa, 0x00, 0x6c, 0xad, 0xc5}
};

EXTERN_C const IID IID_ITextHost = { /* c5bdd8d0-d26e-11ce-a89e-00aa006cadc5 */ 
	0xc5bdd8d0,
	0xd26e,
	0x11ce,
	{0xa8, 0x9e, 0x00, 0xaa, 0x00, 0x6c, 0xad, 0xc5}
};


EXTERN_C const IID IID_ITextEditControl = { /* f6642620-d266-11ce-a89e-00aa006cadc5 */
	0xf6642620,
	0xd266,
	0x11ce,
	{0xa8, 0x9e, 0x00, 0xaa, 0x00, 0x6c, 0xad, 0xc5}
};

void GetSysParms(void)
{
	crAuto		= GetSysColor(COLOR_WINDOWTEXT);
	cxBorder	= GetSystemMetrics(SM_CXBORDER);	// Unsizable window border
	cyBorder	= GetSystemMetrics(SM_CYBORDER);	//  widths
	cxHScroll	= GetSystemMetrics(SM_CXHSCROLL);	// Scrollbar-arrow bitmap 
	cxVScroll	= GetSystemMetrics(SM_CXVSCROLL);	//  dimensions
	cyHScroll	= GetSystemMetrics(SM_CYHSCROLL);	//
	cyVScroll	= GetSystemMetrics(SM_CYVSCROLL);	//
	cxDoubleClk	= GetSystemMetrics(SM_CXDOUBLECLK);
	cyDoubleClk	= GetSystemMetrics(SM_CYDOUBLECLK);
	dct			= GetDoubleClickTime();

	nScrollInset =
		GetProfileIntA( "windows", "ScrollInset", DD_DEFSCROLLINSET );
}

HRESULT InitDefaultCharFormat(CHARFORMATW* pcf, HFONT hfont) 
{
	if (!pcf)
	{
		return E_FAIL;
	}

	if (!hfont)
	{
		hfont = (HFONT)GetStockObject(SYSTEM_FONT);
	}

	LOGFONT lf;
	if (!GetObject(hfont, sizeof(LOGFONT), &lf))
	{
		return E_FAIL;
	}

	pcf->cbSize = sizeof(CHARFORMAT2);

	//��������߶�
	HWND hwnd = GetDesktopWindow();
	HDC hdc = GetDC(hwnd);
	LONG yPixPerInch = GetDeviceCaps(hdc, LOGPIXELSY);

	//��ȡ����DPI��ֵ�쳣ʱ,ʹ��ȱʡֵ,�������Ϊ��
	if (0 == yPixPerInch)
	{
		yPixPerInch = 96;
	}

	pcf->yHeight = lf.lfHeight * LY_PER_INCH / yPixPerInch;
	ReleaseDC(hwnd, hdc);

	//��ʼ��������ʽ
	pcf->yOffset = 0;
	pcf->crTextColor = crAuto;

	pcf->dwEffects = CFM_EFFECTS | CFE_AUTOBACKCOLOR;
	pcf->dwEffects &= ~(CFE_PROTECTED | CFE_LINK);

	if(lf.lfWeight < FW_BOLD)
	{
		pcf->dwEffects &= ~CFE_BOLD;
	}
	if(!lf.lfItalic)
	{
		pcf->dwEffects &= ~CFE_ITALIC;
	}
	if(!lf.lfUnderline)
	{
		pcf->dwEffects &= ~CFE_UNDERLINE;
	}
	if(!lf.lfStrikeOut)
	{
		pcf->dwEffects &= ~CFE_STRIKEOUT;
	}

	pcf->dwMask = CFM_ALL | CFM_BACKCOLOR;
	pcf->bCharSet = lf.lfCharSet;
	pcf->bPitchAndFamily = lf.lfPitchAndFamily;

#ifdef UNICODE
	_tcsncpy_s(pcf->szFaceName, lf.lfFaceName, LF_FACESIZE);
#else
	//need to thunk pcf->szFaceName to a standard char string.in this case it's easy because our thunk is also our copy
	MultiByteToWideChar(CP_ACP, 0, lf.lfFaceName, LF_FACESIZE, pcf->szFaceName, LF_FACESIZE) ;
#endif

	return S_OK;
}

HRESULT InitDefaultParaFormat(PARAFORMAT * ppf) 
{	
	memset(ppf, 0, sizeof(PARAFORMAT));

	ppf->cbSize = sizeof(PARAFORMAT);
	ppf->dwMask = PFM_ALL;
	ppf->wAlignment = PFA_LEFT;
	ppf->cTabCount = 1;
	ppf->rgxTabs[0] = lDefaultTab;

	return S_OK;
}

LRESULT MapHresultToLresult(HRESULT hr, UINT msg)
{
	LRESULT lres = hr;

	switch(msg)
	{
	case EM_GETMODIFY:
		lres = (hr == S_OK) ? -1 : 0;
		break;
	case EM_UNDO:
	case WM_UNDO:
	case EM_CANUNDO:
	case EM_CANPASTE:
	case EM_LINESCROLL:
		lres = (hr == S_OK) ? TRUE : FALSE;
		break;
	case EM_EXLINEFROMCHAR:
	case EM_LINEFROMCHAR:
		lres = SUCCEEDED(hr) ? (LRESULT) hr : 0;
		break;
	case EM_LINEINDEX:
		lres = SUCCEEDED(hr) ? (LRESULT) hr : -1;
		break;	

	default:
		lres = (LRESULT) hr;		
	}

	return lres;
}

BOOL GetIconic(HWND hwnd) 
{
	while(hwnd)
	{
		if(::IsIconic(hwnd))
			return TRUE;
		hwnd = GetParent(hwnd);
	}
	return FALSE;
}

stMicroYaheiSupport CTxtWinHost::m_microYaheiSupport;
CAutoDll CTxtWinHost::m_RichEditDll;
CSafeOleInitialize CTxtWinHost::m_safeOleInitialize;
std::map<HWND, CDragDropRegInfo> CTxtWinHost::m_dragDropRegMap;
std::list<IRichEditMsgProc*> CTxtWinHost::m_HostCtrolColl;

CTxtWinHost::CTxtWinHost()
{
	ZeroMemory(&pnc, sizeof(CTxtWinHost) - offsetof(CTxtWinHost, pnc));

	cchTextMost = cInitTextMax;

	laccelpos = -1;

	fVisible = 1;

	m_bRemoveScrollBar = TRUE;

	m_hostSate = eHostSate_UnInited;

	m_hContextDevice = NULL;

	m_bIMFAutoFontEnabled = TRUE;

	memset(&m_CaretInfo, 0, sizeof(m_CaretInfo));

	m_pIRichEditMsgProc = NULL;
}

CTxtWinHost::~CTxtWinHost()
{
	//��host����ӹ����������Ƴ�
	std::list<IRichEditMsgProc*>::iterator it  = m_HostCtrolColl.begin();
	for (; it != m_HostCtrolColl.end(); ++it)
	{
		if (m_pIRichEditMsgProc == *it)
		{
			m_HostCtrolColl.erase(it);
			break;
		}
	}

	if (m_CaretInfo.hCaret)
	{
		::DeleteObject(m_CaretInfo.hCaret);
		m_CaretInfo.hCaret = NULL;
	}

	if (m_CaretInfo.hCoveredBk)
	{
		::DeleteObject(m_CaretInfo.hCoveredBk);
		m_CaretInfo.hCoveredBk = NULL;
	}

	if (m_CaretInfo.hDC)
	{
		::DeleteObject(m_CaretInfo.hDC);
		m_CaretInfo.hDC = NULL;
	}

	RevokeDragDrop();

	if (m_hostSate != eHostSate_InitedFailed)
	{
		pserv->OnTxInPlaceDeactivate();
		pserv->Release();
	}
}

BOOL CTxtWinHost::Init(HWND h_wnd, const CREATESTRUCT *pcs, PNOTIFY_CALL p_nc, IRichEditMsgProc* pMsgProc)
{
	cRefs = 1;
	pnc = p_nc;
	hwnd = h_wnd;
	m_pIRichEditMsgProc = pMsgProc;

	HDC hWndDC = GetDC(hwnd);
	if (!hWndDC)
	{
		goto err;
	}

	// ��ʼ��ȱʡ������ʽ
	HRESULT hr = InitDefaultCharFormat(&cf, NULL);
	if (S_OK != hr)
	{
		goto err;
	}

	// ��ʼ��ȱʡ������ʽ
	hr = InitDefaultParaFormat(&pf);
	if (S_OK != hr)
	{
		goto err;
	}

	// ���û�������
	dwStyle = ES_MULTILINE;
	fHidden = TRUE;
	fRich = TRUE;

	if(pcs)
	{
		hwndParent = pcs->hwndParent;
		dwExStyle = pcs->dwExStyle;
		dwStyle = pcs->style;

		fBorder = (dwStyle & WS_BORDER);

		if(dwStyle & ES_SUNKEN)
		{
			fBorder = TRUE;
		}

		if (!(dwStyle & (ES_AUTOHSCROLL | WS_HSCROLL)))
		{
			fWordWrap = TRUE;
		}
	}

	if(!(dwStyle & ES_LEFT))
	{
		if(dwStyle & ES_CENTER)
		{
			pf.wAlignment = PFA_CENTER;
		}
		else if(dwStyle & ES_RIGHT)
		{
			pf.wAlignment = PFA_RIGHT;
		}
	}

	// ��ʼ��ϵͳ����/��λ
	HFONT hFontOld = (HFONT)SelectObject(hWndDC, (HFONT)GetStockObject(SYSTEM_FONT));
	TEXTMETRIC tm;
	GetTextMetrics(hWndDC, &tm);
	SelectObject(hWndDC, hFontOld);

	xWidthSys = (INT) tm.tmAveCharWidth;
	yHeightSys = (INT) tm.tmHeight;
	xPerInch = GetDeviceCaps(hWndDC, LOGPIXELSX);
	yPerInch =	GetDeviceCaps(hWndDC, LOGPIXELSY);

	// ����ÿ��������Ӣ��ȱʡ�Ķ�Ӧ��ϵ
	SetDefaultInset();

	// ȱʡ����״̬
	fInplaceActive = TRUE;

	// ����RichEdit����
	if (m_RichEditDll.IsNull())
	{
		m_RichEditDll.Init(_T("riched20.dll"));
	}
	
	IUnknown* pUnk = NULL;
	if (m_RichEditDll.GetMoudle())
	{
		typedef HRESULT (_stdcall *PFNCTS)(__in_opt IUnknown *punkOuter, __in ITextHost *pth, __deref_out IUnknown **ppunk);
		PFNCTS pfn = (PFNCTS)GetProcAddress(m_RichEditDll.GetMoudle(), "CreateTextServices");
		if (pfn)
		{
			hr = pfn(NULL, this, &pUnk);
		}
	}
	if (!pUnk)
	{
		goto err;
	}

	// ��ȡRichEdit����ӿ�
	hr = pUnk->QueryInterface(IID_ITextServices,(void **)&pserv);
	pUnk->Release();
	if (S_OK != hr)
	{
		goto err;
	}

	//�����������Ƶ�RichEdit
	if(pcs && pcs->lpszName)
	{
#ifdef UNICODE
		hr = pserv->TxSetText((TCHAR *)pcs->lpszName);
		if (S_OK != hr)
		{
			goto err;
		}
#else
		//have to thunk the string to a unicode string.
		WCHAR wsz_name[MAX_PATH] ;
		ZeroMemory(wsz_name, MAX_PATH *sizeof WCHAR) ;
		MultiByteToWideChar(CP_ACP, 0, pcs->lpszName, lstrlen(pcs->lpszName),(LPWSTR)&wsz_name, MAX_PATH) ;
		if(FAILED(pserv->TxSetText((LPWSTR)&wsz_name)))
		{
			got err;
		}
#endif
	}

	//����RichEditλ����߿�
	rcClient.left = pcs->x;
	rcClient.top = pcs->y;
	rcClient.right = pcs->x + pcs->cx;
	rcClient.bottom = pcs->y + pcs->cy;

	//�Ȳ���ʾscrollbar
	if(hwnd && !(dwStyle & ES_DISABLENOSCROLL))
	{
		LONG dwStyle = GetWindowLong(hwnd, GWL_STYLE);
		if (dwStyle & WS_VSCROLL)
		{
			//...
		}
		if (dwStyle & WS_HSCROLL)
		{
			//...
		}
	}

	sizelExtent.cx = DXtoHimetricX(rcClient.right - rcClient.left - 2 * HOST_BORDER, xPerInch);
	sizelExtent.cy = DYtoHimetricY(rcClient.bottom - rcClient.top - 2 * HOST_BORDER, yPerInch);

	hr = pserv->OnTxInPlaceActivate(&rcClient);
	if (S_OK != hr)
	{
		goto err;
	}

	//����RichEdit����״̬
	m_hostSate = eHostSate_Usable;

	//ѹ��host�����������
	m_HostCtrolColl.push_back(pMsgProc);

	//��ʽ����
	pserv->TxSendMessage(EM_SETEDITSTYLE, SES_USECTF, SES_USECTF, NULL);

	//����ѡ������
	LRESULT lLanOptions = 0;
	m_bIMFAutoFontEnabled = TRUE;
	pserv->TxSendMessage(EM_GETLANGOPTIONS, 0, 0, &lLanOptions);
	lLanOptions |= IMF_AUTOFONT;
	pserv->TxSendMessage(EM_SETLANGOPTIONS, 0, lLanOptions, NULL);

	//���΢���ź�
	if (!m_microYaheiSupport.m_bChecked)
	{
		HDC hDC = ::GetDC(NULL);
		if (hDC)
		{
			EnumFonts(hDC, NULL, (FONTENUMPROC)EnumFontProc, (LPARAM)this);
			m_microYaheiSupport.m_bChecked = TRUE;
			::ReleaseDC(NULL, hDC);
		}
	}

	if (hWndDC)
	{
		::ReleaseDC(hwnd, hWndDC);
	}

	return TRUE;

err:
	if (hWndDC)
	{
		::ReleaseDC(hwnd, hWndDC);
	}
	m_hostSate = eHostSate_InitedFailed;

	return FALSE;
}


/////////////////////////////////  IUnknown ////////////////////////////////


HRESULT CTxtWinHost::QueryInterface(REFIID riid, void **ppvObject)
{
	HRESULT hr = E_NOINTERFACE;
	*ppvObject = NULL;

	if (IsEqualIID(riid, IID_ITextEditControl))
	{
		*ppvObject = (ITextEditControl *) this;
		AddRef();
		hr = S_OK;
	}
	else if (IsEqualIID(riid, IID_IUnknown) 
		|| IsEqualIID(riid, IID_ITextHost)) 
	{
		AddRef();
		*ppvObject = (ITextHost *) this;
		hr = S_OK;
	}

	return hr;
}

ULONG CTxtWinHost::AddRef(void)
{
	return ++cRefs;
}

ULONG CTxtWinHost::Release(void)
{
	ULONG c_Refs = --cRefs;

	if (c_Refs == 0)
	{
		delete this;
	}

	return c_Refs;
}


//////////////////////////////// Properties ////////////////////////////////


TXTEFFECT CTxtWinHost::TxGetEffects() const
{
	return (dwStyle & ES_SUNKEN) ? TXTEFFECT_SUNKEN : TXTEFFECT_NONE;
}


//////////////////////////// System API wrapper ////////////////////////////



///////////////////////  Windows message dispatch methods  ///////////////////////////////

LRESULT CTxtWinHost::TxWindowProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	LRESULT	lres = 0;
	HRESULT hr;

	if (eHostSate_InitedFailed == m_hostSate)
		return lres;

	switch(msg)
	{
	case WM_NCCALCSIZE:
		{
			// �ᵼ�¹�������ʾ�����ݲ�����
			return S_MSG_KEY_IGNORED;
			GetSysParms();
		}
		break;
	case WM_KEYDOWN:
		{
			lres = OnKeyDown((WORD) wparam, (DWORD) lparam);
			if(lres != 0)
				goto serv;
		}
		break;
	case WM_CHAR:
		{
			lres = OnChar((WORD) wparam, (DWORD) lparam);
			if(lres != 0)
			{
				goto serv;
			}
		}
		break;
	case WM_SYSCOLORCHANGE:
		{
			OnSysColorChange();
			goto serv;
		}
		break;
	case WM_GETDLGCODE:
		{
			lres = OnGetDlgCode(wparam, lparam);
		}
		break;
	case EM_HIDESELECTION:
		{
			if((BOOL)lparam)
			{
				DWORD dwPropertyBits = 0;

				if((BOOL)wparam)
				{
					dwStyle &= ~(DWORD) ES_NOHIDESEL;
					dwPropertyBits = TXTBIT_HIDESELECTION;
				}
				else
					dwStyle |= ES_NOHIDESEL;

				// Notify text services of change in status.
				pserv->OnTxPropertyBitsChange(TXTBIT_HIDESELECTION, 
					dwPropertyBits);
			}

			goto serv;
		}
		break;
	case EM_LIMITTEXT:
		{
			lparam = wparam;
		}
	case EM_EXLIMITTEXT:
		{
			if (lparam == 0)
			{
				// 0 means set the control to the maximum size. However, because
				// 1.0 set this to 64K will keep this the same value so as not to
				// supprise anyone. Apps are free to set the value to be above 64K.
				lparam = (LPARAM) cResetTextMax;
			}

			cchTextMost = (LONG) lparam;
			pserv->OnTxPropertyBitsChange(TXTBIT_MAXLENGTHCHANGE, 
				TXTBIT_MAXLENGTHCHANGE);
		}
		break;
	case EM_SETREADONLY:
		{
			OnSetReadOnly(BOOL(wparam));
			lres = 1;
		}
		break;
	case EM_GETEVENTMASK:
		{
			lres = OnGetEventMask();
		}
		break;
	case EM_SETEVENTMASK:
		{
			OnSetEventMask((DWORD) lparam);
			goto serv;
		}
		break;
	case EM_GETOPTIONS:
		{
			lres = OnGetOptions();
		}
		break;
	case EM_SETOPTIONS:
		{
			OnSetOptions((WORD) wparam, (DWORD) lparam);
			lres = (dwStyle & ECO_STYLES);
			if(fEnableAutoWordSel)
				lres |= ECO_AUTOWORDSELECTION;
		}
		break;
	case WM_SETFONT:
		{
			lres = OnSetFont((HFONT) wparam);
		}
		break;
	case EM_SETRECT:
		{
			OnSetRect((LPRECT)lparam);
		}
		break;
	case EM_GETRECT:
		{
			OnGetRect((LPRECT)lparam);
		}
		break;
	case EM_SETBKGNDCOLOR:
		{
			lres = (LRESULT) crBackground;
			fNotSysBkgnd = !wparam;
			crBackground = (COLORREF) lparam;

			if(wparam)
				crBackground = GetSysColor(COLOR_WINDOW);

			// Notify the text services that color has changed
			pserv->TxSendMessage(WM_SYSCOLORCHANGE, 0, 0, 0);

			if(lres != (LRESULT) crBackground)
				TxInvalidateRect(NULL, TRUE);
		}
		break;
	case EM_REPLACESEL:
		{
			GETTEXTLENGTHEX getTextLenEx;
			getTextLenEx.flags = GTL_DEFAULT;
			getTextLenEx.codepage = 1200;
			hr = pserv->TxSendMessage(EM_GETTEXTLENGTHEX, (WPARAM)&(getTextLenEx), 0, &lres);
 			if (hr != S_OK)
 			{
 				break;
 			}

			LPCTSTR lpszReplace = (LPCTSTR)lparam;
			if (static_cast<long>(lres) >= cchTextMost)
			{
				long nNewContentLen = _tcslen(lpszReplace);

				CHARRANGE crSel;
				pserv->TxSendMessage(EM_EXGETSEL, 0, (LPARAM)&crSel, 0);
				long nSelContentLen = crSel.cpMax - crSel.cpMin;

				if (nNewContentLen <= nSelContentLen)
				{
					hr = pserv->TxSendMessage(msg, wparam, (LPARAM)lpszReplace, &lres);
				}
				else
				{
					return 0;
				}
			}
			else
			{
				if (static_cast<long>(lres) + (long)_tcslen(lpszReplace) >= cchTextMost)
 				{
					long nCpyCount = cchTextMost - static_cast<long>(lres);
					TCHAR* pReplatChar = new TCHAR[nCpyCount + 1];
					wcsncpy(pReplatChar, lpszReplace, nCpyCount);
					pReplatChar[nCpyCount] = 0;
					hr = pserv->TxSendMessage(msg, wparam, (LPARAM)pReplatChar, &lres);

					delete[] pReplatChar;
					pReplatChar = NULL;
 				}
				else
				{
					hr = pserv->TxSendMessage(msg, wparam, (LPARAM)lpszReplace, &lres);
				}
			}
		}
		break;
	case EM_SETCHARFORMAT:
		{
			if(!FValidCF((CHARFORMAT *) lparam))
			{
				return 0;
			}

			if(wparam & SCF_SELECTION)
				goto serv;								// Change selection format
			OnSetCharFormat((CHARFORMAT *) lparam);		// Change default format
		}
		break;
	case EM_SETPARAFORMAT:
		{
			if(!FValidPF((PARAFORMAT *) lparam))
			{
				return 0;
			}

			// check to see if we're setting the default.
			// either SCF_DEFAULT will be specified *or* there is no
			// no text in the document (richedit1.0 behaviour).
			if (!(wparam & SCF_DEFAULT))
			{
				hr = pserv->TxSendMessage(WM_GETTEXTLENGTH, 0, 0, 0);

				if (hr == 0)
				{
					wparam |= SCF_DEFAULT;
				}
			}

			if(wparam & SCF_DEFAULT)
			{								
				OnSetParaFormat((PARAFORMAT *) lparam);	// Change default format
			}
			else
			{
				goto serv;								// Change selection format
			}
		}
		break;
	case WM_SETTEXT:
		{
			// For RichEdit 1.0, the max text length would be reset by a settext so 
			// we follow pattern here as well.

			hr = pserv->TxSendMessage(msg, wparam, lparam, 0);

			if (SUCCEEDED(hr))
			{
				// Update succeeded.
				LONG cNewText = static_cast<LONG>(_tcslen((LPCTSTR) lparam));

				// If the new text is greater than the max set the max to the new
				// text length.
				if (cNewText > cchTextMost)
				{
					cchTextMost = cNewText;                
				}

				lres = 1;
			}
		}
		break;
	case WM_SIZE:
		{
			lres = OnSize(hwnd, static_cast<WORD>(wparam), LOWORD(lparam), HIWORD(lparam));
		}
		break;

	case WM_WINDOWPOSCHANGING:
		{
			lres = ::DefWindowProc(hwnd, msg, wparam, lparam);

			if(TxGetEffects() == TXTEFFECT_SUNKEN)
				OnSunkenWindowPosChanging(hwnd, (WINDOWPOS *) lparam);
		}
		break;
	case WM_SETCURSOR:
		{
			//Only set cursor when over us rather than a child; this
			//			helps prevent us from fighting it out with an inplace child
			if((HWND)wparam == hwnd)
			{
				if(!(lres = ::DefWindowProc(hwnd, msg, wparam, lparam)))
				{
					POINT pt;
					GetCursorPos(&pt);
					::ScreenToClient(hwnd, &pt);
					pserv->OnTxSetCursor(
						DVASPECT_CONTENT,	
						-1,
						NULL,
						NULL,
						NULL,
						NULL,
						NULL,			// Client rect - no redraw 
						pt.x, 
						pt.y);
					lres = TRUE;
				}
			}
		}
		break;
	case WM_SHOWWINDOW:
		{
			hr = OnTxVisibleChange((BOOL)wparam);
		}
		break;
	case WM_NCPAINT:
		{
			lres = ::DefWindowProc(hwnd, msg, wparam, lparam);

			if(TxGetEffects() == TXTEFFECT_SUNKEN)
			{
				HDC hdc = GetDC(hwnd);

				if(hdc)
				{
					DrawSunkenBorder(hwnd, hdc);
					ReleaseDC(hwnd, hdc);
				}
			}
		}
		break;
	case WM_PAINT:
		{
			if (m_pIRichEditMsgProc)
			{
				RECT *prc = (RECT*)lparam;
				LONG lViewId = TXTVIEW_ACTIVE;

				if (!fInplaceActive)
				{
					RECT rcControl;
					GetControlRect(&rcControl);
					prc = &rcControl;
					lViewId = TXTVIEW_INACTIVE;
				}

				m_hContextDevice = (HDC)wparam;

				//��������
				pserv->TxDraw(
					DVASPECT_CONTENT,		// Draw Aspect
					/*-1*/0,				// Lindex
					NULL,					// Info for drawing optimazation
					NULL,					// target device information
					(HDC)wparam,			// Draw device HDC
					NULL, 					// Target device HDC
					(RECTL*)&rcClient,		// Bounding client rectangle
					NULL, 					// Clipping rectangle for metafiles
					(RECT*)lparam,			// Update rectangle
					NULL, 	   				// Call back function
					NULL,					// Call back parameter
					lViewId);				// What view of the object

				if(TXTEFFECT_SUNKEN == TxGetEffects())
				{
					DrawSunkenBorder(hwnd, (HDC)wparam);
				}

				m_hContextDevice = NULL;

				//���ƹ��
				DrawCaretInPaint((HDC)wparam, (RECT*)lparam);
			}
		}
		break;
	default:
serv:
		{
			try
			{
				hr = pserv->TxSendMessage(msg, wparam, lparam, &lres);
			}
			catch (...)
			{
			}

			if (hr == S_FALSE)
			{
				lres = ::DefWindowProc(hwnd, msg, wparam, lparam);
			}
		}
	}

	return lres;
}


///////////////////////////////  Keyboard Messages  //////////////////////////////////


LRESULT CTxtWinHost::OnKeyDown(WORD vkey, DWORD dwFlags)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return 1;

	switch(vkey)
	{
	case VK_ESCAPE:
		if(fInDialogBox)
		{
			PostMessage(hwndParent, WM_CLOSE, 0, 0);
			return 0;
		}
		break;

	case VK_RETURN:
		if(fInDialogBox && !(GetKeyState(VK_CONTROL) & 0x8000) 
			&& !(dwStyle & ES_WANTRETURN))
		{
			// send to default button
			LRESULT id;
			HWND hwndT;

			id = SendMessage(hwndParent, DM_GETDEFID, 0, 0);
			if(LOWORD(id) &&
				(hwndT = GetDlgItem(hwndParent, LOWORD(id))))
			{
				SendMessage(hwndParent, WM_NEXTDLGCTL, (WPARAM) hwndT, (LPARAM) 1);
				if(GetFocus() != hwnd)
					PostMessage(hwndT, WM_KEYDOWN, (WPARAM) VK_RETURN, 0);
			}
			return 0;
		}
		break;

	case VK_TAB:
		if(fInDialogBox) 
		{
			SendMessage(hwndParent, WM_NEXTDLGCTL, 
				!!(GetKeyState(VK_SHIFT) & 0x8000), 0);
			return 0;
		}
		break;
	}
	return 1;
}

#define CTRL(_ch) (_ch - 'A' + 1)

LRESULT CTxtWinHost::OnChar(WORD vkey, DWORD dwFlags)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return 1;

	switch(vkey)
	{
		// Ctrl-Return generates Ctrl-J (LF), treat it as an ordinary return
	case CTRL('J'):
	case VK_RETURN:
		if(fInDialogBox && !(GetKeyState(VK_CONTROL) & 0x8000)
			&& !(dwStyle & ES_WANTRETURN))
			return 0;
		break;

	case VK_TAB:
		if(fInDialogBox && !(GetKeyState(VK_CONTROL) & 0x8000))
			return 0;
	}

	return 1;
}


////////////////////////////////////  View rectangle //////////////////////////////////////


void CTxtWinHost::OnGetRect(LPRECT prc)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	RECT rcInset;

	// Get view inset (in HIMETRIC)
	TxGetViewInset(&rcInset);

	// Convert the himetric inset to pixels
	rcInset.left = HimetricXtoDX(rcInset.left, xPerInch);
	rcInset.top = HimetricYtoDY(rcInset.top , yPerInch);
	rcInset.right = HimetricXtoDX(rcInset.right, xPerInch);
	rcInset.bottom = HimetricYtoDY(rcInset.bottom, yPerInch);

	// Get client rect in pixels
	TxGetClientRect(prc);

	// Modify the client rect by the inset 
	prc->left += rcInset.left;
	prc->top += rcInset.top;
	prc->right -= rcInset.right;
	prc->bottom -= rcInset.bottom;
}

void CTxtWinHost::OnSetRect(LPRECT prc)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	RECT rcClient;

	if(!prc)
	{
		SetDefaultInset();
	}	
	else	
	{
		// For screen display, the following intersects new view RECT
		// with adjusted client area RECT
		TxGetClientRect(&rcClient);

		// Adjust client rect
		// Factors in space for borders
		if(fBorder)
		{																					  
			rcClient.top		+= yHeightSys / 4;
			rcClient.bottom 	-= yHeightSys / 4 - 1;
			rcClient.left		+= xWidthSys / 2;
			rcClient.right	-= xWidthSys / 2;
		}

		// Ensure we have minimum width and height
		rcClient.right = max(rcClient.right, rcClient.left + xWidthSys);
		rcClient.bottom = max(rcClient.bottom, rcClient.top + yHeightSys);

		// Intersect the new view rectangle with the 
		// adjusted client area rectangle
		if(!IntersectRect(&rcViewInset, &rcClient, prc))
			rcViewInset = rcClient;

		// compute inset in pixels
		rcViewInset.left -= rcClient.left;
		rcViewInset.top -= rcClient.top;
		rcViewInset.right = rcClient.right - rcViewInset.right;
		rcViewInset.bottom = rcClient.bottom - rcViewInset.bottom;

		// Convert the inset to himetric that must be returned to ITextServices
		rcViewInset.left = DXtoHimetricX(rcViewInset.left, xPerInch);
		rcViewInset.top = DYtoHimetricY(rcViewInset.top, yPerInch);
		rcViewInset.right = DXtoHimetricX(rcViewInset.right, xPerInch);
		rcViewInset.bottom = DYtoHimetricY(rcViewInset.bottom, yPerInch);
	}

	pserv->OnTxPropertyBitsChange(TXTBIT_VIEWINSETCHANGE, 
		TXTBIT_VIEWINSETCHANGE);
}

HBITMAP CTxtWinHost::CreateMemDIBSec(HDC hdc,int nWidth,int nHeight,LPBYTE* pOutBits,BITMAPINFO* pbi/* = NULL*/)
{
	BITMAPINFO bi;
	memset(&bi,0,sizeof(BITMAPINFO));
	bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bi.bmiHeader.biWidth = nWidth;
	bi.bmiHeader.biHeight = nHeight;
	bi.bmiHeader.biPlanes = 1;
	bi.bmiHeader.biBitCount = 32;
	bi.bmiHeader.biCompression = BI_RGB;
	HBITMAP bmpMem = CreateDIBSection(hdc,&bi,DIB_RGB_COLORS, (void**)pOutBits, NULL, 0);

	if (pbi)
	{
		*pbi = bi;
	}

	return bmpMem;
}

////////////////////////////////////  System notifications  //////////////////////////////////


void CTxtWinHost::OnSysColorChange()
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	crAuto = GetSysColor(COLOR_WINDOWTEXT);
	if(!fNotSysBkgnd)
		crBackground = GetSysColor(COLOR_WINDOW);
	TxInvalidateRect(NULL, TRUE);
}

LRESULT CTxtWinHost::OnGetDlgCode(WPARAM wparam, LPARAM lparam)
{
	LRESULT lres = DLGC_WANTCHARS | DLGC_WANTARROWS | DLGC_WANTTAB;

	if (eHostSate_InitedFailed == m_hostSate)
		return lres;

	if(dwStyle & ES_MULTILINE)
		lres |= DLGC_WANTALLKEYS;

	if(!(dwStyle & ES_SAVESEL))
		lres |= DLGC_HASSETSEL;

	if(lparam)
		fInDialogBox = TRUE;

	if(lparam &&
		((WORD) wparam == VK_BACK))
	{
		lres |= DLGC_WANTMESSAGE;
	}

	return lres;
}


/////////////////////////////////  Other messages  //////////////////////////////////////


LRESULT CTxtWinHost::OnGetOptions() const
{
	LRESULT lres = dwStyle;
	if (eHostSate_InitedFailed == m_hostSate)
		return lres;

	if(fEnableAutoWordSel)
		lres |= ECO_AUTOWORDSELECTION;

	return lres;
}

void CTxtWinHost::OnSetOptions(WORD wOp, DWORD eco)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	const BOOL fAutoWordSel = !!(eco & ECO_AUTOWORDSELECTION);
	DWORD dwStyleNew = dwStyle;
	DWORD dw_Style = 0 ;

	DWORD dwChangeMask = 0;

	// single line controls can't have a selection bar
	// or do vertical writing
	if(!(dw_Style & ES_MULTILINE))
	{
#ifdef DBCS
		eco &= ~(ECO_SELECTIONBAR | ECO_VERTICAL);
#else
		eco &= ~ECO_SELECTIONBAR;
#endif
	}
	dw_Style = (eco & ECO_STYLES);

	switch(wOp)
	{
	case ECOOP_SET:
		dwStyleNew = eco;
		fEnableAutoWordSel = fAutoWordSel;
		break;

	case ECOOP_OR:
		dwStyleNew |= dw_Style;
		if(fAutoWordSel)
			fEnableAutoWordSel = TRUE;
		break;

	case ECOOP_AND:
		dwStyleNew &= eco;
		if(fEnableAutoWordSel && !fAutoWordSel)
			fEnableAutoWordSel = FALSE;
		break;

	case ECOOP_XOR:
		dwStyleNew ^= dw_Style;
		fEnableAutoWordSel = (!fEnableAutoWordSel != !fAutoWordSel);
		break;
	}

	if(fEnableAutoWordSel != (unsigned)fAutoWordSel)
	{
		dwChangeMask |= TXTBIT_AUTOWORDSEL; 
	}

	if(dwStyleNew != dw_Style)
	{
		DWORD dwChange = dwStyleNew ^ dw_Style;
#ifdef DBCS
		USHORT	usMode;
#endif

		dwStyle = dwStyleNew;
		//SetWindowLong(hwnd, GWL_STYLE, dwStyleNew);

		if(dwChange & ES_NOHIDESEL)	
		{
			dwChangeMask |= TXTBIT_HIDESELECTION;
		}

		if(dwChange & ES_READONLY)
		{
			dwChangeMask |= TXTBIT_READONLY;

			// Change drop target state as appropriate.
			if (dwStyleNew & ES_READONLY)
			{
				if (m_pIRichEditMsgProc)
				{
					m_pIRichEditMsgProc->OnRichEditMsgProc(WM_RICHEDIT_UNREG_DRAGDROP, 0, 0);
				}
			}
			else
			{
				if (m_pIRichEditMsgProc)
				{
					m_pIRichEditMsgProc->OnRichEditMsgProc(WM_RICHEDIT_REG_DRAGDROP, 0, 0);
				}
			}
		}

		if(dwChange & ES_VERTICAL)
		{
			dwChangeMask |= TXTBIT_VERTICAL;
		}

		// no action require for ES_WANTRETURN
		// no action require for ES_SAVESEL
		// do this last
		if(dwChange & ES_SELECTIONBAR)
		{
			lSelBarWidth = 212;
			dwChangeMask |= TXTBIT_SELBARCHANGE;
		}
	}

	if (dwChangeMask)
	{
		DWORD dwProp = 0;
		TxGetPropertyBits(dwChangeMask, &dwProp);
		pserv->OnTxPropertyBitsChange(dwChangeMask, dwProp);
	}
}

void CTxtWinHost::OnSetReadOnly(BOOL fReadOnly)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	DWORD dwUpdatedBits = 0;

	if(fReadOnly)
	{
		dwStyle |= ES_READONLY;

		// Turn off Drag Drop 
		if (m_pIRichEditMsgProc)
		{
			m_pIRichEditMsgProc->OnRichEditMsgProc(WM_RICHEDIT_UNREG_DRAGDROP, 0, 0);
		}

		dwUpdatedBits |= TXTBIT_READONLY;
	}
	else
	{
		dwStyle &= ~(DWORD) ES_READONLY;

		// Turn drag drop back on
		if (m_pIRichEditMsgProc)
		{
			m_pIRichEditMsgProc->OnRichEditMsgProc(WM_RICHEDIT_REG_DRAGDROP, 0, 0);
		}
	}

	pserv->OnTxPropertyBitsChange(TXTBIT_READONLY, dwUpdatedBits);
}

void CTxtWinHost::OnSetEventMask(DWORD mask)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	LRESULT lres = (LRESULT) dwEventMask;
	dwEventMask = (DWORD) mask;

}


LRESULT CTxtWinHost::OnGetEventMask() const
{
	return (LRESULT) dwEventMask;
}

/*
*	CTxtWinHost::OnSetFont(hfont)
*
*	Purpose:	
*		Set new font from hfont
*
*	Arguments:
*		hfont	new font (NULL for system font)
*/
BOOL CTxtWinHost::OnSetFont(HFONT hfont)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return FALSE;

	if(SUCCEEDED(InitDefaultCharFormat(&cf, hfont)))
	{
		pserv->OnTxPropertyBitsChange(TXTBIT_CHARFORMATCHANGE, 
			TXTBIT_CHARFORMATCHANGE);
		return TRUE;
	}

	return FALSE;
}

/*
*	CTxtWinHost::OnSetCharFormat(pcf)
*
*	Purpose:	
*		Set new default CharFormat
*
*	Arguments:
*		pch		ptr to new CHARFORMAT
*/
BOOL CTxtWinHost::OnSetCharFormat(CHARFORMAT *pcf)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return FALSE;

	if (pcf)
	{
		memcpy((void*)&cf, (void*)pcf, pcf->cbSize);
	}

	pserv->TxSendMessage(EM_SETCHARFORMAT, SCF_DEFAULT, (LPARAM)pcf, 0);

	/*pserv->OnTxPropertyBitsChange(TXTBIT_CHARFORMATCHANGE, 
		TXTBIT_CHARFORMATCHANGE);*/

	return TRUE;
}

/*
*	CTxtWinHost::OnSetParaFormat(ppf)
*
*	Purpose:	
*		Set new default ParaFormat
*
*	Arguments:
*		pch		ptr to new PARAFORMAT
*/
BOOL CTxtWinHost::OnSetParaFormat(PARAFORMAT *pPF)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return FALSE;

	memcpy((void*)&pf, (void*)pPF, pPF->cbSize);

	pserv->OnTxPropertyBitsChange(TXTBIT_PARAFORMATCHANGE, 
		TXTBIT_PARAFORMATCHANGE);

	return TRUE;
}



////////////////////////////  Event firing  /////////////////////////////////



void * CTxtWinHost::CreateNmhdr(UINT uiCode, LONG cb)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return NULL;

	NMHDR *pnmhdr;

	pnmhdr = (NMHDR*) new char[cb];
	if(!pnmhdr)
		return NULL;

	memset(pnmhdr, 0, cb);

	pnmhdr->hwndFrom = hwnd;
	pnmhdr->idFrom = GetWindowLong(hwnd, GWL_ID);
	pnmhdr->code = uiCode;

	return (VOID *) pnmhdr;
}


////////////////////////////////////  Helpers  /////////////////////////////////////////
void CTxtWinHost::SetDefaultInset()
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	// Generate default view rect from client rect.
	if(fBorder)
	{
		// Factors in space for borders
		rcViewInset.top = DYtoHimetricY(yHeightSys / 4, yPerInch);
		rcViewInset.bottom	= DYtoHimetricY(yHeightSys / 4 - 1, yPerInch);
		rcViewInset.left = DXtoHimetricX(xWidthSys / 2, xPerInch);
		rcViewInset.right = DXtoHimetricX(xWidthSys / 2, xPerInch);
	}
	else
	{
		rcViewInset.top = rcViewInset.left =
			rcViewInset.bottom = rcViewInset.right = 0;
	}
}


/////////////////////////////////  Far East Support  //////////////////////////////////////

HIMC CTxtWinHost::TxImmGetContext(void)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return NULL;

	HIMC himc = ImmGetContext(hwnd);
	return himc;
}

void CTxtWinHost::TxImmReleaseContext(HIMC himc)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	ImmReleaseContext(hwnd, himc);
}

void CTxtWinHost::RevokeDragDrop(void)
{
	std::map<HWND, CDragDropRegInfo>::iterator it = m_dragDropRegMap.find(hwnd);
	if (it == m_dragDropRegMap.end())
	{
		return;
	}

	if (it->second.GetRegisteredFlag() && 
		it->second.GetHotObject() == this)
	{
		::RevokeDragDrop(hwnd);
		m_dragDropRegMap.erase(it);
	}
}

void CTxtWinHost::RegisterDragDrop(void)
{
	if (eHostSate_InitedFailed == m_hostSate)
	{
		return;
	}

	//����ӳ�����Ϣ
	std::map<HWND, CDragDropRegInfo>::iterator it = m_dragDropRegMap.find(hwnd);
	if (it == m_dragDropRegMap.end())
	{
		CDragDropRegInfo regInfo;
		m_dragDropRegMap.insert(std::make_pair(hwnd, regInfo));

		//error
		it = m_dragDropRegMap.find(hwnd);
		if (it == m_dragDropRegMap.end())
		{
			return;
		}
	}

	//��ǰ��ע��
	if (it->second.GetRegisteredFlag() && 
		it->second.GetHotObject() == this)
	{
		return;
	}

	//����֮ǰ��ע���¼�
	if (it->second.GetRegisteredFlag() && 
		it->second.GetHotObject() != this)
	{
		::RevokeDragDrop(hwnd);
		it->second.clear();
	}

	IDropTarget* pdt = NULL;
	if(NOERROR == pserv->TxGetDropTarget(&pdt))
	{
		HRESULT hRet = ::RegisterDragDrop(hwnd, pdt);
		if(NOERROR == hRet)
		{	
			it->second.SetRegInfo(TRUE, this);
		}
		pdt->Release();
	}
}

VOID DrawRectFn(
				HDC hdc, 
				RECT *prc, 
				INT icrTL, 
				INT icrBR,
				BOOL fBot, 
				BOOL fRght)
{
	COLORREF cr;
	COLORREF crSave;
	RECT rc;

	cr = GetSysColor(icrTL);
	crSave = SetBkColor(hdc, cr);

	// top
	rc = *prc;
	rc.bottom = rc.top + 1;
	ExtTextOut(hdc, 0, 0, ETO_OPAQUE, &rc, NULL, 0, NULL);

	// left
	rc.bottom = prc->bottom;
	rc.right = rc.left + 1;
	ExtTextOut(hdc, 0, 0, ETO_OPAQUE, &rc, NULL, 0, NULL);

	if(icrTL != icrBR)
	{
		cr = GetSysColor(icrBR);
		SetBkColor(hdc, cr);
	}

	// right
	rc.right = prc->right;
	rc.left = rc.right - 1;
	if(!fBot)
		rc.bottom -= cyHScroll;
	if(fRght)
	{
		ExtTextOut(hdc, 0, 0, ETO_OPAQUE, &rc, NULL, 0, NULL);
	}

	// bottom
	if(fBot)
	{
		rc.left = prc->left;
		rc.top = rc.bottom - 1;
		if(!fRght)
			rc.right -= cxVScroll;
		ExtTextOut(hdc, 0, 0, ETO_OPAQUE, &rc, NULL, 0, NULL);
	}
	SetBkColor(hdc, crSave);
}

#define cmultBorder 1

VOID CTxtWinHost::OnSunkenWindowPosChanging(HWND hwnd, WINDOWPOS *pwndpos)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	if(fVisible)
	{
		RECT rc;
		HWND hwndParent;

		GetWindowRect(hwnd, &rc);
		InflateRect(&rc, cxBorder * cmultBorder, cyBorder * cmultBorder);
		hwndParent = GetParent(hwnd);
		MapWindowPoints(HWND_DESKTOP, hwndParent, (POINT *) &rc, 2);
		InvalidateRect(hwndParent, &rc, FALSE);
	}
}


VOID CTxtWinHost::DrawSunkenBorder(HWND hwnd, HDC hdc)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	RECT rc;
	RECT rcParent;
	DWORD dwScrollBars;
	HWND hwndParent;

	GetWindowRect(hwnd, &rc);
	hwndParent = GetParent(hwnd);
	rcParent = rc;
	MapWindowPoints(HWND_DESKTOP, hwndParent, (POINT *)&rcParent, 2);
	InflateRect(&rcParent, cxBorder, cyBorder);
	OffsetRect(&rc, -rc.left, -rc.top);

	// draw inner rect
	TxGetScrollBars(&dwScrollBars);
	DrawRectFn(hdc, &rc, COLOR_WINDOWFRAME, COLOR_BTNFACE,
		!(dwScrollBars & WS_HSCROLL), !(dwScrollBars & WS_VSCROLL));

	// draw outer rect
	hwndParent = GetParent(hwnd);
	hdc = GetDC(hwndParent);
	DrawRectFn(hdc, &rcParent, COLOR_BTNSHADOW, COLOR_BTNHIGHLIGHT,
		TRUE, TRUE);
	ReleaseDC(hwndParent, hdc);
}

void CTxtWinHost::SetClientRect(RECT *prc, BOOL fUpdateExtent) 
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	// If the extent matches the client rect then we assume the extent should follow
	// the client rect.
	LONG lTestExt = DYtoHimetricY(
		(rcClient.bottom - rcClient.top) - 2 * HOST_BORDER, yPerInch);

	if (fUpdateExtent 
		&& (sizelExtent.cy == lTestExt))
	{
		sizelExtent.cy = DXtoHimetricX((prc->bottom - prc->top) - 2 * HOST_BORDER, 
			xPerInch);
		sizelExtent.cx = DYtoHimetricY((prc->right - prc->left) - 2 * HOST_BORDER,
			yPerInch);
	}

	rcClient = *prc; 
}

LRESULT CTxtWinHost::OnSize(HWND hwnd, WORD fwSizeType, int nWidth, int nHeight)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return 1;

	RECT rc;
	if (m_pIRichEditMsgProc)
	{
		m_pIRichEditMsgProc->OnRichEditMsgProc(WM_GETDUIRECT, (WPARAM)&rc, 0);
	}
	else
	{
		GetControlRect(&rc);
	}

	rc.bottom = rc.top + nHeight + HOST_BORDER;
	rc.right  = rc.left + nWidth + HOST_BORDER;
	rc.top -= HOST_BORDER;
	rc.left -= HOST_BORDER;

	SetClientRect(&rc, TRUE);

	if(!fVisible)
	{
		fIconic = GetIconic(hwnd);
		if(!fIconic)
			fResized = TRUE;
	}
	else
	{
		pserv->OnTxPropertyBitsChange(TXTBIT_VIEWINSETCHANGE, 
			TXTBIT_VIEWINSETCHANGE);
		if(GetIconic(hwnd))
		{
			fIconic = TRUE;
		}
		else
		{
			if(fIconic)
			{
				InvalidateRect(hwnd, NULL, FALSE);
				fIconic = FALSE;
			}

			if(TxGetEffects() == TXTEFFECT_SUNKEN)	// Draw borders
				DrawSunkenBorder(hwnd, NULL);
		}
	}
	return 0;
}

HRESULT CTxtWinHost::OnTxVisibleChange(BOOL fVisible)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return E_FAIL;

	fVisible = fVisible;

	if(!fVisible && fResized)
	{
		RECT rc;
		// Control was resized while hidden,
		// need to really resize now
		TxGetClientRect(&rc);
		fResized = FALSE;
		pserv->OnTxPropertyBitsChange(TXTBIT_CLIENTRECTCHANGE, 
			TXTBIT_CLIENTRECTCHANGE);
	}

	return S_OK;
}



//////////////////////////// ITextHost Interface  ////////////////////////////

HDC CTxtWinHost::TxGetDC()
{
	if (NULL != m_hContextDevice)
	{
		return m_hContextDevice;
	}

	return ::GetDC(hwnd);
}


int CTxtWinHost::TxReleaseDC(HDC hdc)
{
	if (NULL != m_hContextDevice)
	{
		return S_OK;
	}

	return ::ReleaseDC (hwnd, hdc);
}


BOOL CTxtWinHost::TxShowScrollBar(INT fnBar, BOOL fShow)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return FALSE;

	if (!fShow)
	{
		m_bRemoveScrollBar = TRUE;
	}

	HRESULT hr = S_FALSE;
	if (m_pIRichEditMsgProc)
	{
		hr = m_pIRichEditMsgProc->OnRichEditMsgProc(WM_SHOWSCROLLBAR, fnBar, fShow);
	}

	return (S_OK == hr)? TRUE:FALSE;
}

BOOL CTxtWinHost::TxEnableScrollBar (INT fuSBFlags, INT fuArrowflags)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return FALSE;

	return ::EnableScrollBar(hwnd, fuSBFlags, fuArrowflags) ;
}


BOOL CTxtWinHost::TxSetScrollRange(INT fnBar, LONG nMinPos, INT nMaxPos, BOOL fRedraw)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return FALSE;

	stSCROLLINFO siex;
	memset(&siex, 0, sizeof(stSCROLLINFO));
	siex.m_si.cbSize = sizeof(stSCROLLINFO);
	siex.m_si.fMask = SIF_PAGE | SIF_RANGE;
	siex.m_si.nMin = nMinPos;
	siex.m_si.nMax = nMaxPos;
	siex.m_si.nPage = rcClient.bottom - rcClient.top - 2 * HOST_BORDER;
	siex.m_bRedraw = fRedraw;

	HRESULT hr = S_FALSE;;
	if (m_pIRichEditMsgProc)
	{
		hr = m_pIRichEditMsgProc->OnRichEditMsgProc(WM_SETSCROLLINFO, fnBar, (LPARAM)&siex);
	}
	return (S_OK == hr)? TRUE:FALSE;
}


BOOL CTxtWinHost::TxSetScrollPos (INT fnBar, INT nPos, BOOL fRedraw)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return FALSE;

	stSCROLLINFO siex;
	siex.m_si.cbSize = sizeof(stSCROLLINFO);
	siex.m_si.fMask = SIF_POS;
	siex.m_si.nPos = nPos;
	siex.m_bRedraw = fRedraw;
	
	HRESULT hr = S_FALSE;;
	if (m_pIRichEditMsgProc)
	{
		hr = m_pIRichEditMsgProc->OnRichEditMsgProc(WM_SETSCROLLPOS, fnBar, (LPARAM)&siex);
	}
	return (S_OK == hr)? TRUE:FALSE;
}

void CTxtWinHost::TxInvalidateRect(LPCRECT prc, BOOL fMode)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	if (prc)
	{
		::InvalidateRect(hwnd, prc, fMode);
	}
	else
	{
		if (m_pIRichEditMsgProc)
		{
			m_pIRichEditMsgProc->OnRichEditInsideRedraw();
		}
	}
}

void CTxtWinHost::TxViewChange(BOOL fUpdate) 
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	if (m_pIRichEditMsgProc)
	{
		m_pIRichEditMsgProc->OnRichEditInsideRedraw();
	}
}


BOOL CTxtWinHost::TxCreateCaret(HBITMAP hbmp, INT xWidth, INT yHeight)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return FALSE;

	if (NULL == m_CaretInfo.hDC)
	{
		HDC hPaintDC = ::GetDC(hwnd);
		if (hPaintDC)
		{
			m_CaretInfo.hDC = ::CreateCompatibleDC(hPaintDC);
			::ReleaseDC(hwnd, hPaintDC);
		}
	}

	m_CaretInfo.nCaretWdith = xWidth;
	m_CaretInfo.nCaretHeight = yHeight;
	if (m_CaretInfo.hCaret)
	{
		::DeleteObject(m_CaretInfo.hCaret);
		m_CaretInfo.hCaret = NULL;
	}

	if (hbmp && hbmp != (HBITMAP)1 && m_CaretInfo.hDC)
	{
		BITMAPINFO bmpInfo;
		if (::GetObject(hbmp, sizeof(BITMAPINFO), &bmpInfo))
		{
			m_CaretInfo.nCaretWdith = bmpInfo.bmiHeader.biWidth;
			m_CaretInfo.nCaretHeight = bmpInfo.bmiHeader.biHeight;

			LPBYTE pBits = NULL;
			m_CaretInfo.hCaret = CreateMemDIBSec(m_CaretInfo.hDC, m_CaretInfo.nCaretWdith, m_CaretInfo.nCaretHeight, &pBits);
			HBITMAP hOldBitmap = (HBITMAP)::SelectObject(m_CaretInfo.hDC, m_CaretInfo.hCaret);

			HDC hTempDC = ::CreateCompatibleDC(m_CaretInfo.hDC);
			HBITMAP hTempOldBitmap = (HBITMAP)::SelectObject(hTempDC, hbmp);

			BLENDFUNCTION bfAll = {AC_SRC_OVER, 0, 255, AC_SRC_OVER};
			::AlphaBlend(m_CaretInfo.hDC,
				0,
				0,
				m_CaretInfo.nCaretWdith,
				m_CaretInfo.nCaretHeight,
				hTempDC,
				0,
				0,
				m_CaretInfo.nCaretWdith,
				m_CaretInfo.nCaretHeight,
				bfAll);

			::SelectObject(m_CaretInfo.hDC, hOldBitmap);
			::SelectObject(hTempDC, hTempOldBitmap);
			::DeleteObject(hTempDC);
		}
	}

	if (m_CaretInfo.nCaretWdith <= 0)
	{
		m_CaretInfo.nCaretWdith = 1;
	}

	if (m_CaretInfo.nCaretHeight <= 0)
	{
		m_CaretInfo.nCaretHeight = 8;
	}

	return TRUE;
}


BOOL CTxtWinHost::TxShowCaret(BOOL fShow)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return FALSE;

	ShowCaret(fShow?true:false);

	return TRUE;
}

BOOL CTxtWinHost::TxSetCaretPos(INT x, INT y)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return FALSE;

	m_CaretInfo.nCaretPosX = x;
	m_CaretInfo.nCaretPosY = y;

	::SetCaretPos(x, y);

	UpdateCaretByPosChange();

	return TRUE;
}


BOOL CTxtWinHost::TxSetTimer(UINT idTimer, UINT uTimeout)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return FALSE;

	fTimer = TRUE;
	return ::SetTimer(hwnd, idTimer, uTimeout, NULL) != 0;
}


void CTxtWinHost::TxKillTimer(UINT idTimer)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	::KillTimer(hwnd, idTimer);
	fTimer = FALSE;
}

void CTxtWinHost::TxScrollWindowEx (INT dx, INT dy, LPCRECT lprcScroll,	LPCRECT lprcClip,	HRGN hrgnUpdate, LPRECT lprcUpdate,	UINT fuScroll)	
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	::ScrollWindowEx(hwnd, dx, dy, lprcScroll, lprcClip, hrgnUpdate, lprcUpdate, fuScroll);
}

void CTxtWinHost::TxSetCapture(BOOL fCapture)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	if (fCapture)
	{
		::SetCapture(hwnd);

		if (m_pIRichEditMsgProc)
		{
			m_pIRichEditMsgProc->OnRichEditMsgProc(WM_RICHEDIT_SETCAPTUER, 0, 0);
		}
	}
	else
	{
		::ReleaseCapture();

		if (m_pIRichEditMsgProc)
		{
			m_pIRichEditMsgProc->OnRichEditMsgProc(WM_RICHEDIT_RELEASECAPTUER, 0, 0);
		}
	}
}

void CTxtWinHost::TxSetFocus()
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	if (m_pIRichEditMsgProc)
	{
		m_pIRichEditMsgProc->OnRichEditMsgProc(WM_RICHEDIT_SET_FOCUS, 0, 0);
	}
}

void CTxtWinHost::TxSetCursor(HCURSOR hcur,	BOOL fText)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	::SetCursor(hcur);
}

BOOL CTxtWinHost::TxScreenToClient(LPPOINT lppt)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return FALSE;

	return ::ScreenToClient(hwnd, lppt);
}

BOOL CTxtWinHost::TxClientToScreen(LPPOINT lppt)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return FALSE;

	return ::ClientToScreen(hwnd, lppt);
}

HRESULT CTxtWinHost::TxActivate(LONG *plOldState)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return E_FAIL;

	return S_OK;
}

HRESULT CTxtWinHost::TxDeactivate(LONG lNewState)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return E_FAIL;

	return S_OK;
}


HRESULT CTxtWinHost::TxGetClientRect(LPRECT prc)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return E_FAIL;

	*prc = rcClient;

	GetControlRect(prc);

	return NOERROR;
}


HRESULT CTxtWinHost::TxGetViewInset(LPRECT prc) 
{
	if (eHostSate_InitedFailed == m_hostSate)
		return E_FAIL;

	*prc = rcViewInset;

	return NOERROR;
}

HRESULT CTxtWinHost::TxGetCharFormat(const CHARFORMATW **ppCF)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return E_FAIL;

	*ppCF = &cf;
	return NOERROR;
}

HRESULT CTxtWinHost::TxGetParaFormat(const PARAFORMAT **ppPF)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return E_FAIL;

	*ppPF = &pf;
	return NOERROR;
}


COLORREF CTxtWinHost::TxGetSysColor(int nIndex) 
{
	if (eHostSate_InitedFailed == m_hostSate)
		return 0;

	if (nIndex == COLOR_WINDOW)
	{
		if(!fNotSysBkgnd)
			return GetSysColor(COLOR_WINDOW);
		return crBackground;
	}

	return GetSysColor(nIndex);
}



HRESULT CTxtWinHost::TxGetBackStyle(TXTBACKSTYLE *pstyle)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return E_FAIL;

	*pstyle = !fTransparent ? TXTBACK_OPAQUE : TXTBACK_TRANSPARENT;
	return NOERROR;
}


HRESULT CTxtWinHost::TxGetMaxLength(DWORD *pLength)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return E_FAIL;

	*pLength = cchTextMost;
	return NOERROR;
}



HRESULT CTxtWinHost::TxGetScrollBars(DWORD *pdwScrollBar)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return E_FAIL;

	*pdwScrollBar =  dwStyle & (WS_HSCROLL | ES_AUTOHSCROLL | WS_VSCROLL | ES_AUTOVSCROLL | ES_DISABLENOSCROLL);

	if (m_bRemoveScrollBar)
	{
		TxInvalidateRect(NULL, FALSE);
		m_bRemoveScrollBar = FALSE;
	}

	return NOERROR;
}


HRESULT CTxtWinHost::TxGetPasswordChar(TCHAR *pch)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return E_FAIL;

#ifdef UNICODE
	*pch = chPasswordChar;
#else
	WideCharToMultiByte(CP_ACP, 0, &chPasswordChar, 1, pch, 1, NULL, NULL) ;
#endif
	return NOERROR;
}

HRESULT CTxtWinHost::TxGetAcceleratorPos(LONG *pcp)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return E_FAIL;

	*pcp = laccelpos;
	return S_OK;
} 

HRESULT CTxtWinHost::OnTxCharFormatChange(const CHARFORMATW *pcf)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return E_FAIL;

	if (pcf)
	{
		memcpy((void*)&cf, (void*)pcf, pcf->cbSize);
	}

	return S_OK;
}


HRESULT CTxtWinHost::OnTxParaFormatChange(const PARAFORMAT *ppf)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return E_FAIL;

	if (ppf)
	{
		memcpy((void*)&pf,(void*)ppf, ppf->cbSize);
	}

	return S_OK;
}


HRESULT CTxtWinHost::TxGetPropertyBits(DWORD dwMask, DWORD *pdwBits) 
{
	if (eHostSate_InitedFailed == m_hostSate)
		return E_FAIL;

	DWORD dwProperties = 0;

	if (fRich)
	{
		dwProperties = TXTBIT_RICHTEXT;
	}

	if (dwStyle & ES_MULTILINE)
	{
		dwProperties |= TXTBIT_MULTILINE;
	}

	if (dwStyle & ES_READONLY)
	{
		dwProperties |= TXTBIT_READONLY;
	}


	if (dwStyle & ES_PASSWORD)
	{
		dwProperties |= TXTBIT_USEPASSWORD;
	}

	if (!(dwStyle & ES_NOHIDESEL))
	{
		dwProperties |= TXTBIT_HIDESELECTION;
	}

	if (fEnableAutoWordSel)
	{
		dwProperties |= TXTBIT_AUTOWORDSEL;
	}

	if (fVertical)
	{
		dwProperties |= TXTBIT_VERTICAL;
	}

	if (fWordWrap)
	{
		dwProperties |= TXTBIT_WORDWRAP;
	}

	if (fAllowBeep)
	{
		dwProperties |= TXTBIT_ALLOWBEEP;
	}

	if (fSaveSelection)
	{
		dwProperties |= TXTBIT_SAVESELECTION;
	}

	*pdwBits = dwProperties & dwMask; 
	return NOERROR;
}


HRESULT CTxtWinHost::TxNotify(DWORD iNotify, void *pv)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return E_FAIL;

	if (m_pIRichEditMsgProc && this)
	{
		m_pIRichEditMsgProc->OnRichEditMsgProc(iNotify, 0, (LPARAM)pv);
	}

	return S_OK;
}



HRESULT CTxtWinHost::TxGetExtent(LPSIZEL lpExtent)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return E_FAIL;

	// Calculate the length & convert to himetric
	*lpExtent = sizelExtent;

	return S_OK;
}

HRESULT	CTxtWinHost::TxGetSelectionBarWidth (LONG *plSelBarWidth)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return E_FAIL;

	*plSelBarWidth = lSelBarWidth;
	return S_OK;
}


BOOL CTxtWinHost::GetReadOnly()
{
	if (eHostSate_InitedFailed == m_hostSate)
		return TRUE;

	return (dwStyle & ES_READONLY) != 0;
}

void CTxtWinHost::SetReadOnly(BOOL fReadOnly)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	if (fReadOnly)
	{
		dwStyle |= ES_READONLY;
	}
	else
	{
		dwStyle &= ~ES_READONLY;
	}

	// Notify control of property change
	pserv->OnTxPropertyBitsChange(TXTBIT_READONLY, 
		fReadOnly ? TXTBIT_READONLY : 0);
}

BOOL CTxtWinHost::IsSupportMicroYaheiFont()
{
	if (m_microYaheiSupport.m_bSupportChinese || 
		m_microYaheiSupport.m_bSupportEnglish)
	{
		return TRUE;
	}

	return FALSE;
}

BOOL CTxtWinHost::IsSupportMicroYaheiFontChinese()
{
	return m_microYaheiSupport.m_bSupportChinese;
}

BOOL CTxtWinHost::IsSupportMicroYaheiFontEnglish()
{
	return m_microYaheiSupport.m_bSupportEnglish;
}

void CTxtWinHost::EnableLanOptionAutoFont(BOOL bEanble)
{
	return;

	// ���δ˴����߼�, ���岻ʹ��IMF_AUTOFONT�������ܶ�������ʾ��������
	/*if (eHostSate_InitedFailed == m_hostSate)
		return;

	if (bEanble == m_bIMFAutoFontEnabled)
		return;

	m_bIMFAutoFontEnabled = bEanble;

	LRESULT lLanOptions = 0;
	pserv->TxSendMessage(EM_GETLANGOPTIONS, 0, 0, &lLanOptions);

	if (bEanble)
	{
		lLanOptions |= IMF_AUTOFONT;
	}
	else
	{
		lLanOptions &= (~IMF_AUTOFONT);
	}
	pserv->TxSendMessage(EM_SETLANGOPTIONS, 0, lLanOptions, NULL);*/
}

BOOL CTxtWinHost::GetAllowBeep()
{
	if (eHostSate_InitedFailed == m_hostSate)
		return FALSE;

	return fAllowBeep;
}

void CTxtWinHost::SetAllowBeep(BOOL fAllowBeep)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	fAllowBeep = fAllowBeep;

	// Notify control of property change
	pserv->OnTxPropertyBitsChange(TXTBIT_ALLOWBEEP, 
		fAllowBeep ? TXTBIT_ALLOWBEEP : 0);
}

void CTxtWinHost::SetViewInset(RECT *prc)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	rcViewInset = *prc;

	// Notify control of property change
	pserv->OnTxPropertyBitsChange(TXTBIT_VIEWINSETCHANGE, 0);
}

WORD CTxtWinHost::GetDefaultAlign()
{
	if (eHostSate_InitedFailed == m_hostSate)
		return 0;

	return pf.wAlignment;
}


void CTxtWinHost::SetDefaultAlign(WORD wNewAlign)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	pf.wAlignment = wNewAlign;

	// Notify control of property change
	pserv->OnTxPropertyBitsChange(TXTBIT_PARAFORMATCHANGE, 0);
}

BOOL CTxtWinHost::GetRichTextFlag()
{
	if (eHostSate_InitedFailed == m_hostSate)
		return FALSE;

	return fRich;
}

void CTxtWinHost::SetRichTextFlag(BOOL fNew)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	fRich = fNew;

	// Notify control of property change
	pserv->OnTxPropertyBitsChange(TXTBIT_RICHTEXT, 
		fNew ? TXTBIT_RICHTEXT : 0);
}

LONG CTxtWinHost::GetDefaultLeftIndent()
{
	if (eHostSate_InitedFailed == m_hostSate)
		return 0;

	return pf.dxOffset;
}


void CTxtWinHost::SetDefaultLeftIndent(LONG lNewIndent)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	pf.dxOffset = lNewIndent;

	// Notify control of property change
	pserv->OnTxPropertyBitsChange(TXTBIT_PARAFORMATCHANGE, 0);
}

BOOL CTxtWinHost::SetSaveSelection(BOOL f_SaveSelection)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return FALSE;

	BOOL fResult = f_SaveSelection;

	fSaveSelection = f_SaveSelection;

	// notify text services of property change
	pserv->OnTxPropertyBitsChange(TXTBIT_SAVESELECTION, 
		fSaveSelection ? TXTBIT_SAVESELECTION : 0);

	return fResult;		
}

HRESULT	CTxtWinHost::OnTxInPlaceDeactivate()
{
	if (eHostSate_InitedFailed == m_hostSate)
		return E_FAIL;

	HRESULT hr = pserv->OnTxInPlaceDeactivate();

	if (SUCCEEDED(hr))
	{
		fInplaceActive = FALSE;
	}

	return hr;
}

HRESULT	CTxtWinHost::OnTxInPlaceActivate(LPCRECT prcClient)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return E_FAIL;

	fInplaceActive = TRUE;

	HRESULT hr = pserv->OnTxInPlaceActivate(prcClient);

	if (S_OK != hr)
	{
		fInplaceActive = FALSE;
	}

	return hr;
}

BOOL CTxtWinHost::DoSetCursor(RECT *prc, POINT *pt)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return FALSE;

	RECT rc = prc ? *prc : rcClient;

	// Give some space for our border
	rc.top += HOST_BORDER;
	rc.bottom -= HOST_BORDER;
	rc.left += HOST_BORDER;
	rc.right -= HOST_BORDER;

	// Is this in our rectangle?
	if (PtInRect(&rc, *pt))
	{
		RECT *prcClient = (!fInplaceActive || prc) ? &rc : NULL;

		HDC hdc = GetDC(hwnd);

		pserv->OnTxSetCursor(
			DVASPECT_CONTENT,	
			-1,
			NULL,
			NULL,
			hdc,
			NULL,
			prcClient,
			pt->x, 
			pt->y);

		ReleaseDC(hwnd, hdc);

		return TRUE;
	}

	return FALSE;
}

void CTxtWinHost::GetControlRect(
								 LPRECT prc			//@parm	Where to put client coordinates
								 )
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	// Give some space for our border
	prc->top = rcClient.top + HOST_BORDER;
	prc->bottom = rcClient.bottom - HOST_BORDER;
	prc->left = rcClient.left + HOST_BORDER;
	prc->right = rcClient.right - HOST_BORDER;
}

void CTxtWinHost::SetTransparent(BOOL f_Transparent)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	fTransparent = f_Transparent;

	// notify text services of property change
	pserv->OnTxPropertyBitsChange(TXTBIT_BACKSTYLECHANGE, 0);
}

LONG CTxtWinHost::SetAccelPos(LONG l_accelpos)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return 0;

	LONG laccelposOld = l_accelpos;

	laccelpos = l_accelpos;

	// notify text services of property change
	pserv->OnTxPropertyBitsChange(TXTBIT_SHOWACCELERATOR, 0);

	return laccelposOld;
}

WCHAR CTxtWinHost::SetPasswordChar(WCHAR ch_PasswordChar)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return NULL;

	WCHAR chOldPasswordChar = chPasswordChar;

	chPasswordChar = ch_PasswordChar;

	// notify text services of property change
	pserv->OnTxPropertyBitsChange(TXTBIT_USEPASSWORD, 
		(chPasswordChar != 0) ? TXTBIT_USEPASSWORD : 0);

	return chOldPasswordChar;
}

void CTxtWinHost::SetDisabled(BOOL fOn)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return;

	cf.dwMask	  |= CFM_COLOR	   | CFM_DISABLED;
	cf.dwEffects |= CFE_AUTOCOLOR | CFE_DISABLED;

	if( !fOn )
	{
		cf.dwEffects &= ~CFE_DISABLED;
	}

	pserv->OnTxPropertyBitsChange(TXTBIT_CHARFORMATCHANGE, 
		TXTBIT_CHARFORMATCHANGE);
}

LONG CTxtWinHost::SetSelBarWidth(LONG l_SelBarWidth)
{
	if (eHostSate_InitedFailed == m_hostSate)
		return 0;

	LONG lOldSelBarWidth = lSelBarWidth;

	lSelBarWidth = l_SelBarWidth;

	if (lSelBarWidth)
	{
		dwStyle |= ES_SELECTIONBAR;
	}
	else
	{
		dwStyle &= (~ES_SELECTIONBAR);
	}

	pserv->OnTxPropertyBitsChange(TXTBIT_SELBARCHANGE, TXTBIT_SELBARCHANGE);

	return lOldSelBarWidth;
}

BOOL CTxtWinHost::GetTimerState()
{
	if (eHostSate_InitedFailed == m_hostSate)
		return FALSE;

	return fTimer;
}

void CTxtWinHost::ShowCaret(bool bShow)
{
	if (bShow)
	{
		//���������˸ʱ��
		if (EnableCaretTimer(true))
		{
			m_CaretInfo.bVisible = TRUE;

			if (!m_CaretInfo.bShowByTime)
			{
				ShowCaretByTimer();
			}
		}
	}
	else
	{
		//�رչ������ʱ��
		if (EnableCaretTimer(false))
		{
			m_CaretInfo.bVisible = FALSE;

			if (m_CaretInfo.bShowByTime)
			{
				HideCaretByTimer();
			}
		}
	}
}

void CTxtWinHost::UpdateCaretInTimer()
{
	if (!m_CaretInfo.bVisible)
	{
		return;
	}

	if (m_CaretInfo.bShowByTime)
	{
		HideCaretByTimer();
	}
	else
	{
		ShowCaretByTimer();
	}
}

void CTxtWinHost::DrawCaretInPaint(HDC hPaintDC, RECT* pRcUpdate)
{
	if (!hPaintDC || !pRcUpdate || !m_CaretInfo.hDC || !m_CaretInfo.hCoveredBk)
	{
		return;
	}

	if (m_CaretInfo.bVisible && m_CaretInfo.bShowByTime)
	{
		m_CaretInfo.nCoveredBkPosX = m_CaretInfo.nCaretPosX;
		m_CaretInfo.nCoveredBkPosY = m_CaretInfo.nCaretPosY;

		RECT rcCoveredBk = 
		{
			m_CaretInfo.nCoveredBkPosX,
			m_CaretInfo.nCoveredBkPosY,
			m_CaretInfo.nCoveredBkPosX + m_CaretInfo.nCoveredBkWidth,
			m_CaretInfo.nCoveredBkPosY + m_CaretInfo.nCoveredBkHeight
		};

		RECT rcInterset = {0, 0, 0, 0};
		if (::IntersectRect(&rcInterset, pRcUpdate, &rcCoveredBk))
		{
			int nRealBkPoxX = rcInterset.left - rcCoveredBk.left;
			int nRealBkPoxY = rcInterset.top - rcCoveredBk.top;
			int nRealBkWidth = rcInterset.right - rcInterset.left;
			int nRealBkHeight = rcInterset.bottom - rcInterset.top;

			//��¼����긲�ǲ��ֵı���
			HBITMAP hOldBitmap = (HBITMAP)::SelectObject(m_CaretInfo.hDC, m_CaretInfo.hCoveredBk);

			BLENDFUNCTION bfAll = { AC_SRC_OVER, 0, 255, AC_SRC_OVER };
			::AlphaBlend(m_CaretInfo.hDC,
				nRealBkPoxX,
				nRealBkPoxY,
				nRealBkWidth,
				nRealBkHeight,
				hPaintDC,
				rcInterset.left,
				rcInterset.top,
				nRealBkWidth,
				nRealBkHeight,
				bfAll);

			::SelectObject(m_CaretInfo.hDC, hOldBitmap);

			//���ƹ��
			if (m_CaretInfo.hCaret)
			{
				HBITMAP hOldBitmap = (HBITMAP)::SelectObject(m_CaretInfo.hDC, m_CaretInfo.hCaret);

				::BitBlt(hPaintDC,
					rcInterset.left,
					rcInterset.top,
					nRealBkWidth,
					nRealBkHeight,
					m_CaretInfo.hDC,
					nRealBkPoxX,
					nRealBkPoxY,
					SRCINVERT);

				::SelectObject(m_CaretInfo.hDC, hOldBitmap);
			}
			else
			{
				::InvertRect(hPaintDC, &rcInterset);
			}
		}
	}
}

void CTxtWinHost::UpdateCaretByPosChange()
{
	if (!m_CaretInfo.bVisible)
	{
		return;
	}

	if (!m_CaretInfo.hDC)
	{
		return;
	}

	HDC hClientDC = ::GetDC(hwnd);
	if (hClientDC)
	{
		//�Ȼ�ԭ����긲�ǵĲ���
		if (m_CaretInfo.bShowByTime)
		{
			if (m_CaretInfo.hCoveredBk)
			{
				HBITMAP hOldBitmap = (HBITMAP)::SelectObject(m_CaretInfo.hDC, m_CaretInfo.hCoveredBk);

				BLENDFUNCTION bfAll = { AC_SRC_OVER, 0, 255, AC_SRC_OVER };

				RECT rcCaret = {
					m_CaretInfo.nCoveredBkPosX,
					m_CaretInfo.nCoveredBkPosY,
					m_CaretInfo.nCoveredBkPosX + m_CaretInfo.nCoveredBkWidth,
					m_CaretInfo.nCoveredBkPosY + m_CaretInfo.nCoveredBkHeight
				};

				RECT rcIntersect = { 0, 0, 0, 0 };
				if (::IntersectRect(&rcIntersect, &rcCaret, &rcClient))
				{
					::AlphaBlend(hClientDC,
						rcIntersect.left,
						rcIntersect.top,
						rcIntersect.right - rcIntersect.left,
						rcIntersect.bottom - rcIntersect.top,
						m_CaretInfo.hDC,
						rcIntersect.left - rcCaret.left,
						rcIntersect.top - rcCaret.top,
						rcIntersect.right - rcIntersect.left,
						rcIntersect.bottom - rcIntersect.top,
						bfAll);
				}

				::SelectObject(m_CaretInfo.hDC, hOldBitmap);
			}
		}

		//������ʾ���
		m_CaretInfo.bShowByTime = TRUE;

		//Ȼ����¼�¼���Ǳ�����λͼ�ߴ�
		if (m_CaretInfo.hCoveredBk)
		{
			if (m_CaretInfo.nCoveredBkWidth != m_CaretInfo.nCaretWdith || 
				m_CaretInfo.nCoveredBkHeight != m_CaretInfo.nCaretHeight)
			{
				::DeleteObject(m_CaretInfo.hCoveredBk);
				m_CaretInfo.hCoveredBk = NULL;

				m_CaretInfo.nCoveredBkWidth = m_CaretInfo.nCaretWdith;
				m_CaretInfo.nCoveredBkHeight = m_CaretInfo.nCaretHeight;

				LPBYTE pBits = NULL;
				m_CaretInfo.hCoveredBk = CreateMemDIBSec(m_CaretInfo.hDC, m_CaretInfo.nCoveredBkWidth, m_CaretInfo.nCoveredBkHeight, &pBits);
			}
		}
		else
		{
			m_CaretInfo.nCoveredBkWidth = m_CaretInfo.nCaretWdith;
			m_CaretInfo.nCoveredBkHeight = m_CaretInfo.nCaretHeight;

			LPBYTE pBits = NULL;
			m_CaretInfo.hCoveredBk = CreateMemDIBSec(m_CaretInfo.hDC, m_CaretInfo.nCoveredBkWidth, m_CaretInfo.nCoveredBkHeight, &pBits);
		}

		//��¼����긲�ǲ��ֵı���
		if (m_CaretInfo.hCoveredBk)
		{
			m_CaretInfo.nCoveredBkPosX = m_CaretInfo.nCaretPosX;
			m_CaretInfo.nCoveredBkPosY = m_CaretInfo.nCaretPosY;

			HBITMAP hOldBitmap = (HBITMAP)::SelectObject(m_CaretInfo.hDC, m_CaretInfo.hCoveredBk);

			BLENDFUNCTION bfAll = { AC_SRC_OVER, 0, 255, AC_SRC_OVER };
			::AlphaBlend(m_CaretInfo.hDC,
				0,
				0,
				m_CaretInfo.nCaretWdith,
				m_CaretInfo.nCaretHeight,
				hClientDC,
				m_CaretInfo.nCaretPosX,
				m_CaretInfo.nCaretPosY,
				m_CaretInfo.nCaretWdith,
				m_CaretInfo.nCaretHeight,
				bfAll);

			::SelectObject(m_CaretInfo.hDC, hOldBitmap);
		}

		//���ƹ��
		RECT rcCaret = {
			m_CaretInfo.nCaretPosX,
			m_CaretInfo.nCaretPosY,
			m_CaretInfo.nCaretPosX + m_CaretInfo.nCaretWdith,
			m_CaretInfo.nCaretPosY + m_CaretInfo.nCaretHeight
		};
		RECT rcIntersect = { 0, 0, 0, 0 };
		if (::IntersectRect(&rcIntersect, &rcCaret, &rcClient))
		{
			if (m_CaretInfo.hCaret)
			{
				HBITMAP hOldBitmap = (HBITMAP)::SelectObject(m_CaretInfo.hDC, m_CaretInfo.hCaret);

				//�뱳����XOR����
				::BitBlt(hClientDC,
					rcIntersect.left,
					rcIntersect.top,
					rcIntersect.right - rcIntersect.left,
					rcIntersect.bottom - rcIntersect.top,
					m_CaretInfo.hDC,
					rcIntersect.left - rcCaret.left,
					rcIntersect.top - rcCaret.top,
					SRCINVERT);

					::SelectObject(m_CaretInfo.hDC, hOldBitmap);
			}
			else
			{
				::InvertRect(hClientDC, &rcIntersect);
			}
		}

		//�ͷŴ���DC
		::ReleaseDC(hwnd, hClientDC);

		//���¿������ʱ��
		EnableCaretTimer(false);
		EnableCaretTimer(true);
	}
}

bool CTxtWinHost::EnableCaretTimer(bool bSet)
{
	LRESULT lResult = S_FALSE;
	if (bSet)
	{
		//�������ʱ��
		if (m_pIRichEditMsgProc)
		{
			lResult = m_pIRichEditMsgProc->OnRichEditMsgProc(WM_RICHEDIT_ENABLE_CARET_TIMER, (WPARAM)TRUE, 0);
		}
	}
	else
	{
		//�������ʱ��
		if (m_pIRichEditMsgProc)
		{
			lResult = m_pIRichEditMsgProc->OnRichEditMsgProc(WM_RICHEDIT_ENABLE_CARET_TIMER, (WPARAM)FALSE, 0);
		}
	}

	return (S_OK == lResult)?true:false;
}

void CTxtWinHost::ShowCaretByTimer()
{
	if (m_CaretInfo.nCaretWdith <= 0 || m_CaretInfo.nCaretHeight <= 0)
	{
		return;
	}

	if (!m_CaretInfo.hDC)
	{
		return;
	}

	m_CaretInfo.bShowByTime = TRUE;

	HDC hClientDC = ::GetDC(hwnd);
	if (hClientDC)
	{
		//���¹�긲�Ǳ�����λͼ�ߴ�
		if (m_CaretInfo.hCoveredBk)
		{
			if (m_CaretInfo.nCoveredBkWidth != m_CaretInfo.nCaretWdith || 
				m_CaretInfo.nCoveredBkHeight != m_CaretInfo.nCaretHeight)
			{
				::DeleteObject(m_CaretInfo.hCoveredBk);
				m_CaretInfo.hCoveredBk = NULL;

				m_CaretInfo.nCoveredBkWidth = m_CaretInfo.nCaretWdith;
				m_CaretInfo.nCoveredBkHeight = m_CaretInfo.nCaretHeight;

				LPBYTE pBits = NULL;
				m_CaretInfo.hCoveredBk = CreateMemDIBSec(m_CaretInfo.hDC, m_CaretInfo.nCoveredBkWidth, m_CaretInfo.nCoveredBkHeight, &pBits);
			}
		}
		else
		{
			m_CaretInfo.nCoveredBkWidth = m_CaretInfo.nCaretWdith;
			m_CaretInfo.nCoveredBkHeight = m_CaretInfo.nCaretHeight;

			LPBYTE pBits = NULL;
			m_CaretInfo.hCoveredBk = CreateMemDIBSec(m_CaretInfo.hDC, m_CaretInfo.nCoveredBkWidth, m_CaretInfo.nCoveredBkHeight, &pBits);
		}

		//��¼����긲�ǲ��ֵı���
		if (m_CaretInfo.hCoveredBk)
		{
			m_CaretInfo.nCoveredBkPosX = m_CaretInfo.nCaretPosX;
			m_CaretInfo.nCoveredBkPosY = m_CaretInfo.nCaretPosY;

			HBITMAP hOldBitmap = (HBITMAP)::SelectObject(m_CaretInfo.hDC, m_CaretInfo.hCoveredBk);

			BLENDFUNCTION bfAll = { AC_SRC_OVER, 0, 255, AC_SRC_OVER };
			::AlphaBlend(m_CaretInfo.hDC,
				0,
				0,
				m_CaretInfo.nCaretWdith,
				m_CaretInfo.nCaretHeight,
				hClientDC,
				m_CaretInfo.nCaretPosX,
				m_CaretInfo.nCaretPosY,
				m_CaretInfo.nCaretWdith,
				m_CaretInfo.nCaretHeight,
				bfAll);

			::SelectObject(m_CaretInfo.hDC, hOldBitmap);
		}

		//���ƹ��
		RECT rcCaret = {
			m_CaretInfo.nCaretPosX,
			m_CaretInfo.nCaretPosY,
			m_CaretInfo.nCaretPosX + m_CaretInfo.nCaretWdith,
			m_CaretInfo.nCaretPosY + m_CaretInfo.nCaretHeight
		};
		RECT rcIntersect = { 0, 0, 0, 0 };
		if (::IntersectRect(&rcIntersect, &rcCaret, &rcClient))
		{
			if (m_CaretInfo.hCaret)
			{
				HBITMAP hOldBitmap = (HBITMAP)::SelectObject(m_CaretInfo.hDC, m_CaretInfo.hCaret);

				//�뱳����XOR����
				::BitBlt(hClientDC,
					rcIntersect.left,
					rcIntersect.top,
					rcIntersect.right - rcIntersect.left,
					rcIntersect.bottom - rcIntersect.top,
					m_CaretInfo.hDC,
					rcIntersect.left - rcCaret.left,
					rcIntersect.top - rcCaret.top,
					SRCINVERT);

					::SelectObject(m_CaretInfo.hDC, hOldBitmap);
			}
			else
			{
				::InvertRect(hClientDC, &rcIntersect);
			}
		}

		//�ͷŴ���DC
		::ReleaseDC(hwnd, hClientDC);
	}
}

void CTxtWinHost::HideCaretByTimer()
{
	if (m_CaretInfo.nCoveredBkWidth <= 0 || m_CaretInfo.nCoveredBkHeight <= 0)
	{
		return;
	}

	if (!m_CaretInfo.hDC)
	{
		return;
	}

	m_CaretInfo.bShowByTime = FALSE;

	if (m_CaretInfo.hCoveredBk)
	{
		HDC hClientDC = ::GetDC(hwnd);
		if (hClientDC)
		{
			//�Ȼ�ԭ����긲�ǲ��ֵı���
			HBITMAP hOldBitmap = (HBITMAP)::SelectObject(m_CaretInfo.hDC, m_CaretInfo.hCoveredBk);

			BLENDFUNCTION bfAll = { AC_SRC_OVER, 0, 255, AC_SRC_OVER };

			RECT rcCaret = {
				m_CaretInfo.nCoveredBkPosX,
				m_CaretInfo.nCoveredBkPosY,
				m_CaretInfo.nCoveredBkPosX + m_CaretInfo.nCoveredBkWidth,
				m_CaretInfo.nCoveredBkPosY + m_CaretInfo.nCoveredBkHeight
			};

			RECT rcIntersect = { 0, 0, 0, 0 };
			if (::IntersectRect(&rcIntersect, &rcCaret, &rcClient))
			{
				::AlphaBlend(hClientDC,
					rcIntersect.left,
					rcIntersect.top,
					rcIntersect.right - rcIntersect.left,
					rcIntersect.bottom - rcIntersect.top,
					m_CaretInfo.hDC,
					rcIntersect.left - rcCaret.left,
					rcIntersect.top - rcCaret.top,
					rcIntersect.right - rcIntersect.left,
					rcIntersect.bottom - rcIntersect.top,
					bfAll);
			}

			::SelectObject(m_CaretInfo.hDC, hOldBitmap);

			//�ͷŴ��ڻ���DC
			::ReleaseDC(hwnd, hClientDC);
		}
	}
}

void CTxtWinHost::GetCaretPos(LPPOINT lpCaret)
{
	if (!lpCaret)
	{
		return;
	}

	if (m_CaretInfo.bVisible)
	{
		lpCaret->x = m_CaretInfo.nCaretPosX;
		lpCaret->y = m_CaretInfo.nCaretPosY;
	}
	else
	{
		::GetCaretPos(lpCaret);
	}
}

BOOL CALLBACK CTxtWinHost::EnumFontProc(LPLOGFONT lplf, LPTEXTMETRIC lptm, DWORD dwType, LPARAM lpData)
{
	// Add only TTF fellows, If you want you can change it to check for others
	if (TRUETYPE_FONTTYPE == dwType)
	{
		if (!lplf)
		{
			return TRUE;
		}

		// filter the font will cause bug
		if (0 == _tcsncmp(lplf->lfFaceName, MICRO_YAHEI_CHINESE, sizeof(lplf->lfFaceName)))
		{
			m_microYaheiSupport.m_bSupportChinese = TRUE;
		}
		else if (0 == _tcsncmp(lplf->lfFaceName, MICRO_YAHEI_ENGLISH, sizeof(lplf->lfFaceName)))
		{
			m_microYaheiSupport.m_bSupportEnglish = TRUE;
		}
	}

	return TRUE;
}