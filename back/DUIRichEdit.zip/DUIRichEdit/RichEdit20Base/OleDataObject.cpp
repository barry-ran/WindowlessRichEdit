#include "stdafx.h"
#include "OleDataObject.h"
#include "shlobj.h"

HRESULT CreateEnumFormatEtc(UINT cfmt, FORMATETC* pAfmt, IEnumFORMATETC** ppEnumFormatEtc)
{
	if (0 == cfmt || 0 == pAfmt || 0 == ppEnumFormatEtc)
	{
		return E_INVALIDARG;
	}

	*ppEnumFormatEtc = new CEnumFormatEtc(pAfmt, cfmt);

	return (*ppEnumFormatEtc)?S_OK:E_OUTOFMEMORY;
}

void DeepCopyFormatEtc(FORMATETC* pDest, FORMATETC* pSource)
{
	*pDest = *pSource;
	if (pSource->ptd)
	{
		pDest->ptd = (DVTARGETDEVICE*)CoTaskMemAlloc(sizeof(DVTARGETDEVICE));
		*(pDest->ptd) = *(pSource->ptd);
	}
}

CEnumFormatEtc::CEnumFormatEtc(FORMATETC* pFormatEtc, int nNumFormats)
{
	m_lRefCount = 1;

	m_nIndex = 0;

	m_nNumFormats = nNumFormats;

	m_pFormatEtc = new FORMATETC[nNumFormats];

	for (int i = 0; i < nNumFormats; ++i)
	{
		DeepCopyFormatEtc(&m_pFormatEtc[i], &pFormatEtc[i]);
	}
}

CEnumFormatEtc::~CEnumFormatEtc()
{
	for (ULONG i = 0; i < m_nNumFormats; ++i)
	{
		if (m_pFormatEtc[i].ptd)
		{
			CoTaskMemFree(m_pFormatEtc[i].ptd);
		}
	}

	delete[] m_pFormatEtc;
}

HRESULT STDMETHODCALLTYPE CEnumFormatEtc::QueryInterface(REFIID iid, void** ppvObject)
{
	if (IID_IUnknown == iid)
	{
		*ppvObject = static_cast<IEnumFORMATETC*>(this);
		AddRef();
	}
	else if (IID_IDataObject == iid)
	{
		*ppvObject = static_cast<IEnumFORMATETC*>(this);
		AddRef();
	}
	else
	{
		*ppvObject= NULL;
		return E_NOINTERFACE;
	}

	return S_OK;
}

ULONG STDMETHODCALLTYPE CEnumFormatEtc::AddRef()
{
	m_lRefCount++;

	return m_lRefCount;
}

ULONG STDMETHODCALLTYPE CEnumFormatEtc::Release()
{
	if (0 == m_lRefCount)
	{
		delete this;
		return 0;
	}
	else
	{
		m_lRefCount--;
		if (0 == m_lRefCount)
		{
			delete this;
			return 0;
		}
	}
	return m_lRefCount;
}

HRESULT STDMETHODCALLTYPE CEnumFormatEtc::Reset(void)
{
	m_nIndex = 0;

	return S_OK;
}

HRESULT STDMETHODCALLTYPE CEnumFormatEtc::Skip(ULONG celt)
{
	m_nIndex += celt;

	return (m_nIndex <= m_nNumFormats)?S_OK:S_FALSE;
}

HRESULT STDMETHODCALLTYPE CEnumFormatEtc::Clone(IEnumFORMATETC** ppEnumFormatEtc)
{
	HRESULT hResult = CreateEnumFormatEtc(m_nNumFormats, m_pFormatEtc, ppEnumFormatEtc);
	if (S_OK == hResult)
	{
		((CEnumFormatEtc*)*ppEnumFormatEtc)->m_nIndex = m_nIndex;
	}

	return hResult;
}

HRESULT STDMETHODCALLTYPE CEnumFormatEtc::Next(ULONG celt, FORMATETC* pRgelt, ULONG* pCeltFetched)
{
	ULONG copied = 0;

	while (m_nIndex < m_nNumFormats && copied < celt)
	{
		DeepCopyFormatEtc(&pRgelt[copied], &m_pFormatEtc[m_nIndex]);
		copied++;
		m_nIndex++;
	}

	if (pCeltFetched != 0)
	{
		*pCeltFetched = copied;
	}

	return (copied == celt)?S_OK:S_FALSE;
}

COleDataObject::COleDataObject(FORMATETC* fmtetc, STGMEDIUM* stgmed, int count)
{
	m_lRefCount = 1;

	m_nNumFormats = count;

	m_pFormatEtc =  new FORMATETC[count];

	m_pStgMedium = new STGMEDIUM[count];

	for (int i = 0; i < count; ++i)
	{
		DeepCopyFormatEtc(&(m_pFormatEtc[i]), &(fmtetc[i]));

		m_pStgMedium[i] = stgmed[i];
	}
}

COleDataObject::~COleDataObject()
{
	for (int i = 0; i < m_nNumFormats; ++i)
	{
		if (NULL != m_pFormatEtc[i].ptd)
		{
			CoTaskMemFree(m_pFormatEtc[i].ptd);
		}
	}
	if (m_pFormatEtc) delete[] m_pFormatEtc;


	for (int i = 0; i < m_nNumFormats; ++i)
	{
		::ReleaseStgMedium(&(m_pStgMedium[i]));
	}
	if (m_pStgMedium) delete[] m_pStgMedium;
}

HGLOBAL DupGlobalMem(HGLOBAL hMem)
{
	DWORD dwLen = GlobalSize(hMem);
	PVOID pSource = GlobalLock(hMem);
	PVOID pDest = GlobalAlloc(GMEM_FIXED, dwLen);
	memcpy(pDest, pSource, dwLen);
	GlobalUnlock(hMem);

	return pDest;
}

int COleDataObject::LookupFormatEtc(FORMATETC* pFormatEtc)
{
	for (int i = 0; i < m_nNumFormats; i++)
	{
		if ((m_pFormatEtc[i].tymed & pFormatEtc->tymed) &&
			m_pFormatEtc[i].cfFormat == pFormatEtc->cfFormat &&
			m_pFormatEtc[i].dwAspect == pFormatEtc->dwAspect)
		{
			return i;
		}
	}

	return -1;
}

HRESULT STDMETHODCALLTYPE COleDataObject::QueryInterface(REFIID iid, void** ppvObject)
{
	if (IID_IUnknown == iid)
	{
		*ppvObject = static_cast<IDataObject*>(this);
		AddRef();
	}
	else if (IID_IDataObject == iid)
	{
		*ppvObject = static_cast<IDataObject*>(this);
		AddRef();
	}
	else
	{
		*ppvObject= NULL;
		return E_NOINTERFACE;
	}

	AddRef();

	return S_OK;
}

ULONG STDMETHODCALLTYPE COleDataObject::AddRef()
{
	m_lRefCount++;

	return m_lRefCount;
}

ULONG STDMETHODCALLTYPE COleDataObject::Release()
{
	if (0 == m_lRefCount)
	{
		delete this;
		return 0;
	}
	else
	{
		m_lRefCount--;
		if (0 == m_lRefCount)
		{
			delete this;
			return 0;
		}
	}
	return m_lRefCount;
}

HRESULT STDMETHODCALLTYPE COleDataObject::GetData(FORMATETC* pFormatEtc, STGMEDIUM* pmedium)
{
	int idx;
	if (-1 == (idx = LookupFormatEtc(pFormatEtc)))
	{
		return DV_E_FORMATETC;
	}
	else if (NULL == m_pStgMedium[idx].hGlobal)
	{
		return DV_E_FORMATETC;
	}

	memset(pmedium, 0, sizeof(STGMEDIUM));
	pmedium->tymed = m_pFormatEtc[idx].tymed;
	pmedium->pUnkForRelease = 0;
	switch(m_pFormatEtc[idx].tymed)
	{
	case TYMED_HGLOBAL:
		{
			pmedium->hGlobal = DupGlobalMem(m_pStgMedium[idx].hGlobal);
		}
		break;
	default:
		{
			return DV_E_FORMATETC;
		}
	}

	return S_OK;
}

HRESULT STDMETHODCALLTYPE COleDataObject::GetDataHere(FORMATETC* pFormatEtc, STGMEDIUM* pmedium)
{
	int idx;
	if (-1 == (idx = LookupFormatEtc(pFormatEtc)))
	{
		return DV_E_FORMATETC;
	}

	pmedium->tymed = m_pFormatEtc[idx].tymed;
	pmedium->pUnkForRelease = 0;
	switch(m_pFormatEtc[idx].tymed)
	{
	case TYMED_HGLOBAL:
		{
			pmedium->hGlobal = DupGlobalMem(m_pStgMedium[idx].hGlobal);
		}
		break;
	default:
		{
			return DV_E_FORMATETC;
		}
	}

	return S_OK;
}

HRESULT STDMETHODCALLTYPE COleDataObject::QueryGetData(FORMATETC* pFormatEtc)
{
	int idx = LookupFormatEtc(pFormatEtc);
	if (-1 == idx)
	{
		return DV_E_FORMATETC;
	}
	else
	{
		if (NULL != m_pStgMedium[idx].hGlobal)
		{
			return S_OK;
		}
	}

	return DV_E_FORMATETC;
}

HRESULT STDMETHODCALLTYPE COleDataObject::GetCanonicalFormatEtc(FORMATETC* pformatectIn, FORMATETC* pformatetcOut)
{
	return DATA_S_SAMEFORMATETC;
}

HRESULT STDMETHODCALLTYPE COleDataObject::SetData(FORMATETC* pformatetc, STGMEDIUM* pmedium, BOOL fRelease)
{
	int idx;
	if (-1 == (idx = LookupFormatEtc(pformatetc)))
	{
		return DATA_S_SAMEFORMATETC;
	}
	else
	{
		if (NULL != m_pFormatEtc[idx].ptd)
		{
			CoTaskMemFree(m_pFormatEtc[idx].ptd);
			m_pFormatEtc->ptd = NULL;
		}
		if (NULL != pformatetc->ptd)
		{
			DeepCopyFormatEtc(&(m_pFormatEtc[idx]), pformatetc);
		}

		if (NULL != m_pStgMedium[idx].hGlobal)
		{
			::GlobalFree(m_pStgMedium[idx].hGlobal);
			m_pStgMedium[idx].hGlobal = NULL;
		}
	}

	switch(pformatetc->tymed)
	{
	case TYMED_HGLOBAL:
		{
			m_pStgMedium[idx].tymed = pmedium->tymed;
			m_pStgMedium[idx].hGlobal = DupGlobalMem(pmedium->hGlobal);
			m_pStgMedium[idx].pUnkForRelease = NULL;
		}
		break;
	default:
		{
			return DATA_S_SAMEFORMATETC;
		}
		break;
	}

	return DATA_S_SAMEFORMATETC;
}

HRESULT STDMETHODCALLTYPE COleDataObject::EnumFormatEtc(DWORD dwDirection, IEnumFORMATETC** ppenumFormatEtc)
{
	//return CreateEnumFormatEtc(m_nNumFormats, m_pFormatEtc, ppenumFormatEtc); //window2000���¿���ʹ�øýӿ�

	if (DATADIR_GET == dwDirection)
	{
		int nNumFormatsReal = 0;
		for (int i = 0; i < m_nNumFormats; ++i)
		{
			if (NULL != m_pStgMedium[i].hGlobal && TYMED_HGLOBAL == m_pStgMedium[i].tymed)
			{
				nNumFormatsReal++;
			}
		}

		int nIndex = 0;
		FORMATETC* pFormatEtcReal = new FORMATETC[nNumFormatsReal];
		for (int i = 0; i < m_nNumFormats; ++i)
		{
			if (NULL != m_pStgMedium[i].hGlobal && TYMED_HGLOBAL == m_pStgMedium[i].tymed)
			{
				DeepCopyFormatEtc(&(pFormatEtcReal[nIndex]), &(m_pFormatEtc[i]));

				nIndex++;
			}
		}

		HRESULT hr = SHCreateStdEnumFmtEtc(nNumFormatsReal, pFormatEtcReal, ppenumFormatEtc);

		for (int i = 0; i < nNumFormatsReal; ++i)
		{
			if (NULL != pFormatEtcReal[i].ptd)
			{
				CoTaskMemFree(pFormatEtcReal[i].ptd);
			}
		}
		delete[] pFormatEtcReal;

		return hr;
	}
	else
	{
		return E_NOTIMPL;
	}

	return E_NOTIMPL;
}

HRESULT STDMETHODCALLTYPE COleDataObject::DAdvise(FORMATETC* pformatetc, DWORD advf, IAdviseSink* pAdvSink, DWORD* pdwConnection)
{
	*pdwConnection = 0;
	return OLE_E_ADVISENOTSUPPORTED;
}

HRESULT STDMETHODCALLTYPE COleDataObject::DUnadvise(DWORD dwConnection)
{
	return OLE_E_ADVISENOTSUPPORTED;
}

HRESULT STDMETHODCALLTYPE COleDataObject::EnumDAdvise(LPENUMSTATDATA* ppenumAdvise)
{
	*ppenumAdvise = NULL;
	return OLE_E_ADVISENOTSUPPORTED;
}

HRESULT CreateOleDataObject(FORMATETC* fmtetc, STGMEDIUM* stgmeds, UINT count, IDataObject** ppDataObject)
{
	if (0 == ppDataObject)
	{
		return E_INVALIDARG;
	}

	*ppDataObject = new COleDataObject(fmtetc, stgmeds, count);

	return (*ppDataObject)?S_OK:E_OUTOFMEMORY;
}

COleDataRecvObject::COleDataRecvObject(IDataObject* pIDataObject)
{
	m_pIDataObject = pIDataObject;
}

COleDataRecvObject::~COleDataRecvObject()
{

}

BOOL COleDataRecvObject::IsDataAvailable(CLIPFORMAT cfFormat, BOOL bFromClipBoard)
{
	if (bFromClipBoard)
	{
		return ::IsClipboardFormatAvailable(cfFormat);
	}
	else if (m_pIDataObject)
	{
		FORMATETC formatEtc;
		formatEtc.cfFormat = cfFormat;
		formatEtc.ptd = NULL;
		formatEtc.dwAspect = DVASPECT_CONTENT;
		formatEtc.lindex = -1;
		formatEtc.tymed = TYMED_HGLOBAL|TYMED_GDI|TYMED_MFPICT|TYMED_ENHMF|TYMED_FILE|TYMED_ISTREAM;
		return (S_OK == m_pIDataObject->QueryGetData(&formatEtc));
	}

	return FALSE;
}

HGLOBAL COleDataRecvObject::GetGlobalData(CLIPFORMAT cfFormat)
{
	if (m_pIDataObject)
	{
		FORMATETC formatEtc;
		formatEtc.cfFormat = cfFormat;
		formatEtc.ptd = NULL;
		formatEtc.dwAspect = DVASPECT_CONTENT;
		formatEtc.lindex = -1;
		formatEtc.tymed = TYMED_HGLOBAL|TYMED_GDI|TYMED_MFPICT|TYMED_ENHMF|TYMED_FILE|TYMED_ISTREAM;

		STGMEDIUM stgMedium;
		m_pIDataObject->GetData(&formatEtc, &stgMedium);

		return stgMedium.hGlobal;
	}

	return NULL;
}

BOOL COleDataRecvObject::GetData(CLIPFORMAT cfFormat, STGMEDIUM* pStgMedium)
{
	if (m_pIDataObject)
	{
		FORMATETC formatEtc;
		formatEtc.cfFormat = cfFormat;
		formatEtc.ptd = NULL;
		formatEtc.dwAspect = DVASPECT_CONTENT;
		formatEtc.lindex = -1;
		formatEtc.tymed =TYMED_HGLOBAL|TYMED_GDI|TYMED_MFPICT|TYMED_ENHMF|TYMED_FILE|TYMED_ISTREAM;

		return (S_OK == m_pIDataObject->GetData(&formatEtc, pStgMedium));
	}

	return FALSE;
}