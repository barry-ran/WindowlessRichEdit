/**
 * \brief RichEdit��ole�ص��ӿ�ʵ��
 * \author ts
 * \date 2011-7-17
 */
#pragma once
#include <RichOle.h>
#include "IRichEditMsgProc.h"

struct stClipBoardData 
{
	CHARRANGE* m_lpchrg;
	DWORD m_reco;
	LPDATAOBJECT* m_lplpdataobj;
};

struct stAccpetData
{
	CLIPFORMAT* m_lpcformat;
	DWORD m_reco;
	LPDATAOBJECT m_lpdataobj;
};

class IExRichEditOleCallback : public IRichEditOleCallback
{
public:
	IExRichEditOleCallback();
	virtual ~IExRichEditOleCallback();
	
	
	HWND GetHwnd() const { return m_hWnd; }
	void SetHwnd(HWND val) { m_hWnd = val; }
	void SetRichEditMsgProc(IRichEditMsgProc* pMsgProc) { m_pIRichEditMsgProc = pMsgProc; }

	virtual HRESULT STDMETHODCALLTYPE GetNewStorage(LPSTORAGE* lplpstg);
	virtual HRESULT STDMETHODCALLTYPE QueryInterface(REFIID iid, void ** ppvObject);
	virtual ULONG STDMETHODCALLTYPE AddRef();
	virtual ULONG STDMETHODCALLTYPE Release();
	virtual HRESULT STDMETHODCALLTYPE GetInPlaceContext(LPOLEINPLACEFRAME FAR *lplpFrame,
		LPOLEINPLACEUIWINDOW FAR *lplpDoc, LPOLEINPLACEFRAMEINFO lpFrameInfo);
	virtual HRESULT STDMETHODCALLTYPE ShowContainerUI(BOOL fShow);
	virtual HRESULT STDMETHODCALLTYPE QueryInsertObject(LPCLSID lpclsid, LPSTORAGE lpstg, LONG cp);
	virtual HRESULT STDMETHODCALLTYPE DeleteObject(LPOLEOBJECT lpoleobj);
	virtual HRESULT STDMETHODCALLTYPE QueryAcceptData(LPDATAOBJECT lpdataobj, CLIPFORMAT FAR *lpcfFormat,
		DWORD reco, BOOL fReally, HGLOBAL hMetaPict);
	virtual HRESULT STDMETHODCALLTYPE ContextSensitiveHelp(BOOL fEnterMode);
	virtual HRESULT STDMETHODCALLTYPE GetClipboardData(CHARRANGE FAR *lpchrg, DWORD reco, LPDATAOBJECT FAR *lplpdataobj);
	virtual HRESULT STDMETHODCALLTYPE GetDragDropEffect(BOOL fDrag, DWORD grfKeyState, LPDWORD pdwEffect);
	virtual HRESULT STDMETHODCALLTYPE GetContextMenu(WORD seltyp, LPOLEOBJECT lpoleobj, CHARRANGE FAR *lpchrg,
		HMENU FAR *lphmenu);

private:
	IRichEditMsgProc* m_pIRichEditMsgProc;

	int m_iNumStorages;
	CLSID m_clsid;
	CComPtr<IStorage> pStorage;
	DWORD m_dwRef;
	HWND m_hWnd;

	DWORD	m_dwDropDataFormat;   //��ק���ݵļ��а��ʽ
};