#include "stdafx.h"
#include "md5.h"
#include "md5ex.h"
#include <stdio.h>
#include <memory.h>
#include <string.h>

bool MD5File(const char* pszFile,unsigned char *pMD5 /* 16 Byte*/)
{
	FILE* fp = fopen(pszFile,"rb");
	if(!fp) return false;

	unsigned char pTempMD5[32];
	unsigned char buffer[4096];
	size_t len;
	fseek(fp,0,SEEK_END);
	len = ftell(fp);
	fseek(fp,0,SEEK_SET);

	MD5_CTX context;
	MD5Init (&context);
	while( len )
	{
		size_t readLen = (len < 4096 ? len : 4096);
		if(1 != fread(buffer,readLen,1,fp))
		{
			MD5Final (pTempMD5, &context);
			return false;
		}
		len -= readLen;
		MD5Update (&context, buffer, readLen);
	}
	MD5Final (pTempMD5, &context);


	for(size_t i=0; i <16; ++i)
	{
		int ch = (pTempMD5[i] & 0xf0) >> 4;
		if(ch < 10)
			pMD5[i*2] = ch + '0';
		else
			pMD5[i*2] = ch-0xa + 'a';

		ch = (pTempMD5[i]&0xf);
		if(ch < 10)
			pMD5[i*2+1] = ch + '0';
		else
			pMD5[i*2+1] = ch-0xa + 'a';
	}
	pMD5[32]  = 0;

	if (fp)
	{
		fclose(fp);
	}
	
	return true;
}

bool MD5Data(const void* pData,size_t size,unsigned char *pMD5 /* 16 Byte*/)
{
	MD5_CTX context;
	unsigned char pTempMD5[32];
	MD5Init (&context);
	MD5Update (&context, (unsigned char*)pData, size);
	MD5Final (pTempMD5, &context);

	for(size_t i=0; i <16; ++i)
	{
		int ch = (pTempMD5[i] & 0xf0) >> 4;
		if(ch < 10)
			pMD5[i*2] = ch + '0';
		else
			pMD5[i*2] = ch-0xa + 'a';

		ch = (pTempMD5[i]&0xf);
		if(ch < 10)
			pMD5[i*2+1] = ch + '0';
		else
			pMD5[i*2+1] = ch-0xa + 'a';
	}
	pMD5[32]  = 0;

	return true;
}