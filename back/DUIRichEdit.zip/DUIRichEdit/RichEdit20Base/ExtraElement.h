/**
 * \brief RichEdit����չԪ��
 * \date 2013-3-24
 * \author ts
 */
#pragma once
#include "IXXImageEx.h"
#include <list>
#include <vector>
#include "IRichEditMsgProc.h"

//��չͼƬ
class CExtraImage
{
	enum ImageSourceType
	{
		eImageSource_FromPath,
		eImageSource_FromResource,
		eImageSource_FromImageBase,
		eImageSource_FromHBITMAP,
	};

public:
	CExtraImage(HINSTANCE hResInstance, UINT uResID, LPCTSTR lptszType = _T("GIF"));
	CExtraImage(LPCTSTR lptszImgPath);
	CExtraImage(CUIImageBaseCom* pImgBase);
	CExtraImage(HBITMAP hBitmap, BOOL bBitmapCopyFrom);
	~CExtraImage();

public:
	void AddRef();
	void Release();
	bool IsValid();

	bool IsMyself(HINSTANCE hResInstance, UINT uResID);
	bool IsMyself(LPCTSTR lptszImgPath);
	bool IsMyself(CUIImageBaseCom* pImgBase);
	bool IsMyself(HBITMAP hBitmapCopyFrom, HBITMAP hBitmapUsed);
	bool IsMyself(HBITMAP hBitmap, BOOL bBitmapCopyFrom);

	void OnPaint(HDC hDC, LPRECT lpRect, LPRECT lpClipRect);

	static CExtraImage* NewExtraImage(HINSTANCE hResIntance, UINT uResID, LPCTSTR lptszType = _T("GIF"));
	static CExtraImage* NewExtraImage(LPCTSTR lptszImgPath);
	static CExtraImage* NewExtraImage(CUIImageBaseCom* pImgBase);
	static CExtraImage* NewExtraImage(HBITMAP hBitmap, BOOL bBitmapCopyFrom);

private:
	ImageSourceType		m_eImgSourceType;

	UINT				m_uImgResID;
	HINSTANCE			m_hResInstance;

	WTL::CString		m_strImgPath;
	IXXImageEx*			m_pXXPictureEx;

	CUIImageBaseCom*	m_pImageBase;

	CSize				m_szBitmap;
	HBITMAP				m_hBitmapCopyFrom;
	HBITMAP				m_hBitmapUsed;

	int					m_nRefCount;
	static std::list<CExtraImage*> m_ExtraEleColl;
};

//��չԪ��
class CExtraElement
{
public:
	CExtraElement(
		bool bAutoSize,
		bool bFullFillLayout,
		int nWidth,
		int nHeight,
		int nBeginCharIndex,
		int nEndCharIndex,
		LPRECT lpRectOffset,
		E_RICHEDIT_ELEMENT_VALIGN eVAlign);
	~CExtraElement();

public:
	UINT GetID() { return m_uID; }

	void SetInsertingFlag(bool bInserting) { m_bInserting = bInserting; }
	bool GetInsertingFlag() { return m_bInserting; }

	void SetImage(
		int nImageLeft,
		int nImageTop,
		HINSTANCE hResInstance,
		UINT uResID,
		LPCTSTR lptszType = _T("GIF"));
	void SetImage(
		int nImageLeft,
		int nImageTop,
		LPCTSTR lptszImgPath);
	void SetImage(
		int nImageLeft,
		int nImageTop,
		CUIImageBaseCom* pImgBase);
	void SetImage(
		int nImageLeft,
		int nImageTop,
		HBITMAP hBitmap,
		BOOL bBitmapCopyFrom);
	void SetImageArray(
		int nImageLeft,
		int nImageTop,
		RICHEDIT_RESOURCE_IMG* pImageArray,
		int nArrayCount);
	void SetImageArray(
		int nImageLeft,
		int nImageTop,
		LPCTSTR* pImageArray,
		int nArrayCount);
	void SetImageArray(
		int nImageLeft,
		int nImageTop,
		CUIImageBaseCom** pImageArray,
		int nArrayCount);
	void SetImageArray(
		int nImageLeft,
		int nImageTop,
		RICHEDIT_HBITMAP_IMG* pImageArray,
		int nArrayCount);

	void SetSubImage(
		int nImageLeft,
		int nImageTop,
		HINSTANCE hResInstance,
		UINT uResID,
		LPCTSTR lptszType = _T("GIF"));
	void SetSubImage(
		int nImageLeft,
		int nImageTop,
		LPCTSTR lptszImgPath);
	void SetSubImage(
		int nImageLeft,
		int nImageTop,
		CUIImageBaseCom* pImgBase);
	void SetSubImage(
		int nImageLeft,
		int nImageTop,
		HBITMAP hBitmap,
		BOOL bBitmapCopyFrom);
	void SetSubImageArray(
		int nImageLeft,
		int nImageTop,
		RICHEDIT_RESOURCE_IMG* pImageArray,
		int nArrayCount);
	void SetSubImageArray(
		int nImageLeft,
		int nImageTop,
		LPCTSTR* pImageArray,
		int nArrayCount);
	void SetSubImageArray(
		int nImageLeft,
		int nImageTop,
		CUIImageBaseCom** pImageArray,
		int nArrayCount);
	void SetSubImageArray(
		int nImageLeft,
		int nImageTop,
		RICHEDIT_HBITMAP_IMG* pImageArray,
		int nArrayCount);

	void SetText(int nTextLeft, int nTextTop, LPCTSTR lptszText, COLORREF clrText);

	void SetSupportClick(bool bSupport) { m_bSupportClick = bSupport; }
	bool IsSupportClick() { return m_bSupportClick; }

	void SetExtraData(DWORD_PTR dwExtraData) { m_dwExtraData = dwExtraData; }
	DWORD_PTR GetExtraData() { return m_dwExtraData; }

	void Destroy();
	void DestroySub();

	bool IsAutoSize() { return m_bAutoSize; }
	bool IsFullFillLayout() { return m_bFullFillLayout; }

	int GetBeginCharIndex() { return m_nBeginCharIndex; }
	void SetBeginCharIndex(int nCharIndex) { m_nBeginCharIndex = nCharIndex; }

	int GetEndCharIndex() { return m_nEndCharIndex; }
	void SetEndCharIndex(int nCharIndex) { m_nEndCharIndex = nCharIndex; }

	void SetClientIndent(int nLeftClientIndent, int nRightClientIndent);
	void SetMinSize(int nMinWidth, int nMinHeight);
	void SetMaxSize(int nMaxWidth, int nMaxHeight);

	E_RICHEDIT_ELEMENT_VALIGN GetVAlign() { return m_eVAlign; }
	RECT GetOffset();

	int GetREContentLeftIndent() { return m_nREContentLeftIndent; }
	void SetREContentLeftIndent(int nIndent) { m_nREContentLeftIndent = nIndent; }

	int GetREContentRightIndent() { return m_nREContentRightIndent; }
	void SetREContentRightIndent(int nIndent) { m_nREContentRightIndent = nIndent; }

	WORD GetREContentAlign() { return m_wREContentAlign; }
	void SetREContentAlign(WORD wAlignment) { m_wREContentAlign = wAlignment; }

	bool IsREContentAlignInHalf() { return m_bREContentAlignInHalf; }
	void SetREContentAlignInHalf(bool bInHalf) { m_bREContentAlignInHalf = bInHalf; }

	int GetLeftClientIndent();
	int GetRightClientIndent();

	int GetWidth() { return m_nWidth; }
	int GetHeight() { return m_nHeight; }

	int GetMinWidth() { return m_nMinWidth; }
	int GetMinHeight() { return m_nMinHeight; }

	int GetMaxWidth() { return  m_nMaxWidth; }
	int GetMaxHeight() { return m_nMaxHeight; }

	bool IsImageArray();

	bool CheckREAlign(LPCRECT lpREClient);
	void ResetREAlignResult();
	void OnPaint(HDC hDC, LPRECT lpRect, LPRECT lpClipRect, UINT uDrawTick);

    void SetOleID(DWORD dID);
    DWORD GetOleID();
private:
	UINT m_uID;
	bool m_bInserting;
	bool m_bAutoSize;
	bool m_bFullFillLayout;
	bool m_bSupportClick;
	DWORD_PTR m_dwExtraData;
	int m_nBeginCharIndex;
	int m_nEndCharIndex;
	CRect m_rcOffset;
	int m_nLeftClientIndent;
	int m_nRightClientIndent;
	int m_nWidth;
	int m_nHeight;
	int m_nMinWidth;
	int m_nMinHeight;
	int m_nMaxWidth;
	int m_nMaxHeight;
	E_RICHEDIT_ELEMENT_VALIGN m_eVAlign;

	//RichEdit���ݲ���
	CRect m_rcREClient;
	int m_nREContentLeftIndent;
	int m_nREContentRightIndent;
	WORD m_wREContentAlign;
	bool m_bREContentAlignInHalf;

	//ͼƬ
	int m_nImgLeft;
	int m_nImgTop;
	std::vector<CExtraImage*> m_ExtraImgColl;

	//ͼƬ�򶯻�֡<��>
	int m_nSubImgLeft;
	int m_nSubImgTop;
	std::vector<CExtraImage*> m_SubExtraImgColl;

	//��ʾ����
	int m_nTextLeft;
	int m_nTextTop;
	COLORREF m_clrText;
	WTL::CString m_strText;

    // oleID
    DWORD m_uOleID;
};