/**
 * \brief RichEdit��GIf��Ч������
 * \author ts
 * \date 2011-7-17
 */
#pragma once
#include "atlmisc.h"
#include <Richedit.h>
#include <RichOle.h>
#include <vector>
#include <list>
#include "IXXImageEx.h"
#include "IRichEditMsgProc.h"
#include "IOleProcesser.h"

class CIMGifProcesser : public IOleProcesser
{
//�Զ���ṹ
public:
	/**
	 * \brief �Ѵ�gif����Դ
	 */
	struct stResElem
	{
		WTL::CString   m_szResName;
		DWORD          m_dwRef;
		UINT		   m_nResID;
		HINSTANCE	   m_hResInstance;
		UINT           m_nFrameCount;
		SIZE           m_PictureSize;
		BOOL           m_bIsGIF;
		COLORREF       m_clrBackground;
		IXXImageEx*    m_xxPictureEx;
	};
	typedef std::vector<stResElem*> Vec_ResList;

//���졢����
public:
	CIMGifProcesser();
	virtual ~CIMGifProcesser();

//���ؽӿ�
public:
	virtual OleProcesserType GetType();

	virtual void SetUserData(DWORD_PTR dwUserData) { m_dwUserData = dwUserData; }
	virtual DWORD_PTR GetUserData() { return m_dwUserData; }

	virtual BOOL IsEnableAutoSize() { return m_bEnableAutoSize; }
	virtual void EnableAutoSize(BOOL bEnable) { m_bEnableAutoSize = bEnable; }

	virtual SIZE GetSize() const;
    virtual void SetSize(int nWidth, int nHeight){}

	virtual BOOL GetVisible() { return m_bVisible; }
	virtual void SetVisible(BOOL bVisible) { m_bVisible = bVisible; }

	virtual void SetVisibleInside(BOOL bVisible);
	virtual void SyncVisible();

	virtual void OnPaint(HDC hDC, LPRECT lpRect, bool& bResultPlayAni, UINT uAniTick, LPRECT lpClipRect = NULL, bool bForbidSmooth = true);

//����ӿ�
public:
	void Stop();
	void Destroy();

	BOOL IsGIF() const;
	BOOL IsPlaying() const;
	BOOL IsAnimatedGIF() const;

	BOOL IsLoadFromRes() const;
	LPCTSTR GetFilePathName() const { return m_szFileName; }
	HINSTANCE GetResInstance() { return m_hResInstance; }
	UINT GetResID() { return m_nResID; }

	void SetFileURL(LPCTSTR lpFileURL);
	LPCTSTR GetFileURL() const;
	BOOL IsExistFileURL() const;

	void SetFileURLImageSize(int nWidth, int nHeight);
	int GetFileURLImageWidth();
	int GetFileURLImageHeight();

	int GetFrameCount() const;
	COLORREF GetBkColor() const;
	void SetBkColor(COLORREF clr);
	
	BOOL Draw();
	BOOL Load(LPCTSTR szFileName, IRichEditMsgProc* pMsgProc);
	BOOL Load(HINSTANCE hInstance, UINT nIDResource, const char* lpszType, IRichEditMsgProc* pMsgProc);
	void OnDestroy();
	BOOL GetFirstBitmap(HDC hDC);

	BOOL IsEnableSnapshot() { return m_bEnableSnapshot; }
	void EnableSnapshot(BOOL bEnable);

	void SetRichEditMsgProc(IRichEditMsgProc* pMsgProc) { m_pRichEditMsgProc = pMsgProc; }

protected:
	void ClearRes();
	Vec_ResList::iterator GetIterFromResList();

	static void ThreadAnimation();
	static UINT WINAPI _ThreadAnimation(LPVOID pParam);
	bool DoAnimation();
	BOOL LoadDone();
	void DestroySnapshot();

protected:
	DWORD_PTR m_dwUserData;
	SIZE     m_PictureSize;
	UINT     m_nCurrFrame;
	BOOL     m_bIsPlaying;
	BOOL     m_bIsGIF;
	BOOL     m_bIsInitialized;
	UINT     m_nFrameCount;
	UINT     m_nElapseTime;
	UINT	 m_nResID;
	HINSTANCE m_hResInstance;
	WTL::CString m_szFileName;
	WTL::CString m_szFileURL;
	SIZE     m_PictureURLSize;
	COLORREF m_clrBackground;
	BOOL	 m_bVisible;
	BYTE     m_bVisibleInside;
	BOOL	 m_bCanGoNextFrame;

	BOOL	 m_bEnableAutoSize;
	BOOL	 m_bEnableSnapshot;
	SIZE	 m_szSnapshot;
	HDC		 m_hDCSnapshot;
	HBITMAP	 m_hBitmapSnapshot;

	static std::list<CIMGifProcesser*> m_vecGifList;
	static std::list<CIMGifProcesser*> m_vecAddingGifList;
	static std::list<IRichEditMsgProc*>  m_vecUpdateWnd;
	static Vec_ResList        m_vecResList;

	static volatile BOOL      m_bExitThread;
	static HANDLE             m_hThread;

	static HANDLE             m_hExitEvent;
	static LPCRITICAL_SECTION m_lpSection;
	static HANDLE             m_hAddingEvent;
	static HBRUSH             m_hBgBrush;

	IXXImageEx*               m_xxPictureEx;

	IRichEditMsgProc*         m_pRichEditMsgProc;
};
