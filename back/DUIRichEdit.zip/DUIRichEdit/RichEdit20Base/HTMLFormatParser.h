/**
 * \brief HTML ��ʽ������
 * \author ts
 * \date 2011-7-17
 */
#pragma once
#include <vector>

struct stHTMLElem
{
	stHTMLElem()
	: m_nType(0)
	, m_nSysFace(-1)
	{}
	int m_nType; //0Ϊ���֣�1ΪͼƬ��2Ϊ������ͼƬ
	int m_nSysFace; //ϵͳ��������
	WTL::CString m_strElem; //����������Ϣ�Լ�ͼƬ·��
};

class CHTMLFormatParser
{
public:
	CHTMLFormatParser()
	: m_bProducing(false)
	, m_nCurElem(0)
	{
		m_strHttpFileSavePath = _T("");
		m_uSysImgPngStart = 2050;
		m_uSysImgPngEnd = 2100;
		m_uSysImgGifStart = 2000;
		m_uSysImgGifEnd = 2049;
	}

public:

	void AddTextToHtml(LPCTSTR lpszText);
	void AddImageToHtmlBySrc(LPCTSTR lpszImageSrcPath, bool bSysFace = false, int nSysFAceID = -1);
	void AddImageToHtmlByRes(LPCTSTR lpszImageResPath, UINT nResID, DWORD dwResType);
	void AddImageToHtmlByURL(LPCTSTR lpszImageURL);
	
	bool BeginProduceHtml();
	bool EndProduceHtml(WTL::CString& strHtmlCode);
	bool EndProduceHtmlA(std::string& strHtmlCode);

	bool PaserHtml(LPCSTR lpszHtml);
	bool PaserHtml(LPCTSTR lpszHtml);
	bool GetFirstElem(WTL::CString& strElem, int& nCode, int& nSysFace);
	bool GetNextElem(WTL::CString& strElem, int& nCode, int& nSysFace);

	void ProduceTextElem(WTL::CString& strText);

	bool IsDIBBitmap();
	bool IsExistImageElement();

	void SetSysImgParam(UINT nSysImgPngStart, UINT nSysImgPngEnd, UINT nSysImgGifStart, UINT nSysImgGifEnd);
	bool IsSysImg(UINT nIndex);
	void SetHttpFileSavePath(LPCTSTR strPicRcvPath);

protected:
	void RemoveUnuseChar(WTL::CString& strInfo, int nStart, int nEnd);
	void DwondLoadHttpImg(LPCTSTR lptszHttpHost, LPCTSTR lptszHttpObjName, WTL::CString& strLocalImgPath);

private:
	bool m_bProducing;
	WTL::CString m_strProduct;
	WTL::CString m_strHttpFileSavePath;
	std::vector<stHTMLElem> m_vecElems;
	int m_nCurElem;

	//ϵͳͼƬ��ԴID��Χ
	UINT m_uSysImgPngStart;
	UINT m_uSysImgPngEnd;
	UINT m_uSysImgGifStart;
	UINT m_uSysImgGifEnd;
};