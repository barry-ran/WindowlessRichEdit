/**
 * \brief ole���������ʵ����
 * \author ts
 * \date 2011.7.26
 */
#pragma once
#include "objidl.h"

//IEnumFORMATETC��ҪΪwin2000���µĲ���ϵͳ��ʵ��
class CEnumFormatEtc:public IEnumFORMATETC
{
public:
	CEnumFormatEtc(FORMATETC* pFormatEtc, int nNumFormats);
	~CEnumFormatEtc();

	//COM�̶��ӿ�ʵ��
	HRESULT STDMETHODCALLTYPE QueryInterface(REFIID iid, void** ppvObject);
	ULONG STDMETHODCALLTYPE AddRef(void);
	ULONG STDMETHODCALLTYPE Release(void);

	//IEnumFORMATETC�ӿ�ʵ��
	HRESULT STDMETHODCALLTYPE Next(ULONG celt, FORMATETC* pRgelt, ULONG* pCeltFetched);

	HRESULT STDMETHODCALLTYPE Skip(ULONG celt);

	HRESULT STDMETHODCALLTYPE Reset(void);

	HRESULT STDMETHODCALLTYPE Clone(IEnumFORMATETC** ppEnumFormatEtc);

private:
	LONG m_lRefCount;

	ULONG m_nIndex;

	ULONG m_nNumFormats;

	FORMATETC* m_pFormatEtc;
};

//IDataObjectʵ����
class COleDataObject: public IDataObject
{
public:
	COleDataObject(FORMATETC* fmtetc, STGMEDIUM* stgmed, int count);
	~COleDataObject();

	//COM�̶��ӿ�ʵ��
	HRESULT STDMETHODCALLTYPE QueryInterface(REFIID iid, void** ppvObject);
	ULONG STDMETHODCALLTYPE AddRef(void);
	ULONG STDMETHODCALLTYPE Release(void);

	//IDataObject�ӿ�ʵ��
	HRESULT STDMETHODCALLTYPE GetData(FORMATETC* pFormatEtc, STGMEDIUM* pmedium);

	HRESULT STDMETHODCALLTYPE GetDataHere(FORMATETC* pFormatEtc, STGMEDIUM* pmedium);

	HRESULT STDMETHODCALLTYPE QueryGetData(FORMATETC* pFormatEtc);

	HRESULT STDMETHODCALLTYPE GetCanonicalFormatEtc(FORMATETC* pformatectIn, FORMATETC* pformatetcOut);

	HRESULT STDMETHODCALLTYPE SetData(FORMATETC* pformatetc, STGMEDIUM* pmedium, BOOL fRelease);

	HRESULT STDMETHODCALLTYPE EnumFormatEtc(DWORD dwDirection, IEnumFORMATETC** ppenumFormatEtc);

	HRESULT STDMETHODCALLTYPE DAdvise(FORMATETC* pformatetc, DWORD advf, IAdviseSink* pAdvSink, DWORD* pdwConnection);

	HRESULT STDMETHODCALLTYPE DUnadvise(DWORD dwConnection);

	HRESULT STDMETHODCALLTYPE EnumDAdvise(IEnumSTATDATA** ppenumAdvise);

private:
	LONG m_lRefCount;

	int m_nNumFormats;

	FORMATETC* m_pFormatEtc;

	STGMEDIUM* m_pStgMedium;

	int LookupFormatEtc(FORMATETC* pFormatEtc);
};

//IDataObject���մ�����
class COleDataRecvObject
{
public:
	COleDataRecvObject(IDataObject* pIDataObject);

	~COleDataRecvObject();

public:
	BOOL IsDataAvailable(CLIPFORMAT cfFormat, BOOL bFromClipBoard);

	HGLOBAL GetGlobalData(CLIPFORMAT cfFormat);

	BOOL GetData(CLIPFORMAT cfFormat, STGMEDIUM* pStgMedium);

private:
	IDataObject* m_pIDataObject;
};

extern HRESULT CreateOleDataObject(FORMATETC* fmtetc, STGMEDIUM* stgmeds, UINT count, IDataObject** ppDataObject);