#include "stdafx.h"
#include <atlrx.h>
#include "Wininet.h"
#include "IRichEditMsgProc.h"
#include "HTMLFormatParser.h"
#include "md5ex.h"
#include "IXXImageEx.h"

//UTF-16
#define HTML_EXAMPLE_HEAD _T("Version:0.9\n\
StartHTML:000000sh\n\
EndHTML:000000eh\n\
StartFragment:000000sf\n\
EndFragment:000000ef\n")

#define HTML_FORMAT_HEAD _T("Version:0.9\n\
StartHTML:%0.8d\n\
EndHTML:%0.8d\n\
StartFragment:%0.8d\n\
EndFragment:%0.8d\n")

#define HTML_FORMAT_BODY _T("<!doctype><html><body>\n\
<!--StartFragment-->\n\
%s\n\
<!--EndFragment-->\n\
</body>\n\
</html>")

//UTF-8
#define HTML_EXAMPLE_HEAD_A "Version:0.9\n\
StartHTML:000000sh\n\
EndHTML:000000eh\n\
StartFragment:000000sf\n\
EndFragment:000000ef\n"

#define HTML_FORMAT_HEAD_A "Version:0.9\n\
StartHTML:%0.8d\n\
EndHTML:%0.8d\n\
StartFragment:%0.8d\n\
EndFragment:%0.8d\n"

#define HTML_FORMAT_BODY_A "<!doctype><html><body>\n\
<!--StartFragment-->\n\
%s\n\
<!--EndFragment-->\n\
</body>\n\
</html>"

void CHTMLFormatParser::AddTextToHtml(LPCTSTR lpszText)
{
	if (!m_bProducing)
	{
		return;
	}

	WTL::CString strTemp = lpszText;
	// �滻html����
 	strTemp.Replace(_T("&"), _T("&amp;"));
 	strTemp.Replace(_T(">"), _T("&gt;"));
 	strTemp.Replace(_T("<"), _T("&lt;"));
	strTemp.Replace(_T("\n"), _T("<br>"));
 	strTemp.Replace(_T(" "), _T("&nbsp;"));
 	strTemp.Replace(_T("\""), _T("&quot;"));

	m_strProduct += strTemp;
}

void CHTMLFormatParser::AddImageToHtmlBySrc(LPCTSTR lpszImageSrcPath, bool bSysFace, int nSysFAceID)
{
	if (!lpszImageSrcPath || !m_bProducing)
	{
		return;
	}

	WTL::CString strPath = _T("");
	if (bSysFace)
	{
		strPath.Format(_T("<IMG src=\"file:///%s\" ztsysface=%d>"), lpszImageSrcPath, nSysFAceID);
		m_strProduct += strPath;
	}
	else
	{
		strPath.Format(_T("<IMG src=\"file:///%s\">"), lpszImageSrcPath);
		m_strProduct += strPath;
	}
}

void CHTMLFormatParser::AddImageToHtmlByRes(LPCTSTR lpszImageResPath, UINT nResID, DWORD dwResType)
{
	if (!lpszImageResPath || !m_bProducing)
	{
		return;
	}

	WTL::CString strPath = _T("");
	switch(dwResType)
	{
	case XXIMAGE_FORMAT_BMP:
		{
			strPath.Format(_T("<IMG src=\"res://%s/2/%u\">"), lpszImageResPath, nResID);
		}
		break;
	case XXIMAGE_FORMAT_GIF:
		{
			strPath.Format(_T("<IMG src=\"res://%s/GIF/%u\">"), lpszImageResPath, nResID);
		}
		break;
	case XXIMAGE_FORMAT_PNG:
		{
			strPath.Format(_T("<IMG src=\"res://%s/PNG/%u\">"), lpszImageResPath, nResID);
		}
		break;
	case XXIMAGE_FORMAT_JPG:
		{
			strPath.Format(_T("<IMG src=\"res://%s/JPG/%u\">"), lpszImageResPath, nResID);
		}
		break;
	case XXIMAGE_FORMAT_ICO:
		{
			strPath.Format(_T("<IMG src=\"res://%s/ICON/%u\">"), lpszImageResPath, nResID);
		}
		break;
	default:
		{
			strPath.Format(_T("<IMG src=\"res://%s/BITMAP/%u\">"), lpszImageResPath, nResID);
		}
		break;
	}
	m_strProduct += strPath;
}

void CHTMLFormatParser::AddImageToHtmlByURL(LPCTSTR lpszImageURL)
{
	if (!lpszImageURL || !m_bProducing)
	{
		return;
	}

	WTL::CString strPath = _T("");
	strPath.Format(_T("<IMG src=\"%s\">"), lpszImageURL);
	m_strProduct += strPath;
}

bool CHTMLFormatParser::BeginProduceHtml()
{
	if (m_bProducing)
	{
		return false;
	}
		
	m_bProducing = true;
	m_strProduct.Empty();

	return true;
}

bool CHTMLFormatParser::EndProduceHtml(WTL::CString& strHtmlCode)
{
	if (!m_bProducing)
	{
		return false;
	}

	//BODY����
	WTL::CString strBody = _T("");
	strBody.Format(HTML_FORMAT_BODY, m_strProduct);

	//HTML��ǩ��ʼλ��
	WTL::CString strExampleHead = HTML_EXAMPLE_HEAD;
	int nHTMLStartPos = strExampleHead.GetLength();

	//HTML��ǩ����λ��
	int nHTMLEndPos = nHTMLStartPos + strBody.GetLength();

	//Fragment��ǩ��ʼλ��
	int nFragmentStartPos = nHTMLStartPos + strBody.Find(_T("<!--StartFragment-->"));

	//Fragment��ǩ����λ��
	int nFragmentEndPos = nHTMLStartPos + strBody.Find(_T("<!--EndFragment-->"));

	//HEAD����
	WTL::CString strHead = _T("");
	strHead.Format(HTML_FORMAT_HEAD, nHTMLStartPos, nHTMLEndPos, nFragmentStartPos, nFragmentEndPos);

	strHtmlCode = strHead + strBody;
	m_bProducing = false;

	return true;
}

bool CHTMLFormatParser::EndProduceHtmlA(std::string& strHtmlCode)
{
	if (!m_bProducing)
	{
		return false;
	}

	//BODY����
	std::vector<char> vecBodyContent;
	int nBodyContent = ::WideCharToMultiByte(CP_UTF8, 0, (LPCTSTR)m_strProduct, -1, NULL, 0, NULL, NULL) + 1;
	vecBodyContent.resize(nBodyContent);
	char* pszBodyContent = (char*)&(vecBodyContent[0]);
	memset(pszBodyContent, 0, nBodyContent);
	::WideCharToMultiByte(CP_UTF8, 0, (LPCTSTR)m_strProduct, -1, pszBodyContent, nBodyContent, NULL, NULL);

	std::vector<char> vecBodyHtml;
	int nBodyHtml = nBodyContent + 400;
	vecBodyHtml.resize(nBodyHtml);
	char* pszBodyHtml = (char*)&(vecBodyHtml[0]);
	memset(pszBodyHtml, 0, nBodyHtml);
	_snprintf(pszBodyHtml, nBodyHtml, HTML_FORMAT_BODY_A, pszBodyContent);

	std::string strBodyHtml = pszBodyHtml;

	//HTML��ǩ��ʼλ��
	std::string strExampleHead = HTML_EXAMPLE_HEAD_A;
	int nHTMLStartPos = strExampleHead.length();

	//HTML��ǩ����λ��
	int nHTMLEndPos = nHTMLStartPos + strBodyHtml.length();

	//Fragment��ǩ��ʼλ��
	int nFragmentStartPos = nHTMLStartPos + strBodyHtml.find("<!--StartFragment-->");

	//Fragment��ǩ����λ��
	int nFragmentEndPos = nHTMLStartPos + strBodyHtml.find("<!--EndFragment-->");

	//HEAD����
	char szHeadHtml[400] = {0};
	_snprintf(szHeadHtml, 400, HTML_FORMAT_HEAD_A, nHTMLStartPos, nHTMLEndPos, nFragmentStartPos, nFragmentEndPos);

	strHtmlCode = szHeadHtml + strBodyHtml;
	m_bProducing = false;

	return true;
}

bool CHTMLFormatParser::PaserHtml(LPCSTR lpszHtml)
{
#ifdef _UNICODE
	int nLen = MultiByteToWideChar(CP_UTF8, 0, lpszHtml, -1, NULL, 0);
	TCHAR* tszText = new TCHAR[nLen+1];
	memset(tszText, 0, (nLen+1)*sizeof(TCHAR));
	MultiByteToWideChar(CP_UTF8, 0, lpszHtml, -1, tszText, nLen);

	PaserHtml(tszText);
	SAFE_DELETE_ARRAY(tszText);
#else
	PaserHtml(lpszHtml);
#endif

	return true;
}

void CHTMLFormatParser::RemoveUnuseChar(WTL::CString& strInfo, int nStart, int nEnd)
{
	if (nEnd == -1)
	{
		nEnd = strInfo.GetLength() - 1;
	}
	if (nStart > nEnd)
	{
		return;
	}
	if (nEnd >= strInfo.GetLength())
	{
		return;
	}

	while (nStart != nEnd+1)
	{
		if (strInfo[nStart] == ' '
			|| strInfo[nStart] == '\r'
			|| strInfo[nStart] == '\n'
			|| strInfo[nStart] == '\t')
		{
			strInfo.Delete(nStart);
			if (strInfo.IsEmpty())
			{
				break;
			}
			continue;
		}

		nStart++;
	}
}

void CHTMLFormatParser::ProduceTextElem(WTL::CString& strText)
{
	WTL::CString strParseText = strText;

	//UTF8��"�ո�"����׼�ո�
	//����UTF8ת��UTF16��,�ٽ�UTF16תGB2312ʱ��������,��ΪGB2312��û�д˿ո��ַ�
	strParseText.Replace(160, 32);

	WTL::CString strResult = _T("");

	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szStart = strParseText;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szMatch = 0;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szEnd = 0;

	CAtlRegExp<CAtlRECharTraits> reg;
	REParseError status = reg.Parse(_T("{&#[0-9]+;}|{&[a-z]+;}"));
	if (REPARSE_ERROR_OK != status)
	{
		//Unexpected error
	}

	while (strParseText.GetLength() > 0)
	{
		CAtlREMatchContext<CAtlRECharTraits> mc;
		if (!reg.Match(strParseText, &mc))
		{
			strResult += strParseText;
			break;
		}

		//��һ��ת�����ͣ�����"&#32;"��ʾ�ո�
		mc.GetMatch(0, &szMatch, &szEnd);
		if (szMatch)
		{
			strResult += strParseText.Mid(0, szMatch - szStart);

			ptrdiff_t nLength = szEnd - szMatch - 3;
			ptrdiff_t nHead = szMatch - szStart + 2;
			WTL::CString strFirstTypeString = strParseText.Mid(nHead, nLength);
			UINT uFirstTypeValue = _tcstoul(strFirstTypeString, '\0', 10);
			switch (uFirstTypeValue)
			{
			case 32:
			case 160:
				strResult += _T(" ");
				break;
			case 33:
				strResult += _T("!");
				break;
			case 34:
				strResult += _T("\"");
				break;
			case 35:
				strResult += _T("#");
				break;
			case 36:
				strResult += _T("$");
				break;
			case 37:
				strResult += _T("%");
				break;
			case 38:
				strResult += _T("&");
				break;
			case 40:
				strResult += _T("(");
				break;
			case 41:
				strResult += _T(")");
				break;
			case 42:
				strResult += _T("*");
				break;
			case 43:
				strResult += _T("+");
				break;
			case 45:
				strResult += _T("-");
				break;
			case 46:
				strResult += _T(".");
				break;
			case 47:
				strResult += _T("/");
				break;
			case 58:
				strResult += _T(":");
				break;
			case 59:
				strResult += _T(";");
				break;
			case 60:
				strResult += _T("<");
				break;
			case 61:
				strResult += _T("=");
				break;
			case 62:
				strResult += _T(">");
				break;
			case 63:
				strResult += _T("?");
				break;
			case 64:
				strResult += _T("@");
				break;
			case 91:
				strResult += _T("[");
				break;
			case 92:
				strResult += _T("\\");
				break;
			case 93:
				strResult += _T("]");
				break;
			case 94:
				strResult += _T("^");
				break;
			case 95:
				strResult += _T("_");
				break;
			case 123:
				strResult += _T("{");
				break;
			case 124:
				strResult += _T("|");
				break;
			case 125:
				strResult += _T("}");
				break;
			default:
				strResult += strFirstTypeString;
				break;
			}

			strParseText = strParseText.Right(strParseText.GetLength()-(szEnd-szStart));
			szStart = strParseText;
			continue;
		}

		//�ڶ���ת�����ͣ�����"&nbsp;"��ʾ�ո�
		mc.GetMatch(1, &szMatch, &szEnd);
		if (szMatch)
		{
			strResult += strParseText.Mid(0, szMatch - szStart);

			ptrdiff_t nLength = szEnd - szMatch - 2;
			ptrdiff_t nHead = szMatch - szStart + 1;
			WTL::CString strSecondTypeValue = strParseText.Mid(nHead, nLength);
			if (_T("amp") == strSecondTypeValue)
			{
				strResult += _T("&");
			}
			else if (_T("gt") == strSecondTypeValue)
			{
				strResult += _T(">");
			}
			else if (_T("lt") == strSecondTypeValue)
			{
				strResult += _T("<");
			}
			else if (_T("nbsp") == strSecondTypeValue)
			{
				strResult += _T(" ");
			}
			else if (_T("quot") == strSecondTypeValue)
			{
				strResult += _T("\\");
			}
			else
			{
				strResult += strSecondTypeValue;
			}

			strParseText = strParseText.Right(strParseText.GetLength()-(szEnd-szStart));
			szStart = strParseText;
			continue;
		}
	}

	strResult.Replace(_T("\r"), _T(""));
	strResult.Replace(_T("\n"), _T(""));
	strResult.Replace(_T("\t"), _T(""));

	stHTMLElem elem;
	elem.m_nType = 0;
	elem.m_strElem = strResult;
	elem.m_nSysFace = -1;
	m_vecElems.push_back(elem);
}

//�������ʽ�ָ�����
#define		PARSE_ANCHOR	_T("|")

//ƥ��ע��
#define		PARSE_NOTES		_T("{<\\!--(.)+?-->}")

//ƥ�����
#define		PARSE_TITLE		_T("{<[tT][iI][tT][lL][eE]>(.)*?</[tT][iI][tT][lL][eE]>}")

//ƥ������,ʹ��'>'Ϊ����������ʼ����,���Դ�����ƥ��Ч��
#define		PARSE_WORDS		_T("{>[^<>]*?[^\\ \\\r\\\n\\\t<>]+?[^<>]*?<}")

//ƥ��ͼƬ��ǩ
#define		PARSE_IMG		_T("{(<[iI][mM][gG]\\ (.)+?>)|(<[vV]:[iI][mM][aA][gG][eE][dD][aA][tT][aA]\\ (.)+?>)}")

//ƥ�任�б�ǩ,ʹ�����ƥ��ԭ��,ֻ��ƥ���ǩͷ
#define		PARSE_BR		_T("{<[Bb][Rr][ >]}")

//ƥ���б�ǩ,ʹ�����ƥ��ԭ��,ֻ��ƥ���ǩͷ
#define		PARSE_NEWLINE	_T("{(<[Tt][RrDd][ >])|(<[Pp][ >])|(<h[0-9][ >])|(<[Dd][Ii][Vv][ >])}")


bool CHTMLFormatParser::PaserHtml(LPCTSTR lpszHtml)
{
	WTL::CString strHtml = lpszHtml;
	m_vecElems.clear();

	CAtlRegExp<CAtlRECharTraits> reg;
	REParseError status = reg.Parse(_T("{<\\!--[\\ ]*?StartFragment[\\ ]*?-->}(.)+?{<\\!--[\\ ]*?EndFragment[\\ ]*?-->}"));
	if (REPARSE_ERROR_OK != status)
	{
		// Unexpected error.
	}
	CAtlREMatchContext<CAtlRECharTraits> mc;
	if (!reg.Match(strHtml, &mc))
	{
		return false;
	}

	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szStart = strHtml;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szMatch = 0;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szEnd   = 0;

	mc.GetMatch(0, &szMatch, &szEnd);
	if (!szEnd)
	{
		return false;
	}
	int nStart = szEnd - szStart;
	WTL::CString strHostHtml = _T("");
	if (nStart < 0)
	{
		return false;
	}
	else
	{
		//��ȡ��ǰ����������Host��ַ
		int nHostBegin = strHtml.Find(_T("SourceURL:http://"), 0);
		int nHostEnd = -1;
		if (nHostBegin != -1)
		{
			nHostEnd = strHtml.Find(_T("/"), nHostBegin+17);
			strHostHtml = strHtml.Mid(nHostBegin+17, nHostEnd-nHostBegin-17);
		}
		else
		{
			nHostBegin = strHtml.Find(_T("SourceURL:https://"), 0);
			if (nHostBegin != -1)
			{
				nHostEnd = strHtml.Find(_T("/"), nHostBegin+18);
				strHostHtml = strHtml.Mid(nHostBegin+18, nHostEnd-nHostBegin-18);
			}
		}
	}

	mc.GetMatch(1, &szMatch, &szEnd);
	if (!szEnd)
	{
		return false;
	}
	int nEnd = szEnd - szStart;
	if (nEnd < 0)
	{
		return false;
	}

	strHtml = strHtml.Mid(nStart, nEnd-nStart);

	//��װ�������ʽ����
	WTL::CString strParse = PARSE_NOTES;
	strParse += PARSE_ANCHOR;
	strParse += PARSE_TITLE;
	strParse += PARSE_ANCHOR;
	strParse += PARSE_IMG;
	strParse += PARSE_ANCHOR;
	strParse += PARSE_NEWLINE;
	strParse += PARSE_ANCHOR;
	strParse += PARSE_BR;
	strParse +=  PARSE_ANCHOR;
	strParse += PARSE_WORDS;
	status = reg.Parse((LPCTSTR)strParse);
	if (REPARSE_ERROR_OK != status)
	{
		// Unexpected error.
	}

	//Ϊ��֤��Чƥ�����ʽ����ȷ�ԣ��������ַ�'>'��β�ַ�'<'
	strHtml = ">" + strHtml + "<";

	//��ʼƥ��
	szStart = strHtml;
	int nInfoLength = 0;
	while(strHtml.GetLength()>0)
	{
		if (nInfoLength > MAX_CHATINFOSIZE)
		{
			break;
		}
		if (!reg.Match(strHtml, &mc))
		{
			break;
		}

		//ע��
		mc.GetMatch(0, &szMatch, &szEnd);
		if (szMatch)
		{
			strHtml = strHtml.Right(strHtml.GetLength()-(szEnd-szStart));
			szStart = strHtml;
			continue;
		}

		//����
		mc.GetMatch(1, &szMatch, &szEnd);
		if (szMatch)
		{
			strHtml = strHtml.Right(strHtml.GetLength()-(szEnd-szStart));
			szStart = strHtml;
			continue;
		}

		//ͼƬ
		mc.GetMatch(2, &szMatch, &szEnd);
		if (szMatch)
		{
			ptrdiff_t nLength = szEnd - szMatch;
			ptrdiff_t nHead = szMatch - szStart;

			WTL::CString strFormat;
			strFormat.Format(_T("%%.%ds"), nLength);

			WTL::CString strEmot;
			strEmot.Format(strFormat, szMatch);

			stHTMLElem elem;
			elem.m_nType = 1;
			elem.m_strElem = strEmot;
			nStart = elem.m_strElem.Find(_T("res://"));
			nEnd = elem.m_strElem.Find(';');

			// ͼƬ��ʽ�����������ڣ� <IMG alt=WorldClient src="LookOut/biglogo.gif">
			// ϵͳͼƬ�����������ڣ� <IMG alt=WorldClient src="res://GIF/12">
			// ����srcΪͼƬʵ�ʵ�ַ����ϵͳ������ڲ�����Чʱ������ʵ�ʵ�ַ
			if (nStart != -1 && nEnd != -1)
			{
				WTL::CString strSysFacePath = elem.m_strElem;
				int nCharIndex = 0;
				int nTempIndex = strSysFacePath.Find('/', 0);;
				while (nTempIndex != -1)
				{
					nCharIndex = nTempIndex;
					nTempIndex = strSysFacePath.Find('/', nCharIndex+1);
				}
				if (nCharIndex != -1)
				{
					DWORD dwSysFaceID = _tcstoul(strSysFacePath.Mid(nCharIndex+1, strSysFacePath.GetLength()-1), '\0', 10);
					if (dwSysFaceID >= 1000)
					{
						if (!IsSysImg(dwSysFaceID))
						{
							dwSysFaceID -= 1000;
						}

						elem.m_nSysFace = dwSysFaceID;
						elem.m_strElem = _T("");
						m_vecElems.push_back(elem);
						nInfoLength += elem.m_strElem.GetLength();
					}
				}
			}
			else
			{
				elem.m_nSysFace = -1;
				nStart = elem.m_strElem.Find(_T("src=\""));
				if (nStart == -1)
				{
					strHtml = strHtml.Right(strHtml.GetLength()-(szEnd-1-szStart));
					szStart = strHtml;
					continue;
				}
				nEnd = elem.m_strElem.Find(_T("\""), nStart+6);
				if (nEnd == -1)
				{
					strHtml = strHtml.Right(strHtml.GetLength()-(szEnd-1-szStart));
					szStart = strHtml;
					continue;
				}
				elem.m_strElem = elem.m_strElem.Mid(nStart+5, nEnd-nStart-5);

				//����ͼƬ
				if (elem.m_strElem.Find(_T("file:///")) != -1)
				{
					elem.m_strElem.Replace(_T("file:///"), _T(""));
					m_vecElems.push_back(elem);
				}
				else if (elem.m_strElem.Find(_T("file://")) != -1)
				{
					elem.m_strElem.Replace(_T("file://"), _T(""));
					m_vecElems.push_back(elem);
				}
				//httpͼƬ��ַ
				else
				{
					bool bImgDownloaded = false;
					WTL::CString strHostName = _T("");
					WTL::CString strImgName = _T("");

					//��ȡͼƬ��Զ�˷������е�λ����Ϣ
					if (elem.m_strElem.Find(_T("http://")) != -1)
					{
						elem.m_strElem.Replace(_T("http://"), _T(""));
						int nHostEnd = elem.m_strElem.Find(_T("/"));
						if (nHostEnd != -1)
						{
							strHostName = elem.m_strElem.Mid(0, nHostEnd);
							strImgName = elem.m_strElem.Mid(nHostEnd + 1, elem.m_strElem.GetLength() - nHostEnd - 1);
						}
					}
					else
					{
						strHostName = strHostHtml;
						strImgName = elem.m_strElem;
					}

					//���Դ�����������ͼƬ
					if (strHostName.GetLength() > 0 && strImgName.GetLength() > 0)
					{
						DwondLoadHttpImg(strHostName, strImgName, elem.m_strElem);

						if (elem.m_strElem.GetLength() > 0)
						{
							bImgDownloaded = true;
						}
					}

					if (!bImgDownloaded)
					{
						elem.m_nSysFace = -1;
						elem.m_nType = 2;
						elem.m_strElem = _T(" ");
					}
					m_vecElems.push_back(elem);
				}
				nInfoLength += elem.m_strElem.GetLength();
			}

			strHtml = strHtml.Right(strHtml.GetLength()-(szEnd-1-szStart));
			szStart = strHtml;
			continue;
		}

		//p/hx/tr/div���� td�ո�
		mc.GetMatch(3, &szMatch, &szEnd);
		if (szMatch)
		{
			ptrdiff_t nLength = szEnd - szMatch;
			ptrdiff_t nHead = szMatch - szStart;

			if (!m_vecElems.empty())
			{
				stHTMLElem elem;
				elem.m_nType = 0;
				WTL::CString strCompare;
				strCompare.Format(_T("%.3s"), szMatch);
				if (strCompare.CompareNoCase(_T("<TD")) == 0)
				{
					elem.m_strElem = _T(" ");
				}
				else
				{
					elem.m_strElem = _T("\n");
				}
				elem.m_nSysFace = -1;
				m_vecElems.push_back(elem);
				nInfoLength += elem.m_strElem.GetLength();
			}

			strHtml = strHtml.Right(strHtml.GetLength()-(szMatch-szStart)-1);
			szStart = strHtml;
			continue;
		}

		//br����
		mc.GetMatch(4, &szMatch, &szEnd);
		if (szMatch)
		{
			ptrdiff_t nLength = szEnd - szMatch;
			ptrdiff_t nHead = szMatch - szStart;
			strHtml = strHtml.Right(strHtml.GetLength()-(szMatch-szStart)-3);
			szStart = strHtml;
			stHTMLElem elem;
			elem.m_nType = 0;
			elem.m_strElem = _T("\n");
			elem.m_nSysFace = -1;
			m_vecElems.push_back(elem);
			nInfoLength += elem.m_strElem.GetLength();
			continue;
		}

		//��������
		mc.GetMatch(5, &szMatch, &szEnd);
		if (szMatch)
		{
			ptrdiff_t nLength = szEnd - 2 - szMatch;
			ptrdiff_t nHead = szMatch - szStart + 1;
			ProduceTextElem(strHtml.Mid(nHead, nLength));
			strHtml = strHtml.Right(strHtml.GetLength()-(szEnd-1-szStart));
			nInfoLength += m_vecElems.back().m_strElem.GetLength();
			szStart = strHtml;
			continue;
		}
	}

	return true;
}

bool CHTMLFormatParser::GetFirstElem(WTL::CString& strElem, int& nCode, int& nSysFace)
{
	if (m_vecElems.empty())
	{
		return false;
	}

	m_nCurElem = 0;
	return GetNextElem(strElem, nCode, nSysFace);
}

bool CHTMLFormatParser::GetNextElem(WTL::CString& strElem, int& nCode, int& nSysFace)
{
	if (m_nCurElem < static_cast<int>(m_vecElems.size()))
	{
		strElem = m_vecElems[m_nCurElem].m_strElem;
		nCode = m_vecElems[m_nCurElem].m_nType;
		if (m_vecElems[m_nCurElem].m_nSysFace != -1)
		{
			nSysFace = m_vecElems[m_nCurElem].m_nSysFace;
		}
		else
		{
			nSysFace = -1;
		}
		m_nCurElem++;
	}
	else
	{
		m_nCurElem = 0;
		return false;
	}

	return true;
}

bool CHTMLFormatParser::IsDIBBitmap()
{
	if (m_vecElems.empty())
	{
		return true;
	}

	if (m_vecElems.size() == 1)
	{
		if (m_vecElems[0].m_nType == 2)
		{
			return true;
		}
	}

	return false;
}

bool CHTMLFormatParser::IsExistImageElement()
{
	size_t szCount = m_vecElems.size();
	for (size_t i = 0; i < szCount; ++i)
	{
		if (1 == m_vecElems[i].m_nType)
		{
			return true;
		}
	}
	return false;
}

void CHTMLFormatParser::SetSysImgParam(UINT nSysImgPngStart, UINT nSysImgPngEnd, UINT nSysImgGifStart, UINT nSysImgGifEnd)
{
	m_uSysImgPngStart = nSysImgPngStart;
	m_uSysImgPngEnd = nSysImgPngEnd;
	m_uSysImgGifStart = nSysImgGifStart;
	m_uSysImgGifEnd = nSysImgGifEnd;
}

bool CHTMLFormatParser::IsSysImg(UINT nIndex)
{
	if (nIndex >= m_uSysImgPngStart && nIndex <= m_uSysImgPngEnd)
	{
		return true;
	}

	if (nIndex >= m_uSysImgGifStart && nIndex <= m_uSysImgGifEnd)
	{
		return true;
	}

	return false;
}

void CHTMLFormatParser::SetHttpFileSavePath(LPCTSTR strPicRcvPath)
{
	m_strHttpFileSavePath = strPicRcvPath;
}

void CHTMLFormatParser::DwondLoadHttpImg(LPCTSTR lptszHttpHost, LPCTSTR lptszHttpObjName, WTL::CString& strLocalImgPath)
{
	strLocalImgPath = _T("");

	if (!lptszHttpHost || !lptszHttpObjName)
	{
		return;
	}

	WTL::CString strExt = _T(".png");
	WTL::CString strImageFileName = lptszHttpObjName;
	int nExtBegin = strImageFileName.ReverseFind(_T('.'));
	if (nExtBegin != -1 && strImageFileName.GetLength() - nExtBegin < 10)
	{
		strExt = strImageFileName.Mid(nExtBegin, strImageFileName.GetLength() - nExtBegin);
	}

	//Ϊ��goto����ܸ���������Ҫ�쳣�����ľ������ǰ�ڴ˶���
	HINTERNET hSession = NULL;
	HINTERNET hConnection = NULL;
	HINTERNET hHttpFile = NULL;
	std::vector<char> vecTmp;

	//����HTTP�Ự
	hSession = InternetOpen(
		NULL,
		PRE_CONFIG_INTERNET_ACCESS,
		NULL,
		NULL,
		0);
	if(NULL == hSession)
	{
		goto _process_return;
	}

	//����HTTP����
	hConnection = InternetConnect(
		hSession,
		lptszHttpHost,
		INTERNET_INVALID_PORT_NUMBER,
		NULL,
		NULL,
		INTERNET_SERVICE_HTTP,
		0,
		1);
	if(NULL == hConnection)
	{
		goto _process_return;
	}

	//����һ��HTTP����
	hHttpFile = HttpOpenRequest(
		hConnection,
		_T("GET"),
		lptszHttpObjName,
		NULL,
		NULL,
		NULL,
		INTERNET_FLAG_DONT_CACHE,
		1);
	if(!hHttpFile)
	{
		goto _process_return;
	}

	//����HTTP����ʱʱ��
	int HTTP_ZT_TIMEOUT = 2*1000;
	if (!InternetSetOption(
		hHttpFile,
		INTERNET_OPTION_CONNECT_TIMEOUT,
		&HTTP_ZT_TIMEOUT,
		sizeof(HTTP_ZT_TIMEOUT)))
	{
		goto _process_return;
	}

	//������ೢ������1��
	int nretry = 1;
	if (!InternetSetOption(
		hHttpFile,
		INTERNET_OPTION_CONNECT_RETRIES,
		&nretry,
		sizeof(nretry)))
	{
		goto _process_return;
	}

	//�������Ӹ�������ͷ
	const char szHeaders[] = "Accept: */*\r\n";
	if(!HttpAddRequestHeadersA(
		hHttpFile,
		szHeaders,
		strlen(szHeaders),
		HTTP_ADDREQ_FLAG_ADD))
	{
		goto _process_return;
	}

	//����HTTP����
	if(!HttpSendRequestA(
		hHttpFile,
		szHeaders,
		strlen(szHeaders),
		NULL,
		0))
	{
		goto _process_return;
	}

	//��ѯHTTP�ļ�״̬
	TCHAR tszBuffer[100];
	DWORD dwLen = sizeof(tszBuffer);
	if(!HttpQueryInfo(hHttpFile,HTTP_QUERY_STATUS_CODE,tszBuffer,&dwLen,NULL))
	{
		goto _process_return;
	}
	DWORD dwLastStatusCode = _tcstoul(tszBuffer, '\0', 10);
	if(dwLastStatusCode < 200 || dwLastStatusCode > 299)
	{
		//HTTP�ļ�����
		goto _process_return;
	}

	//��ȡHTTP�ļ�����
	dwLen = sizeof(tszBuffer);
	if(!HttpQueryInfo(hHttpFile,HTTP_QUERY_CONTENT_LENGTH ,tszBuffer,&dwLen,NULL))
	{
		goto _process_return;
	}
	DWORD dwFileLen = _tcstoul(tszBuffer, '\0', 10);
	if(0 == dwFileLen)
	{
		goto _process_return;
	}

	//��ȡHTTP����
	vecTmp.resize(dwFileLen);
	char* pHttpData = (char*)&(vecTmp[0]);
	if (!pHttpData)
	{
		goto _process_return;
	}

	DWORD dwReadLen = 0;
	memset(pHttpData, 0, dwFileLen);
	if(!InternetReadFile(hHttpFile,pHttpData,dwFileLen,&dwReadLen))
	{
		goto _process_return;
	}
	if (0 == dwReadLen)
	{
		goto _process_return;
	}

	//�����ļ���md5��
	unsigned char md5FileName[MAX_MD5_LEN] = {0};
	if (!MD5Data(pHttpData, dwReadLen, md5FileName))
	{
		goto _process_return;
	}
	TCHAR tszmd5FileName[MAX_MD5_LEN+1] = {0};
#ifdef _UNICODE
	MultiByteToWideChar(CP_OEMCP, MB_ERR_INVALID_CHARS, (LPCSTR)md5FileName, -1, 
		tszmd5FileName, MAX_MD5_LEN);
#else
	strncpy(tszmd5FileName, md5FileName, MAX_MD5_LEN);
#endif
	
	//��ʱ�ļ���������
	if (0 == m_strHttpFileSavePath.GetLength())
	{
		strLocalImgPath = _T("C:\\DOCUME~1\\taoshu\\LOCALS~1\\Temp\\");
		strLocalImgPath += tszmd5FileName;
		strLocalImgPath += strExt;
	}
	else
	{
		strLocalImgPath = m_strHttpFileSavePath + tszmd5FileName + strExt;
	}

	//�����ļ�
	if (!::PathFileExists(strLocalImgPath))
	{
		HANDLE hFile = ::CreateFile(strLocalImgPath, 
			GENERIC_WRITE, 
			FILE_SHARE_READ,
			NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

		if (INVALID_HANDLE_VALUE == hFile)
		{
			goto _process_return;
		}

		DWORD dwWritedLen = 0;
		::WriteFile(hFile, pHttpData, dwReadLen, &dwWritedLen, NULL);
		::CloseHandle(hFile);
	}

_process_return:
	if (!hHttpFile)
	{
		InternetCloseHandle(hHttpFile);
	}

	if (!hConnection)
	{
		InternetCloseHandle(hConnection);
	}

	if (!hSession)
	{
		InternetCloseHandle(hSession);
	}
}
