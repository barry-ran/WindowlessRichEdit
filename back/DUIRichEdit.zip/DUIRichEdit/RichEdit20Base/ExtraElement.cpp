#include "stdafx.h"
#include "ExtraElement.h"
#include "SysHelper.h"
#include "richedit.h"

std::list<CExtraImage*> CExtraImage::m_ExtraEleColl;

#define RT_FREE_BITMAP_W		MAKEINTRESOURCEW(2)
#define RT_FREE_ICON_W			MAKEINTRESOURCEW(3)

#define RT_FREE_BITMAP_A		MAKEINTRESOURCEA(2)
#define RT_FREE_ICON_A			MAKEINTRESOURCEA(3)

CExtraImage::CExtraImage(HINSTANCE hResInstance, UINT uResID, LPCTSTR lptszType /* = _T */)
:m_eImgSourceType(eImageSource_FromResource)
,m_uImgResID(uResID)
,m_hResInstance(hResInstance)
,m_pXXPictureEx(NULL)
,m_strImgPath(_T(""))
,m_pImageBase(NULL)
,m_hBitmapCopyFrom(NULL)
,m_hBitmapUsed(NULL)
,m_nRefCount(1)
{
	m_pXXPictureEx = CSysHelper::GetXXImageDll().CreateImageObj();
	if (m_pXXPictureEx)
	{
		if (RT_FREE_BITMAP_W == lptszType)
		{
			m_pXXPictureEx->LoadAnimation(m_hResInstance, m_uImgResID, RT_FREE_BITMAP_A);
		}
		else if (RT_FREE_ICON_W == lptszType)
		{
			m_pXXPictureEx->LoadAnimation(m_hResInstance, m_uImgResID, RT_FREE_ICON_A);
		}
		else
		{
			char szImgType[MAX_PATH+1] = {0};
			if (lptszType)
			{
#ifdef _UNICODE
				WideCharToMultiByte(CP_OEMCP, NULL, (LPCTSTR)lptszType, -1, szImgType, MAX_PATH, NULL, FALSE);
#else
				strncpy(szImgType, lptszType, MAX_PATH);
#endif
			}
			else
			{
				strncpy(szImgType, "GIF", MAX_PATH);
			}
			m_pXXPictureEx->LoadAnimation(m_hResInstance, m_uImgResID, szImgType);
		}
	}
}

CExtraImage::CExtraImage(LPCTSTR lptszImgPath)
:m_eImgSourceType(eImageSource_FromPath)
,m_uImgResID(0)
,m_hResInstance(NULL)
,m_pXXPictureEx(NULL)
,m_strImgPath(_T(""))
,m_pImageBase(NULL)
,m_hBitmapCopyFrom(NULL)
,m_hBitmapUsed(NULL)
,m_nRefCount(1)
{
	if (lptszImgPath)
	{
		m_strImgPath = lptszImgPath;
	}

	m_pXXPictureEx = CSysHelper::GetXXImageDll().CreateImageObj();
	if (m_pXXPictureEx)
	{
		char szImgPath[MAX_PATH+1] = {0};
#ifdef _UNICODE
		WideCharToMultiByte(CP_OEMCP, NULL, (LPCTSTR)m_strImgPath, -1, szImgPath, MAX_PATH, NULL, FALSE);
#else
		strncpy(szImgPath, m_strImgPath, MAX_PATH);
#endif
		m_pXXPictureEx->LoadAnimation(szImgPath);
	}
}

CExtraImage::CExtraImage(CUIImageBaseCom* pImgBase)
:m_eImgSourceType(eImageSource_FromImageBase)
,m_uImgResID(0)
,m_hResInstance(NULL)
,m_pXXPictureEx(NULL)
,m_strImgPath(_T(""))
,m_pImageBase(pImgBase)
,m_hBitmapCopyFrom(NULL)
,m_hBitmapUsed(NULL)
,m_nRefCount(1)
{
}

CExtraImage::CExtraImage(HBITMAP hBitmap, BOOL bBitmapCopyFrom)
:m_eImgSourceType(eImageSource_FromHBITMAP)
,m_uImgResID(0)
,m_hResInstance(NULL)
,m_pXXPictureEx(NULL)
,m_strImgPath(_T(""))
,m_pImageBase(NULL)
,m_hBitmapCopyFrom(NULL)
,m_hBitmapUsed(NULL)
,m_szBitmap(0,0)
,m_nRefCount(1)
{
	if (hBitmap)
	{
		BITMAP bitmap;
		GetObject(hBitmap, sizeof (BITMAP), &bitmap);
		m_szBitmap.cx = bitmap.bmWidth;
		m_szBitmap.cy = bitmap.bmHeight;

		if (hBitmap && bBitmapCopyFrom)
		{
			m_hBitmapCopyFrom = hBitmap;
			m_hBitmapUsed = CloneHBITMAP(m_hBitmapCopyFrom);
		}
		else
		{
			m_hBitmapUsed = hBitmap;
		}
	}
}

CExtraImage::~CExtraImage()
{
	if (m_pXXPictureEx)
	{
		if (!m_pXXPictureEx->IsNull())
		{
			m_pXXPictureEx->Destroy();
		}
		m_pXXPictureEx->Release();
	}

	SAFE_DELETEOBJECT(m_hBitmapUsed);
}

void CExtraImage::AddRef()
{
	m_nRefCount += 1;
}

void CExtraImage::Release()
{
	if (m_nRefCount > 0)
	{
		m_nRefCount -= 1;
	}

	if (m_nRefCount > 0)
	{
		return;
	}

	//�Ӷ����б����Ƴ�
	std::list<CExtraImage*>::iterator it = m_ExtraEleColl.begin();
	for (; it != m_ExtraEleColl.end();)
	{
		CExtraImage* pExtraImage = *it;
		if (pExtraImage)
		{
			if (eImageSource_FromResource == m_eImgSourceType)
			{
				if (pExtraImage->IsMyself(m_hResInstance, m_uImgResID))
				{
					m_ExtraEleColl.erase(it++);
					continue;
				}
			}
			else if (eImageSource_FromPath == m_eImgSourceType)
			{
				if (pExtraImage->IsMyself(m_strImgPath))
				{
					m_ExtraEleColl.erase(it++);
					continue;
				}
			}
			else if (eImageSource_FromHBITMAP == m_eImgSourceType)
			{
				if (pExtraImage->IsMyself(m_hBitmapCopyFrom, m_hBitmapUsed))
				{
					m_ExtraEleColl.erase(it++);
					continue;
				}
			}
			else
			{
				if (pExtraImage->IsMyself(m_pImageBase))
				{
					m_ExtraEleColl.erase(it++);
					continue;
				}
			}
		}
		++it;
	}

	//ɾ������
	delete this;
}

bool CExtraImage::IsValid()
{
	if (eImageSource_FromPath == m_eImgSourceType || 
		eImageSource_FromResource == m_eImgSourceType)
	{
		if (m_pXXPictureEx && !m_pXXPictureEx->IsNull())
		{
			return true;
		}
	}
	else if (eImageSource_FromHBITMAP == m_eImgSourceType)
	{
		if (m_hBitmapUsed)
		{
			return true;
		}
	}
	else
	{
		if (m_pImageBase)
		{
			return true;
		}
	}

	return false;
}

bool CExtraImage::IsMyself(HINSTANCE hResInstance, UINT uResID)
{
	if (eImageSource_FromResource != m_eImgSourceType)
	{
		return false;
	}

	if (hResInstance == m_hResInstance && uResID == m_uImgResID)
	{
		return true;
	}

	return false;
}

bool CExtraImage::IsMyself(LPCTSTR lptszImgPath)
{
	if (eImageSource_FromPath != m_eImgSourceType)
	{
		return false;
	}

	if (lptszImgPath && lptszImgPath == m_strImgPath)
	{
		return true;
	}

	return false;
}

bool CExtraImage::IsMyself(CUIImageBaseCom* pImgBase)
{
	if (eImageSource_FromImageBase != m_eImgSourceType)
	{
		return false;
	}

	if (pImgBase == m_pImageBase)
	{
		return true;
	}

	return false;
}

bool CExtraImage::IsMyself(HBITMAP hBitmapCopyFrom, HBITMAP hBitmapUsed)
{
	if (eImageSource_FromHBITMAP != m_eImgSourceType)
	{
		return false;
	}

	if (hBitmapCopyFrom == m_hBitmapCopyFrom && hBitmapUsed == m_hBitmapUsed)
	{
		return true;
	}

	return false;
}

bool CExtraImage::IsMyself(HBITMAP hBitmap, BOOL bBitmapCopyFrom)
{
	if (!bBitmapCopyFrom)
	{
		return false;
	}

	if (hBitmap == m_hBitmapCopyFrom)
	{
		return true;
	}

	return false;
}

void CExtraImage::OnPaint(HDC hDC, LPRECT lpRect, LPRECT lpClipRect)
{
	if (eImageSource_FromImageBase == m_eImgSourceType)
	{
		if (!m_pImageBase || !lpRect)
		{
			return;
		}

		m_pImageBase->Draw(hDC, *lpRect);
	}
	else if (eImageSource_FromHBITMAP == m_eImgSourceType)
	{
		if (!m_hBitmapUsed || !lpRect)
		{
			return;
		}

		HDC dcTemp = ::CreateCompatibleDC(NULL);
		HBITMAP hOldBmpTemp = (HBITMAP)::SelectObject(dcTemp, m_hBitmapUsed);

		BLENDFUNCTION bfTemp = { AC_SRC_OVER, 0,255, AC_SRC_ALPHA }; 

		int nDrawWidth = lpRect->right - lpRect->left;
		int nDrawHeight = lpRect->bottom - lpRect->top;

		::AlphaBlend(
			hDC,
			lpRect->left,
			lpRect->top,
			nDrawWidth,
			nDrawHeight,
			dcTemp,
			0,
			0,
			m_szBitmap.cx,
			m_szBitmap.cy,
			bfTemp);	

		::SelectObject(dcTemp, hOldBmpTemp);
		::DeleteDC(dcTemp);
	}
	else
	{
		if (!m_pXXPictureEx || m_pXXPictureEx->IsNull())
		{
			return;
		}

		m_pXXPictureEx->GetFrame(0, hDC, lpRect, false, lpClipRect, true);
	}
}

CExtraImage* CExtraImage::NewExtraImage(HINSTANCE hResIntance, UINT uResID, LPCTSTR lptszType /* = _T */)
{
	//�Ӷ����б���ֱ������
	std::list<CExtraImage*>::iterator it = m_ExtraEleColl.begin();
	for (; it != m_ExtraEleColl.end(); ++it)
	{
		CExtraImage* pExtraImage = *it;
		if (pExtraImage && pExtraImage->IsMyself(hResIntance, uResID))
		{
			pExtraImage->AddRef();
			return pExtraImage;
		}
	}

	//�����µĶ������ӵ������б���
	CExtraImage* pExtraImage = new CExtraImage(hResIntance, uResID, lptszType);
	if (pExtraImage && pExtraImage->IsValid())
	{
		m_ExtraEleColl.push_back(pExtraImage);
		return pExtraImage;
	}

	return NULL;
}

CExtraImage* CExtraImage::NewExtraImage(LPCTSTR lptszImgPath)
{
	//�Ӷ����б���ֱ������
	std::list<CExtraImage*>::iterator it = m_ExtraEleColl.begin();
	for (; it != m_ExtraEleColl.end(); ++it)
	{
		CExtraImage* pExtraImage = *it;
		if (pExtraImage && pExtraImage->IsMyself(lptszImgPath))
		{
			pExtraImage->AddRef();
			return pExtraImage;
		}
	}

	//�����µĶ������ӵ������б���
	CExtraImage* pExtraImage = new CExtraImage(lptszImgPath);
	if (pExtraImage && pExtraImage->IsValid())
	{
		m_ExtraEleColl.push_back(pExtraImage);
		return pExtraImage;
	}

	return NULL;
}

CExtraImage* CExtraImage::NewExtraImage(CUIImageBaseCom* pImgBase)
{
	//�Ӷ����б���ֱ������
	std::list<CExtraImage*>::iterator it = m_ExtraEleColl.begin();
	for (; it != m_ExtraEleColl.end(); ++it)
	{
		CExtraImage* pExtraImage = *it;
		if (pExtraImage && pExtraImage->IsMyself(pImgBase))
		{
			pExtraImage->AddRef();
			return pExtraImage;
		}
	}

	//�����µĶ������ӵ������б���
	CExtraImage* pExtraImage = new CExtraImage(pImgBase);
	if (pExtraImage && pExtraImage->IsValid())
	{
		m_ExtraEleColl.push_back(pExtraImage);
		return pExtraImage;
	}

	return NULL;
}

CExtraImage* CExtraImage::NewExtraImage(HBITMAP hBitmap, BOOL bBitmapCopyFrom)
{
	//�Ӷ����б���ֱ������
	std::list<CExtraImage*>::iterator it = m_ExtraEleColl.begin();
	for (; it != m_ExtraEleColl.end(); ++it)
	{
		CExtraImage* pExtraImage = *it;
		if (pExtraImage && pExtraImage->IsMyself(hBitmap, bBitmapCopyFrom))
		{
			pExtraImage->AddRef();
			return pExtraImage;
		}
	}

	//�����µĶ������ӵ������б���
	CExtraImage* pExtraImage = new CExtraImage(hBitmap, bBitmapCopyFrom);
	if (pExtraImage && pExtraImage->IsValid())
	{
		m_ExtraEleColl.push_back(pExtraImage);
		return pExtraImage;
	}

	return NULL;
}

CExtraElement::CExtraElement(
	bool bAutoSize,
	bool bFullFillLayout,
	int nWidth,
	int nHeight,
	int nBeginCharIndex,
	int nEndCharIndex,
	LPRECT lpRectOffset,
	E_RICHEDIT_ELEMENT_VALIGN eVAlign)
:m_uID(0)
,m_bInserting(false)
,m_bAutoSize(bAutoSize)
,m_bFullFillLayout(bFullFillLayout)
,m_bSupportClick(false)
,m_dwExtraData(0)
,m_nWidth(nWidth)
,m_nHeight(nHeight)
,m_nMinWidth(0)
,m_nMinHeight(0)
,m_nMaxWidth(9999)
,m_nMaxHeight(9999)
,m_nBeginCharIndex(nBeginCharIndex)
,m_nEndCharIndex(nEndCharIndex)
,m_rcOffset(0,0,0,0)
,m_nLeftClientIndent(0)
,m_nRightClientIndent(0)
,m_eVAlign(eVAlign)

,m_rcREClient(0,0,0,0)
,m_nREContentLeftIndent(0)
,m_nREContentRightIndent(0)
,m_wREContentAlign(PFA_LEFT)
,m_bREContentAlignInHalf(false)

,m_nImgLeft(0)
,m_nImgTop(0)

,m_nSubImgLeft(0)
,m_nSubImgTop(0)

,m_nTextLeft(0)
,m_nTextTop(0)
,m_clrText(0)
,m_strText(_T(""))

,m_uOleID(0)
{
	static UINT uNextEleID = 1;
	m_uID = uNextEleID;
	uNextEleID += 1;
	if (uNextEleID >= 0xffffffff)
	{
		uNextEleID = 1;
	}

	if (lpRectOffset)
	{
		m_rcOffset = *lpRectOffset;
	}
}

CExtraElement::~CExtraElement()
{
}

void CExtraElement::SetImage(int nImageLeft, int nImageTop, HINSTANCE hResInstance, UINT uResID, LPCTSTR lptszType /* = _T */)
{
	Destroy();

	CExtraImage* pExtraImage = CExtraImage::NewExtraImage(hResInstance, uResID, lptszType);
	if (pExtraImage)
	{
		m_ExtraImgColl.push_back(pExtraImage);
		m_nImgLeft = nImageLeft;
		m_nImgTop = nImageTop;
	}
}

void CExtraElement::SetImage(int nImageLeft, int nImageTop, LPCTSTR lptszImgPath)
{
	Destroy();

	CExtraImage* pExtraImage = CExtraImage::NewExtraImage(lptszImgPath);
	if (pExtraImage)
	{
		m_ExtraImgColl.push_back(pExtraImage);
		m_nImgLeft = nImageLeft;
		m_nImgTop = nImageTop;
	}
}

void CExtraElement::SetImage(int nImageLeft, int nImageTop, CUIImageBaseCom* pImgBase)
{
	Destroy();

	CExtraImage* pExtraImage = CExtraImage::NewExtraImage(pImgBase);
	if (pExtraImage)
	{
		m_ExtraImgColl.push_back(pExtraImage);
		m_nImgLeft = nImageLeft;
		m_nImgTop = nImageTop;
	}
}

void CExtraElement::SetImage(
	int nImageLeft,
	int nImageTop,
	HBITMAP hBitmap,
	BOOL bBitmapCopyFrom)
{
	Destroy();

	CExtraImage* pExtraImage = CExtraImage::NewExtraImage(hBitmap, bBitmapCopyFrom);
	if (pExtraImage)
	{
		m_ExtraImgColl.push_back(pExtraImage);
		m_nImgLeft = nImageLeft;
		m_nImgTop = nImageTop;
	}
}

void CExtraElement::SetImageArray(
	int nImageLeft,
	int nImageTop,
	RICHEDIT_RESOURCE_IMG* pImageArray,
	int nArrayCount)
{
	Destroy();

	if (pImageArray && nArrayCount > 0)
	{
		for (int i = 0; i < nArrayCount; ++i)
		{
			CExtraImage* pExtraImage = CExtraImage::NewExtraImage(pImageArray[i].hResInstance, pImageArray[i].uResID, (LPCTSTR)pImageArray[i].tszType);
			if (pExtraImage)
			{
				m_ExtraImgColl.push_back(pExtraImage);
				m_nImgLeft = nImageLeft;
				m_nImgTop = nImageTop;
			}
		}
	}
}

void CExtraElement::SetImageArray(
	int nImageLeft,
	int nImageTop,
	LPCTSTR* pImageArray,
	int nArrayCount)
{
	Destroy();

	if (pImageArray && nArrayCount > 0)
	{
		for (int i = 0; i < nArrayCount; ++i)
		{
			CExtraImage* pExtraImage = CExtraImage::NewExtraImage(pImageArray[i]);
			if (pExtraImage)
			{
				m_ExtraImgColl.push_back(pExtraImage);
				m_nImgLeft = nImageLeft;
				m_nImgTop = nImageTop;
			}
		}
	}
}

void CExtraElement::SetImageArray(
	int nImageLeft,
	int nImageTop,
	CUIImageBaseCom** pImageArray,
	int nArrayCount)
{
	Destroy();

	if (pImageArray && nArrayCount > 0)
	{
		for (int i = 0; i < nArrayCount; ++i)
		{
			CExtraImage* pExtraImage = CExtraImage::NewExtraImage(pImageArray[i]);
			if (pExtraImage)
			{
				m_ExtraImgColl.push_back(pExtraImage);
				m_nImgLeft = nImageLeft;
				m_nImgTop = nImageTop;
			}
		}
	}
}

void CExtraElement::SetImageArray(
	int nImageLeft,
	int nImageTop,
	RICHEDIT_HBITMAP_IMG* pImageArray,
	int nArrayCount)
{
	Destroy();

	if (pImageArray && nArrayCount > 0)
	{
		for (int i = 0; i < nArrayCount; ++i)
		{
			CExtraImage* pExtraImage = CExtraImage::NewExtraImage(pImageArray[i].hBitmap, pImageArray[i].bBitmapCopyFrom);
			if (pExtraImage)
			{
				m_ExtraImgColl.push_back(pExtraImage);
				m_nImgLeft = nImageLeft;
				m_nImgTop = nImageTop;
			}
		}
	}
}

void CExtraElement::SetSubImage(
	int nImageLeft,
	int nImageTop,
	HINSTANCE hResInstance,
	UINT uResID,
	LPCTSTR lptszType /* = _T */)
{
	DestroySub();

	CExtraImage* pExtraImage = CExtraImage::NewExtraImage(hResInstance, uResID, lptszType);
	if (pExtraImage)
	{
		m_SubExtraImgColl.push_back(pExtraImage);
		m_nSubImgLeft = nImageLeft;
		m_nSubImgTop = nImageTop;
	}
}

void CExtraElement::SetSubImage(
	int nImageLeft,
	int nImageTop,
	LPCTSTR lptszImgPath)
{
	DestroySub();

	CExtraImage* pExtraImage = CExtraImage::NewExtraImage(lptszImgPath);
	if (pExtraImage)
	{
		m_SubExtraImgColl.push_back(pExtraImage);
		m_nSubImgLeft = nImageLeft;
		m_nSubImgTop = nImageTop;
	}
}

void CExtraElement::SetSubImage(
	int nImageLeft,
	int nImageTop,
	CUIImageBaseCom* pImgBase)
{
	DestroySub();

	CExtraImage* pExtraImage = CExtraImage::NewExtraImage(pImgBase);
	if (pExtraImage)
	{
		m_SubExtraImgColl.push_back(pExtraImage);
		m_nSubImgLeft = nImageLeft;
		m_nSubImgTop = nImageTop;
	}
}

void CExtraElement::SetSubImage(
	int nImageLeft,
	int nImageTop,
	HBITMAP hBitmap,
	BOOL bBitmapCopyFrom)
{
	DestroySub();

	CExtraImage* pExtraImage = CExtraImage::NewExtraImage(hBitmap, bBitmapCopyFrom);
	if (pExtraImage)
	{
		m_SubExtraImgColl.push_back(pExtraImage);
		m_nSubImgLeft = nImageLeft;
		m_nSubImgTop = nImageTop;
	}
}

void CExtraElement::SetSubImageArray(
	int nImageLeft,
	int nImageTop,
	RICHEDIT_RESOURCE_IMG* pImageArray,
	int nArrayCount)
{
	DestroySub();

	if (pImageArray && nArrayCount > 0)
	{
		for (int i = 0; i < nArrayCount; ++i)
		{
			CExtraImage* pExtraImage = CExtraImage::NewExtraImage(pImageArray[i].hResInstance, pImageArray[i].uResID, (LPCTSTR)pImageArray[i].tszType);
			if (pExtraImage)
			{
				m_SubExtraImgColl.push_back(pExtraImage);
				m_nSubImgLeft = nImageLeft;
				m_nSubImgTop = nImageTop;
			}
		}
	}
}

void CExtraElement::SetSubImageArray(
	int nImageLeft,
	int nImageTop,
	LPCTSTR* pImageArray,
	int nArrayCount)
{
	DestroySub();

	if (pImageArray && nArrayCount > 0)
	{
		for (int i = 0; i < nArrayCount; ++i)
		{
			CExtraImage* pExtraImage = CExtraImage::NewExtraImage(pImageArray[i]);
			if (pExtraImage)
			{
				m_SubExtraImgColl.push_back(pExtraImage);
				m_nSubImgLeft = nImageLeft;
				m_nSubImgTop = nImageTop;
			}
		}
	}
}

void CExtraElement::SetSubImageArray(
	int nImageLeft,
	int nImageTop,
	CUIImageBaseCom** pImageArray,
	int nArrayCount)
{
	DestroySub();

	if (pImageArray && nArrayCount > 0)
	{
		for (int i = 0; i < nArrayCount; ++i)
		{
			CExtraImage* pExtraImage = CExtraImage::NewExtraImage(pImageArray[i]);
			if (pExtraImage)
			{
				m_SubExtraImgColl.push_back(pExtraImage);
				m_nSubImgLeft = nImageLeft;
				m_nSubImgTop = nImageTop;
			}
		}
	}
}

void CExtraElement::SetSubImageArray(
	int nImageLeft,
	int nImageTop,
	RICHEDIT_HBITMAP_IMG* pImageArray,
	int nArrayCount)
{
	DestroySub();

	if (pImageArray && nArrayCount > 0)
	{
		for (int i = 0; i < nArrayCount; ++i)
		{
			CExtraImage* pExtraImage = CExtraImage::NewExtraImage(pImageArray[i].hBitmap, pImageArray[i].bBitmapCopyFrom);
			if (pExtraImage)
			{
				m_SubExtraImgColl.push_back(pExtraImage);
				m_nSubImgLeft = nImageLeft;
				m_nSubImgTop = nImageTop;
			}
		}
	}
}

void CExtraElement::SetText(int nTextLeft, int nTextTop, LPCTSTR lptszText, COLORREF clrText)
{
	m_nTextLeft = nTextLeft;
	m_nTextTop = nTextTop;
	m_clrText = clrText;
	if (lptszText)
	{
		m_strText = lptszText;
	}
}

void CExtraElement::Destroy()
{
	DestroySub();

	int nImageCount = (int)m_ExtraImgColl.size();
	for (int i = 0; i < nImageCount; ++i)
	{
		if (m_ExtraImgColl[i])
		{
			m_ExtraImgColl[i]->Release();
		}
	}
	m_ExtraImgColl.clear();
}

void CExtraElement::DestroySub()
{
	int nImageCount = (int)m_SubExtraImgColl.size();
	for (int i = 0; i < nImageCount; ++i)
	{
		if (m_SubExtraImgColl[i])
		{
			m_SubExtraImgColl[i]->Release();
		}
	}
	m_SubExtraImgColl.clear();
}

void CExtraElement::SetClientIndent(int nLeftClientIndent, int nRightClientIndent)
{
	m_nLeftClientIndent = nLeftClientIndent;
	m_nRightClientIndent = nRightClientIndent;
}

void CExtraElement::SetMinSize(int nMinWidth, int nMinHeight)
{
	m_nMinWidth = nMinWidth;
	m_nMinHeight = nMinHeight;
}

void CExtraElement::SetMaxSize(int nMaxWidth, int nMaxHeight)
{
	m_nMaxWidth = nMaxWidth;
	m_nMaxHeight = nMaxHeight;
}

RECT CExtraElement::GetOffset()
{
	return m_rcOffset;
}

int CExtraElement::GetLeftClientIndent()
{
	return m_nLeftClientIndent;
}

int CExtraElement::GetRightClientIndent()
{
	return m_nRightClientIndent;
}

bool CExtraElement::IsImageArray()
{
	if (m_ExtraImgColl.size() > 1)
	{
		return true;
	}

	if (m_SubExtraImgColl.size() > 1)
	{
		return true;
	}

	return false;
}

bool CExtraElement::CheckREAlign(LPCRECT lpREClient)
{
	if (!lpREClient || (PFA_RIGHT != m_wREContentAlign && PFA_CENTER != m_wREContentAlign))
	{
		return false;
	}

	if (m_rcREClient.Width() == lpREClient->right - lpREClient->left)
	{
		return false;
	}

	if (-1 == m_nBeginCharIndex || -1 == m_nEndCharIndex)
	{
		return false;
	}

	m_rcREClient = lpREClient;

	return true;
}

void CExtraElement::ResetREAlignResult()
{
	m_rcREClient.SetRectEmpty();
}

void CExtraElement::OnPaint(HDC hDC, LPRECT lpRect, LPRECT lpClipRect, UINT uDrawTick)
{
	UINT uImageCount = (UINT)m_ExtraImgColl.size();
	if (uImageCount > 0)
	{
		UINT uCurImgIndex = uDrawTick % uImageCount;
		if (m_ExtraImgColl[uCurImgIndex])
		{
			m_ExtraImgColl[uCurImgIndex]->OnPaint(hDC, lpRect, lpClipRect);
		}
	}

	UINT uSubImageCount = (UINT)m_SubExtraImgColl.size();
	if (uSubImageCount > 0 && lpRect)
	{
		UINT uCurSubImgIndex = uDrawTick % uSubImageCount;
		if (m_SubExtraImgColl[uCurSubImgIndex])
		{
			CRect rcSubImg = lpRect;
			rcSubImg.OffsetRect(m_nSubImgLeft, m_nSubImgTop);
			m_SubExtraImgColl[uCurSubImgIndex]->OnPaint(hDC, &rcSubImg, lpClipRect);
		}
	}

	if (lpRect && m_strText.GetLength() && !lpClipRect)
	{
		::SetTextColor(hDC, m_clrText);

		RECT rcText = *lpRect;
		::OffsetRect(&rcText, m_nTextLeft, m_nTextTop);
		::ExtTextOut(hDC, rcText.left, rcText.top, ETO_CLIPPED,
			&rcText, m_strText, m_strText.GetLength(), NULL);
	}
}

void CExtraElement::SetOleID(DWORD dID)
{
    m_uOleID = dID;
}

DWORD CExtraElement::GetOleID()
{
    return m_uOleID;
}