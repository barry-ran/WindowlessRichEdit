#pragma once

bool MD5File(const char* pszFile,unsigned char *pMD5 /* 16 Byte*/);
bool MD5Data(const void* pData,size_t size,unsigned char *pMD5 /* 16 Byte*/);