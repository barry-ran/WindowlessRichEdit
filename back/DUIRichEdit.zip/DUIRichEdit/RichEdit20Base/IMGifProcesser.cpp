#include "..\stdafx.h"
#include "winbase.h"
#include <Windows.h>
#include <process.h>
#include <comutil.h>
#include "IMGifProcesser.h"
#include "SysHelper.h"

HANDLE CIMGifProcesser::m_hThread = NULL;
std::list<CIMGifProcesser*> CIMGifProcesser::m_vecGifList;
std::list<CIMGifProcesser*> CIMGifProcesser::m_vecAddingGifList;
std::list<IRichEditMsgProc*> CIMGifProcesser::m_vecUpdateWnd;
CIMGifProcesser::Vec_ResList CIMGifProcesser::m_vecResList;
volatile BOOL CIMGifProcesser::m_bExitThread = FALSE;
HANDLE CIMGifProcesser::m_hExitEvent = NULL;
HANDLE CIMGifProcesser::m_hAddingEvent = NULL;
LPCRITICAL_SECTION CIMGifProcesser::m_lpSection = NULL;
HBRUSH CIMGifProcesser::m_hBgBrush = NULL;

CIMGifProcesser::CIMGifProcesser()
{
	m_dwUserData = 0;
	m_bIsInitialized   = FALSE;
	m_bIsPlaying       = FALSE;
	m_bIsGIF		   = FALSE;
	m_clrBackground    = RGB(255,255,255);
	m_nCurrFrame	   = 0;
	m_nFrameCount      = 0;
	m_nElapseTime      = 0;
	m_nResID		   = -1;
	m_hResInstance	   = NULL;
	m_szFileName       = _T("");
	m_szFileURL        = _T("");
	m_PictureSize.cx   = m_PictureSize.cy = 0;
	m_PictureURLSize.cx= m_PictureURLSize.cy = 0;
	m_xxPictureEx      = NULL;
	m_bVisible		   = TRUE;
	m_bVisibleInside   = FALSE;
	m_pRichEditMsgProc = NULL;
	m_bCanGoNextFrame  = TRUE;
	m_bEnableAutoSize  = FALSE;
	m_bEnableSnapshot  = FALSE;
	memset(&m_szSnapshot, 0, sizeof(m_szSnapshot));
	m_hDCSnapshot = NULL;
	m_hBitmapSnapshot = NULL;

	if (m_hExitEvent == NULL)
	{
		m_hExitEvent = CreateEvent(NULL,TRUE,FALSE,NULL);
	}	

	if (m_lpSection == NULL)
	{
		m_lpSection = new CRITICAL_SECTION;
		InitializeCriticalSection(m_lpSection);
	}

	if (m_hAddingEvent == NULL)
	{
		m_hAddingEvent = CreateEvent(NULL,TRUE,FALSE,NULL);
	}

	if (m_hBgBrush == NULL)
	{
		m_hBgBrush = CreateSolidBrush(RGB(255, 255, 255));
	}
}

CIMGifProcesser::~CIMGifProcesser()
{
	Destroy();
	DestroySnapshot();
}

OleProcesserType CIMGifProcesser::GetType()
{
	return OleProcesser_Gif;
}

BOOL CIMGifProcesser::Load(LPCTSTR szFileName, IRichEditMsgProc* pMsgProc)
{
	m_szFileName = szFileName;
	m_pRichEditMsgProc = pMsgProc;

	//����Ƿ��ͼƬ��Դ�Ѿ�����
	Vec_ResList::iterator it = GetIterFromResList();
	if (it != m_vecResList.end())
	{
		++(*it)->m_dwRef;
		return LoadDone();
	}

	//����ͼƬ��Դ
	if(!m_xxPictureEx)
		m_xxPictureEx = CSysHelper::GetXXImageDll().CreateImageObj();

	char szFile[MAX_PATH];
	WideCharToMultiByte(CP_OEMCP, NULL, szFileName, -1, szFile, MAX_PATH, NULL, FALSE );

	stResElem* pResElem = new stResElem;
	if (m_xxPictureEx->LoadAnimation(szFile))  //GIF
	{
		m_bIsGIF = TRUE;
	}
	else //��̬ͼƬ
	{
		m_bIsGIF = FALSE;   
	}

	if (m_xxPictureEx->IsNull())
		return FALSE;

	m_nFrameCount =m_xxPictureEx->GetFrameNum();
	m_xxPictureEx->GetImageSize(m_PictureSize);

	pResElem->m_xxPictureEx = m_xxPictureEx;
	pResElem->m_szResName = m_szFileName;
	pResElem->m_nResID = -1;
	pResElem->m_hResInstance = NULL;
	pResElem->m_dwRef = 1;
	pResElem->m_bIsGIF = m_bIsGIF;
	pResElem->m_clrBackground = m_clrBackground;
	pResElem->m_nFrameCount = m_nFrameCount;
	pResElem->m_PictureSize.cx = m_PictureSize.cx;
	pResElem->m_PictureSize.cy = m_PictureSize.cy;
	m_vecResList.push_back(pResElem);

	return LoadDone();
}

BOOL CIMGifProcesser::Load(HINSTANCE hInstance, UINT nIDResource, const char* lpszType, IRichEditMsgProc* pMsgProc)
{	
	m_nResID = nIDResource;
	m_hResInstance = hInstance;
	m_pRichEditMsgProc = pMsgProc;

	//����Ƿ��ͼƬ��Դ�Ѿ�����
	Vec_ResList::iterator it = GetIterFromResList();
	if (it != m_vecResList.end())
	{
		++(*it)->m_dwRef;
		return LoadDone();
	}

	//����ͼƬ��Դ
	if(!m_xxPictureEx)
		m_xxPictureEx = CSysHelper::GetXXImageDll().CreateImageObj();

	stResElem* pResElem = new stResElem;
	if (m_xxPictureEx->LoadAnimation(hInstance, m_nResID, lpszType))  //GIF
	{
		m_bIsGIF = TRUE;
	}
	else //��̬ͼƬ
	{
		m_bIsGIF = FALSE;
	}

	if (m_xxPictureEx->IsNull())
		return FALSE;

	m_nFrameCount =m_xxPictureEx->GetFrameNum();
	m_xxPictureEx->GetImageSize(m_PictureSize);

	pResElem->m_xxPictureEx = m_xxPictureEx;
	pResElem->m_szResName = _T("");
	pResElem->m_nResID = m_nResID;
	pResElem->m_hResInstance = hInstance;
	pResElem->m_dwRef = 1;
	pResElem->m_bIsGIF = m_bIsGIF;
	pResElem->m_clrBackground = m_clrBackground;
	pResElem->m_nFrameCount = m_nFrameCount;
	pResElem->m_PictureSize.cx = m_PictureSize.cx;
	pResElem->m_PictureSize.cy = m_PictureSize.cy;
	m_vecResList.push_back(pResElem);

	return LoadDone();
}

BOOL CIMGifProcesser::LoadDone()
{
	m_bIsInitialized = TRUE;

	return TRUE;
}

void CIMGifProcesser::DestroySnapshot()
{
	if (m_hBitmapSnapshot)
	{
		::DeleteObject(m_hBitmapSnapshot);
		m_hBitmapSnapshot = NULL;
	}

	if (m_hDCSnapshot)
	{
		::DeleteObject(m_hDCSnapshot);
		m_hDCSnapshot = NULL;
	}

	m_szSnapshot.cx = 0;
	m_szSnapshot.cy = 0;
}

UINT WINAPI CIMGifProcesser::_ThreadAnimation(LPVOID pParam)
{
	CIMGifProcesser *pPic = reinterpret_cast<CIMGifProcesser *> (pParam); 

	CIMGifProcesser::ThreadAnimation();

	if (pPic->m_hThread)
	{
		CloseHandle(pPic->m_hThread); 
		pPic->m_hThread = 0;
	}
	return 0;
}

void CIMGifProcesser::ThreadAnimation()
{
	std::list<CIMGifProcesser*>::iterator it, itend;
	std::list<CIMGifProcesser*>::iterator itAdding;
	while (!m_bExitThread)
	{
		if (!m_lpSection)
		{
			return;
		}
		EnterCriticalSection(m_lpSection); 

		if (!m_vecAddingGifList.empty())
		{
			itAdding = m_vecAddingGifList.begin();
			for (; itAdding != m_vecAddingGifList.end(); ++itAdding)
			{
				m_vecGifList.push_back((*itAdding));
			}
			m_vecAddingGifList.clear();
			m_vecUpdateWnd.clear();

			if (WAIT_OBJECT_0 == WaitForSingleObject(m_hAddingEvent, 80))
			{
				if (!m_lpSection)
				{
					return;
				}
				LeaveCriticalSection(m_lpSection);
				continue;
			}
		}

		it = CIMGifProcesser::m_vecGifList.begin();
		itend = CIMGifProcesser::m_vecGifList.end();

		bool bShouldUpdate = false;
		for (; it != itend; ++it)
		{
			if ((*it))
			{
				if ((*it)->DoAnimation())
				{
					bShouldUpdate = true;
				}
			}
		}

		if (bShouldUpdate)
		{
			std::list<IRichEditMsgProc*>::iterator itUpdateWnd = m_vecUpdateWnd.begin();
			IRichEditMsgProc* pMsgProc = NULL;
			for (; itUpdateWnd != m_vecUpdateWnd.end(); ++itUpdateWnd)
			{
				pMsgProc = (*itUpdateWnd);

				if (pMsgProc) pMsgProc->OnRichEditInsideRedraw(false);
			}

			m_vecUpdateWnd.clear();
		}

		if (!m_lpSection)
		{
			return;
		}
		LeaveCriticalSection(m_lpSection); 

		WaitForSingleObject(m_hExitEvent, 80);

		if (m_bExitThread) break;
	}

	_endthread();
}

bool CIMGifProcesser::DoAnimation()
{
	if (!m_bCanGoNextFrame) return false;

	if (!m_bIsGIF) return false;

	bool bShouldUpdate = false;
	// �Ѿ�����
	if (!m_bIsPlaying)
	{
		return bShouldUpdate;
	}

	if (m_nCurrFrame < m_nFrameCount)
	{
		m_nElapseTime += 80;

		if (m_xxPictureEx->GetFrameDelay() < 8) 
		{
			if (m_nElapseTime < 80)
			{
				return bShouldUpdate;
			}
		}
		else
		{
			if (m_nElapseTime < 10*m_xxPictureEx->GetFrameDelay())
			{
				return bShouldUpdate;
			}
		}

		if (GetVisible())
		{
			bShouldUpdate = true;

			std::list<IRichEditMsgProc*>::iterator it = m_vecUpdateWnd.begin();
			for (; it != m_vecUpdateWnd.end(); ++it)
			{
				if ((*it) == m_pRichEditMsgProc)
				{
					break;
				}
			}
			if (it == m_vecUpdateWnd.end())
			{
				m_vecUpdateWnd.push_back(m_pRichEditMsgProc);
			}

		}
		
		m_nElapseTime = 0;
	}

	m_nCurrFrame++;
	if (m_nCurrFrame >= m_nFrameCount)
	{
		m_nCurrFrame = 0; 
	}

	return bShouldUpdate;
}

CIMGifProcesser::Vec_ResList::iterator CIMGifProcesser::GetIterFromResList()
{
	Vec_ResList::iterator it = m_vecResList.begin();

	for (; it != m_vecResList.end(); ++it)
	{
		if ((!m_szFileName.IsEmpty() && (*it)->m_szResName == m_szFileName)
			|| (m_nResID != -1 && (*it)->m_nResID == m_nResID && (*it)->m_hResInstance == m_hResInstance))
		{
			stResElem* pElem = (*it);
			if (!pElem)
			{
				return m_vecResList.end();
			}
			m_xxPictureEx    = pElem->m_xxPictureEx;
			m_bIsGIF         = pElem->m_bIsGIF;
			m_clrBackground  = pElem->m_clrBackground;
			m_nFrameCount    = pElem->m_nFrameCount;
			m_PictureSize.cx = pElem->m_PictureSize.cx;
			m_PictureSize.cy = pElem->m_PictureSize.cy;
			return it;
		}
	}

	return m_vecResList.end();
}

void CIMGifProcesser::ClearRes()
{
	Vec_ResList::iterator it = GetIterFromResList();
	if (it != m_vecResList.end())
	{
		if (--(*it)->m_dwRef == 0)
		{
			if(!((stResElem*)(*it))->m_xxPictureEx->IsNull())
			{
				((stResElem*)(*it))->m_xxPictureEx->Destroy();
			}
			((stResElem*)(*it))->m_xxPictureEx->Release();

			delete (*it);

			// ���ü���Ϊ0ɾ���ڴ��е���Դ
			m_vecResList.erase(it);
			ATLTRACE(_T("%d"), m_vecResList.size());
		}
	}

	// �������
	m_xxPictureEx = NULL;
	m_bIsGIF = FALSE;
	m_clrBackground = RGB(255, 255, 255);
	m_nFrameCount = 0;
	m_PictureSize.cx = 0;
	m_PictureSize.cy = 0;

	m_szFileName = _T("");
	m_nResID = 0;
	m_hResInstance = NULL;
}

void CIMGifProcesser::Destroy()
{
	// ������
	if (!m_bIsInitialized && !m_xxPictureEx)
	{
		return;
	}

	// ��ǰ��ղ�������
	BOOL bIsAnimateGif = IsAnimatedGIF();

	Stop();
	m_bIsInitialized   = FALSE;
	m_bIsGIF		   = FALSE;
	m_clrBackground    = RGB(255, 255, 255);
	m_nCurrFrame	   = 0;

	// �ٽ�����Դ����ʱ���п��ܴ��ھ�̬ͼƬ��Դ
	if (!m_lpSection)
	{
		ClearRes();
		return;
	}

	// ���ٶ��̷߳�����Դ
	bool bCriticalSecLeaved = false;
	EnterCriticalSection(m_lpSection);

	ClearRes();

	if (bIsAnimateGif)
	{
		std::list<IRichEditMsgProc*>::iterator it_pMsgProc = m_vecUpdateWnd.begin();
		for (; it_pMsgProc != m_vecUpdateWnd.end();)
		{
			if ((*it_pMsgProc) == m_pRichEditMsgProc)
			{
				m_vecUpdateWnd.erase(it_pMsgProc++);
			}
			else
			{
				++it_pMsgProc;
			}
		}

		std::list<CIMGifProcesser*>::iterator it = m_vecGifList.begin();
		for (; it != m_vecGifList.end();)
		{
			if (*it == this)
			{
				m_vecGifList.erase(it++);
			}
			else
			{
				++it;
			}
		}
		it = m_vecAddingGifList.begin();
		for (; it != m_vecAddingGifList.end();)
		{
			if (*it == this)
			{
				m_vecAddingGifList.erase(it++);
			}
			else
			{
				++it;
			}
		}

		if (m_vecGifList.empty() && m_vecAddingGifList.empty())
		{
			m_bExitThread = TRUE;
			SetEvent(m_hExitEvent);
			if (m_hThread)
			{
				//�ر��߳�ǰ�����ͷ�����Դ����ֹ���������߳�ִ����δ���Ȼ������Դ�����µ��߳�ǿ�ƽ���
				//���������WaitForSingleObject(m_hThread, 5000)����ִ�к��߳�Ӧ���Ѿ��Զ�����
				LeaveCriticalSection(m_lpSection);
				bCriticalSecLeaved = true;

				WaitForSingleObject(m_hThread, 5000);
				CloseHandle(m_hThread);
				m_hThread = NULL;
			}

			CloseHandle(m_hExitEvent);
			m_hExitEvent = NULL;

			if (m_hBgBrush)
			{
				::DeleteObject(m_hBgBrush);
				m_hBgBrush = NULL;
			}

			if (m_hAddingEvent)
			{
				CloseHandle(m_hAddingEvent);
				m_hAddingEvent = NULL;
			}

			if (!bCriticalSecLeaved)
			{
				LeaveCriticalSection(m_lpSection);
				bCriticalSecLeaved = true;
			}

			DeleteCriticalSection(m_lpSection);
			delete m_lpSection;
			m_lpSection = NULL;
		}
	}

	if (!bCriticalSecLeaved && m_lpSection)
	{
		LeaveCriticalSection(m_lpSection);
	}
}

BOOL CIMGifProcesser::Draw()
{
	if (!m_bIsInitialized)
	{
		return FALSE;
	}

	if (IsAnimatedGIF())
	{
		SetEvent(m_hAddingEvent);

		if (!m_lpSection)
		{
			return FALSE;
		}
		EnterCriticalSection(m_lpSection);

		m_bIsPlaying = TRUE;
		m_vecAddingGifList.push_back(this);

		if (!m_lpSection)
		{
			return FALSE;
		}
		LeaveCriticalSection(m_lpSection);

		unsigned int nDummy;
		if (NULL == m_hThread)
		{
			m_bExitThread = FALSE;
			m_hThread = (HANDLE) _beginthreadex(NULL, 0, _ThreadAnimation, this,
				CREATE_SUSPENDED, &nDummy);
			if (!m_hThread)
			{
				return FALSE;
			} 
			else 
			{
				ResumeThread(m_hThread);
			}
		}
	} 

	return FALSE;	
}

SIZE CIMGifProcesser::GetSize() const
{
	return m_PictureSize;
}

BOOL CIMGifProcesser::IsGIF() const
{
	return m_bIsGIF;
}

BOOL CIMGifProcesser::IsAnimatedGIF() const
{
	return (m_bIsGIF && m_nFrameCount > 1);
}

BOOL CIMGifProcesser::IsLoadFromRes() const
{
	if (m_hResInstance != NULL)
	{
		return TRUE;
	}

	return FALSE;
}

BOOL CIMGifProcesser::IsPlaying() const
{
	return m_bIsPlaying;
}

void CIMGifProcesser::SetFileURL(LPCTSTR lpFileURL)
{
	m_szFileURL = lpFileURL;
}

LPCTSTR CIMGifProcesser::GetFileURL() const
{
	return m_szFileURL;
}

BOOL CIMGifProcesser::IsExistFileURL() const
{
	return (m_szFileURL.GetLength() > 0) ? TRUE : FALSE;
}

void CIMGifProcesser::SetFileURLImageSize(int nWidth, int nHeight)
{
	m_PictureURLSize.cx = nWidth;
	m_PictureURLSize.cy = nHeight;
}

int CIMGifProcesser::GetFileURLImageWidth()
{
	return m_PictureURLSize.cx;
}

int CIMGifProcesser::GetFileURLImageHeight()
{
	return m_PictureURLSize.cy;
}

int CIMGifProcesser::GetFrameCount() const
{
	if (!IsAnimatedGIF())
		return 0;

	return m_nFrameCount;
}

COLORREF CIMGifProcesser::GetBkColor() const
{
	return m_clrBackground;
}

BOOL CIMGifProcesser::GetFirstBitmap(HDC hDC)
{
	if (!m_xxPictureEx)
		return FALSE;

	if (m_xxPictureEx->IsNull())
		return FALSE;

	m_xxPictureEx->GetFrame(0, hDC, CRect(0, 0, m_PictureSize.cx, m_PictureSize.cy), false);
	return TRUE;
}

void CIMGifProcesser::OnPaint(HDC hDC, LPRECT lpRect, bool& bResultPlayAni, UINT uAniTick, LPRECT lpClipRect, bool bForbidSmooth) 
{
	if (!m_xxPictureEx)
	{
		return;
	}

	if (m_xxPictureEx->IsNull())
	{
		return;
	}

	//ʹ�÷ǿ��շ�ʽ����
	if (bForbidSmooth || !m_bEnableSnapshot)
	{
		m_xxPictureEx->GetFrame(m_nCurrFrame, hDC, lpRect, false, lpClipRect, false);
	}
	//ʹ�ÿ��շ�ʽ����(�ڴ濪������, ƽ������ͼƬʱ��������)
	else
	{
		if (!lpRect)
		{
			return;
		}

		int nWidth = lpRect->right - lpRect->left;
		int nHeight = lpRect->bottom - lpRect->top;

		SIZE szOriginal;
		m_xxPictureEx->GetImageSize(szOriginal);

		//û������������ֱ�ӻ���
		if (nWidth == szOriginal.cx && nHeight == szOriginal.cy)
		{
			m_xxPictureEx->GetFrame(m_nCurrFrame, hDC, lpRect, false, lpClipRect, false);
			return;
		}

		if (!m_hDCSnapshot)
		{
			m_hDCSnapshot = ::CreateCompatibleDC(hDC);
		}

		if (!m_hBitmapSnapshot)
		{
			BITMAPINFO bi;
			memset(&bi, 0, sizeof(BITMAPINFO));
			bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
			bi.bmiHeader.biWidth = szOriginal.cx;
			bi.bmiHeader.biHeight = szOriginal.cy;
			bi.bmiHeader.biPlanes = 1;
			bi.bmiHeader.biBitCount = 32;
			bi.bmiHeader.biCompression = BI_RGB;

			LPBYTE pBits = NULL;
			m_hBitmapSnapshot = CreateDIBSection(hDC, &bi, DIB_RGB_COLORS, (void**)&pBits, NULL, 0);
		}

		if (m_hDCSnapshot && m_hBitmapSnapshot && 
			(m_szSnapshot.cx != nWidth || m_szSnapshot.cy != nHeight))
		{
			RECT rcSnapshot;
			rcSnapshot.left = 0;
			rcSnapshot.top = 0;
			rcSnapshot.right = rcSnapshot.left + nWidth;
			rcSnapshot.bottom = rcSnapshot.top + nHeight;

			HBITMAP hOldBitmap = (HBITMAP)::SelectObject(m_hDCSnapshot, m_hBitmapSnapshot);

			Graphics graphics(m_hDCSnapshot);
			graphics.Clear(Color(255, 255, 255, 255));
			m_xxPictureEx->GetFrame(m_nCurrFrame, m_hDCSnapshot, &rcSnapshot, false, &rcSnapshot, true);

			::SelectObject(m_hDCSnapshot, hOldBitmap);

			m_szSnapshot.cx = nWidth;
			m_szSnapshot.cy = nHeight;
		}

		if (m_hBitmapSnapshot && 
			nWidth == m_szSnapshot.cx && nHeight == m_szSnapshot.cy)
		{
			HBITMAP hOldBitmap = (HBITMAP)::SelectObject(m_hDCSnapshot, m_hBitmapSnapshot);

			CRect rcDraw;
			if (lpClipRect)
			{
				rcDraw.IntersectRect(lpRect, lpClipRect);
			}
			else
			{
				rcDraw = lpRect;
			}

			::BitBlt(hDC, rcDraw.left, rcDraw.top, rcDraw.Width(), rcDraw.Height(), 
				m_hDCSnapshot, rcDraw.left - lpRect->left, rcDraw.top - lpRect->top, SRCCOPY);

			::SelectObject(m_hDCSnapshot, hOldBitmap);
		}
	}

	m_bCanGoNextFrame = TRUE;
}

void CIMGifProcesser::SetVisibleInside(BOOL bVisible)
{
	m_bVisibleInside = bVisible;
}

void CIMGifProcesser::SyncVisible()
{
	m_bVisible = m_bVisibleInside;
	m_bVisibleInside = FALSE;
}

void CIMGifProcesser::EnableSnapshot(BOOL bEnable)
{
	m_bEnableSnapshot = bEnable;

	if (!m_bEnableSnapshot)
	{
		DestroySnapshot();
	}
}

void CIMGifProcesser::Stop()
{
	m_bIsPlaying = FALSE;
}

void CIMGifProcesser::OnDestroy() 
{
	Stop();	
}

void CIMGifProcesser::SetBkColor(COLORREF clr)
{
	if (!m_bIsInitialized) return;

	m_clrBackground = clr;
}

