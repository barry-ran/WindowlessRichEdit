/**
 * \brief RichEdit��Ole������
 * \author ts
 * \date 2015-10-8
 */
#ifndef _IOLEPROCESSER_H_20150108
#define _IOLEPROCESSER_H_20150108

enum OleProcesserType
{
	OleProcesser_Gif,		// gif
	OleProcesser_Control,	// �Զ���ؼ�
};

class IOleProcesser
{
public:
	virtual ~IOleProcesser() {}
	virtual OleProcesserType GetType() = 0;

	virtual void SetUserData(DWORD_PTR dwUserData) = 0;
	virtual DWORD_PTR GetUserData() = 0;

	virtual BOOL IsEnableAutoSize()  = 0;
	virtual void EnableAutoSize(BOOL bEnable) = 0;

	virtual SIZE GetSize() const = 0;
    virtual void SetSize(int nWidth, int nHeight) = 0;

	virtual BOOL GetVisible() = 0;
	virtual void SetVisible(BOOL bVisible) = 0;

	virtual void SetVisibleInside(BOOL bVisible) = 0;
	virtual void SyncVisible() = 0;

	virtual void OnPaint(HDC hDC, LPRECT lpRect, bool& bResultPlayAni, UINT uAniTick, LPRECT lpClipRect = NULL, bool bForbidSmooth = true) = 0;
};

struct stOleData 
{
	stOleData()
		: dwID(0)
		, nLeftClientIndent(0)
		, nRightClientIndent(0)
		, pProcesser(NULL)
	{}

	DWORD dwID;
	LONG nLeftClientIndent;
	LONG nRightClientIndent;
	IOleProcesser* pProcesser;
};

#endif // _IOLEPROCESSER_H_20150108