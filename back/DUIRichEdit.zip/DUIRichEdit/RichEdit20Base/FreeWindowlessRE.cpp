#include "stdafx.h"
#include "richedit.h"
#include <RichOle.h>
#include "FreeWindowlessRE.h"

CFreeWindowlessRE::CFreeWindowlessRE()
{
	m_pRichEditMsgProc = NULL;
	m_hREParentWnd = NULL;
	m_lpSection = NULL;
	m_bMsgProcessing = false;
	m_bHostUsable = false;
}

CFreeWindowlessRE::~CFreeWindowlessRE()
{
	if (m_editControlInfo.ptwh)
	{
		m_editControlInfo.ptwh->Release();
		m_editControlInfo.ptwh = NULL;
	}

	if (m_lpSection)
	{
		LeaveCriticalSection(m_lpSection);
		DeleteCriticalSection(m_lpSection);
		delete m_lpSection;
	}
}

LRESULT CFreeWindowlessRE::WindowlessREProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	if (!m_hREParentWnd)
	{
		return S_MSG_KEY_IGNORED;
	}

	LONG x = LOWORD (lParam);
	LONG y = HIWORD (lParam);

	stEditControlInfo *paseci = &m_editControlInfo;
	stEditControlInfo *pseci = NULL;

	if (paseci)
	{
		switch(message)
		{
		case WM_SETCURSOR:
			{
				if (m_pRichEditMsgProc)
				{
					POINT pt;
					::GetCursorPos(&pt);
					::ScreenToClient(m_hREParentWnd, &pt);
					if (!(paseci->ptwh))
						return 0;
					if(!paseci->ptwh->DoSetCursor(NULL, &pt) )
					{
						HMODULE st= GetModuleHandle(0);
						SetCursor(LoadCursor(GetModuleHandle(0), IDC_ARROW));
						goto ignore;
					}
					return 0;
				}
			}
			break;
		case WM_DESTROY:
			{
				goto ignore;
			}
			break;
		case WM_PAINT:
			{
				HDC hDC = (HDC)wParam;
				RECT* pRcPaint = (RECT*)lParam;
				if (m_pRichEditMsgProc && hDC && pRcPaint)
				{
					if (pRcPaint->left != pRcPaint->right && pRcPaint->top != pRcPaint->bottom)
					{
						wParam = (WPARAM) hDC;
						lParam = (LPARAM) pRcPaint;

						//�Զ���Ԫ��
						m_pRichEditMsgProc->OnRichEditMsgProc(WM_ELEMENT_PAINT, wParam, (LPARAM)pRcPaint);

						//��������
						if ((0 == pRcPaint->bottom) && (0 == pRcPaint->right))
						{
							lParam = 0;
						}

						pseci = paseci;

						if (m_bHostUsable)
						{
							pseci->ptwh->TxWindowProc(m_hREParentWnd, message, wParam, (LPARAM)pRcPaint);
						}

						//ole����
						m_pRichEditMsgProc->OnRichEditMsgProc(WM_OLE_PAINT, wParam, (LPARAM)pRcPaint);
					}
				}

				return 0;
			}
			break;
		case WM_TIMER:
			{
				lParam = 0;
				goto ignore;
			}
			break;
		case WM_GETCLIENTRECT:
		case WM_SHOWSCROLLBAR:
		case WM_SETSCROLLPOS: 
		case WM_SETSCROLLRANGE:
		case WM_SETSCROLLINFO:
		case WM_ELEMENT_PAINT:
		case WM_OLE_PAINT:
		case WM_DELETEOLE:
		case WM_INSERTOLE:
			{
				goto ignore;
			}
			break;
		default:
			{
				pseci = paseci ;

				if (pseci->fFocus)
				{
					try
					{
						LRESULT lr = pseci->ptwh->TxWindowProc(m_hREParentWnd, message, wParam, lParam);
						return lr;
					}
					catch (...)
					{
					}
				}
			}
			break;
		}
	}

ignore:
	return S_MSG_KEY_IGNORED;
}

CTxtWinHost* CFreeWindowlessRE::GetWinHost() const
{
	if (!m_bHostUsable)
		return NULL;
	return m_editControlInfo.ptwh;
}

int CFreeWindowlessRE::CreateHost(DWORD dwFlags, RECT& rc)
{
	if (!m_hREParentWnd)
	{
		return 1;
	}

	HRESULT hr = CreateTextControl(
		m_hREParentWnd,
		m_hREParentWnd,
		dwFlags, 
		_T(""),
		rc.left,
		rc.top,
		rc.right-rc.left,
		rc.bottom-rc.top,
		&m_editControlInfo.ptwh);
	if (S_OK != hr)
	{
		m_bHostUsable = false;
		return 1;
	}

	// ������ý���
	m_bHostUsable = true;
	m_editControlInfo.ptwh->OnTxInPlaceActivate(NULL);
	m_editControlInfo.fFocus = TRUE;

	if (m_lpSection == NULL)
	{
		m_lpSection = new CRITICAL_SECTION;
		InitializeCriticalSection(m_lpSection);
	}

	return 0;
}

HRESULT CFreeWindowlessRE::CreateTextControl(
										  HWND hwndControl,
										  HWND hwndParent,
										  DWORD dwStyle,
										  TCHAR *pszText,
										  LONG lLeft,
										  LONG lTop,
										  LONG lWidth,
										  LONG lHeight,
										  CTxtWinHost **ppHost)
{
	CREATESTRUCT cs;

	cs.lpszName = pszText; // һ���ÿ�
	cs.hwndParent = hwndParent;
	cs.style = dwStyle;
	cs.dwExStyle = 0;

	cs.x = lLeft;
	cs.y = lTop;
	cs.cy = lHeight;
	cs.cx = lWidth;

	HRESULT hr = E_FAIL;
	GdiSetBatchLimit(1);

	CTxtWinHost *phost = new CTxtWinHost();

	if(phost)
	{
		if (phost->Init(hwndControl, &cs, NULL, m_pRichEditMsgProc))
		{
			*ppHost = phost;
			hr = S_OK;
		}
	}

	if (S_OK != hr)
	{
		delete phost;
		return E_FAIL;
	}
	if (phost)
	{
		phost->SetTransparent(TRUE);
	}

	return S_OK;
}

HWND CFreeWindowlessRE::SetFocus()
{
	if (!m_bHostUsable)
		return NULL;

	HRESULT hr;
	::SetFocus(m_hREParentWnd);
	hr = m_editControlInfo.ptwh->GetTextServices()->TxSendMessage(WM_SETFOCUS, 0, 0, 0);

	if (FAILED(hr)) return NULL;

	return m_hREParentWnd;
}

BOOL CFreeWindowlessRE::SetReadOnly(BOOL bReadOnly)
{
	LRESULT lr = GetWinHost()->TxWindowProc(m_hREParentWnd, EM_SETREADONLY, (WPARAM)bReadOnly, 0);
	if (0 == lr)
	{
		return FALSE;
	}

	return (lr != 0);
}

BOOL CFreeWindowlessRE::GetReadOnly()
{
	if (GetWinHost())
	{
		return GetWinHost()->GetReadOnly();
	}

	return FALSE;
}

CPoint CFreeWindowlessRE::PosFromChar(UINT nChar) const
{
	if (!m_bHostUsable)
		return CPoint(0, 0);

	CPoint pt;
	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_POSFROMCHAR, (WPARAM)&pt, nChar, &lr);

	if (FAILED(hr)) return CPoint(0, 0);

	return pt;
}

long CFreeWindowlessRE::CharFromPos(CPoint pt) const
{
	if (!m_bHostUsable) return -1;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_CHARFROMPOS, 0, (LPARAM)&pt, &lr);

	if (FAILED(hr)) return -1;

	return (long)lr;
}

void CFreeWindowlessRE::LineScroll(int nLines, int nChars)
{
	if (!m_bHostUsable) return;

	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_LINESCROLL, 0, (LPARAM)nLines, 0);

	if (FAILED(hr))
	{
		//....
	}
}

void CFreeWindowlessRE::GetScrollPos(CPoint& pt) const
{
	if (!m_bHostUsable) return;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_GETSCROLLPOS, 0, (LPARAM)&pt, &lr);
}

long CFreeWindowlessRE::LineFromChar(long nIndex) const
{
	if (!m_bHostUsable) return -1;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_EXLINEFROMCHAR, 0, (LPARAM)nIndex, &lr);

	if (FAILED(hr)) return -1;

	return (long)lr;
}

int CFreeWindowlessRE::GetFirstVisibleLine() const
{
	if (!m_bHostUsable) return -1;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_GETFIRSTVISIBLELINE, 0, 0, &lr);

	if (FAILED(hr)) return -1;

	return (int)lr;
}

int CFreeWindowlessRE::GetLineCount() const
{
	if (!m_bHostUsable) return -1;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_GETLINECOUNT, 0, 0, &lr);

	if (FAILED(hr)) return -1;

	return (int)lr;
}

int CFreeWindowlessRE::LineIndex(int nLine) const
{
	if (!m_bHostUsable) return -1;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_LINEINDEX, (WPARAM)nLine, 0, &lr);

	if (FAILED(hr)) return -1;

	return (int)lr;
}

int CFreeWindowlessRE::LineLength(int nLine) const
{
	if (!m_bHostUsable) return -1;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_LINELENGTH, (WPARAM)nLine, 0, &lr);

	if (FAILED(hr)) return -1;

	return (int)lr;
}


long CFreeWindowlessRE::GetTextLengthEx() const
{
	return GetTextLengthEx(GT_USECRLF, 1200);
}

void CFreeWindowlessRE::GetTextEx(LPTSTR lpContent, int nMaxCount) const
{
	memset(lpContent, 0, sizeof(TCHAR)*nMaxCount);

	GETTEXTEX getTextEx;
	getTextEx.cb = (nMaxCount)*sizeof(TCHAR);
	getTextEx.flags = GT_USECRLF;
	getTextEx.codepage = 1200;

	LRESULT lr;
	GetWinHost()->GetTextServices()->TxSendMessage(EM_GETTEXTEX, (WPARAM)&getTextEx, (LPARAM)lpContent, &lr);
}

void CFreeWindowlessRE::SetText(LPCTSTR strText)
{
	if (strText)
	{
		LRESULT lr;
		long nEventMask = GetEventMask();
		SetEventMask(nEventMask & (~ENM_CHANGE));

		HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(WM_SETTEXT, 0, (LPARAM)(LPCTSTR)strText, &lr);
	
		SetEventMask(nEventMask);

		if (FAILED(hr))
		{
			//...
		}
	}

}

void CFreeWindowlessRE::GetSel(CHARRANGE& cr) const
{
	if (!m_bHostUsable) return;

	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_EXGETSEL, 0, (LPARAM)&cr, 0);

	if (FAILED(hr))
	{
		//...
	}
}

void CFreeWindowlessRE::GetSel(long& nStartChar, long& nEndChar) const
{
	CHARRANGE cr;
	
	GetSel(cr);

	nStartChar = cr.cpMin;
	nEndChar = cr.cpMax;
}

void CFreeWindowlessRE::SetSel(CHARRANGE& cr, bool bHideCaret)
{
	if (!m_bHostUsable) return;

	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_EXSETSEL, 0, (LPARAM)&cr, 0);

	//if (bHideCaret && m_hREParentWnd) ::HideCaret(m_hREParentWnd);

	if (FAILED(hr))
	{
		//...
	}
}

void CFreeWindowlessRE::SetSel(long nStartChar, long nEndChar, bool bHideCaret)
{
	CHARRANGE cr;
	cr.cpMin = nStartChar;
	cr.cpMax = nEndChar;
	SetSel(cr, bHideCaret);
}

void CFreeWindowlessRE::Clear()
{
	if (!m_bHostUsable) return;

	SETTEXTEX settext;
	settext.flags = ST_DEFAULT;
	settext.codepage = 1200;
	WTL::CString strInsertText = _T("");

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_SETTEXTEX, (WPARAM)&settext, (LPARAM)(LPCTSTR)strInsertText, &lr);
	if (FAILED(hr))
	{
		//...
	}
}

void CFreeWindowlessRE::ReplaceSel(LPCTSTR lpszNewText, BOOL bCanUndo)
{
	GetWinHost()->TxWindowProc(m_hREParentWnd, EM_REPLACESEL, (WPARAM)bCanUndo, (LPARAM)lpszNewText);
}

void CFreeWindowlessRE::HideSelection(BOOL bHide, BOOL bPerm)
{
	if (!m_bHostUsable) return;

	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_HIDESELECTION, (WPARAM)bHide, 0, 0);

	if (FAILED(hr))
	{
		//...
	}

	if (bPerm)
	{
		hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_SETOPTIONS, ECOOP_SET, ECO_NOHIDESEL, 0);
	}
	else
	{
		hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_SETOPTIONS, 0, ECO_NOHIDESEL, 0);
	}

	if (FAILED(hr))
	{
		//...
	}
}

WORD CFreeWindowlessRE::GetSelectionType() const
{
	if (!m_bHostUsable) return 0;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_SELECTIONTYPE, 0, 0, &lr);
	if (FAILED(hr))
	{
		//...
	}
	return static_cast<WORD>(lr);
}

long CFreeWindowlessRE::GetSelText(LPSTR lpBuf) const
{
	if (!m_bHostUsable) return -1;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_GETSELTEXT, 0, (LPARAM)lpBuf, &lr);
	if (FAILED(hr))
	{
		//...
	}
	return (long)lr;
}

WTL::CString CFreeWindowlessRE::GetSelText() const
{
	CHARRANGE cr = {0,0};
	GetSel(cr);

	WTL::CString strResult = _T("");

	int nLen = cr.cpMax - cr.cpMin;
	if (nLen < 0)
	{
		nLen = GetTextLengthEx();
		LPTSTR pBuffer = strResult.GetBuffer(nLen + 1);
		GetTextEx(pBuffer, nLen + 1);
		strResult.ReleaseBuffer(-1);
		return strResult;
	}

	LPTSTR pBuffer = strResult.GetBuffer(nLen + 1);
	GetSelText((LPSTR)pBuffer);
	strResult.ReleaseBuffer(-1);
	return strResult;
}

int CFreeWindowlessRE::GetTextRange(int nFirst, int nLast, WTL::CString& refString) const
{
	if (!m_bHostUsable) return -1;

	TEXTRANGE tr;
	tr.chrg.cpMin = nFirst;
	tr.chrg.cpMax = nLast;
#ifdef UNICODE
	tr.lpstrText = (LPWSTR)(LPCTSTR)refString;
#else
	tr.lpstrText = (LPSTR)(LPCTSTR)refString;
#endif

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_GETTEXTRANGE, 0, (LPARAM)&tr, &lr);
	if (FAILED(hr))
	{
		//...
	}

	return (int)lr; 
}

void CFreeWindowlessRE::GetIRichEditOle(IRichEditOle** pResult) const
{
	if (!pResult)
	{
		return;
	}
	*pResult = NULL;

	if (!m_bHostUsable)
	{
		return;
	}

	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_GETOLEINTERFACE, 0, (LPARAM)(LPVOID*)pResult, 0);
	if (S_OK != hr)
	{
		*pResult = NULL;
	}
}

BOOL CFreeWindowlessRE::SetOLECallback(IRichEditOleCallback* pCallback)
{
	if (!m_bHostUsable) return FALSE;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_SETOLECALLBACK, 0, (LPARAM)pCallback, &lr);

	if (FAILED(hr))
	{
		//...
	}

	return SUCCEEDED(lr);
}

DWORD CFreeWindowlessRE::GetDefaultCharFormat(CHARFORMAT& cf) const
{
	cf.cbSize = sizeof(CHARFORMAT);
	return GetDefaultCharFormat((CHARFORMAT*)&cf);
}

DWORD CFreeWindowlessRE::GetDefaultCharFormat(CHARFORMAT2& cf) const
{
	cf.cbSize = sizeof(CHARFORMAT2);
	return GetDefaultCharFormat((CHARFORMAT*)&cf);
}

DWORD CFreeWindowlessRE::GetDefaultCharFormat(CHARFORMAT* pcf) const
{
	if (!m_bHostUsable || !pcf)
	{
		return 0;
	}

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_GETCHARFORMAT , SCF_DEFAULT, (LPARAM)pcf, &lr);
	if (FAILED(hr))
	{
		//...
	}
	return (DWORD)lr;
}

DWORD CFreeWindowlessRE::GetParaFormat(PARAFORMAT& pf) const
{
	pf.cbSize = sizeof(PARAFORMAT);
	return GetParaFormat((PARAFORMAT*)&pf);
}

DWORD CFreeWindowlessRE::GetParaFormat(PARAFORMAT2& pf) const
{
	pf.cbSize = sizeof(PARAFORMAT2);
	return GetParaFormat((PARAFORMAT*)&pf);
}

DWORD CFreeWindowlessRE::GetParaFormat(PARAFORMAT* ppf) const
{
	if (!m_bHostUsable || !ppf)
	{
		return 0;
	}

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_GETPARAFORMAT , SCF_DEFAULT, (LPARAM)ppf, &lr);
	if (FAILED(hr))
	{
		//...
	}
	return (DWORD)lr;
}

DWORD CFreeWindowlessRE::GetSelectionCharFormat(CHARFORMAT& cf) const
{
	cf.cbSize = sizeof(CHARFORMAT);
	return GetSelectionCharFormat((CHARFORMAT*)&cf);
}

DWORD CFreeWindowlessRE::GetSelectionCharFormat(CHARFORMAT2& cf) const
{
	cf.cbSize = sizeof(CHARFORMAT2);
	return GetSelectionCharFormat((CHARFORMAT*)&cf);
}

DWORD CFreeWindowlessRE::GetSelectionCharFormat(CHARFORMAT* pcf) const
{
	if (!m_bHostUsable || !pcf)
	{
		return 0;
	}

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_GETCHARFORMAT , SCF_SELECTION, (LPARAM)pcf, &lr);
	if (FAILED(hr))
	{
		//...
	}
	return (DWORD)lr;
}

DWORD CFreeWindowlessRE::GetAllCharFormat(CHARFORMAT& cf) const
{
	cf.cbSize = sizeof(CHARFORMAT);
	return GetAllCharFormat((CHARFORMAT*)&cf);
}

DWORD CFreeWindowlessRE::GetAllCharFormat(CHARFORMAT2& cf) const
{
	cf.cbSize = sizeof(CHARFORMAT2);
	return GetAllCharFormat((CHARFORMAT*)&cf);
}

DWORD CFreeWindowlessRE::GetAllCharFormat(CHARFORMAT* pcf) const
{
	if (!m_bHostUsable || !pcf)
	{
		return 0;
	}

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_GETCHARFORMAT , SCF_ALL, (LPARAM)pcf, &lr);
	if (FAILED(hr))
	{
		//...
	}
	return (DWORD)lr;
}

BOOL CFreeWindowlessRE::SetDefaultCharFormat(CHARFORMAT& cf)
{
	cf.cbSize = sizeof(CHARFORMAT);
	return SetDefaultCharFormat((CHARFORMAT*)&cf);
}

BOOL CFreeWindowlessRE::SetDefaultCharFormat(CHARFORMAT2& cf)
{
	cf.cbSize = sizeof(CHARFORMAT2);
	return SetDefaultCharFormat((CHARFORMAT*)&cf);
}

BOOL CFreeWindowlessRE::SetDefaultCharFormat(CHARFORMAT* pcf)
{
	if (!m_bHostUsable || !pcf)
	{
		return FALSE;
	}

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_SETCHARFORMAT, SCF_DEFAULT, (LPARAM)pcf, &lr);
	if (FAILED(hr))
	{
		//...
	}
	if(0 == lr)
	{
		return FALSE;
	}
	return TRUE;
}

BOOL CFreeWindowlessRE::SetParaFormat(PARAFORMAT& pf)
{
	pf.cbSize = sizeof(PARAFORMAT);
	return SetParaFormat((PARAFORMAT*)&pf);
}

BOOL CFreeWindowlessRE::SetParaFormat(PARAFORMAT2& pf)
{
	pf.cbSize = sizeof(PARAFORMAT2);
	return SetParaFormat((PARAFORMAT*)&pf);
}

BOOL CFreeWindowlessRE::SetParaFormat(PARAFORMAT* ppf)
{
	if (!m_bHostUsable || !ppf)
	{
		return FALSE;
	}

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_SETPARAFORMAT , 0, (LPARAM)ppf, &lr);
	if (FAILED(hr))
	{
		//...
	}
	if(0 == lr)
	{
		return FALSE;
	}
	return TRUE;
}

BOOL CFreeWindowlessRE::SetSelectionCharFormat(CHARFORMAT& cf)
{
	cf.cbSize = sizeof(CHARFORMAT);
	return SetSelectionCharFormat((CHARFORMAT*)&cf);
}

BOOL CFreeWindowlessRE::SetSelectionCharFormat(CHARFORMAT2& cf)
{
	cf.cbSize = sizeof(CHARFORMAT2);
	return SetSelectionCharFormat((CHARFORMAT*)&cf);
}

BOOL CFreeWindowlessRE::SetSelectionCharFormat(CHARFORMAT* pcf)
{
	if (!m_bHostUsable || !pcf)
	{
		return FALSE;
	}

	// �������һ����
	if (0 == _tcsncmp(pcf->szFaceName, MICRO_YAHEI_CHINESE, LF_FACESIZE) && 
		FALSE == GetWinHost()->IsSupportMicroYaheiFontChinese())
	{
		if (GetWinHost()->IsSupportMicroYaheiFontEnglish())
		{
			_tcsncpy(pcf->szFaceName, MICRO_YAHEI_ENGLISH, LF_FACESIZE);
		}
	}

	if (0 == _tcsncmp(pcf->szFaceName, MICRO_YAHEI_ENGLISH, LF_FACESIZE) && 
		FALSE == GetWinHost()->IsSupportMicroYaheiFontEnglish())
	{
		if (GetWinHost()->IsSupportMicroYaheiFontChinese())
		{
			_tcsncpy(pcf->szFaceName, MICRO_YAHEI_CHINESE, LF_FACESIZE);
		}
	}

	// ����������ʽ
	LRESULT lr = 0;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_SETCHARFORMAT , SCF_SELECTION, (LPARAM)pcf, &lr);
	if (FAILED(hr))
	{
		//...
	}
	if(0 == lr)
	{
		return FALSE;
	}

	// ���������������
	if ((pcf->dwMask & CFM_FACE) && 
		GetWinHost()->IsSupportMicroYaheiFont() && (
		0 == _tcsncmp(pcf->szFaceName, MICRO_YAHEI_CHINESE, LF_FACESIZE) || 
		0 == _tcsncmp(pcf->szFaceName, MICRO_YAHEI_ENGLISH, LF_FACESIZE)))
	{
		GetWinHost()->EnableLanOptionAutoFont(FALSE);
	}
	else
	{
		GetWinHost()->EnableLanOptionAutoFont(TRUE);
	}

	return TRUE;
}

BOOL CFreeWindowlessRE::SetWordCharFormat(CHARFORMAT& cf)
{
	cf.cbSize = sizeof(CHARFORMAT);
	return SetWordCharFormat((CHARFORMAT*)&cf);
}

BOOL CFreeWindowlessRE::SetWordCharFormat(CHARFORMAT2& cf)
{
	cf.cbSize = sizeof(CHARFORMAT2);
	return SetWordCharFormat((CHARFORMAT*)&cf);
}

BOOL CFreeWindowlessRE::SetWordCharFormat(CHARFORMAT* pcf)
{
	if (!m_bHostUsable || !pcf)
	{
		return FALSE;
	}

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_SETCHARFORMAT , SCF_WORD, (LPARAM)pcf, &lr);
	if (FAILED(hr))
	{
		//...
	}
	if(lr == 0)
	{
		return FALSE;
	}
	return TRUE;
}

DWORD CFreeWindowlessRE::SetAllCharFormat(CHARFORMAT& cf)
{
	cf.cbSize = sizeof(CHARFORMAT);
	return SetAllCharFormat((CHARFORMAT*)&cf);
}

DWORD CFreeWindowlessRE::SetAllCharFormat(CHARFORMAT2& cf)
{
	cf.cbSize = sizeof(CHARFORMAT2);
	return SetAllCharFormat((CHARFORMAT*)&cf);
}

DWORD CFreeWindowlessRE::SetAllCharFormat(CHARFORMAT* pcf)
{
	if (!m_bHostUsable) return FALSE;

	// �������һ����
	if (0 == _tcsncmp(pcf->szFaceName, MICRO_YAHEI_CHINESE, LF_FACESIZE) && 
		FALSE == GetWinHost()->IsSupportMicroYaheiFontChinese())
	{
		if (GetWinHost()->IsSupportMicroYaheiFontEnglish())
		{
			_tcsncpy(pcf->szFaceName, MICRO_YAHEI_ENGLISH, LF_FACESIZE);
		}
	}

	if (0 == _tcsncmp(pcf->szFaceName, MICRO_YAHEI_ENGLISH, LF_FACESIZE) && 
		FALSE == GetWinHost()->IsSupportMicroYaheiFontEnglish())
	{
		if (GetWinHost()->IsSupportMicroYaheiFontChinese())
		{
			_tcsncpy(pcf->szFaceName, MICRO_YAHEI_CHINESE, LF_FACESIZE);
		}
	}

	// ����������ʽ
	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_SETCHARFORMAT , SCF_ALL, (LPARAM)pcf, &lr);
	if (FAILED(hr))
	{
		//...
	}
	if(lr == 0)
	{
		return FALSE;
	}

	// ���������������
	if ((pcf->dwMask & CFM_FACE) && 
		GetWinHost()->IsSupportMicroYaheiFont() && (
		0 == _tcsncmp(pcf->szFaceName, MICRO_YAHEI_CHINESE, LF_FACESIZE) || 
		0 == _tcsncmp(pcf->szFaceName, MICRO_YAHEI_ENGLISH, LF_FACESIZE)))
	{
		GetWinHost()->EnableLanOptionAutoFont(FALSE);
	}
	else
	{
		GetWinHost()->EnableLanOptionAutoFont(TRUE);
	}

	return TRUE;
}

BOOL CFreeWindowlessRE::CanPaste(UINT nFormat) const
{
	if (!m_bHostUsable) return FALSE;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_CANPASTE, (WPARAM)nFormat, 0, &lr);
	if (FAILED(hr))
	{
		return FALSE;
	}
	if(lr == 0)
	{
		return FALSE;
	}
	return TRUE;
}

BOOL CFreeWindowlessRE::CanRedo() const
{
	if (!m_bHostUsable) return FALSE;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_CANREDO, 0, 0, &lr);
	if (FAILED(hr))
	{
		return FALSE;
	}
	if(lr == 0)
	{
		return FALSE;
	}
	return TRUE;
}

BOOL CFreeWindowlessRE::CanUndo() const
{
	if (!m_bHostUsable) return FALSE;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_CANUNDO, 0, 0, &lr);
	if (FAILED(hr))
	{
		return FALSE;
	}
	if(lr == 0)
	{
		return FALSE;
	}
	return TRUE;
}

void CFreeWindowlessRE::EmptyUndoBuffer()
{
	if (!m_bHostUsable) return;

	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_EMPTYUNDOBUFFER, 0, 0, 0);
	if (FAILED(hr))
	{
		//...
	}
}

BOOL CFreeWindowlessRE::Redo()
{
	if (!m_bHostUsable)
		return FALSE;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_REDO, 0, 0, &lr);
	if (FAILED(hr))
	{
		//...
	}
	if(lr == 0)
	{
		return FALSE;
	}
	return TRUE;
}

BOOL CFreeWindowlessRE::Undo()
{
	if (!m_bHostUsable)
		return FALSE;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_UNDO, 0, 0, &lr);
	if (FAILED(hr))
	{
		//...
	}
	if(lr == 0)
	{
		return FALSE;
	}
	return TRUE;
}

void CFreeWindowlessRE::SetOptions(WORD wOp, DWORD dwFlags)
{
	GetWinHost()->TxWindowProc(m_hREParentWnd, EM_SETOPTIONS, (WPARAM)wOp, dwFlags);
}

UINT CFreeWindowlessRE::GetOptions() const
{
	return (UINT)GetWinHost()->TxWindowProc(m_hREParentWnd, EM_GETOPTIONS, 0, 0);
}

UINT CFreeWindowlessRE::SetUndoLimit(UINT nLimit)
{
	if (!m_bHostUsable) return 0;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_SETUNDOLIMIT, nLimit, 0, &lr);
	if (FAILED(hr))
	{
		//...
	}
	
	return (UINT)lr;
}

long CFreeWindowlessRE::GetLimitText() const
{
	if (!m_bHostUsable) return -1;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_GETLIMITTEXT, 0, 0, &lr);
	if (FAILED(hr))
	{
		//...
	}
	return (long)lr;
}

void CFreeWindowlessRE::LimitText(long nChars)
{
	if (!m_bHostUsable) return;

	GetWinHost()->TxWindowProc(m_hREParentWnd, EM_LIMITTEXT, nChars, 0);
}

BOOL CFreeWindowlessRE::SetAutoURLDetect(BOOL bEnable)
{
	if (!m_bHostUsable) return FALSE;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_AUTOURLDETECT, (WPARAM)bEnable, 0, &lr);
	if (FAILED(hr))
	{
		//...
	}
	if(lr == 0)
	{
		return FALSE;
	}
	return TRUE;
}

DWORD CFreeWindowlessRE::SetEventMask(DWORD dwEventMask)
{
	if (!m_bHostUsable) return 0;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_SETEVENTMASK, 0, (LPARAM)dwEventMask, &lr);
	if (FAILED(hr))
	{
		//...
	}
	
	return static_cast<DWORD>(lr);
}

long CFreeWindowlessRE::GetEventMask() const
{
	if (!m_bHostUsable) return -1;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_GETEVENTMASK, 0, 0, &lr);
	if (FAILED(hr))
	{
		//...
	}

	return static_cast<DWORD>(lr);
}

long CFreeWindowlessRE::StreamIn(int nFormat, EDITSTREAM& es)
{
	if (!m_bHostUsable) return -1;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_STREAMIN , (WPARAM)nFormat, (LPARAM)&es, &lr);
	if (FAILED(hr))
	{
		//...
	}

	return static_cast<long>(lr);
}

long CFreeWindowlessRE::StreamOut(int nFormat, EDITSTREAM& es)
{
	if (!m_bHostUsable) return -1;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_STREAMOUT , (WPARAM)nFormat, (LPARAM)&es, &lr);
	if (FAILED(hr))
	{
		//...
	}

	return static_cast<long>(lr);
}

COLORREF CFreeWindowlessRE::SetBackgroundColor(BOOL bSysColor, COLORREF cr)
{
	LRESULT lr = GetWinHost()->TxWindowProc(m_hREParentWnd, EM_SETBKGNDCOLOR, (WPARAM)bSysColor, (LPARAM)cr);

	return static_cast<COLORREF>(lr);
}


long CFreeWindowlessRE::GetTextLength() const
{
	if (!m_bHostUsable) return -1;

	LRESULT lr;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(WM_GETTEXTLENGTH, 0, 0, &lr);
	if (FAILED(hr))
	{
		//...
	}

	return static_cast<long>(lr);
}

long CFreeWindowlessRE::GetTextLengthEx(DWORD dwFlags, UINT uCodePage) const
{
	if (!m_bHostUsable) return -1;

	LRESULT lr;
	GETTEXTLENGTHEX getTextLenEx;
	getTextLenEx.flags = dwFlags;
	getTextLenEx.codepage = uCodePage;
	HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_GETTEXTLENGTHEX, (WPARAM)&(getTextLenEx), 0, &lr);
	if (FAILED(hr))
	{
		//...
	}

	return static_cast<long>(lr);
}

LONG CALLBACK ForbidEditWordBreakProc( char *pchText, LONG cchText, BYTE bCharSet, INT code )
{
	return FALSE;
}

void CFreeWindowlessRE::EnableWordBreak( bool bEnable )
{
	LRESULT lr;
	if(bEnable)
	{
		HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_SETWORDBREAKPROC, 0, NULL, &lr);
		if (FAILED(hr))
		{
			//...
		}
	}
	else
	{
		HRESULT hr = GetWinHost()->GetTextServices()->TxSendMessage(EM_SETWORDBREAKPROC,0,(LPARAM)(EDITWORDBREAKPROC)ForbidEditWordBreakProc, &lr);
		if (FAILED(hr))
		{
			//...
		}
	}
}

void CFreeWindowlessRE::ShowCaret(bool bShow)
{
	if (GetWinHost())
	{
		GetWinHost()->ShowCaret(bShow);
	}
}

void CFreeWindowlessRE::UpdateCaretInTimer()
{
	if (GetWinHost())
	{
		GetWinHost()->UpdateCaretInTimer();
	}
}

void CFreeWindowlessRE::GetCaretPos(LPPOINT lpCaret)
{
	if (GetWinHost())
	{
		GetWinHost()->GetCaretPos(lpCaret);
	}
}

void CFreeWindowlessRE::RegisterDragDrop()
{
	if (GetWinHost())
	{
		GetWinHost()->RegisterDragDrop();
	}
}

void CFreeWindowlessRE::RevokeDragDrop()
{
	if (GetWinHost())
	{
		GetWinHost()->RevokeDragDrop();
	}
}