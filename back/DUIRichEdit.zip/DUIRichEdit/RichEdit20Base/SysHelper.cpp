#include "stdafx.h"
#include "SysHelper.h"

CXXImageDll CSysHelper::m_xxImageDll;

CSysHelper::CSysHelper()
{
	m_uSysImgPngStart = 2050;
	m_uSysImgPngEnd = 2100;
	m_uSysImgGifStart = 2000;
	m_uSysImgGifEnd = 2049;

	m_hintImageColl.insert(std::make_pair(IMAGE_TYPE_LOADING_GIF, 2000));
	m_hintImageColl.insert(std::make_pair(IMAGE_TYPE_BLOCKIMAGE_GIF, 2001));
	m_hintImageColl.insert(std::make_pair(IMAGE_TYPE_NO_IMAGE_PNG, 2051));
	m_hintImageColl.insert(std::make_pair(IMAGE_TYPE_NORMAL_HINT_PNG, 2055));

	m_hRcFaceDll = NULL;

	m_strPicRcvPath = _T("");
	
	m_strSafeCheckSite = _T("");

	m_pFnGetExistSRImgPath = NULL;
}

CSysHelper::~CSysHelper()
{

}

void CSysHelper::SetSysImgParam(UINT nSysImgPngStart, UINT nSysImgPngEnd, UINT nSysImgGifStart, UINT nSysImgGifEnd)
{
	m_uSysImgPngStart = nSysImgPngStart;
	m_uSysImgPngEnd = nSysImgPngEnd;
	m_uSysImgGifStart = nSysImgGifStart;
	m_uSysImgGifEnd = nSysImgGifEnd;
}

void CSysHelper::SetSysSpecialImgResID(UINT nResID_LoadingGif, UINT nResID_BlockingGif, UINT nResID_ImgNotExistPng, UINT nResID_CommonHintPng)
{
	m_hintImageColl[IMAGE_TYPE_LOADING_GIF] = nResID_LoadingGif;
	m_hintImageColl[IMAGE_TYPE_BLOCKIMAGE_GIF] = nResID_BlockingGif;
	m_hintImageColl[IMAGE_TYPE_NO_IMAGE_PNG] = nResID_ImgNotExistPng;
	m_hintImageColl[IMAGE_TYPE_NORMAL_HINT_PNG] = nResID_CommonHintPng;
}

bool CSysHelper::IsSysImg(UINT nIndex)
{
	if (nIndex >= m_uSysImgPngStart && nIndex <= m_uSysImgPngEnd)
	{
		return true;
	}

	if (nIndex >= m_uSysImgGifStart && nIndex <= m_uSysImgGifEnd)
	{
		return true;
	}

	return false;
}

bool CSysHelper::SysImgIsPng(UINT index)
{
	if (index >= m_uSysImgPngStart && index <= m_uSysImgPngEnd)
	{
		return true;
	}

	return false;
}

void CSysHelper::SetSysHintImageInfo(UINT nHintType, UINT nImageID)
{
	std::map<UINT, UINT>::iterator it = m_hintImageColl.find(nHintType);
	if (it != m_hintImageColl.end())
	{
		it->second = nImageID;
	}
	else
	{
		m_hintImageColl.insert(std::make_pair(nHintType, nImageID));
	}
}

UINT CSysHelper::GetSysHintImageID(UINT nHintType)
{
	std::map<UINT, UINT>::iterator it = m_hintImageColl.find(nHintType);
	if (it != m_hintImageColl.end())
	{
		return it->second;
	}

	it = m_hintImageColl.find(IMAGE_TYPE_NORMAL_HINT_PNG);
	if (it != m_hintImageColl.end())
	{
		return it->second;
	}

	return 2055;
}

void CSysHelper::SetSysFaceParam(BYTE bySysFaceType, UINT nSysFaceIDBase, UINT nSysFaceNum)
{
    MAP_SYS_ANI_FACE_PARAM::iterator it = m_mapSysFaceParam.find(bySysFaceType);
    if (m_mapSysFaceParam.end() == it)
    {
        SysAniFaceParam param;
        param.uBase  = nSysFaceIDBase;
        param.uCount = nSysFaceNum;
        m_mapSysFaceParam.insert(std::make_pair(bySysFaceType, param));
    }
    else
    {
        SysAniFaceParam& param = it->second;
        param.uBase  = nSysFaceIDBase;
        param.uCount = nSysFaceNum;
    }
}

UINT CSysHelper::GetSysFaceResouceID(UINT nIndex)
{
	// �Ǳ��飬ϵͳʹ�õ�gif����loading.gif
	if (nIndex >= m_uSysImgGifStart && nIndex <= m_uSysImgGifEnd)
	{
		return nIndex;
	}

	// �Ǳ��飬ϵͳʹ�õ�bmp����shark.bmp
	if (nIndex >= m_uSysImgPngStart && nIndex <= m_uSysImgPngEnd)
	{
		return nIndex;
	}
	//������id�ĺϷ���
	nIndex = GetValidFaceID(nIndex);
	return nIndex;
}

UINT CSysHelper::GetSysFaceBaseID(BYTE bySysFaceType)
{
    MAP_SYS_ANI_FACE_PARAM::iterator it = m_mapSysFaceParam.find(bySysFaceType);
    if (m_mapSysFaceParam.end() == it)
    {
        return 0;
    }
    return it->second.uBase;
}

UINT CSysHelper::GetSysFaceNum(BYTE bySysFaceType)
{
    MAP_SYS_ANI_FACE_PARAM::iterator it = m_mapSysFaceParam.find(bySysFaceType);
    if (m_mapSysFaceParam.end() == it)
    {
        return 0;
    }
    return it->second.uCount;
}

UINT CSysHelper::GetAllSysAnimaFaceNum()
{
    UINT uTotalCount = 0;
    MAP_SYS_ANI_FACE_PARAM::iterator it = m_mapSysFaceParam.begin();
    for (; it != m_mapSysFaceParam.end(); ++it)
    {
        SysAniFaceParam& param = it->second;
        uTotalCount += param.uCount;
    }
    return uTotalCount;
}

void CSysHelper::SetRcFaceDll(HMODULE hRcFaceDll)
{
	m_hRcFaceDll = hRcFaceDll;
}

HMODULE CSysHelper::GetRcFaceDll()
{
	return m_hRcFaceDll;
}

void CSysHelper::SetPicRcvPath(LPCTSTR strPicRcvPath)
{
	m_strPicRcvPath = strPicRcvPath;
}

void CSysHelper::GetPicRcvPath(WTL::CString& strPicPath)
{
	strPicPath = m_strPicRcvPath;
}

void CSysHelper::SetSafeCheckSite(LPCTSTR strSafeCheckSite)
{
	m_strSafeCheckSite = strSafeCheckSite;
}

void CSysHelper::GetSafeCheckSite(WTL::CString& strSafeCheckSite)
{
	strSafeCheckSite = m_strSafeCheckSite;
}

UINT CSysHelper::GetValidFaceID(UINT nSrcFaceID)
{
    bool bInFaceIDRange = false;
    MAP_SYS_ANI_FACE_PARAM::iterator it = m_mapSysFaceParam.begin();
    for (; it != m_mapSysFaceParam.end(); ++it)
    {
        SysAniFaceParam& param = it->second;
        if ((nSrcFaceID >= param.uBase) && (nSrcFaceID < (param.uBase + param.uCount)))
        {
            bInFaceIDRange = true;
            break;
        }
    }
    return (bInFaceIDRange ? nSrcFaceID : 0);
}

void CSysHelper::InitxXXImageDll()
{
	if (!m_xxImageDll.IsLoaded())
	{
		CXXImageDll* pxxImageDll = CUIRes::GetXXImageDll();
		if (NULL == pxxImageDll || !(pxxImageDll->IsLoaded()))
		{
			TCHAR drive[_MAX_DRIVE];
			TCHAR dir[_MAX_DIR];

			memset(drive, 0, sizeof(TCHAR)*_MAX_DRIVE);
			memset(dir, 0, sizeof(TCHAR)*_MAX_DIR);

			TCHAR filePath[MAX_PATH];
			GetModuleFileName(NULL, filePath, MAX_PATH);

			_tsplitpath(filePath, drive, dir, NULL, NULL);

			TCHAR szTempPath[MAX_PATH];
			_stprintf(szTempPath, _T("%s%s"), drive, dir);

			WTL::CString strXxImgeDllPath;
			strXxImgeDllPath.Format(_T("%sxximage.dll"), szTempPath);

			m_xxImageDll.Init(strXxImgeDllPath);
		}
		else
		{
			m_xxImageDll = *pxxImageDll;
		}
	}
}

CXXImageDll& CSysHelper::GetXXImageDll()
{
	if (!m_xxImageDll.IsLoaded())
	{
		CXXImageDll* pxxImageDll = CUIRes::GetXXImageDll();
		if (NULL == pxxImageDll || !(pxxImageDll->IsLoaded()))
		{
			TCHAR drive[_MAX_DRIVE];
			TCHAR dir[_MAX_DIR];

			memset(drive, 0, sizeof(TCHAR)*_MAX_DRIVE);
			memset(dir, 0, sizeof(TCHAR)*_MAX_DIR);

			TCHAR filePath[MAX_PATH];
			GetModuleFileName(NULL, filePath, MAX_PATH);

			_tsplitpath(filePath, drive, dir, NULL, NULL);

			TCHAR szTempPath[MAX_PATH];
			_stprintf(szTempPath, _T("%s%s"), drive, dir);

			WTL::CString strXxImgeDllPath;
			strXxImgeDllPath.Format(_T("%sxximage.dll"), szTempPath);

			m_xxImageDll.Init(strXxImgeDllPath);
		}
		else
		{
			m_xxImageDll = *pxxImageDll;
		}
	}

	return m_xxImageDll;
}

void CSysHelper::SetGetExistSRImagePathFn( FnGetExistSRImagePath pFn )
{
	m_pFnGetExistSRImgPath = pFn;
}

bool CSysHelper::GetExistSRImagePath( LPCTSTR strImageName,LPTSTR pstrImagePath,int nLen )
{	
	if(m_pFnGetExistSRImgPath)
	{
		return m_pFnGetExistSRImgPath(strImageName,pstrImagePath,nLen);
	}
	return false;
}

void CSysHelper::GetSRPicPath(LPCTSTR strFileName,WTL::CString& strFilePath)
{
	TCHAR tszPicRcvPath[MAX_PATH+1];
	if(GetExistSRImagePath(strFileName,tszPicRcvPath,MAX_PATH+1))
	{
		//���ͼƬ����ֱ��ʹ���Ѵ��ڵ�·��
		strFilePath = tszPicRcvPath;
	}
	else
	{
		//ͼƬ������ ʹ�õ�ǰ�����ļ���·���������ļ�
		GetPicRcvPath(strFilePath);
		strFilePath += strFileName;
	}
}