/**
 * \brief ϵͳ������
 * \author ts
 * \date 2011-7-17
 */
#pragma once
#include "xxImageDll.h"
#include<map>

#define IMAGE_TYPE_LOADING_GIF           0 //���ڼ�����GIF�ļ���
#define IMAGE_TYPE_BLOCKIMAGE_GIF        1 //ͼƬ�����GIF�ļ�
#define IMAGE_TYPE_NO_IMAGE_PNG          2 //ͼƬ������ʱ��ʾͼƬ
#define IMAGE_TYPE_NORMAL_HINT_PNG       3 //��׼��ʾͼƬ

//��ȡ�Ѿ����ڵ�ͼƬ��·�� �������򷵻�false
typedef bool (*FnGetExistSRImagePath)(LPCTSTR strImageName,LPTSTR strImagePath,int nLen);

class CSysHelper
{
public:
	CSysHelper();
	~CSysHelper();

public:
	void SetSysImgParam(UINT nSysImgPngStart, UINT nSysImgPngEnd, UINT nSysImgGifStart, UINT nSysImgGifEnd);
	void SetSysSpecialImgResID(UINT nResID_LoadingGif, UINT nResID_BlockingGif, UINT nResID_ImgNotExistPng, UINT nResID_CommonHintPng);
	bool IsSysImg(UINT nIndex);
	bool SysImgIsPng(UINT nIndex);

	void SetSysHintImageInfo(UINT nHintType, UINT nImageID);
	UINT GetSysHintImageID(UINT nHintType);

	void SetSysFaceParam(BYTE bySysFaceType, UINT nSysFaceIDBase, UINT nSysFaceNum);
	UINT GetSysFaceResouceID(UINT nIndex);
	UINT GetSysFaceBaseID(BYTE bySysFaceType);
	UINT GetSysFaceNum(BYTE bySysFaceType);
	UINT GetAllSysAnimaFaceNum();

	void SetRcFaceDll(HMODULE hRcFaceDll);
	HMODULE GetRcFaceDll();

	void SetPicRcvPath(LPCTSTR strPicRcvPath);
	void GetPicRcvPath(WTL::CString& strPicPath);

	void SetGetExistSRImagePathFn(FnGetExistSRImagePath pFn);
	bool GetExistSRImagePath(LPCTSTR strImageName,LPTSTR pstrImagePath,int nLen);

	void GetSRPicPath(LPCTSTR strFileName,WTL::CString& strFilePath);

	void SetSafeCheckSite(LPCTSTR strSafeCheckSite);
	void GetSafeCheckSite(WTL::CString& strSafeCheckSite);

private:
	UINT GetValidFaceID(UINT nSrcFaceID);

public:
	static void InitxXXImageDll();
	static CXXImageDll& GetXXImageDll();

private:
	//ϵͳͼƬ��Դ����
	UINT m_uSysImgPngStart;
	UINT m_uSysImgPngEnd;
	UINT m_uSysImgGifStart;
	UINT m_uSysImgGifEnd;

	//��ʾͼƬ��Դ�б� <ͼƬ��ʾ����, ͼƬID>
	std::map<UINT, UINT> m_hintImageColl;

	//ϵͳ������Դ����
    struct SysAniFaceParam {
        UINT uBase;
        UINT uCount;
    };
    typedef std::map<int, SysAniFaceParam> MAP_SYS_ANI_FACE_PARAM;
    MAP_SYS_ANI_FACE_PARAM m_mapSysFaceParam;

	HMODULE m_hRcFaceDll;

	//�Զ���ͼƬ����
	WTL::CString m_strPicRcvPath;

	FnGetExistSRImagePath	m_pFnGetExistSRImgPath;

	//������������ַ
	WTL::CString m_strSafeCheckSite;

private:
	static CXXImageDll        m_xxImageDll;
};