/**
* \brief RichEdit��Ole��չ�ؼ�������
* \author ts
* \date 2015-10-8
*/
#ifndef _IMCONTROLPROCESSER_H_20150109
#define _IMCONTROLPROCESSER_H_20150109
#include "IOleProcesser.h"

class CRichElementBase;
class CIMControlProcesser : public IOleProcesser
{
public:
	CIMControlProcesser();
	virtual ~CIMControlProcesser();

public:
	virtual OleProcesserType GetType();

	virtual void SetUserData(DWORD_PTR dwUserData) { m_dwUserData = dwUserData; }
	virtual DWORD_PTR GetUserData() { return m_dwUserData; }

	virtual BOOL IsEnableAutoSize() { return m_bEnableAutoSize; }
	virtual void EnableAutoSize(BOOL bEnable) { m_bEnableAutoSize = bEnable; }

	virtual SIZE GetSize() const;
    virtual void SetSize(int nWidth, int nHeight);

	virtual BOOL GetVisible() { return m_bVisible; }
	virtual void SetVisible(BOOL bVisible) { m_bVisible = bVisible; }

	virtual void SetVisibleInside(BOOL bVisible);
	virtual void SyncVisible();

	virtual void OnPaint(HDC hDC, LPRECT lpRect, bool& bResultPlayAni, UINT uAniTick, LPRECT lpClipRect = NULL, bool bForbidSmooth = true);

public:
	void OnMouseMove(CPoint& ptCursor, BOOL& bRetInvidate, CRichElementBase** pRetHotElement, CRichElementBase** pRetLeaveElement, CRichElementBase** pRetHitElement);
	void OnMouseLeave(BOOL& bRetInvidate, CRichElementBase** pRetElement);
	void OnLButtonDown(CPoint& ptCursor, BOOL& bRetInvidate, CRichElementBase** pRetLButtonDownElement, CRichElementBase** pRetLeaveElement);
	void OnLButtonUp(CPoint& ptCursor, BOOL& bRetInvidate, CRichElementBase** pRetLButtonUpElement, CRichElementBase** pRetLeaveElement);

public:
	void SetControlElement(CRichElementBase* pElementModel);
	CRichElementBase* GetControlElement() { return m_pControlElement; }
	LPCTSTR GetControlElementName();
	
	SIZE CalcSizeByAutoLayout(HDC hDC, int nMaxWidth, int nMaxHeight);
	void SetNeedRelayout();

	void SetElementVisible(LPCTSTR lpName, BOOL bVisible);
	BOOL IsElementVisible(LPCTSTR lpName);

	void SetElementEnabled(LPCTSTR lpName, BOOL bEnabled);
	BOOL IsElementEnabled(LPCTSTR lpName);

	void SetElementDisposeMouse(LPCTSTR lpName, BOOL bDispose);
	BOOL IsElementDisposeMouse(LPCTSTR lpName);

	void SetElementTooltip(LPCTSTR lpName, LPCTSTR lpTooltip);
	void SetElementTooltipByStringCaption(LPCTSTR lpName, LPCTSTR lpStringCaption);

	BOOL IsElementStatic(LPCTSTR lpName);
	BOOL SetElementStaticText(LPCTSTR lpName, LPCTSTR lpText);
	BOOL SetElementStaticTextByStringCaption(LPCTSTR lpName, LPCTSTR lpStringCaption);
	LPCTSTR GetElementStaticText(LPCTSTR lpName);
	BOOL SetElementStaticTextColor(LPCTSTR lpName, COLORREF clrTextNormal, COLORREF clrTextHot, COLORREF clrTextPress, COLORREF clrTextDisabled);
	COLORREF GetElementStaticTextNormalColor(LPCTSTR lpName);
	COLORREF GetElementStaticTextHotColor(LPCTSTR lpName);
	COLORREF GetElementStaticTextPressColor(LPCTSTR lpName);
	COLORREF GetElementStaticTextDisabledColor(LPCTSTR lpName);
	CUITextStyleCom* GetElementStaticTextStyle(LPCTSTR lpName);
	void SetElementStaticTextStyle(LPCTSTR lpName, CUITextStyleCom* pTextStyle);

	BOOL IsElementLogo(LPCTSTR lpName);
	BOOL SetElementLogoImage(LPCTSTR lpName, CUIImageBaseCom* pLogo);
	CUIImageBaseCom* GetElementLogoImageBase(LPCTSTR lpName);
	BOOL SetElementLogoImage(LPCTSTR lpName, CUIImageListCom* pImagList, int nLogoIndex);
	CUIImageListCom* GetElementLogoImageList(LPCTSTR lpName);
	int GetElementLogoImageIndex(LPCTSTR lpName);
	BOOL SetElementLogoImageBmp(LPCTSTR lpName, HBITMAP hBmpLogo, BOOL bTemporySource);
	HBITMAP GetItemElementLogoImageBmp(LPCTSTR lpName);

	void SetElementFixedWidth(LPCTSTR lpName, int nWidth);
	int GetElementFixedWidth(LPCTSTR lpName);

	void SetElementFixedHeight(LPCTSTR lpName, int nHeight);
	int GetElementFixedHeight(LPCTSTR lpName);

	RECT GetItemElementRect(LPCTSTR lpName);
	CRichElementBase* HitTest(POINT ptCursor);

private:
	DWORD_PTR			m_dwUserData;
	BOOL				m_bVisible;
	BYTE				m_bVisibleInside;
	BOOL				m_bEnableAutoSize;
	SIZE				m_curSize;
	BOOL				m_bNeedRelayout;
	CRichElementBase*	m_pControlElement;
};

#endif // _IMCONTROLPROCESSER_H_20150109