#include "stdafx.h"
#include "IMControlProcesser.h"
#include "../public/RichItemElement/RichItemElement.h"

CIMControlProcesser::CIMControlProcesser()
: m_dwUserData(0)
, m_bVisible(TRUE)
, m_bVisibleInside(FALSE)
, m_bEnableAutoSize(FALSE)
, m_pControlElement(NULL)
, m_bNeedRelayout(FALSE)
{
	m_curSize.cx = 0;
	m_curSize.cy = 0;
}

CIMControlProcesser::~CIMControlProcesser()
{
	SAFE_DELETE(m_pControlElement);
}

OleProcesserType CIMControlProcesser::GetType()
{
	return OleProcesser_Control;
}

SIZE CIMControlProcesser::GetSize() const
{
	return m_curSize;
}

void CIMControlProcesser::SetVisibleInside(BOOL bVisible)
{
	m_bVisibleInside = bVisible;
}

void CIMControlProcesser::SyncVisible()
{
	m_bVisible = m_bVisibleInside;
	m_bVisibleInside = FALSE;
}

void CIMControlProcesser::OnPaint(HDC hDC, LPRECT lpRect, bool& bResultPlayAni, UINT uAniTick, LPRECT lpClipRect/* = NULL*/, bool bForbidSmooth/* = true*/)
{
	if (!m_pControlElement || !lpRect)
	{
		return;
	}

	// �ͺ����Ԫ�ز���
	if (m_bNeedRelayout || m_pControlElement->IsNeedReCalcRect())
	{
		m_bNeedRelayout = FALSE;
		m_pControlElement->CalcRect(hDC, 0, 0, m_curSize.cx, m_curSize.cy);
	}

	// ����Ԫ������
	BOOL bPlayAni = FALSE;
	CPoint ptLeftTop(lpRect->left, lpRect->top);
	m_pControlElement->OnDraw(hDC, &ptLeftTop, FALSE, FALSE, uAniTick, bPlayAni, FALSE);

	if (bPlayAni)
	{
		bResultPlayAni = TRUE;
	}
}

void CIMControlProcesser::OnMouseMove(CPoint& ptCursor, BOOL& bRetInvidate, CRichElementBase** pRetHotElement, CRichElementBase** pRetLeaveElement, CRichElementBase** pRetHitElement)
{
	bRetInvidate = FALSE;
	if (pRetHotElement)
	{
		*pRetHotElement = NULL;
	}
	if (pRetLeaveElement)
	{
		*pRetLeaveElement = NULL;
	}
	if (pRetHitElement)
	{
		*pRetHitElement = NULL;
	}

	if (m_pControlElement)
	{
		m_pControlElement->OnMouseMove(ptCursor, bRetInvidate, pRetHotElement, pRetLeaveElement, pRetHitElement);
	}
}

void CIMControlProcesser::OnMouseLeave(BOOL& bRetInvidate, CRichElementBase** pRetElement)
{
	bRetInvidate = FALSE;
	if (pRetElement)
	{
		*pRetElement = NULL;
	}

	if (m_pControlElement)
	{
		m_pControlElement->OnMouseLeave(bRetInvidate, pRetElement);
	}
}

void CIMControlProcesser::OnLButtonDown(CPoint& ptCursor, BOOL& bRetInvidate, CRichElementBase** pRetLButtonDownElement, CRichElementBase** pRetLeaveElement)
{
	bRetInvidate = FALSE;
	if (pRetLButtonDownElement)
	{
		*pRetLButtonDownElement = NULL;
	}
	if (pRetLeaveElement)
	{
		*pRetLeaveElement = NULL;
	}

	if (m_pControlElement)
	{
		m_pControlElement->OnLButtonDown(ptCursor, bRetInvidate, pRetLButtonDownElement, pRetLeaveElement);
	}
}

void CIMControlProcesser::OnLButtonUp(CPoint& ptCursor, BOOL& bRetInvidate, CRichElementBase** pRetLButtonUpElement, CRichElementBase** pRetLeaveElement)
{
	bRetInvidate = FALSE;
	if (pRetLButtonUpElement)
	{
		*pRetLButtonUpElement = NULL;
	}
	if (pRetLeaveElement)
	{
		*pRetLeaveElement = NULL;
	}

	if (m_pControlElement)
	{
		m_pControlElement->OnLButtonUp(ptCursor, bRetInvidate, pRetLButtonUpElement, pRetLeaveElement);
	}
}

void CIMControlProcesser::SetControlElement(CRichElementBase* pElementModel)
{
	if (m_pControlElement)
	{
		SAFE_DELETE(m_pControlElement);
	}

	if (pElementModel)
	{
		m_pControlElement = pElementModel->Clone();
	}
}

LPCTSTR CIMControlProcesser::GetControlElementName()
{
	if (m_pControlElement)
	{
		return m_pControlElement->GetName();
	}

	return _T("");
}

void CIMControlProcesser::SetSize(int nWidth, int nHeight)
{
	if (m_curSize.cx != nWidth || 
		m_curSize.cy != nHeight)
	{
		m_curSize.cx = nWidth;
		m_curSize.cy = nHeight;

		SetNeedRelayout();
	}
}

SIZE CIMControlProcesser::CalcSizeByAutoLayout(HDC hDC, int nMaxWidth, int nMaxHeight)
{
	if (!m_pControlElement)
	{
		return m_curSize;
	}

	m_pControlElement->CalcRect(hDC, 0, 0, nMaxWidth,nMaxHeight);

	int nResultWidth = 0;
	int nResultHeight = 0;
	m_pControlElement->TryCalcMinSize(nResultWidth, nResultHeight);

	m_curSize.cx = nResultWidth;
	m_curSize.cy = nResultHeight;
	return m_curSize;
}

void CIMControlProcesser::SetNeedRelayout()
{
	m_bNeedRelayout = TRUE;
}

void CIMControlProcesser::SetElementVisible(LPCTSTR lpName, BOOL bVisible)
{
	if (!m_pControlElement)
	{
		return;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return;
	}

	if (pElement->IsVisible() != bVisible)
	{
		SetNeedRelayout();
	}

	pElement->SetVisible(bVisible);
}

BOOL CIMControlProcesser::IsElementVisible(LPCTSTR lpName)
{
	if (!m_pControlElement)
	{
		return FALSE;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return FALSE;
	}

	return pElement->IsVisible();
}

void CIMControlProcesser::SetElementEnabled(LPCTSTR lpName, BOOL bEnabled)
{
	if (!m_pControlElement)
	{
		return;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return;
	}

	pElement->SetEnabled(bEnabled);
}

BOOL CIMControlProcesser::IsElementEnabled(LPCTSTR lpName)
{
	if (!m_pControlElement)
	{
		return FALSE;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return FALSE;
	}

	return pElement->IsEnabled();
}

void CIMControlProcesser::SetElementDisposeMouse(LPCTSTR lpName, BOOL bDispose)
{
	if (!m_pControlElement)
	{
		return;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return;
	}

	pElement->SetDisposeMouse(bDispose);
}

BOOL CIMControlProcesser::IsElementDisposeMouse(LPCTSTR lpName)
{
	if (!m_pControlElement)
	{
		return FALSE;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return FALSE;
	}

	return pElement->IsDisposeMouse();
}

void CIMControlProcesser::SetElementTooltip(LPCTSTR lpName, LPCTSTR lpTooltip)
{
	if (!m_pControlElement)
	{
		return;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return;
	}

	pElement->SetToolTips(lpTooltip);
}

void CIMControlProcesser::SetElementTooltipByStringCaption(LPCTSTR lpName, LPCTSTR lpStringCaption)
{
	if (!m_pControlElement)
	{
		return;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return;
	}

	pElement->SetToolTipsCaption(lpStringCaption);
}

BOOL CIMControlProcesser::IsElementStatic(LPCTSTR lpName)
{
	if (!m_pControlElement)
	{
		return FALSE;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return FALSE;
	}

	if (pElement->GetType() != eRichElement_Static)
	{
		return FALSE;
	}

	return TRUE;
}

BOOL CIMControlProcesser::SetElementStaticText(LPCTSTR lpName, LPCTSTR lpText)
{
	if (!m_pControlElement)
	{
		return FALSE;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return FALSE;
	}

	if (pElement->GetType() != eRichElement_Static)
	{
		return FALSE;
	}

	((CRichElementStatic*)pElement)->SetText(lpText);

	if (pElement->IsAutoHeight() || pElement->IsAutoWidth())
	{
		SetNeedRelayout();
	}

	return TRUE;
}

BOOL CIMControlProcesser::SetElementStaticTextByStringCaption(LPCTSTR lpName, LPCTSTR lpStringCaption)
{
	if (!m_pControlElement)
	{
		return FALSE;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return FALSE;
	}

	if (pElement->GetType() != eRichElement_Static)
	{
		return FALSE;
	}

	((CRichElementStatic*)pElement)->SetTextByStringCaption(lpStringCaption);

	if (pElement->IsAutoHeight() || pElement->IsAutoWidth())
	{
		SetNeedRelayout();
	}

	return TRUE;
}

LPCTSTR CIMControlProcesser::GetElementStaticText(LPCTSTR lpName)
{
	if (!m_pControlElement)
	{
		return _T("");
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return _T("");
	}

	if (pElement->GetType() != eRichElement_Static)
	{
		return _T("");
	}

	return ((CRichElementStatic*)pElement)->GetText();
}

BOOL CIMControlProcesser::SetElementStaticTextColor(LPCTSTR lpName, COLORREF clrTextNormal, COLORREF clrTextHot, COLORREF clrTextPress, COLORREF clrTextDisabled)
{
	if (!m_pControlElement)
	{
		return FALSE;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return FALSE;
	}

	if (pElement->GetType() != eRichElement_Static)
	{
		return FALSE;
	}

	((CRichElementStatic*)pElement)->SetNormalTextColor(clrTextNormal);
	((CRichElementStatic*)pElement)->SetHotTextColor(clrTextHot);
	((CRichElementStatic*)pElement)->SetPressTextColor(clrTextPress);
	((CRichElementStatic*)pElement)->SetDisabledTextColor(clrTextDisabled);

	return TRUE;
}

COLORREF CIMControlProcesser::GetElementStaticTextNormalColor(LPCTSTR lpName)
{
	if (!m_pControlElement)
	{
		return 0;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return 0;
	}

	if (pElement->GetType() != eRichElement_Static)
	{
		return 0;
	}

	return ((CRichElementStatic*)pElement)->GetNormalTextColor();
}

COLORREF CIMControlProcesser::GetElementStaticTextHotColor(LPCTSTR lpName)
{
	if (!m_pControlElement)
	{
		return 0;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return 0;
	}

	if (pElement->GetType() != eRichElement_Static)
	{
		return 0;
	}

	return ((CRichElementStatic*)pElement)->GetHotTextColor();
}

COLORREF CIMControlProcesser::GetElementStaticTextPressColor(LPCTSTR lpName)
{
	if (!m_pControlElement)
	{
		return 0;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return 0;
	}

	if (pElement->GetType() != eRichElement_Static)
	{
		return 0;
	}

	return ((CRichElementStatic*)pElement)->GetPressTextColor();
}

COLORREF CIMControlProcesser::GetElementStaticTextDisabledColor(LPCTSTR lpName)
{
	if (!m_pControlElement)
	{
		return 0;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return 0;
	}

	if (pElement->GetType() != eRichElement_Static)
	{
		return 0;
	}

	return ((CRichElementStatic*)pElement)->GetDisabledTextColor();
}

CUITextStyleCom* CIMControlProcesser::GetElementStaticTextStyle(LPCTSTR lpName)
{
	if (!m_pControlElement)
	{
		return NULL;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return NULL;
	}

	if (pElement->GetType() != eRichElement_Static)
	{
		return NULL;
	}

	return ((CRichElementStatic*)pElement)->GetTextStyle();
}

void CIMControlProcesser::SetElementStaticTextStyle(LPCTSTR lpName, CUITextStyleCom* pTextStyle)
{
	if (!m_pControlElement)
	{
		return;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return;
	}

	if (pElement->GetType() != eRichElement_Static)
	{
		return;
	}

	((CRichElementStatic*)pElement)->SetTextStyle(pTextStyle);
}

BOOL CIMControlProcesser::IsElementLogo(LPCTSTR lpName)
{
	if (!m_pControlElement)
	{
		return FALSE;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return FALSE;
	}

	if (pElement->GetType() != eRichElement_Logo)
	{
		return FALSE;
	}

	return TRUE;
}

BOOL CIMControlProcesser::SetElementLogoImage(LPCTSTR lpName, CUIImageBaseCom* pLogo)
{
	if (!m_pControlElement)
	{
		return FALSE;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return FALSE;
	}

	if (pElement->GetType() != eRichElement_Logo)
	{
		return FALSE;
	}

	((CRichElementLogo*)pElement)->SetLogo(pLogo);

	if (pElement->IsAutoHeight() || pElement->IsAutoWidth())
	{
		SetNeedRelayout();
	}

	return TRUE;
}

CUIImageBaseCom* CIMControlProcesser::GetElementLogoImageBase(LPCTSTR lpName)
{
	if (!m_pControlElement)
	{
		return NULL;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return NULL;
	}

	if (pElement->GetType() != eRichElement_Logo)
	{
		return NULL;
	}

	return ((CRichElementLogo*)pElement)->GetLogoImageBase();
}

BOOL CIMControlProcesser::SetElementLogoImage(LPCTSTR lpName, CUIImageListCom* pImagList, int nLogoIndex)
{
	if (!m_pControlElement)
	{
		return FALSE;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return FALSE;
	}

	if (pElement->GetType() != eRichElement_Logo)
	{
		return FALSE;
	}

	((CRichElementLogo*)pElement)->SetLogo(pImagList, nLogoIndex);

	if (pElement->IsAutoHeight() || pElement->IsAutoWidth())
	{
		SetNeedRelayout();
	}

	return TRUE;
}

CUIImageListCom* CIMControlProcesser::GetElementLogoImageList(LPCTSTR lpName)
{
	if (!m_pControlElement)
	{
		return NULL;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return NULL;
	}

	if (pElement->GetType() != eRichElement_Logo)
	{
		return NULL;
	}

	return ((CRichElementLogo*)pElement)->GetLogoImageList();
}

int CIMControlProcesser::GetElementLogoImageIndex(LPCTSTR lpName)
{
	if (!m_pControlElement)
	{
		return 0;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return 0;
	}

	if (pElement->GetType() != eRichElement_Logo)
	{
		return 0;
	}

	return ((CRichElementLogo*)pElement)->GetLogoImageIndex();
}

BOOL CIMControlProcesser::SetElementLogoImageBmp(LPCTSTR lpName, HBITMAP hBmpLogo, BOOL bTemporySource)
{
	if (!m_pControlElement)
	{
		return FALSE;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return FALSE;
	}

	if (pElement->GetType() != eRichElement_Logo)
	{
		return FALSE;
	}

	((CRichElementLogo*)pElement)->SetLogo(hBmpLogo, bTemporySource);

	if (pElement->IsAutoHeight() || pElement->IsAutoWidth())
	{
		SetNeedRelayout();
	}

	return TRUE;
}

HBITMAP CIMControlProcesser::GetItemElementLogoImageBmp(LPCTSTR lpName)
{
	if (!m_pControlElement)
	{
		return NULL;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return NULL;
	}

	if (pElement->GetType() != eRichElement_Logo)
	{
		return NULL;
	}

	return ((CRichElementLogo*)pElement)->GetLogoBmp();
}

void CIMControlProcesser::SetElementFixedWidth(LPCTSTR lpName, int nWidth)
{
	if (!m_pControlElement)
	{
		return;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return;
	}

	if (nWidth == pElement->GetFixedWidth())
	{
		return;
	}

	pElement->SetFixedWidth(nWidth);

	SetNeedRelayout();
}

int CIMControlProcesser::GetElementFixedWidth(LPCTSTR lpName)
{
	if (!m_pControlElement)
	{
		return 0;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return 0;
	}

	return pElement->GetFixedWidth();
}

void CIMControlProcesser::SetElementFixedHeight(LPCTSTR lpName, int nHeight)
{
	if (!m_pControlElement)
	{
		return;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return;
	}

	if (nHeight == pElement->GetFixedHeight())
	{
		return;
	}

	pElement->SetFixedHeight(nHeight);

	SetNeedRelayout();
}

int CIMControlProcesser::GetElementFixedHeight(LPCTSTR lpName)
{
	if (!m_pControlElement)
	{
		return 0;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return 0;
	}

	return pElement->GetFixedHeight();
}

RECT CIMControlProcesser::GetItemElementRect(LPCTSTR lpName)
{
	CRect rcElement(0,0,0,0);
	if (!m_pControlElement)
	{
		return rcElement;
	}

	CRichElementBase* pElement = m_pControlElement->GetElementByName(lpName);
	if (!pElement)
	{
		return rcElement;
	}

	return pElement->GetRect();
}

CRichElementBase* CIMControlProcesser::HitTest(POINT ptCursor)
{
	if (!m_pControlElement)
	{
		return NULL;
	}

	return m_pControlElement->HitTest(ptCursor);
}