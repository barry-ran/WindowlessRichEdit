/**
 * \brief RichEdit�û��Զ���Ϣ��RichEdit��Ϣ��������ӿ�
 * \author ts
 * \date 2011-7-17
 */

#pragma once

#ifndef SAFE_DELETE
#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#endif

#ifndef SAFE_DELETE_ARRAY
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#endif

#ifndef SAFE_RELEASE
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }
#endif

#define MAX_CHATINFOSIZE			8000
#define MAX_MD5_LEN					40

#define RICHEDIT_TEXT_MAX_COUNT		64000
#define RICHEDIT_TEXT_ALLOW_COUNT	62000

#define RT_FREE_BITMAP				MAKEINTRESOURCEA(2)
#define RT_FREE_ICON				MAKEINTRESOURCEA(3)

#define INVALID_CURSOR_POS_Y		10000
#define INVALID_CURSOR_POS_X		10000

//������ɫ
#define CHATMSG_CHATTEXT_CLR		RGB(0,0,0)			//�����ı���Ϣ��ɫ
#define	CHATMSG_MYNAME_CLR			RGB(0,128,0)		//�������ҵ�������ʾ����ɫ
#define CHATMSG_OTHERNAME_CLR		RGB(0,0,255)		//�����˵�������ʾ����ɫ
#define CHATMSG_SYSMSG_CLR			RGB(80,80,80)		//ϵͳ��ʾ��Ϣ����ɫ
#define CHATMSG_FLOCK_ADMIN_CLR		RGB(0,114,193)		//Ⱥ����Ⱥ����Ⱥ������������������ɫ
#define SECRETMSG_NAME_CLR			RGB(255, 0, 255)	//˽��ʱ������ʾ����ɫ
#define SYS_NOTICE_CLR				RGB(255, 0, 255)	//ϵͳ������ʾ����ɫ

#define MSG_YHEIGHT					185					//��ʾ��Ϣͳһ�ַ��߶�
#define MSG_TOPSPACE				60					//�������и߶�

// FreeRichEdit
#define WM_READONLY_INPUT			(WM_USER + 1300)
#define WM_READONLY_IME_INPUT		(WM_USER + 1301)
#define WM_SHOWSCROLLBAR			(WM_USER + 1302)
#define WM_SETSCROLLPOS				(WM_USER + 1303)
#define WM_SETSCROLLRANGE			(WM_USER + 1304)
#define WM_SETSCROLLINFO			(WM_USER + 1305)

#define WM_ELEMENT_PAINT			(WM_USER + 1306)
#define WM_OLE_PAINT				(WM_USER + 1307)
#define WM_DELETEOLE				(WM_USER + 1308)
#define WM_INSERTOLE				(WM_USER + 1309)
#define WM_GETCLIENTRECT			(WM_USER + 1310)
#define WM_GETCLIPBOARDDATA			(WM_USER + 1311)
#define WM_QERYACCPETDATA			(WM_USER + 1312)
#define WM_GETDUIRECT				(WM_USER + 1313)
#define WM_RICHEDIT_SETCAPTUER		(WM_USER + 1314)
#define WM_RICHEDIT_RELEASECAPTUER	(WM_USER + 1315)
#define WM_RICHEDIT_GETVISIBLE		(WM_USER + 1316)
#define WM_RICHEDIT_SHOW_CARET		(WM_USER + 1317)
#define WM_RICHEDIT_ENABLE_CARET_TIMER (WM_USER + 1318)
#define WM_RICHEDIT_SET_FOCUS		(WM_USER + 1319)
#define WM_RICHEDIT_REG_DRAGDROP	(WM_USER + 1320)
#define WM_RICHEDIT_UNREG_DRAGDROP	(WM_USER + 1321)

// ztGifProcessor
#define  WM_UPDATE_GIF				(WM_USER + 1330)

//�˵�
#define ID_MENU_EDIT_CUT			(WM_USER + 1400)
#define ID_MENU_EDIT_COPY			(WM_USER + 1401)
#define ID_MENU_EDIT_PASTE			(WM_USER + 1402)
#define ID_MENU_EDIT_SEL_ALL		(WM_USER + 1403)
#define ID_MENU_EDIT_UNDO			(WM_USER + 1404)
#define ID_MENU_EDIT_REDO			(WM_USER + 1405)
#define ID_MENU_EDIT_CLEAR			(WM_USER + 1406)
#define ID_MENU_EDIT_SAVE_AS		(WM_USER + 1407)
#define ID_MENU_EDIT_ADD_TO_FACE	(WM_USER + 1408)
#define ID_MENU_EDIT_LOCK_SCREEN	(WM_USER + 1409)
#define ID_MENU_EDIT_SHIELD_FACE	(WM_USER + 1410)
#define ID_MENU_EDIT_SHIELD_MSG		(WM_USER + 1411)

#define ID_MENU_EDIT_EXTRA_ERROR	(WM_USER + 8887)
#define ID_MENU_EDIT_EXTRA_BEGIN	(WM_USER + 8888)
#define ID_MENU_EDIT_EXTRA_END		(WM_USER + 8889)

//Ole��չԪ�����ģ����
#define OLE_ELEEX_MODAL_MAX			20

//Ole��չԪ�ر༭ID
#define ID_OLE_ELEMENTEX_EDIT_BEGIN	5001

//��������Ϣ
typedef struct stCaretInfo
{
	int nCaretPosX;
	int nCaretPosY;
	int nCaretWdith;
	int nCaretHeight;
	HBITMAP hCaret;

	int nCoveredBkPosX;
	int nCoveredBkPosY;
	int nCoveredBkWidth;
	int nCoveredBkHeight;
	BOOL bVisible;
	BOOL bShowByTime;
	HBITMAP hCoveredBk;

	HDC hDC;
}stCaretInfo;

class IRichEditMsgProc
{
public:
	IRichEditMsgProc() {}
	~IRichEditMsgProc() {}

public:
	virtual LRESULT OnRichEditMsgProc(UINT nMessageID, WPARAM wParam, LPARAM lParam) = 0;
	virtual LRESULT OnRichEditInsideRedraw(bool bIgnoreThreadSafe = true) = 0;
};