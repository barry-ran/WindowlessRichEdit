// ExRichEditOleCallback.cpp : implementation file
//

#include "stdafx.h"
#include "richedit.h"
#include "ExRichEditOleCallback.h"
#include "FreeWindowlessRE.h"

IExRichEditOleCallback::IExRichEditOleCallback()
{
	pStorage = NULL;
	m_iNumStorages = 0;
	m_dwRef = 0;
	m_hWnd = NULL;
	m_clsid = CLSID_NULL;
	m_pIRichEditMsgProc = NULL;
	m_dwDropDataFormat = 0;
}

IExRichEditOleCallback::~IExRichEditOleCallback()
{
}

HRESULT STDMETHODCALLTYPE 
IExRichEditOleCallback::GetNewStorage(LPSTORAGE* lplpstg)
{
	if (!pStorage)
	{
		// set up OLE storage

		HRESULT hResult = ::StgCreateDocfile(NULL,
			STGM_TRANSACTED  | STGM_TRANSACTED | STGM_READWRITE | STGM_SHARE_EXCLUSIVE | STGM_DELETEONRELEASE | STGM_CREATE,
			0, &pStorage);

		if ( pStorage == NULL ||
			hResult != S_OK )
		{
			//AfxThrowOleException( hResult );
		}
	}

	m_iNumStorages++;
	WCHAR tName[50];
	swprintf_s(tName, 50, L"REOLEStorage%d", m_iNumStorages);

	HRESULT hResult = pStorage->CreateStorage(tName, 
		STGM_TRANSACTED | STGM_READWRITE | STGM_SHARE_EXCLUSIVE | STGM_CREATE ,
		0, 0, lplpstg );

	if (hResult != S_OK )
	{
		//::AfxThrowOleException( hResult );
	}

	return hResult;
}

HRESULT STDMETHODCALLTYPE 
IExRichEditOleCallback::QueryInterface(REFIID iid, void ** ppvObject)
{

	HRESULT hr = S_OK;
	*ppvObject = NULL;

	if ( iid == IID_IUnknown ||
		iid == IID_IRichEditOleCallback )
	{
		*ppvObject = this;
		AddRef();
		hr = NOERROR;
	}
	else
	{
		hr = E_NOINTERFACE;
	}

	return hr;
}



ULONG STDMETHODCALLTYPE 
IExRichEditOleCallback::AddRef()
{
	return ++m_dwRef;
}



ULONG STDMETHODCALLTYPE 
IExRichEditOleCallback::Release()
{
	if ( --m_dwRef == 0 )
	{
		return 0;
	}

	return m_dwRef;
}


HRESULT STDMETHODCALLTYPE 
IExRichEditOleCallback::GetInPlaceContext(LPOLEINPLACEFRAME FAR *lplpFrame,
										  LPOLEINPLACEUIWINDOW FAR *lplpDoc, LPOLEINPLACEFRAMEINFO lpFrameInfo)
{
	return S_OK;
}


HRESULT STDMETHODCALLTYPE 
IExRichEditOleCallback::ShowContainerUI(BOOL fShow)
{
	return S_OK;
}



HRESULT STDMETHODCALLTYPE 
IExRichEditOleCallback::QueryInsertObject(LPCLSID lpclsid, LPSTORAGE lpstg, LONG cp)
{
	//Assert(m_hWnd);
	/*if (S_OK != ::SendMessage(m_hWnd, WM_INSERTOLE, NULL, NULL))
	{
		return E_NOTIMPL;
	}*/

	return S_OK;
}


HRESULT STDMETHODCALLTYPE 
IExRichEditOleCallback::DeleteObject(LPOLEOBJECT lpoleobj)
{
	//Assert(m_hWnd);
	//::SendMessage(m_hWnd, WM_DELETEOLE, (WPARAM)lpoleobj, NULL);
	return S_OK;
}



HRESULT STDMETHODCALLTYPE 
IExRichEditOleCallback::QueryAcceptData(LPDATAOBJECT lpdataobj, CLIPFORMAT FAR *lpcfFormat,
										DWORD reco, BOOL fReally, HGLOBAL hMetaPict)
{
	//ѯ���Ƿ��ܽ�����ק���������
	if (!fReally)
	{
		return S_OK;
	}

	//������ק���ݻ��������
	if (m_pIRichEditMsgProc)
	{
		stAccpetData data;
		data.m_lpdataobj = lpdataobj;
		data.m_lpcformat = lpcfFormat;
		data.m_reco = reco;
		m_pIRichEditMsgProc->OnRichEditMsgProc(WM_QERYACCPETDATA, (WPARAM)&data, 0);
	}

	//ע���û��Զ�����ק���ݸ�ʽ
	if (0 == m_dwDropDataFormat)
	{
		m_dwDropDataFormat = ::RegisterClipboardFormat(IM_DRAG_USER_FORMAT);
	}
	if (lpdataobj) 
	{
		FORMATETC fmtetc;
		fmtetc.cfFormat = (CLIPFORMAT)m_dwDropDataFormat;
		fmtetc.ptd = NULL;
		fmtetc.dwAspect = DVASPECT_CONTENT;
		fmtetc.lindex = -1;
		fmtetc.tymed = TYMED_HGLOBAL;
		if (S_OK == lpdataobj->QueryGetData(&fmtetc))
		{
			//richeditע���drop�¼���ص�Ӧ�ò��drop�¼�
			//������IM_DRAG_USER_FORMAT�ļ��а�����ʱ����Ϣ��Ӧ�ò�
			if (m_hWnd)
			{
				HRESULT hResult = S_OK;
				::SendMessage(m_hWnd,UISM_DRAG_DATA_OTHERDROP,(WPARAM)lpdataobj,(LPARAM)&hResult);
				if(hResult != S_OK)
				{
					return E_FAIL;
				}
			}
		}	
	}

	//�����ض����ݸ�ʽ�Զ��崦��(������riched20.dll����)
	if (lpcfFormat)
	{
		if (CF_METAFILEPICT == (*lpcfFormat) || 
			CF_BITMAP == (*lpcfFormat) || 
			CF_DIB == (*lpcfFormat) || 
			0 == (*lpcfFormat))
		{
			return E_FAIL;
		}
	}

	return S_OK;
}


HRESULT STDMETHODCALLTYPE 
IExRichEditOleCallback::ContextSensitiveHelp(BOOL fEnterMode)
{
	return S_OK;
}



HRESULT STDMETHODCALLTYPE 
IExRichEditOleCallback::GetClipboardData(CHARRANGE FAR *lpchrg, DWORD reco, LPDATAOBJECT FAR *lplpdataobj)
{
	if (m_pIRichEditMsgProc)
	{
		stClipBoardData data;
		data.m_lpchrg = lpchrg;
		data.m_reco = reco;
		data.m_lplpdataobj = lplpdataobj;

		m_pIRichEditMsgProc->OnRichEditMsgProc(WM_GETCLIPBOARDDATA, (WPARAM)&data, 0);
	}
	return NOERROR;
}


HRESULT STDMETHODCALLTYPE 
IExRichEditOleCallback::GetDragDropEffect(BOOL fDrag, DWORD grfKeyState, LPDWORD pdwEffect)
{
	return S_OK;
}

HRESULT STDMETHODCALLTYPE 
IExRichEditOleCallback::GetContextMenu(WORD seltyp, LPOLEOBJECT lpoleobj, CHARRANGE FAR *lpchrg, HMENU FAR *lphmenu)
{
	return S_OK;
}