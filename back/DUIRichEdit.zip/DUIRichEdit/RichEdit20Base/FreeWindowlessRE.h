/**
 * \brief richedit20��host��װ����
 * \author ts
 * \date 2011-7-19
 */
#pragma once
#include "tstxtsrv.h"
#include "host.h"
#include "IRichEditMsgProc.h"

struct stEditControlInfo
{
	stEditControlInfo()
	{
		fFocus = FALSE;
		ptwh = NULL;
	}

	BOOL			fFocus;	// ����� 
	CTxtWinHost*	ptwh;	// Host 
};

class CFreeWindowlessRE
{
public:
	CFreeWindowlessRE();
	virtual ~CFreeWindowlessRE();

public:
	/// ��Ϣ��������
	virtual LRESULT WindowlessREProc(UINT message, WPARAM wParam, LPARAM lParam);

	/// �����ؼ�
	virtual int CreateHost(DWORD dwFlags, RECT& rc);

	void SetRichEditMsgProc(IRichEditMsgProc* pMsgProc) { m_pRichEditMsgProc = pMsgProc; }
	void SetREParentHwnd(HWND hWnd) { m_hREParentWnd = hWnd; }

	CTxtWinHost* GetWinHost() const;

public:
	//-----------------------richedit ��������--------------------------
	HWND SetFocus();

	BOOL SetReadOnly(BOOL bReadOnly = TRUE);
	BOOL GetReadOnly();

	CPoint PosFromChar(UINT nChar) const;
	long CharFromPos(CPoint pt) const;

	void LineScroll(int nLines, int nChars = 0);
	void GetScrollPos(CPoint& pt) const;

	long LineFromChar(long nIndex) const;

	int GetFirstVisibleLine() const;

	int GetLineCount() const;

	int LineIndex(int nLine = -1) const;

	int LineLength(int nLine = -1) const;

	void GetTextEx(LPTSTR lpContent, int nMaxCount) const;
	long GetTextLengthEx() const;

	void SetText(LPCTSTR strText);

	void GetSel(CHARRANGE& cr) const;
	void GetSel(long& nStartChar, long& nEndChar) const;

	void SetSel(CHARRANGE& cr, bool bHideCaret);
	void SetSel(long nStartChar, long nEndChar, bool bHideCaret);

	void Clear();

	void ReplaceSel(LPCTSTR lpszNewText, BOOL bCanUndo = FALSE);

	void HideSelection(BOOL bHide, BOOL bPerm);

	WORD GetSelectionType() const;

	long GetSelText(LPSTR lpBuf) const;
	WTL::CString GetSelText() const;

	int GetTextRange(int nFirst, int nLast, WTL::CString& refString) const;

	void GetIRichEditOle(IRichEditOle** pResult) const;
	BOOL SetOLECallback(IRichEditOleCallback* pCallback);

	DWORD GetDefaultCharFormat(CHARFORMAT& cf) const;
	DWORD GetDefaultCharFormat(CHARFORMAT2& cf) const;
	DWORD GetDefaultCharFormat(CHARFORMAT* pcf) const;

	DWORD GetParaFormat(PARAFORMAT& pf) const;
	DWORD GetParaFormat(PARAFORMAT2& pf) const;
	DWORD GetParaFormat(PARAFORMAT* ppf) const;

	DWORD GetSelectionCharFormat(CHARFORMAT& cf) const;
	DWORD GetSelectionCharFormat(CHARFORMAT2& cf) const;
	DWORD GetSelectionCharFormat(CHARFORMAT* pcf) const;

	DWORD GetAllCharFormat(CHARFORMAT& cf) const;
	DWORD GetAllCharFormat(CHARFORMAT2& cf) const;
	DWORD GetAllCharFormat(CHARFORMAT* pcf) const;

	BOOL SetDefaultCharFormat(CHARFORMAT& cf);
	BOOL SetDefaultCharFormat(CHARFORMAT2& cf);
	BOOL SetDefaultCharFormat(CHARFORMAT* pcf);

	BOOL SetParaFormat(PARAFORMAT& pf);
	BOOL SetParaFormat(PARAFORMAT2& pf);
	BOOL SetParaFormat(PARAFORMAT* ppf);

	BOOL SetSelectionCharFormat(CHARFORMAT& cf);
	BOOL SetSelectionCharFormat(CHARFORMAT2& cf);
	BOOL SetSelectionCharFormat(CHARFORMAT* pcf);

	BOOL SetWordCharFormat(CHARFORMAT& cf);
	BOOL SetWordCharFormat(CHARFORMAT2& cf);
	BOOL SetWordCharFormat(CHARFORMAT* pcf);

	DWORD SetAllCharFormat(CHARFORMAT& cf);
	DWORD SetAllCharFormat(CHARFORMAT2& cf);
	DWORD SetAllCharFormat(CHARFORMAT* pcf);

	BOOL CanPaste(UINT nFormat = 0) const;
	BOOL CanRedo() const;
	BOOL CanUndo() const;

	void EmptyUndoBuffer();
	UINT SetUndoLimit(UINT nLimit);

	BOOL Redo();
	BOOL Undo();

	void SetOptions(WORD wOp, DWORD dwFlags);
	UINT GetOptions() const;


	long GetLimitText() const;
	void LimitText(long nChars = 0);

	BOOL SetAutoURLDetect(BOOL bEnable = TRUE);

	DWORD SetEventMask(DWORD dwEventMask);
	long GetEventMask() const;

	long StreamIn(int nFormat, EDITSTREAM& es);
	long StreamOut(int nFormat, EDITSTREAM& es);

	COLORREF SetBackgroundColor(BOOL bSysColor, COLORREF cr);

	long GetTextLength() const;
	long GetTextLengthEx(DWORD dwFlags, UINT uCodePage = -1) const;

	void EnableWordBreak(bool bEnable);

	void ShowCaret(bool bShow);
	void UpdateCaretInTimer();
	void GetCaretPos(LPPOINT lpCaret);

	void RegisterDragDrop();
	void RevokeDragDrop();

private:
	/// �ڲ������ؼ�
	virtual HRESULT CreateTextControl(
		HWND hwndControl,
		HWND hwndParent,
		DWORD dwStyle,
		TCHAR *pszText,
		LONG lLeft,
		LONG lTop,
		LONG lWidth,
		LONG lHeight,
		CTxtWinHost **ppHost);

private:
	bool    m_bHostUsable;
	bool    m_bMsgProcessing;
	HWND    m_hREParentWnd;
	LPCRITICAL_SECTION m_lpSection;
	stEditControlInfo m_editControlInfo;
	IRichEditMsgProc* m_pRichEditMsgProc;
};