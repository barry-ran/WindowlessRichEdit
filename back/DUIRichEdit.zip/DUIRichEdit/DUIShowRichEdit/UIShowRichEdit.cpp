#include "stdafx.h"
#include "UIShowRichEdit.h"
#include "UIScrollBarCom.h"
#include "UIPopupMenuCom.h"
#include "UIMenuItemCom.h"
#include "../public/RichItemElement/RichItemElement.h"
#include "../public/Base/NCString.h"

#ifndef _EXCLUDE_RESOURCE
#include "../public/RichItemElement/RichItemEditDlg.h"
#endif

#define IMAGE_CHECK_FOR_LOADING_ELAPSE	1*1000		//2���Ӽ��һ��

#define DEAULT_FONT_NAME				_T("΢���ź�")
#define IMG_PREVIEW_PREFIX				_T("preview_");

//�������ʽ���ָ�����
#define		PARSE_ANCHOR				_T("|")

//�������ʽ����Դ��ͼƬ
#define		PARSE_RESOURCE_PIC			_T("{\\[/[0-9]+?\\]}")
#define		PARSE_RESOURCE_PIC_FORMAT	_T("[/%d]")

//�������ʽ���ļ�·��ͼƬ
#define		PARSE_DEFAULT_PIC			_T("{\\[i.*?\\.([Jj][Pp][Gg])|([Jj][Pp][Ee][Gg])|([Pp][Nn][Gg])|([Ii][Mm][Gg])|([Gg][Ii][Ff])|([Bb][Mm][Pp])\\[width_[0-9]+?\\]\\[height_[0-9]+?\\]\\]}")
#define		PARSE_DEFAULT_PIC_FORMAT	_T("[i%s[width_%d][height_%d]]")
#define		PARSE_COPYDATA_PIC			_T("{\\[c.*?\\.([Jj][Pp][Gg])|([Jj][Pp][Ee][Gg])|([Pp][Nn][Gg])|([Ii][Mm][Gg])|([Gg][Ii][Ff])|([Bb][Mm][Pp])<url_.*?><width_[0-9]+?><height_[0-9]+?>\\]}")
#define		PARSE_COPYDATA_PIC_FORMAT	_T("[c%s<url_%s><width_%d><height_%d>]")

//�������ʽ��������
#define		PARSE_HYPER_LINK			_T("{([Hh][Tt][Tt][Pp]([Ss])?:(//+))|([Ff][Tt][Pp]:(//+))|([Ff][Tt][Pp]\\.)|([Ff][Ii][Ll][Ee]:(//+))|([Ww][Ww][Ww]\\.)[-!@#$%^`~&*+=?()<>|;.,:/\\\\0-9A-Za-z_]+}")

//�������ʽ���ɻ�Ʊ
#define		PARSE_TICKET_LINK			_T("{([Dd][Dd]://)[0-9]+}")

CUIShowRichEdit::CUIShowRichEdit()
: m_bInit(false)
, m_hCursor(NULL)
, m_dwCurPicCount(0)
, m_bReadOnly(FALSE)
, m_bPainting(false)
, m_bUpdateNow(true)
, m_bEnableSetScrollPos(true)
, m_pScrollBarImplVert(NULL)
, m_pScrollBarImplHorz(NULL)
, m_pScaleProp(NULL)
, m_pDrawScaleButton(NULL)
, m_pImgScaleMaxWidth(NULL)
, m_pImgScaleMaxHeight(NULL)
, m_pGroupProp(NULL)
, m_pImgLoading(NULL)
, m_pImgError(NULL)
, m_pImgTimeout(NULL)
, m_pLoadingElementName(NULL)
, m_pLoadingElementWidth(NULL)
, m_pLoadingElementHeight(NULL)
, m_pErrorElementName(NULL)
, m_pErrorElementWidth(NULL)
, m_pErrorElementHeight(NULL)

, m_pOleElementExModalProp(NULL)

, m_bHasFocus(false)
, m_bShowFaceTip(false)
, m_bHasCaptureState(false)
, m_bValidLButtonUp(false)
, m_pPopupMenu(NULL)
, m_hWndDirectUI(NULL)
, m_pLinkProp(NULL)
, m_pColorLink(NULL)
, m_pUnderlineLink(NULL)
, m_hCursorLink(NULL)
, m_uAniFrameTick(0)
, m_bOlePlayAni(false)
, m_bExtraPlayAni(false)
, m_bLButtonDownHitLink(FALSE)
, m_bLButtonDownHitElement(FALSE)
{
	for (int i = 0; i < DUIRICHEDIT_STATE_LAST; ++i)
	{
		m_pDrawProp[i] = NULL;
		m_pImgScaleButton[i] = NULL;
	}

	for (int i = 0; i < OLE_ELEEX_MODAL_MAX; ++i)
	{
		m_pOleElementExModalArray[i].strEleName = _T("");
		m_pOleElementExModalArray[i].pEditProp = NULL;
		m_pOleElementExModalArray[i].pEleHeight = NULL;
		m_pOleElementExModalArray[i].pEleTextStyle = NULL;
		m_pOleElementExModalArray[i].pElement = NULL;
	}

	m_bEnableAutoKeyProc = true;
	m_bSetArrowCursor = false;
	m_nCurEndVisibleIndex = -1;
	m_nLastScrollCommand = -1;

	m_bCanClrOrLockScr = true;
	m_bLockScr = false;
	m_bEnableTicket = true;
	m_bBlockImage = false;
	m_bDisplaySysFace = true;
	m_bDisplayChannelMsg = true;
	m_bSafeSiteCheck = true;
	m_bScrollBtmBeforeInsert = true;
	m_nMaxLinCout = 1000;
	m_nBufferLinCout = 300;

    m_nLoadingTimeout = 15;
	m_nIDDelayPicCheckForLoading = -1;
	m_nIDForbidSnapshot = -1;
	m_nIDTAniDrawTick = -1;

	m_nDrawIdleTick = 0;
	m_nIDTDraw = -1;
	m_bNeedReDraw = FALSE;

	m_bRegisterMessage = false;
	m_bMouseEnter = false;
	m_bForbidSnapshot = false;
	m_bEnablePicScale = false;
	m_dwHostScaleButton = -1;
	m_dwMouseHotOleID = -1;
	m_bLButtonDownHitOleControl = FALSE;
	m_bKeepMouseMoving = false;
	m_hClipRgn = NULL;
	m_bVertScrollBarExist = false;
	m_bHorzScrollBarExist = false;

	memset(&m_rcDUIClient, 0, sizeof(m_rcDUIClient));

	m_bEnableRPopupMenu = true;
	m_bVisableShieldFaceMsgMenu = false;

	m_nfmtSysFaceID = ::RegisterClipboardFormat(_T("Format_SysFaceID"));
	m_nfmtHtmlID = ::RegisterClipboardFormat(_T("HTML Format"));
	m_bShowUserDefImage = true;
	m_nlastOverImageChar = -1;

	m_nIDTPicTips = -1;
	m_nIDTCaret = -1;
	m_nIDForbidSnapshot = -1;
	m_nIDActionInMouseMove = -1;
	m_nIDTScrollHide = -1;

	m_fmtetc[0].cfFormat = CF_TEXT;
	m_fmtetc[0].ptd = NULL;
	m_fmtetc[0].dwAspect = DVASPECT_CONTENT;
	m_fmtetc[0].lindex = -1;
	m_fmtetc[0].tymed = TYMED_HGLOBAL;

	m_fmtetc[1].cfFormat = m_nfmtSysFaceID;
	m_fmtetc[1].ptd = NULL;
	m_fmtetc[1].dwAspect = DVASPECT_CONTENT;
	m_fmtetc[1].lindex = -1;
	m_fmtetc[1].tymed = TYMED_HGLOBAL;

	m_fmtetc[2].cfFormat = m_nfmtHtmlID;
	m_fmtetc[2].ptd = NULL;
	m_fmtetc[2].dwAspect = DVASPECT_CONTENT;
	m_fmtetc[2].lindex = -1;
	m_fmtetc[2].tymed = TYMED_HGLOBAL;

	m_fmtetc[3].cfFormat = CF_UNICODETEXT;
	m_fmtetc[3].ptd = NULL;
	m_fmtetc[3].dwAspect = DVASPECT_CONTENT;
	m_fmtetc[3].lindex = -1;
	m_fmtetc[3].tymed = TYMED_HGLOBAL;

	m_stgmed[0].tymed = TYMED_HGLOBAL;
	m_stgmed[0].hGlobal = NULL;
	m_stgmed[0].pUnkForRelease = NULL;

	m_stgmed[1].tymed = TYMED_HGLOBAL;
	m_stgmed[1].hGlobal = NULL;
	m_stgmed[1].pUnkForRelease = NULL;

	m_stgmed[2].tymed = TYMED_HGLOBAL;
	m_stgmed[2].hGlobal = NULL;
	m_stgmed[2].pUnkForRelease = NULL;

	m_stgmed[3].tymed = TYMED_HGLOBAL;
	m_stgmed[3].hGlobal = NULL;
	m_stgmed[3].pUnkForRelease = NULL;

	m_strParseExcludeTicket = _T("");
	m_strParseAllElement = _T("");
	m_strParseHyperlinkAndTicket = _T("");

    m_dwPartID = 0;

	UpdateRegExpression();
}

CUIShowRichEdit::~CUIShowRichEdit()
{
	ClearAllOleEleExModal();

	if (m_hClipRgn)
	{
		::DeleteObject(m_hClipRgn);
		m_hClipRgn = NULL;
	}

	DestroyAllTimer();

	//shared cursor ����Ҫ����DestroyCursor������
	if (m_hCursorLink)
	{
		m_hCursorLink = NULL;
	}

	if (m_pPopupMenu && m_pPopupMenu->GetOwnerCtrl() == this)
	{
		m_pPopupMenu->SetOwnerCtrl(NULL);
	}
}

LRESULT CUIShowRichEdit::OnRichEditMsgProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	if (!m_bInit) return -1;

	switch(message)
	{
	case WM_RICHEDIT_GETVISIBLE:
		{
			BOOL* pVisible = (BOOL*)wParam;
			HWND* pHWnd = (HWND*)lParam;
			if (pVisible)
			{
				*pVisible = IsVisible();
			}
			if (pHWnd)
			{
				*pHWnd = m_hWndDirectUI;
			}
		}
		break;
	case WM_QERYACCPETDATA:
		break;
	case WM_GETCLIPBOARDDATA:
		{
			OnGetClipBoardData(wParam, lParam);
		}
		break;
	case WM_UPDATE_GIF:
		break;
	case WM_SETFOCUS:
	case WM_KILLFOCUS:
		{
			goto serv;
		}
		break;
	case EN_CHANGE:
		{
			OnEnChange();
			return 0;
		}
		break;
	case EN_UPDATE:
		{
			OnEnUpdate();
			return 0;
		}
		break;
	case EN_LINK:
		{
			//OnURLClick(wParam, lParam);
			return 0;
		}
		break;
	case WM_SETCURSOR:
		{
			if (m_bSetArrowCursor)
			{
				return -1;
			}

			LRESULT lr;
			lr = m_FreeWindowlessRE.WindowlessREProc(message, wParam, lParam);
			if (lr != S_MSG_KEY_IGNORED)
			{
				return lr;
			}
		}
		break;
	case WM_MOUSEWHEEL:
		{
			LRESULT lr;
			short zDelta = HIWORD(wParam);
			if (zDelta > 0)
			{
				lr = m_FreeWindowlessRE.WindowlessREProc(WM_VSCROLL, MAKEWPARAM(SB_LINEUP, 0), lParam);
			}
			else
			{
				lr = m_FreeWindowlessRE.WindowlessREProc(WM_VSCROLL, MAKEWPARAM(SB_LINEDOWN, 0), lParam);
			}
			return lr;
		}
		break;
	case WM_PAINT:
		{
			if (!CanUpdateNow())
			{
				return 0;
			}

			return m_FreeWindowlessRE.WindowlessREProc(message, wParam, lParam);
		}
		break;
	case WM_ERASEBKGND:
		{
			if (!CanUpdateNow())
			{
				return 0;
			}

			return m_FreeWindowlessRE.WindowlessREProc(message, wParam, lParam);
		}
		break;
	case WM_ELEMENT_PAINT:
		{
			OnElementPaint(wParam, lParam);
		}
		break;
	case WM_OLE_PAINT:
		{
			OnOlePaint(wParam, lParam);
		}
		break;
	case WM_SHOWSCROLLBAR:
		{
			UINT nBar = (UINT)wParam;
			BOOL bShow = (BOOL)lParam;
			switch(nBar)
			{
			case SB_VERT:
				{
					m_bVertScrollBarExist = bShow ? true : false;
					if (!m_bVertScrollBarExist)
					{
						ShowScrollBar(FALSE, TRUE, FALSE);
					}

					long nScrollWidth = bShow?GetScrollSize():0;
					CRect rcDUI = GetRect();
					WPARAM newSize = MAKEWPARAM(rcDUI.Width() - nScrollWidth, rcDUI.Height());
					m_FreeWindowlessRE.WindowlessREProc(WM_SIZE, 0, newSize);
				}
				break;
			case SB_HORZ:
				{
				}
				break;
			case SB_BOTH:
				{
					m_bVertScrollBarExist = bShow ? true : false;
					if (!m_bVertScrollBarExist)
					{
						ShowScrollBar(FALSE, TRUE, FALSE);
					}

					long nScrollWidth = bShow?GetScrollSize():0;
					CRect rcDUI = GetRect();
					WPARAM newSize = MAKEWPARAM(rcDUI.Width() - nScrollWidth, rcDUI.Height());
					m_FreeWindowlessRE.WindowlessREProc(WM_SIZE, 0, newSize);
				}
				break;
			default:
				break;
			}

			DUICtrlNotifyInfo UINotifyInfo;
			memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
			UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_SHOW_SCROLLBAR;
			UINotifyInfo.lParam1 = (DWORD_PTR)(this);
			UINotifyInfo.lParam2 = (DWORD_PTR)(nBar);
			UINotifyInfo.lParam3 = (DWORD_PTR)(bShow);
			::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);

			return 0;
		}
		break;
	case WM_SETSCROLLPOS:
		{
			stSCROLLINFO* pSiex = (stSCROLLINFO*)lParam;
			if (pSiex)
			{
				SetScrollPos(pSiex->m_si.nPos, TRUE, FALSE);
				CheckImageLoadingTimer();
			}
			return 0;
		}
		break;
	case WM_SETSCROLLRANGE:
	case WM_SETSCROLLINFO:
		{
			stSCROLLINFO* pSiex = (stSCROLLINFO*)lParam;
			if (pSiex)
			{
				DUISCROLLINFO si;
				si.ulSize = sizeof(DUISCROLLINFO);
				si.ulMask = pSiex->m_si.fMask;
				si.nMin = pSiex->m_si.nMin;
				si.nMax = pSiex->m_si.nMax;
				si.nPos = pSiex->m_si.nPos;
				si.ulPage = pSiex->m_si.nPage;
				si.nTrackPos = pSiex->m_si.nTrackPos;
				SetScrollInfo(&si, pSiex->m_bRedraw, (SB_HORZ == wParam)?TRUE:FALSE);
				CheckImageLoadingTimer();
			}

			return 0;
		}
		break;
	case WM_GETCLIENTRECT:
		{
			CRect rcClient = GetRect();
			RECT* pRcClient = (RECT*)wParam;
			if (pRcClient)
			{
				long nScrollWidth = IsScrollBarExist(FALSE)?GetScrollSize():0;
				pRcClient->left = 0;
				pRcClient->right = rcClient.Width()-nScrollWidth;
				pRcClient->top = 0;
				pRcClient->bottom = rcClient.Height();
			}
			return 0;
		}
		break;
	case WM_GETDUIRECT:
		{
			CRect rcClient = GetRect();
			RECT* pRcClient = (RECT*)wParam;
			if (pRcClient)
			{
				long nScrollWidth = IsScrollBarExist(FALSE)?GetScrollSize():0;
				pRcClient->left = rcClient.left;
				pRcClient->right = rcClient.right-nScrollWidth;
				pRcClient->top = rcClient.top;
				pRcClient->bottom = rcClient.bottom;
			}
		}
		break;
	case WM_SIZE:
		{
			RECT rcDUIClientNew = GetRect();
			rcDUIClientNew.right = rcDUIClientNew.left + LOWORD(lParam);
			rcDUIClientNew.bottom = rcDUIClientNew.top + HIWORD(lParam);
			if (!EqualRect(&rcDUIClientNew, &m_rcDUIClient))
			{
				//���¿ͻ�����ߴ�
				BOOL bResize = TRUE;
				if (HIWORD(lParam) == m_rcDUIClient.bottom - m_rcDUIClient.top && 
					LOWORD(lParam) == m_rcDUIClient.right - m_rcDUIClient.left)
				{
					bResize = FALSE;
				}
				m_rcDUIClient = rcDUIClientNew;

				//��¼��������ǰ�Ƿ��õ�
				DUISCROLLINFO si;
				si.ulSize = sizeof(DUISCROLLINFO);
				bool bScrollToBottom = false;
				if (GetScrollInfo(&si, DUISB_SIF_ALL, FALSE))
				{
					if (si.nMax <= si.nPos + (LONG)si.ulPage)
					{
						bScrollToBottom = true;
					}
				}

				//���ÿ���ģʽ����100����
				ForbidSnapshot(100);

				//֪ͨWM_SIZE��RichEdit
				LRESULT lr = m_FreeWindowlessRE.WindowlessREProc(message, wParam, lParam);

				//����ole�������չԪ������Ӧ�ߴ�
				if (bResize)
				{
					ResizeOleData();
					UpdateExtraElememtAlign(rcDUIClientNew);
				}

				//�������õײ�
				if (bScrollToBottom)
				{
					m_FreeWindowlessRE.WindowlessREProc(WM_VSCROLL, SB_BOTTOM, 0);
				}

				if (lr != S_MSG_KEY_IGNORED)
				{
					return lr;
				}
			}

			return 0;
		}
		break;
	case WM_VSCROLL:
	case WM_HSCROLL:
		{
			LRESULT lr;
			lr = m_FreeWindowlessRE.WindowlessREProc(message, wParam, lParam);
			return lr;
		}
		break;
	case WM_MOUSELEAVE:
		{
			return m_FreeWindowlessRE.WindowlessREProc(message, wParam, lParam);
		}
		break;
	case WM_MOUSEMOVE:
		{
			CPoint ptCursor(LOWORD(lParam), HIWORD(lParam));
			CRect rcSkinClient = GetRect();

			BOOL bInClient = rcSkinClient.PtInRect(ptCursor);
			if (bInClient || m_bHasCaptureState)
			{
				if (!bInClient)
				{
					if (ptCursor.y < INVALID_CURSOR_POS_Y)
					{
						if (ptCursor.y > rcSkinClient.bottom)
						{
							m_nLastScrollCommand = SB_LINEDOWN;
							m_FreeWindowlessRE.WindowlessREProc(WM_VSCROLL, (WPARAM)SB_LINEDOWN, (LPARAM)NULL);
						}
						else if (ptCursor.y < rcSkinClient.top)
						{
							m_nLastScrollCommand = SB_LINEUP;
							m_FreeWindowlessRE.WindowlessREProc(WM_VSCROLL, (WPARAM)SB_LINEUP, (LPARAM)NULL);
						}
					}
					else
					{
						if (SB_LINEUP == m_nLastScrollCommand)
						{
							m_FreeWindowlessRE.WindowlessREProc(WM_VSCROLL, (WPARAM)SB_LINEUP, (LPARAM)NULL);
						}
						else if (SB_LINEDOWN == m_nLastScrollCommand)
						{
							m_FreeWindowlessRE.WindowlessREProc(WM_VSCROLL, (WPARAM)SB_LINEDOWN, (LPARAM)NULL);
						}
					}
				}

				LPARAM lPraramNew = MAKELPARAM(ptCursor.x, ptCursor.y);
				return m_FreeWindowlessRE.WindowlessREProc(message, wParam, lPraramNew);
			}
		}
		break;
	case WM_LBUTTONUP:
		{
			CPoint ptCursor(LOWORD(lParam), HIWORD(lParam));
			CRect rcSkinClient = GetRect();
			if (rcSkinClient.PtInRect(ptCursor) || m_bHasCaptureState)
			{
				LPARAM lPraramNew = MAKELPARAM(ptCursor.x, ptCursor.y);
				return m_FreeWindowlessRE.WindowlessREProc(message, wParam, lPraramNew);
			}
		}
		break;
	case WM_LBUTTONDOWN:
	case WM_LBUTTONDBLCLK:
	case WM_RBUTTONDOWN:
	case WM_RBUTTONDBLCLK:
	case WM_MBUTTONDOWN:
	case WM_MBUTTONUP:
	case WM_MBUTTONDBLCLK:
		{
			CPoint ptCursor(LOWORD(lParam), HIWORD(lParam));
			CRect rcSkinClient = GetRect();
			if (rcSkinClient.PtInRect(ptCursor))
			{
				SetRichEditFocus();
				LPARAM lPraramNew = MAKELPARAM(ptCursor.x, ptCursor.y);
				return m_FreeWindowlessRE.WindowlessREProc(message, wParam, lPraramNew);
			}
		}
		break;
	case WM_RBUTTONUP:
		{
			CPoint ptCursor(LOWORD(lParam), HIWORD(lParam));
			CRect rcSkinClient = GetRect();
			if (rcSkinClient.PtInRect(ptCursor))
			{
				LPARAM lPraramNew = MAKELPARAM(ptCursor.x, ptCursor.y);
				return m_FreeWindowlessRE.WindowlessREProc(message, wParam, lPraramNew);
			}
		}
		break;
	case WM_ENTERMENULOOP:
	case WM_MENURBUTTONUP:
	case WM_MENUDRAG:
	case WM_MENUGETOBJECT:
	case WM_UNINITMENUPOPUP:
	case WM_MENUCOMMAND:
	case WM_INITMENU:
	case WM_INITMENUPOPUP:
	case WM_MENUSELECT:
	case WM_MENUCHAR:
	case WM_DRAWITEM:
	case WM_MEASUREITEM:
	case WM_CONTEXTMENU:
	case WM_COMMAND:
		{
		}
		break;
	case WM_IME_STARTCOMPOSITION:
		{
			if (m_bReadOnly)
			{
				if (m_hWndDirectUI)
				{
					DUICtrlNotifyInfo UINotifyInfo;
					memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
					UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_READONLY_IME_INPUT;
					UINotifyInfo.lParam1 = (DWORD_PTR)(this);
					UINotifyInfo.lParam2 = wParam;
					UINotifyInfo.lParam3 = lParam;
					::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
				}
			}
			goto serv;
		}
		break;

	case WM_CHAR:
		{
			if (m_bReadOnly)
			{
				// 1ȫѡ, 3����, 24����
				if (1 == wParam || 3 == wParam || 24 == wParam)
				{
					// �ڲ�ִ��һ�θ��ƶ���
					// ��ע: �ڲ�����ִ�и��ƶ���, richedit��̬���ڲ������ĸ��ƶ�����ĳ������²��ᴥ��,ԭ����...
					// ��ע: ʧ��״̬��,˫��ָ�����������,˫��ʱ��걣�ֲ���,Ȼ��ctrl+c����,����ʱ���Ҳ���ֲ���,�򲻻ᴥ��richedit�ڲ��ĸ��ƶ���...
					if (3 == wParam)
					{
						OnMenuCopy();
					}

					goto serv;
				}

				if (m_hWndDirectUI)
				{
					DUICtrlNotifyInfo UINotifyInfo;
					memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
					UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_READONLY_INPUT;
					UINotifyInfo.lParam1 = (DWORD_PTR)(this);
					UINotifyInfo.lParam2 = wParam;
					UINotifyInfo.lParam3 = lParam;
					::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);

				}
				return 0;
			}
			goto serv;
		}
		break;
	case WM_KEYDOWN:
		{
			if (!m_bEnableAutoKeyProc)
			{
				if (wParam == VK_RETURN || wParam == VK_ESCAPE)
				{
					return S_OK;
					//return CWnd::WindowProc(message, wParam, lParam);
				}
			}
			goto serv;
		}
		break;
	case WM_RICHEDIT_SETCAPTUER:
		{
			m_bHasCaptureState = true;
		}
		break;
	case WM_RICHEDIT_RELEASECAPTUER:
		{
			m_bHasCaptureState = false;
		}
		break;
	case WM_RICHEDIT_ENABLE_CARET_TIMER:
		{
			BOOL bSet = (BOOL)wParam;
			if (bSet)
			{
				if (GetDirectUI())
				{
					if (!IsVisible() || GetDirectUI()->GetFocusObject() != this)
					{
						return S_FALSE;
					}

					if (-1 == m_nIDTCaret)
					{
						m_nIDTCaret = GetDirectUI()->SetTimer(this, 500, NULL);
					}
				}
			}
			else
			{
				if (GetDirectUI())
				{
					if (m_nIDTCaret != -1)
					{
						GetDirectUI()->KillTimer(m_nIDTCaret);
						m_nIDTCaret = -1;
					}
				}
			}
		}
		break;
	case WM_RICHEDIT_SET_FOCUS:
		{
			SetRichEditFocus();
		}
		break;
	case WM_RICHEDIT_REG_DRAGDROP:
		{
			//do nothing
		}
		break;
	case WM_RICHEDIT_UNREG_DRAGDROP:
		{
			m_FreeWindowlessRE.RevokeDragDrop();
		}
		break;
	default:
		{
serv:
			LRESULT lr;
			lr = m_FreeWindowlessRE.WindowlessREProc(message, wParam, lParam);
			if (lr != S_MSG_KEY_IGNORED)
			{
				return lr;
			}
		}
	}

	return S_OK;
}

LRESULT CUIShowRichEdit::OnRichEditInsideRedraw(bool bIgnoreThreadSafe)
{
	if (!CanUpdateNow() || !IsVisible())
	{
		return S_FALSE;
	}

	RECT rcUpdate;
	rcUpdate.left = m_rcDUIClient.left;
	rcUpdate.right = m_rcDUIClient.right;
	rcUpdate.top = m_rcDUIClient.top;
	rcUpdate.bottom = m_rcDUIClient.bottom;

	::InvalidateRect(m_hWndDirectUI, &rcUpdate, TRUE);

	return S_OK;
}

void CUIShowRichEdit::AddCustomReg(int regIdx, LPCTSTR regExp)
{
	m_customRegMap[regIdx] = regExp;
	UpdateRegExpression();
}
void CUIShowRichEdit::RemoveCustomReg(int regIdx)
{
	std::map<int, WTL::CString>::iterator it = m_customRegMap.find(regIdx);
	if (it != m_customRegMap.end())
		m_customRegMap.erase(it);

	UpdateRegExpression();
}

CPoint CUIShowRichEdit::PosFromChar(UINT nChar) const
{
	if (!m_bInit) return CPoint(0, 0);

	return m_FreeWindowlessRE.PosFromChar(nChar);
}

int CUIShowRichEdit::CharFromPos(CPoint pt) const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.CharFromPos(pt);
}

void CUIShowRichEdit::LineScroll(int nLines, int nChars)
{
	if (!m_bInit) return;

	return m_FreeWindowlessRE.LineScroll(nLines, nChars);
}

long CUIShowRichEdit::LineFromChar(long nIndex) const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.LineFromChar(nIndex);
}

int CUIShowRichEdit::GetFirstVisibleLine() const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetFirstVisibleLine();
}

int CUIShowRichEdit::GetLineCount( )
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetLineCount();
}

int CUIShowRichEdit::LineIndex(int nLine) const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.LineIndex(nLine);
}

int CUIShowRichEdit::LineLength(int nLine) const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.LineLength(nLine);
}

void CUIShowRichEdit::GetSel(long& nStartChar, long& nEndChar)
{
	if (!m_bInit) return;

	return m_FreeWindowlessRE.GetSel(nStartChar, nEndChar);
}

void CUIShowRichEdit::SetSel(long nStartChar, long nEndChar)
{
	if (!m_bInit) return;

	return m_FreeWindowlessRE.SetSel(nStartChar, nEndChar, false);
}

void CUIShowRichEdit::GetSel(CHARRANGE& cr) const
{
	if (!m_bInit) return;

	return m_FreeWindowlessRE.GetSel(cr);
}

void CUIShowRichEdit::SetSel(CHARRANGE& cr, bool bHideCaret)
{
	if (!m_bInit) return;

	return m_FreeWindowlessRE.SetSel(cr, bHideCaret);
}

void CUIShowRichEdit::HideSelection(BOOL bHide, BOOL bPerm)
{
	if (!m_bInit) return;

	return m_FreeWindowlessRE.HideSelection(bHide, bPerm);
}

WORD CUIShowRichEdit::GetSelectionType() const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetSelectionType();
}

long CUIShowRichEdit::GetSelText(LPSTR lpBuf) const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetSelText(lpBuf);
}

WTL::CString CUIShowRichEdit::GetSelText() const
{
	if (!m_bInit) return _T("");

	return m_FreeWindowlessRE.GetSelText();
}

int CUIShowRichEdit::GetTextRange(int nFirst, int nLast, WTL::CString& refString) const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetTextRange(nFirst, nLast, refString);
}

void CUIShowRichEdit::GetIRichEditOle(IRichEditOle** pResult) const
{
	if (!pResult)
	{
		return;
	}

	if (!m_bInit)
	{
		return;
	}

	m_FreeWindowlessRE.GetIRichEditOle(pResult);
}

BOOL CUIShowRichEdit::SetOLECallback(IRichEditOleCallback* pCallback)
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.SetOLECallback(pCallback);
}

DWORD CUIShowRichEdit::GetDefaultCharFormat(CHARFORMAT& cf)
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetDefaultCharFormat(cf);
}

DWORD CUIShowRichEdit::GetDefaultCharFormat(CHARFORMAT2& cf) const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetDefaultCharFormat(cf);
}

DWORD CUIShowRichEdit::GetParaFormat(PARAFORMAT& pf)
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetParaFormat(pf);
}

DWORD CUIShowRichEdit::GetParaFormat(PARAFORMAT2& pf)
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetParaFormat(pf);
}

DWORD CUIShowRichEdit::GetSelectionCharFormat(CHARFORMAT& cf)
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetSelectionCharFormat(cf);
}

DWORD CUIShowRichEdit::GetSelectionCharFormat(CHARFORMAT2& cf)
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetSelectionCharFormat(cf);
}

BOOL CUIShowRichEdit::SetDefaultCharFormat(CHARFORMAT& cf)
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.SetDefaultCharFormat(cf);
}

BOOL CUIShowRichEdit::SetDefaultCharFormat(CHARFORMAT2& cf)
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.SetDefaultCharFormat(cf);
}

BOOL CUIShowRichEdit::SetParaFormat(PARAFORMAT& pf)
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.SetParaFormat(pf);
}

BOOL CUIShowRichEdit::SetParaFormat(PARAFORMAT2& pf)
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.SetParaFormat(pf);
}

BOOL CUIShowRichEdit::SetSelectionCharFormat(CHARFORMAT& cf)
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.SetSelectionCharFormat(cf);
}

BOOL CUIShowRichEdit::SetSelectionCharFormat(CHARFORMAT2& cf)
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.SetSelectionCharFormat(cf);
}

BOOL CUIShowRichEdit::SetWordCharFormat(CHARFORMAT& cf)
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.SetWordCharFormat(cf);
}

BOOL CUIShowRichEdit::SetWordCharFormat(CHARFORMAT2& cf)
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.SetWordCharFormat(cf);
}

BOOL CUIShowRichEdit::CanPaste(UINT nFormat) const
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.CanPaste(nFormat);
}

BOOL CUIShowRichEdit::CanRedo() const
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.CanRedo();
}

BOOL CUIShowRichEdit::CanUndo() const
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.CanUndo();
}

void CUIShowRichEdit::EmptyUndoBuffer()
{
	if (!m_bInit) return;

	return m_FreeWindowlessRE.EmptyUndoBuffer();
}

UINT CUIShowRichEdit::SetUndoLimit(UINT nLimit)
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.SetUndoLimit(nLimit);
}

BOOL CUIShowRichEdit::Redo()
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.Redo();
}

BOOL CUIShowRichEdit::Undo()
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.Undo();
}

void CUIShowRichEdit::SetOptions(WORD wOp, DWORD dwFlags)
{
	if (!m_bInit) return;

	return m_FreeWindowlessRE.SetOptions(wOp, dwFlags);
}

UINT CUIShowRichEdit::GetOptions() const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetOptions();
}

long CUIShowRichEdit::GetLimitText() const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetLimitText();
}

void CUIShowRichEdit::LimitText(long nChars)
{
	if (!m_bInit) return;

	return m_FreeWindowlessRE.LimitText(nChars);
}

BOOL CUIShowRichEdit::SetAutoURLDetect(BOOL bEnable)
{
	if (!m_bInit) return FALSE;

	return m_FreeWindowlessRE.SetAutoURLDetect(bEnable);
}

DWORD CUIShowRichEdit::SetEventMask(DWORD dwEventMask)
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.SetEventMask(dwEventMask);
}

long CUIShowRichEdit::GetEventMask() const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetEventMask();
}

long CUIShowRichEdit::StreamIn(int nFormat, EDITSTREAM& es)
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.StreamIn(nFormat, es);
}

long CUIShowRichEdit::StreamOut(int nFormat, EDITSTREAM& es)
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.StreamOut(nFormat, es);
}

COLORREF CUIShowRichEdit::SetBackgroundColor(BOOL bSysColor, COLORREF cr)
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.SetBackgroundColor(bSysColor, cr);
}

long CUIShowRichEdit::GetTextLengthEx(DWORD dwFlags, UINT uCodePage) const
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetTextLengthEx(dwFlags, uCodePage);
}

bool CUIShowRichEdit::OnHitTestOleControl(UINT nHitMessage, CPoint& pt)
{
	CRect rcResultOle(0,0,0,0);
	DWORD dwResultOleID = -1;
	HitTestOleByPoint(pt, dwResultOleID, rcResultOle);

	BOOL bRetInvalidate = FALSE;
	BOOL bSetHandCuror = FALSE;
	BOOL bHitRet = FALSE;
	switch (nHitMessage)
	{
	case WM_LBUTTONUP:
		{
			CRichElementBase* pOleLButtonUp = NULL;
			if (dwResultOleID != -1)
			{
				IOleProcesser* pOleProsser = GetOleProcesser(dwResultOleID);
				if (pOleProsser && pOleProsser->GetType() == OleProcesser_Control)
				{
					bHitRet = TRUE;

					CIMControlProcesser* pOleControl = (CIMControlProcesser*)pOleProsser;

					CPoint ptHitOle = pt;
					ptHitOle.Offset(-rcResultOle.left, -rcResultOle.top);

					CRichElementBase* pOleMouseLeave = NULL;
					pOleControl->OnLButtonUp(ptHitOle, bRetInvalidate, &pOleLButtonUp, &pOleMouseLeave);

					if (pOleMouseLeave)
					{
						OnMouseLeaveOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
							pOleMouseLeave, pOleControl->GetUserData());
					}
					if (pOleLButtonUp)
					{
						OnLButtonUpOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
							pOleLButtonUp, pOleControl->GetUserData());
					}
				}
			}

			//�������
			while (pOleLButtonUp)
			{
				if (pOleLButtonUp->IsDisposeMouse() && 
					pOleLButtonUp->IsEnabled())
				{
					break;
				}

				pOleLButtonUp = pOleLButtonUp->GetParentElement();
			}
			if (!m_bHasCaptureState && pOleLButtonUp)
			{
				bSetHandCuror = TRUE;
			}
		}
		break;
	case WM_RBUTTONUP:
		{
			if (dwResultOleID != -1)
			{
				IOleProcesser* pOleProsser = GetOleProcesser(dwResultOleID);
				if (pOleProsser && pOleProsser->GetType() == OleProcesser_Control)
				{
					bHitRet = TRUE;

					CIMControlProcesser* pOleControl = (CIMControlProcesser*)pOleProsser;

					CPoint ptHitOle = pt;
					ptHitOle.Offset(-rcResultOle.left, -rcResultOle.top);

					CRichElementBase* pHitElement = pOleControl->HitTest(ptHitOle);
					OnRButtonUpOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
						pHitElement, pOleControl->GetUserData());
				}
			}
		}
		break;
	case WM_MOUSEMOVE:
		{
			//MouseLeave
			if (dwResultOleID != m_dwMouseHotOleID && m_dwMouseHotOleID != -1)
			{
				IOleProcesser* pOleMouseLeave = GetOleProcesser(m_dwMouseHotOleID);
				if (pOleMouseLeave && pOleMouseLeave->GetType() == OleProcesser_Control)
				{
					CIMControlProcesser* pOleControl = (CIMControlProcesser*)pOleMouseLeave;

					CRichElementBase* pRetElement = NULL;
					pOleControl->OnMouseLeave(bRetInvalidate, &pRetElement);

					if (pRetElement)
					{
						OnMouseLeaveOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
							pRetElement, pOleControl->GetUserData());
					}
				}
			}

			//����MouseHot��
			m_dwMouseHotOleID = dwResultOleID;

			//MouseEnter
			CRichElementBase* pRetHitElement = NULL;
			if (m_dwMouseHotOleID != -1)
			{
				IOleProcesser* pOleMouseHot = GetOleProcesser(m_dwMouseHotOleID);
				if (pOleMouseHot && pOleMouseHot->GetType() == OleProcesser_Control)
				{
					bHitRet = TRUE;

					CIMControlProcesser* pOleControl = (CIMControlProcesser*)pOleMouseHot;

					CPoint ptHitOle = pt;
					ptHitOle.Offset(-rcResultOle.left, -rcResultOle.top);

					CRichElementBase* pRetHotElement = NULL;
					CRichElementBase* pRetLeaveElement = NULL;
					pOleControl->OnMouseMove(ptHitOle, bRetInvalidate, &pRetHotElement, &pRetLeaveElement, &pRetHitElement);

					if (pRetLeaveElement)
					{
						OnMouseLeaveOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
							pRetLeaveElement, pOleControl->GetUserData());
					}
					if (pRetHotElement)
					{
						OnMouseEnterOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
							pRetHotElement, pOleControl->GetUserData());
					}
				}
			}

			//�������
			while (pRetHitElement)
			{
				if (pRetHitElement->IsDisposeMouse() && 
					pRetHitElement->IsEnabled())
				{
					break;
				}

				pRetHitElement = pRetHitElement->GetParentElement();
			}
			if (!m_bHasCaptureState && pRetHitElement)
			{
				bSetHandCuror = TRUE;
			}
		}
		break;
	case WM_LBUTTONDOWN:
		{
			CRichElementBase* pOleLButtonDown = NULL;
			if (dwResultOleID != -1)
			{
				IOleProcesser* pOleProsser = GetOleProcesser(dwResultOleID);
				if (pOleProsser && pOleProsser->GetType() == OleProcesser_Control)
				{
					bHitRet = TRUE;

					CIMControlProcesser* pOleControl = (CIMControlProcesser*)pOleProsser;

					CPoint ptHitOle = pt;
					ptHitOle.Offset(-rcResultOle.left, -rcResultOle.top);

					CRichElementBase* pOleMouseLeave = NULL;
					pOleControl->OnLButtonDown(ptHitOle, bRetInvalidate, &pOleLButtonDown, &pOleMouseLeave);

					if (pOleMouseLeave)
					{
						OnMouseLeaveOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
							pOleMouseLeave, pOleControl->GetUserData());
					}
					if (pOleLButtonDown)
					{
						OnLButtonDownOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
							pOleLButtonDown, pOleControl->GetUserData());
					}
				}
			}

			//�������
			while (pOleLButtonDown)
			{
				if (pOleLButtonDown->IsDisposeMouse() && 
					pOleLButtonDown->IsEnabled())
				{
					break;
				}

				pOleLButtonDown = pOleLButtonDown->GetParentElement();
			}
			if (pOleLButtonDown)
			{
				bSetHandCuror = TRUE;
			}
		}
		break;
	case WM_RBUTTONDOWN:
		{
			//do nothing
		}
		break;
	case WM_SETCURSOR:
		{
			//do nothing
		}
		break;
	default:
		break;
	}

	if (bSetHandCuror)
	{
		if (NULL == m_hCursorLink)
		{
			m_hCursorLink = ::LoadCursor(NULL, IDC_HAND);
		}
		if (m_hCursorLink)
		{
			::SetCursor(m_hCursorLink);
		}
	}

	if (bRetInvalidate)
	{
		DirectRedraw2(NULL);
	}

	return bHitRet ? true : false;
}

bool CUIShowRichEdit::HitTestOleByPoint(POINT pt, DWORD& dwResultOleID, CRect& rcResultOle)
{
	dwResultOleID = -1;
	rcResultOle.SetRectEmpty();

	if (!m_bInit)
	{
		return false;
	}

	CComPtr<IRichEditOle> pReo;
	GetIRichEditOle(&pReo);
	if (!pReo)
	{
		return false;
	}

	//���ж�����Ƿ��ڵ�ǰ�ؼ�����
	long nScrollWidth = IsScrollBarExist(FALSE)?GetScrollSize():0;
	CRect rcClient = GetRect();
	if (rcClient.Width() > nScrollWidth)
	{
		rcClient.right -= nScrollWidth;
	}
	if (!rcClient.PtInRect(pt))
	{
		return false;
	}

	//���ȿ��ٶ�λһ���ɼ�ole����
	REOBJECT reObject;
	int nCount = pReo->GetObjectCount();
	int nEndIndex = 0;

	HDC hDC = ::GetDC(m_hWndDirectUI);
	LONG xPerInch = ::GetDeviceCaps(hDC, LOGPIXELSX);
	LONG yPerInch = ::GetDeviceCaps(hDC, LOGPIXELSY);
	GetOneOleUpdateIndex(pReo, reObject, xPerInch, yPerInch, rcClient, nCount, nEndIndex);
	::ReleaseDC(m_hWndDirectUI, hDC);

	//�ӵ�ǰ�ɼ�ole��������λ�ã������˷�ɢ��ʼƥ��
	CPoint ptObjPos;
	LONG li_Width = 0, li_Height = 0;

	//���ϼ���ƥ�����
	for (int i = nEndIndex; i >= 0; i--)
	{
		if (!GetOleObjPos(pReo, reObject, i, ptObjPos, xPerInch, yPerInch, li_Width, li_Height))
		{
			return false;
		}

		//ole�����ڵ�ǰ�ͻ�����
		bool bInClientRc = false;
		if (ptObjPos.x < rcClient.right && ptObjPos.x + li_Width > rcClient.left && 
			ptObjPos.y < rcClient.bottom && ptObjPos.y + li_Height > rcClient.top)
		{
			bInClientRc = true;
		}
		else
		{
			bInClientRc = false;
		}

		if (!bInClientRc)
		{
			break;
		}

		if (pt.x >= ptObjPos.x && pt.x <= ptObjPos.x + li_Width && 
			pt.y >= ptObjPos.y && pt.y <= ptObjPos.y + li_Height)
		{
			dwResultOleID =  reObject.dwUser;
			rcResultOle.left = ptObjPos.x;
			rcResultOle.right = ptObjPos.x + li_Width;
			rcResultOle.top = ptObjPos.y;
			rcResultOle.bottom = ptObjPos.y + li_Height;
			return true;
		}
	}

	//���¼�����ƶ���
	for (int i = nEndIndex + 1; i < nCount; i++)
	{
		if (!GetOleObjPos(pReo, reObject, i, ptObjPos, xPerInch, yPerInch, li_Width, li_Height))
		{
			return false;
		}

		//ole�����ڵ�ǰ�ͻ�����
		bool bInClientRc = false;
		if (ptObjPos.x < rcClient.right && ptObjPos.x + li_Width > rcClient.left && 
			ptObjPos.y < rcClient.bottom && ptObjPos.y + li_Height > rcClient.top)
		{
			bInClientRc = true;
		}
		else
		{
			bInClientRc = false;
		}

		if (!bInClientRc)
		{
			break;
		}

		if (pt.x >= ptObjPos.x && pt.x <= ptObjPos.x + li_Width && 
			pt.y >= ptObjPos.y && pt.y <= ptObjPos.y + li_Height)
		{
			dwResultOleID =  reObject.dwUser;
			rcResultOle.left = ptObjPos.x;
			rcResultOle.right = ptObjPos.x + li_Width;
			rcResultOle.top = ptObjPos.y;
			rcResultOle.bottom = ptObjPos.y + li_Height;
			return true;
		}
	}

	return false;
}

DWORD CUIShowRichEdit::AddOleData(IOleProcesser* pOleProcesser, DWORD dwID, LONG nLeftClientIndent, LONG nRightClientIndent)
{
	if (!pOleProcesser)
	{
		return -1;
	}

	RichOleMap::iterator it_ole = m_richOleMap.find(dwID);
	if (it_ole != m_richOleMap.end())
	{
		RemoveOleData(dwID);
	}

	stOleData data;
	data.dwID = dwID;
	data.pProcesser = pOleProcesser;
	data.nLeftClientIndent = nLeftClientIndent;
	data.nRightClientIndent = nRightClientIndent;
	m_richOleMap.insert(std::make_pair(dwID, data));

	return dwID;
}

BOOL CUIShowRichEdit::CheckOlesByAdd(LONG lInsertChar, LONG lCharCount)
{
	// do nothing
	return TRUE;
}

BOOL CUIShowRichEdit::CheckOlesByDel(LONG lStartChar, LONG lEndChar)
{
	if (!m_bInit)
	{
		return FALSE;
	}

	if (lEndChar < lStartChar)
	{
		return FALSE;
	}

	CComPtr<IRichEditOle> pReo;
	GetIRichEditOle(&pReo);
	if(NULL == pReo)
	{
		return FALSE;
	}

	int nCount = pReo->GetObjectCount();
	for (int i = nCount - 1; i >= 0; --i)
	{
		REOBJECT reObject;
		memset(&reObject, 0, sizeof(REOBJECT));
		reObject.cbStruct = sizeof(REOBJECT);
		pReo->GetObject(i, &reObject, REO_GETOBJ_NO_INTERFACES);

		if (reObject.cp >= lStartChar && reObject.cp <= lEndChar)
		{
			RemoveOleData(reObject.dwUser);
		}
	}

	return TRUE;
}

void CUIShowRichEdit::RemoveOleData(DWORD dwID)
{
	RichOleMap::iterator it_ole = m_richOleMap.find(dwID);
	if (it_ole != m_richOleMap.end())
	{
		if (it_ole->second.pProcesser)
		{
			SAFE_DELETE(it_ole->second.pProcesser);
		}

		m_richOleMap.erase(it_ole);
	}

	if (dwID == m_dwHostScaleButton)
	{
		m_dwHostScaleButton = -1;
	}

	if (dwID == m_dwMouseHotOleID)
	{
		m_dwMouseHotOleID = -1;
	}

    DUICtrlNotifyInfo UINotifyInfo;
    memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
    UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_OLE_CONTROL_DEL;
    UINotifyInfo.lParam1 = (DWORD_PTR)(this);
    UINotifyInfo.lParam2 = (DWORD_PTR)dwID;
    ::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
}

DWORD CUIShowRichEdit::GetOleID()
{
	if (-1 == m_dwCurPicCount)
	{
		m_dwCurPicCount = 0;
	}

	DWORD dwID = ++m_dwCurPicCount;
    return dwID;
}

IOleProcesser* CUIShowRichEdit::GetOleProcesser(DWORD dwID)
{
	RichOleMap::iterator it_ole = m_richOleMap.find(dwID);
	if (it_ole != m_richOleMap.end())
	{
		return it_ole->second.pProcesser;
	}

	return NULL;
}

IOleProcesser* CUIShowRichEdit::GetExtralOleControl(DWORD dwID)
{
    ExtralOleControlMap::iterator it = m_extraOleControlMap.find(dwID);
    if (it != m_extraOleControlMap.end())
    {
        return it->second;
    }
    return NULL;
}

long CUIShowRichEdit::GetOleLeftClientIndent(DWORD dwID)
{
	RichOleMap::iterator it_ole = m_richOleMap.find(dwID);
	if (it_ole != m_richOleMap.end())
	{
		return it_ole->second.nLeftClientIndent;
	}

	return 0;
}

long CUIShowRichEdit::GetOleRightClientIndent(DWORD dwID)
{
	RichOleMap::iterator it_ole = m_richOleMap.find(dwID);
	if (it_ole != m_richOleMap.end())
	{
		return it_ole->second.nRightClientIndent;
	}

	return 0;
}

DWORD CUIShowRichEdit::InsertImage(LPCTSTR picPath, DWORD dwUserID)
{
	CIMGifProcesser* pGifProcesser = new CIMGifProcesser;
	if (!pGifProcesser->Load(picPath, (IRichEditMsgProc*)this))
	{
		delete pGifProcesser;
		pGifProcesser = NULL;
		return -1;
	}

	//ʹ�ÿ���ģʽ
	BOOL bOpenSnapshot = TRUE;
	if (pGifProcesser->IsGIF())
	{
		bOpenSnapshot = FALSE;
	}
	pGifProcesser->EnableAutoSize(TRUE);
	pGifProcesser->EnableSnapshot(bOpenSnapshot);

	DWORD dwRetID = InsertImageImpl(pGifProcesser, dwUserID, true);
	if (-1 == dwRetID)
	{
		delete pGifProcesser;
		pGifProcesser = NULL;
		return -1;
	}

	return dwRetID;
}

DWORD CUIShowRichEdit::InsertImage(HINSTANCE hInstance, UINT nIDResource, const char* lpszType, DWORD dwUserID)
{
	CIMGifProcesser* pGifProcesser = new CIMGifProcesser;
	if (!pGifProcesser->Load(hInstance, nIDResource, lpszType, (IRichEditMsgProc*)this))
	{
		delete pGifProcesser;
		pGifProcesser = NULL;
		return -1;
	}

	//ʹ�÷ǿ���ģʽ
	pGifProcesser->EnableAutoSize(FALSE);
	pGifProcesser->EnableSnapshot(FALSE);

	DWORD dwRetID = InsertImageImpl(pGifProcesser, dwUserID, false);
	if (-1 == dwRetID)
	{
		delete pGifProcesser;
		pGifProcesser = NULL;
		return -1;
	}

	return dwRetID;
}

DWORD CUIShowRichEdit::InsertImageImpl(CIMGifProcesser* pImageProcesser, DWORD dwUserID, bool bAutoScale)
{
	if (!pImageProcesser)
	{
		return -1;
	}

	//S_OK��ʼ���ɹ���S_FALSE�ظ���ʼ����RPC_E_CHANGED_MODE
	HRESULT hr = ::CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
	if (FAILED(hr))
	{
		return -1;
	}

	CComPtr<IRichEditOle> pReo;
	GetIRichEditOle(&pReo);
	if (!pReo)
	{
		return -1;
	}

	CComPtr<IOleClientSite> lpClientSite;
	pReo->GetClientSite(&lpClientSite);

	REOBJECT reobject;
	ZeroMemory(&reobject, sizeof(REOBJECT));
	reobject.cbStruct = sizeof(REOBJECT);

	//Pixels��Ӣ��ı�������
	HDC hDC = ::GetDC(m_hWndDirectUI);
	LONG xPerInch = GetDeviceCaps(hDC, LOGPIXELSX); 
	LONG yPerInch =	GetDeviceCaps(hDC, LOGPIXELSY); 
	::ReleaseDC(m_hWndDirectUI, hDC);

	//ԭʼ��С
	SIZE szOrg = pImageProcesser->GetSize();

	//���������λ, ѹ���ߴ�
	SIZE szTransfer = szOrg;
	LONG nLeftClientIndent = 0;
	LONG nRightClienIndent = 0;
	if (bAutoScale && m_bEnablePicScale)
	{
		//�ͻ������������
		CRect rcClient = GetRect();
		LONG nClientWidth = rcClient.Width() - GetScrollSize();
		LONG nClientHeight = rcClient.Height();

		//��������(��λΪ�, 1�Ϊ1440Ӣ��, xPerInchˮƽ���ص�Ϊ1Ӣ��)
		PARAFORMAT2 paraFormat;
		paraFormat.cbSize = sizeof(PARAFORMAT2);
		paraFormat.dwMask = PFM_ALIGNMENT|PFM_STARTINDENT|PFM_OFFSETINDENT|PFM_RIGHTINDENT;
		m_FreeWindowlessRE.GetParaFormat(paraFormat);

		nLeftClientIndent = paraFormat.dxStartIndent;
		nRightClienIndent = paraFormat.dxRightIndent;

		nClientWidth -= (nLeftClientIndent*xPerInch)/1440;
		nClientWidth -= (nRightClienIndent*xPerInch)/1440;
		
		//��������4�����ص�ƫ��, ����RichEdit�ڲ������ٽ�ֵ�ļ���״̬
		nClientWidth -= 4;

		SIZE szScale = szOrg;
		ScaleSize(szScale, nClientWidth, nClientHeight > 60 ? nClientHeight - 60 : nClientHeight);
		szTransfer.cx = DXtoHimetricX(szScale.cx, xPerInch);
		szTransfer.cy = DYtoHimetricY(szScale.cy, yPerInch);

	}
	else
	{
		szTransfer.cx = DXtoHimetricX(szOrg.cx, xPerInch);
		szTransfer.cy = DYtoHimetricY(szOrg.cy, yPerInch);
	}

	// ��¼ԭʼѡ������
	LONG lStart = 0;
	LONG lEnd = 0;
	GetSel(lStart, lEnd);

	// case1: ѡ������û������
	// case2: ѡ����������ݵ���1���ַ�,�պ��������Ole�����û�
	// case3: ѡ����������ݶ���1���ַ�
	bool bReplaceMode = false;
	if (lEnd <= lStart)
	{
		// do nothing
	}
	else if (lEnd - 1 == lStart)
	{
		// ���滻������Ҳ��Ole����,�򵥶�ɾ���ö���
		CRect rcResultOle(0,0,0,0);
		DWORD dwResultOleID = -1;
		CPoint ptSel = m_FreeWindowlessRE.PosFromChar(lStart);

		// ƫ��1������,����ͬʱ����2�������ŵ�����ole����
		ptSel.x += 1;
		ptSel.y += 1;
		if (HitTestOleByPoint(ptSel, dwResultOleID, rcResultOle))
		{
			RemoveOleData(dwResultOleID);
		}

		bReplaceMode = true;
	}
	else
	{
		OnDelChar(lStart, lEnd - 1);
		m_FreeWindowlessRE.ReplaceSel(_T(""), FALSE);
	}

	//����Ole����
	reobject.cp = REO_CP_SELECTION;
	reobject.dvaspect = DVASPECT_CONTENT;
	reobject.poleobj = NULL;
	reobject.polesite = lpClientSite;
	reobject.pstg = NULL;
	reobject.sizel = szTransfer;
	reobject.dwUser = AddOleData(pImageProcesser, dwUserID, nLeftClientIndent, nRightClienIndent);
	if (m_bReadOnly)
	{
		reobject.dwFlags = REO_BELOWBASELINE;
	}

	if (pReo->InsertObject(&reobject) != S_OK)
	{
		RemoveOleData(reobject.dwUser);
	}
	else
	{
		pImageProcesser->Draw();
	}

	// ��¼�µ�ѡ������
	LONG lStart2 = 0;
	LONG lEnd2 = 0;
	GetSel(lStart2, lEnd2);

	// case1: �����Ole������ĩβ
	// case1: �����Ole������ԭѡ���������ݵ����û�
	// case2: �����Ole������ĩβ, ѡ������û��ѡ������
	// case3: �����Ole������ĩβ, ѡ��������ѡ������
	LONG lCurEnd = SelEnd(false);
	if (lEnd2 >= lCurEnd)
	{
		// do nothing
	}
	else if (bReplaceMode)
	{
		// do nothing
	}
	else if (lEnd == lStart)
	{
		OnAddChar(lStart, lEnd2 - lStart, false);
	}
	else
	{
		OnAddChar(lStart, lEnd2 - lStart, true);
	}

	// ��ԭ��ǰѡ������
	SetSel(lStart2,lEnd2);

	//����ַ�����
	CheckCharLimit();

	return reobject.dwUser;
}

int CUIShowRichEdit::GetLineHeight(long lCharIndex, CPoint* pPtPos)
{
	CPoint pt;
	if (pPtPos)
	{
		pt = *pPtPos;
	}
	else
	{
		pt = m_FreeWindowlessRE.PosFromChar(lCharIndex);
	}

	long lIndex = LineFromChar(lCharIndex);
	if (lIndex == -1)
	{
		return 0;
	}

	CPoint ptNetxLineChar;
	int nNetxLineChar;
	// ���һ����Ҫ�������ַ����м���
	if (GetLineCount()-1 == lIndex)
	{
		return ptNetxLineChar.y;
	}
	else
	{
		nNetxLineChar = LineIndex(lIndex+1);
		ptNetxLineChar = m_FreeWindowlessRE.PosFromChar(nNetxLineChar);
	}

	return ptNetxLineChar.y - pt.y;
}

int CUIShowRichEdit::GetImageTop(long lCharIndex, int nImageHeight, CPoint ptPos)
{
	long lIndex = LineFromChar(lCharIndex);
	if (lIndex == -1)
	{
		return ptPos.y;
	}

	int nLineHeight = GetLineHeight(lCharIndex, &ptPos);

	if (nLineHeight > nImageHeight)
	{
		ptPos.y += nLineHeight - nImageHeight;
	}

	return ptPos.y;
}

void CUIShowRichEdit::ClearOleDatas()
{
	RichOleMap::iterator it_ole = m_richOleMap.begin();
	for (; it_ole != m_richOleMap.end(); ++it_ole)
	{
		if (it_ole->second.pProcesser)
		{
			SAFE_DELETE(it_ole->second.pProcesser);
		}
	}

	m_dwHostScaleButton = -1;
	m_richOleMap.clear();
}

void CUIShowRichEdit::ResizeOleData()
{
	if (!m_bEnablePicScale)
	{
		return;
	}

	CComPtr<IRichEditOle> pReo;
	GetIRichEditOle(&pReo);
	if(NULL == pReo)
	{
		return;
	}

	SetCanUpdateNow(false);

	HDC hDC = ::GetDC(m_hWndDirectUI);
	if (NULL == hDC) return;
	LONG xPerInch = GetDeviceCaps(hDC, LOGPIXELSX); 
	LONG yPerInch =	GetDeviceCaps(hDC, LOGPIXELSY);
	::ReleaseDC(m_hWndDirectUI, hDC);

	CRect rcClient = GetRect();
	LONG nClientWidth = rcClient.Width() - GetScrollSize();
	LONG nClientHeight = rcClient.Height();

	long lCount = pReo->GetObjectCount();
	for (long i = 0; i < lCount; ++i)
	{
		REOBJECT reObject;
		memset(&reObject, 0, sizeof(REOBJECT));
		reObject.cbStruct = sizeof(REOBJECT);
		pReo->GetObject(i, &reObject, REO_GETOBJ_NO_INTERFACES);

		CPoint ptObject = m_FreeWindowlessRE.PosFromChar(reObject.cp);
		if (ptObject.x < 0)
		{
			continue;
		}

		IOleProcesser* pOleProcesser = GetOleProcesser(reObject.dwUser);
		if (!pOleProcesser || !pOleProcesser->IsEnableAutoSize())
		{
			continue;
		}

		SIZE szObject;
		szObject.cx = HimetricXtoDX(reObject.sizel.cx, xPerInch);
		szObject.cy = HimetricYtoDY(reObject.sizel.cy, yPerInch);

		LONG nLeftClientIndent = GetOleLeftClientIndent(reObject.dwUser);
		LONG nRightClientIndent = GetOleRightClientIndent(reObject.dwUser);

		//����ǰ��ʾ��������
		LONG nMaxObjectWidth = nClientWidth - (nLeftClientIndent*xPerInch)/1440 - (nRightClientIndent*xPerInch)/1440;

		//��������4�����ص�ƫ��, ����RichEdit�ڲ������ٽ�ֵ�ļ���״̬
		nMaxObjectWidth -= 4;

		SIZE szScale = pOleProcesser->GetSize();
		ScaleSize(szScale, nMaxObjectWidth, nClientHeight > 60 ? nClientHeight - 60 : nClientHeight);

		if (szScale.cx != szObject.cx)
		{
			CComPtr<IOleClientSite> lpClientSite;
			pReo->GetClientSite(&lpClientSite);

			//Pixelsת��ΪӢ��
			SIZE szTransfer;
			szTransfer.cx = DXtoHimetricX(szScale.cx, xPerInch);
			szTransfer.cy = DYtoHimetricY(szScale.cy, yPerInch);

			//��¼ԭ��ѡ������
			CHARRANGE curSelRange;
			GetSel(curSelRange);

			//ѡ���޸Ķ���
			m_FreeWindowlessRE.SetSel(reObject.cp, reObject.cp + 1, false);

			//����Ole����
			REOBJECT reModify;
			memset(&reModify, 0, sizeof(REOBJECT));
			reModify.cbStruct = sizeof(REOBJECT);
			reModify.cp = REO_CP_SELECTION;
			reModify.dvaspect = DVASPECT_CONTENT;
			reModify.poleobj = NULL;
			reModify.polesite = lpClientSite;
			reModify.pstg = NULL;
			reModify.sizel = szTransfer;
			reModify.dwUser = reObject.dwUser;
			if (m_bReadOnly)
			{
				reModify.dwFlags = REO_BELOWBASELINE;
			}

			if (S_OK == pReo->InsertObject(&reModify))
			{
				reObject.sizel = reModify.sizel;
			}

			//��ԭԭ��ѡ������
			SetSel(curSelRange, true);
		}
	}

	SetCanUpdateNow(true);
}

void CUIShowRichEdit::GetOneOleUpdateIndex(
	IRichEditOle* pReo,
	REOBJECT& reObject,
	LONG xPerInch,
	LONG yPerInch,
	const RECT& rcClient,
	int nAllCount,
	int& nStart)
{
	//�ú����ӿ��У���Ҫʵ�ֶԿɼ�ole����Ŀ��ٶ�λ
	//�ܷ�������Ų��Զ�ole������ٶ�λ��ֱ��Ӱ����richedit����ʾ���� ts 2012��2��28
	nStart = 0;
	if (pReo && nAllCount > 0)
	{
		CPoint ptObjPos;
		LONG li_Width, li_Height;

		//���������ϴα���Ŀɼ�ole���������ٶ�λ
		if (m_bReadOnly && m_nCurEndVisibleIndex >= 0 && m_nCurEndVisibleIndex < nAllCount)
		{
			if (GetOleObjPos(pReo, reObject, m_nCurEndVisibleIndex, ptObjPos, xPerInch, yPerInch, li_Width, li_Height))
			{
				//�ϴοɼ���ole�����Դ��ڵ�ǰ�ͻ�����
				if (ptObjPos.x < rcClient.right && ptObjPos.x + li_Width > rcClient.left && 
					ptObjPos.y < rcClient.bottom && ptObjPos.y + li_Height > rcClient.top)
				{
					nStart = m_nCurEndVisibleIndex;
					return;
				}
				else
				{
					//�ϴοɼ���ole�����ڵ�ǰ��Ļ�·�
					if (ptObjPos.y >= rcClient.bottom)
					{
						int nCurIndex = m_nCurEndVisibleIndex - 1;
						while (nCurIndex >= 0)
						{
							if (GetOleObjPos(pReo, reObject, nCurIndex, ptObjPos, xPerInch, yPerInch, li_Width, li_Height))
							{
								//ole�����ڵ�ǰ�ͻ�����
								if (ptObjPos.x < rcClient.right && ptObjPos.x + li_Width > rcClient.left && 
									ptObjPos.y < rcClient.bottom && ptObjPos.y + li_Height > rcClient.top)
								{
									nStart = nCurIndex;
									return;
								}
								else
								{
									//���ϲ��ң����ֱ����������Ѿ�����Ļ�Ϸ��ˣ�������ν�Ĳ���
									if (ptObjPos.y <= rcClient.top)
									{
										nStart = nCurIndex;
										return;
									}
								}

								nCurIndex--;
							}
							else
							{
								nStart = 0;
								return;
							}
						}

						//��ǰû���κ�ole����ɼ�
						nStart = 0;
						return;
					}
					//�ϴοɼ���ole�����ڵ�ǰ��Ļ�Ϸ�
					else if (ptObjPos.y <= rcClient.top)
					{
						int nCurIndex = m_nCurEndVisibleIndex + 1;
						while (nCurIndex < nAllCount)
						{
							if (GetOleObjPos(pReo, reObject, nCurIndex, ptObjPos, xPerInch, yPerInch, li_Width, li_Height))
							{
								//ole�����ڵ�ǰ�ͻ�����
								if (ptObjPos.x < rcClient.right && ptObjPos.x + li_Width > rcClient.left && 
									ptObjPos.y < rcClient.bottom && ptObjPos.y + li_Height > rcClient.top)
								{
									nStart = nCurIndex;
									return;
								}
								else
								{
									//���²��ң����ֵ�ǰ��������Ļ�·���������ν�Ĳ���
									if (ptObjPos.y >= rcClient.bottom)
									{
										nStart = nCurIndex;
										return;
									}
								}

								nCurIndex++;
							}
							else
							{
								nStart = 0;
								return;
							}
						}

						//��ǰû���κ�ole����ɼ�
						nStart = nAllCount - 1;
						return;
					}
				}
			}
			else
			{
				nStart = 0;
				return;
			}
		}

		//�����ϴα���Ŀɼ���δ�ܿ��ٶ�λ����ʼ���ֱ�����������λ
		//Ϊ���⼫��������˴�����ƽ�������ȶ���2�ַ��������ұȽϺ���
		int nHalfPathBegin = 0;
		int nHalfPathEnd = nAllCount - 1;

		//���ֲ�����ʼole��������Ļ�·���������������ν�Ĳ���
		if (GetOleObjPos(pReo, reObject, nHalfPathBegin, ptObjPos, xPerInch, yPerInch, li_Width, li_Height))
		{
			if (ptObjPos.y >= rcClient.bottom)
			{
				nStart = nHalfPathBegin;
				return;
			}
		}
		else
		{
			nStart = 0;
			return;
		}

		//���ֲ���ĩβole��������Ļ�Ϸ���������������ν�Ĳ���
		if (GetOleObjPos(pReo, reObject, nHalfPathEnd, ptObjPos, xPerInch, yPerInch, li_Width, li_Height))
		{
			if (ptObjPos.y <= rcClient.top)
			{
				nStart = nHalfPathEnd;
				return;
			}
		}
		else
		{
			nStart = 0;
			return;
		}

		//��ʼ���ֲ��ҹ���
		nStart = nHalfPathEnd;
		while (nHalfPathBegin + 1 < nHalfPathEnd)
		{
			int nHalfPathNew = nHalfPathBegin + (nHalfPathEnd - nHalfPathBegin)/2;
			if (GetOleObjPos(pReo, reObject, nHalfPathNew, ptObjPos, xPerInch, yPerInch, li_Width, li_Height))
			{
				//���ֽڵ㴦��ole�����ڿͻ�����
				if (ptObjPos.x < rcClient.right && ptObjPos.x + li_Width > rcClient.left && 
					ptObjPos.y < rcClient.bottom && ptObjPos.y + li_Height > rcClient.top)
				{
					nStart = nHalfPathNew;
					return;
				}
				else
				{
					//���ֽڵ㴦��ole�����ڵ�ǰ��Ļ�·�
					if (ptObjPos.y >= rcClient.bottom)
					{
						nHalfPathEnd = nHalfPathNew;
					}
					//���ֽڵ㴦��ole�����ڵ�ǰ��Ļ�Ϸ�
					else if (ptObjPos.y <= rcClient.top)
					{
						nHalfPathBegin = nHalfPathNew;
					}
					else
					{
						//������������ߵ�����
						return;
					}
				}
			}
			else
			{
				return;
			}
		}
	}
}

bool CUIShowRichEdit::GetOleObjPos(
								   IRichEditOle* pReo,
								   REOBJECT& reObject,
								   int OleObjIndex,
								   CPoint& ptOlePoint,
								   LONG xPerInch,
								   LONG yPerInch,
								   LONG& li_Width,
								   LONG& li_Height)
{
	ptOlePoint.x = ptOlePoint.y = 0;
	li_Width = li_Height = 0;

	if (!pReo) return false;

	memset(&reObject, 0, sizeof(REOBJECT));
	reObject.cbStruct = sizeof(REOBJECT);
	pReo->GetObject(OleObjIndex, &reObject, REO_GETOBJ_NO_INTERFACES);

	ptOlePoint = m_FreeWindowlessRE.PosFromChar(reObject.cp);

	li_Width = HimetricXtoDX(reObject.sizel.cx, xPerInch);
	li_Height = HimetricYtoDY(reObject.sizel.cy, yPerInch);

	ptOlePoint.y = GetImageTop(reObject.cp, li_Height, ptOlePoint);

	return true;
}

DWORD CUIShowRichEdit::InsertOleControl(LPCTSTR lpOleEleName, int nWidth, int nHeight, DWORD dwOleID)
{
	HRESULT hr;
	hr = ::CoInitializeEx(NULL, COINIT_APARTMENTTHREADED);
	if (FAILED(hr)) //S_OK��ʼ���ɹ���S_FALSE�ظ���ʼ����RPC_E_CHANGED_MODE
	{
		return -1;
	}

	CComPtr<IRichEditOle> pReo;
	GetIRichEditOle(&pReo);
	if (!pReo)
	{
		return -1;
	}

	CIMControlProcesser* pOleControlProcesser = new CIMControlProcesser;
	if (!pOleControlProcesser)
	{
		return -1;
	}

	//��ʼ��Ole��չ�ؼ�
	pOleControlProcesser->EnableAutoSize(FALSE);
	pOleControlProcesser->SetSize(nWidth, nHeight);

	CRichElementBase* pOleControlEle = GetOleEleExModalByName(lpOleEleName);
	if (pOleControlEle)
	{
		pOleControlProcesser->SetControlElement(pOleControlEle);
	}

	//Pixels��Ӣ��ı�������
	HDC hDC = ::GetDC(m_hWndDirectUI);
	LONG xPerInch = GetDeviceCaps(hDC, LOGPIXELSX); 
	LONG yPerInch =	GetDeviceCaps(hDC, LOGPIXELSY); 
	::ReleaseDC(m_hWndDirectUI, hDC);

	//��������(��λΪ�, 1�Ϊ1440Ӣ��, xPerInchˮƽ���ص�Ϊ1Ӣ��)
	PARAFORMAT2 paraFormat;
	paraFormat.cbSize = sizeof(PARAFORMAT2);
	paraFormat.dwMask = PFM_ALIGNMENT|PFM_STARTINDENT|PFM_OFFSETINDENT|PFM_RIGHTINDENT;
	m_FreeWindowlessRE.GetParaFormat(paraFormat);

	//Pixelsת��ΪӢ��
	SIZE szTransfer;
	szTransfer.cx = DXtoHimetricX(nWidth, xPerInch);
	szTransfer.cy = DYtoHimetricY(nHeight, yPerInch);

	//��¼ԭʼѡ������
	LONG lStart = 0;
	LONG lEnd = 0;
	GetSel(lStart, lEnd);

	//case1: ѡ������û������
	//case2: ѡ����������ݵ���1���ַ�,�պ��������Ole�����û�
	//case3: ѡ����������ݶ���1���ַ�
	bool bReplaceMode = false;
	if (lEnd <= lStart)
	{
		//do nothing
	}
	else if (lEnd - 1 == lStart)
	{
		//���滻������Ҳ��Ole����,�򵥶�ɾ���ö���
		CRect rcResultOle(0,0,0,0);
		DWORD dwResultOleID = -1;
		CPoint ptSel = m_FreeWindowlessRE.PosFromChar(lStart);
		if (HitTestOleByPoint(ptSel, dwResultOleID, rcResultOle))
		{
			RemoveOleData(dwResultOleID);
		}

		bReplaceMode = true;
	}
	else
	{
		OnDelChar(lStart, lEnd - 1);
		m_FreeWindowlessRE.ReplaceSel(_T(""), FALSE);
	}

	//����Ole����
	CComPtr<IOleClientSite> lpClientSite;
	pReo->GetClientSite(&lpClientSite);

	REOBJECT reobject;
	ZeroMemory(&reobject, sizeof(REOBJECT));
	reobject.cbStruct = sizeof(REOBJECT);
	reobject.cp = REO_CP_SELECTION;
	reobject.dvaspect = DVASPECT_CONTENT;
	reobject.poleobj = NULL;
	reobject.polesite = lpClientSite;
	reobject.pstg = NULL;
	reobject.sizel = szTransfer;
	reobject.dwUser = AddOleData(pOleControlProcesser, dwOleID, paraFormat.dxStartIndent, paraFormat.dxRightIndent);
	if (m_bReadOnly)
	{
		reobject.dwFlags = REO_BELOWBASELINE;
	}

	if (pReo->InsertObject(&reobject) != S_OK)
	{
		RemoveOleData(dwOleID);
	}

	//��¼�µ�ѡ������
	LONG lStart2 = 0;
	LONG lEnd2 = 0;
	GetSel(lStart2, lEnd2);

	//case1: �����Ole������ĩβ
	//case1: �����Ole������ԭѡ���������ݵ����û�
	//case2: �����Ole������ĩβ, ѡ������û��ѡ������
	//case3: �����Ole������ĩβ, ѡ��������ѡ������
	LONG lCurEnd = SelEnd(false);
	if (lEnd2 >= lCurEnd)
	{
		//do nothing
	}
	else if (bReplaceMode)
	{
		//do nothing
	}
	else if (lEnd == lStart)
	{
		OnAddChar(lStart, lEnd2 - lStart, false);
	}
	else
	{
		OnAddChar(lStart, lEnd2 - lStart, true);
	}

	// ��ԭ��ǰѡ������
	SetSel(lStart2,lEnd2);

	//����ַ�����
	CheckCharLimit();

	return dwOleID;
}

void CUIShowRichEdit::SetOleControlUserData(DWORD dwOleID, DWORD_PTR dwUserData)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (NULL == pOleProcesser)
	{
		pOleProcesser = GetExtralOleControl(dwOleID);
	}
    
    if (pOleProcesser)
    {
        pOleProcesser->SetUserData(dwUserData);
    }
}

DWORD_PTR CUIShowRichEdit::GetOleControlUserData(DWORD dwOleID)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (NULL == pOleProcesser)
	{
		pOleProcesser = GetExtralOleControl(dwOleID);
	}
    
    if (pOleProcesser)
    {
        return pOleProcesser->GetUserData();
    }

    return NULL;
}

bool CUIShowRichEdit::IsExistOleControl(DWORD dwOleID)
{
    IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }

    if (pOleProcesser)
    {
        return true;
    }

    return false;
}

void CUIShowRichEdit::OnMouseEnterOleControlElement(DWORD dwOleID, LPCTSTR lpOleControlName, CRichElementBase* pMouseEnterEle, DWORD_PTR dwUserData)
{
	if (!pMouseEnterEle)
	{
		return;
	}

	WTL::CString strToolTips = pMouseEnterEle->GetToolTips();
	if (strToolTips.GetLength() > 0 && m_hWndDirectUI)
	{
		::SendMessage(m_hWndDirectUI, WM_SETTOOPTIP, (WPARAM)(LPCTSTR)strToolTips, (LPARAM)this);
	}

	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_OLE_CONTROL_MOUSEENTER_ELEMENT;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	UINotifyInfo.lParam2 = (DWORD_PTR)dwOleID;
	UINotifyInfo.lParam3 = (DWORD_PTR)lpOleControlName;
	UINotifyInfo.lParam4 = (DWORD_PTR)pMouseEnterEle->GetName();
	UINotifyInfo.lParam5 = (DWORD_PTR)dwUserData;
	::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&UINotifyInfo, 0);
}

void CUIShowRichEdit::OnMouseLeaveOleControlElement(DWORD dwOleID, LPCTSTR lpOleControlName, CRichElementBase* pMouseLeaveEle, DWORD_PTR dwUserData)
{
	if (!pMouseLeaveEle)
	{
		return;
	}

	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_OLE_CONTROL_MOUSELEAVE_ELEMENT;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	UINotifyInfo.lParam2 = (DWORD_PTR)dwOleID;
	UINotifyInfo.lParam3 = (DWORD_PTR)lpOleControlName;
	UINotifyInfo.lParam4 = (DWORD_PTR)pMouseLeaveEle->GetName();
	UINotifyInfo.lParam5 = (DWORD_PTR)dwUserData;
	::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&UINotifyInfo, 0);
}

void CUIShowRichEdit::OnLButtonDownOleControlElement(DWORD dwOleID, LPCTSTR lpOleControlName, CRichElementBase* pClickedEle, DWORD_PTR dwUserData)
{
	if (!pClickedEle)
	{
		return;
	}

	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_OLE_CONTROL_LBUTTONDOWN_ELEMENT;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	UINotifyInfo.lParam2 = (DWORD_PTR)dwOleID;
	UINotifyInfo.lParam3 = (DWORD_PTR)lpOleControlName;
	UINotifyInfo.lParam4 = (DWORD_PTR)pClickedEle->GetName();
	UINotifyInfo.lParam5 = (DWORD_PTR)dwUserData;
	::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&UINotifyInfo, 0);
}

void CUIShowRichEdit::OnLButtonUpOleControlElement(DWORD dwOleID, LPCTSTR lpOleControlName, CRichElementBase* pClickedEle, DWORD_PTR dwUserData)
{
	if (!pClickedEle)
	{
		return;
	}
    DUICtrlNotifyInfo UINotifyInfo;
    memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
    UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_OLE_CONTROL_LBUTTONUP_ELEMENT;
    UINotifyInfo.lParam1 = (DWORD_PTR)(this);
    UINotifyInfo.lParam2 = (DWORD_PTR)dwOleID;
    UINotifyInfo.lParam3 = (DWORD_PTR)lpOleControlName;
    UINotifyInfo.lParam4 = (DWORD_PTR)pClickedEle->GetName();
    UINotifyInfo.lParam5 = (DWORD_PTR)dwUserData;

    tDelayImageInfo::iterator it = m_tWaitImageQueue.begin();
    for (; it != m_tWaitImageQueue.end(); ++it)
    {
        if (it->dwOleID == dwOleID)
        {
            InsertContentBegin(eInsertModeBack, FALSE);
            SetSel(it->pos, it->pos + 1);
            it->dwOleID = this->InsertLoadingImg();
            it->imgStatus = eImageStatus_Loading;
            it->uTickTime = ::GetTickCount();
            InsertContentEnd(eScrollAuto);

            UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_TRY_DOWNLOAD_IMG;
            UINotifyInfo.lParam2 = (DWORD_PTR)it->dwOleID;
            UINotifyInfo.lParam3 = NULL;
            UINotifyInfo.lParam4 = (DWORD_PTR)(LPCTSTR)it->strFileName;            
            UINotifyInfo.lParam5 = (DWORD_PTR)(LPCTSTR)it->strFileURL;

			int nFileNamePos = it->strFileName.ReverseFind(_T('/'));
			if (-1 == nFileNamePos)
			{
				nFileNamePos = it->strFileName.ReverseFind(_T('\\'));
			}
			if (nFileNamePos != -1)
			{
				UINotifyInfo.lParam6 = (DWORD_PTR)(LPCTSTR)it->strFileName.Mid(nFileNamePos + 1, it->strFileName.GetLength() - nFileNamePos - 1);
			}
			else
			{
				UINotifyInfo.lParam6 = (DWORD_PTR)(LPCTSTR)it->strFileName;
			}

            StartImageLoadingTimer();
            break;
        }
    }
	
	::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&UINotifyInfo, 0);
}

void CUIShowRichEdit::OnRButtonUpOleControlElement(DWORD dwOleID, LPCTSTR lpOleControlName, CRichElementBase* pClickedEle, DWORD_PTR dwUserData)
{
	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_OLE_CONTROL_RBUTTONUP_ELEMENT;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	UINotifyInfo.lParam2 = (DWORD_PTR)dwOleID;
	UINotifyInfo.lParam3 = (DWORD_PTR)lpOleControlName;
	UINotifyInfo.lParam4 = (DWORD_PTR)(pClickedEle ? pClickedEle->GetName() : _T(""));
	UINotifyInfo.lParam5 = (DWORD_PTR)dwUserData;
	::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&UINotifyInfo, 0);
}

void CUIShowRichEdit::GetContent(WTL::CString& strContent)
{
	long len = m_FreeWindowlessRE.GetTextLengthEx();
	LPTSTR pBuffer = strContent.GetBuffer(len+1);
	m_FreeWindowlessRE.GetTextEx(pBuffer, len+1);
	strContent.ReleaseBuffer();

	NCString strTemp = strContent;
	strTemp.Remove(_T('\r'));
	strContent = strTemp;
}

void CUIShowRichEdit::GetCharFormat(CHARFORMAT& charFormat, DWORD dwMask/* = CFM_COLOR | CFM_FACE | CFM_SIZE | CFM_BOLD | CFM_ITALIC | CFM_UNDERLINE*/)
{
	charFormat.cbSize = sizeof(CHARFORMAT);
	charFormat.dwMask = dwMask;
	GetSelectionCharFormat(charFormat);
}

LRESULT CUIShowRichEdit::OnElementPaint(WPARAM wParam, LPARAM lParam)
{
	if (!m_bInit)
	{
		return -1;
	}

	HDC hDC = (HDC)wParam;
	CRect rcUpdate = CRect((RECT*)lParam);

	CRect rcDUI = GetRect();
	if (IsScrollBarExist(FALSE))
	{
		long nScrollBarWidth = GetScrollSize();
		rcDUI.right -= nScrollBarWidth;
	}

	LRESULT lRetExtra = DrawExtraElement(hDC, rcDUI, rcUpdate);
	if (S_OK == lRetExtra)
	{
		return S_OK;
	}

	return -1;
}

LRESULT CUIShowRichEdit::OnOlePaint(WPARAM wParam, LPARAM lParam)
{
	if (!m_bInit)
	{
		return -1;
	}

	HDC hDC = (HDC)wParam;
	CRect rcUpdate = CRect((RECT*)lParam);

	CRect rcDUI = GetRect();
	if (IsScrollBarExist(FALSE))
	{
		long nScrollBarWidth = GetScrollSize();
		rcDUI.right -= nScrollBarWidth;
	}

	LRESULT lRetOle = DrawOles(hDC, rcDUI, rcUpdate);
	if (S_OK == lRetOle)
	{
		return S_OK;
	}

	return -1;
}

LRESULT CUIShowRichEdit::DrawOles(HDC hDC, const RECT& rcClient, const RECT& rcUpdate)
{
	if (!m_bInit) return -1;

	CComPtr<IRichEditOle> pReo;
	GetIRichEditOle(&pReo);
	if(pReo == NULL)
	{
		return -1;
	}

	CHARRANGE charrange;
	m_FreeWindowlessRE.GetSel(charrange);

	//���ȿ��ٶ�λһ���ɼ�ole����
	REOBJECT reObject;
	LONG xPerInch = GetDeviceCaps(hDC, LOGPIXELSX); 
	LONG yPerInch =	GetDeviceCaps(hDC, LOGPIXELSY); 
	int nCount = pReo->GetObjectCount();
	int nEndIndex = 0;
	GetOneOleUpdateIndex(pReo, reObject, xPerInch, yPerInch, rcClient, nCount, nEndIndex);

	//�ӵ�ǰ�ɼ�ole��������λ�ã������˷�ɢ��ʼ����
	CPoint ptObjPos;
	LONG li_Width, li_Height;
	bool bOleVisible = false;
	bool bInClientRc = false;
	bool bInUpdateRc = false;

	//�Ƿ�����������ť״̬
	BOOL bResetScaleBtnState = TRUE;

	//���ϼ�����ƶ���
	RECT rcPaint, rcClip;
	bool bHasMatched = false;
	memset(&rcPaint, 0, sizeof(rcPaint));
	memset(&rcClip, 0, sizeof(rcClip));
	for (int i = nEndIndex; i >= 0; i--)
	{
		if (!GetOleObjPos(pReo, reObject, i, ptObjPos, xPerInch, yPerInch, li_Width, li_Height))
		{
			return 0;
		}

		//ole��������Ч��������
		if (ptObjPos.x < rcUpdate.right && ptObjPos.x + li_Width > rcUpdate.left && 
			ptObjPos.y < rcUpdate.bottom  && ptObjPos.y + li_Height > rcUpdate.top)
		{
			bInUpdateRc = true;
		}
		else
		{
			bInUpdateRc = false;
		}

		//ole�����ڵ�ǰ�ͻ�����
		if (ptObjPos.x < rcClient.right && ptObjPos.x + li_Width > rcClient.left && 
			ptObjPos.y < rcClient.bottom && ptObjPos.y + li_Height > rcClient.top)
		{
			bInClientRc = true;
		}
		else
		{
			bInClientRc = false;
		}

		if (!bInClientRc)
		{
			//���ö��������д��ڿɼ����������ϼ���
			if (bHasMatched && 
				(ptObjPos.y == rcPaint.top || ptObjPos.y + li_Height == rcPaint.bottom))
			{
				//do nothing
			}
			else
			{
				break;
			}
		}

		IOleProcesser* pOleProcesser = GetOleProcesser(reObject.dwUser);
		if (!pOleProcesser)
		{
			continue;
		}

		//����ole����ɼ�״̬
		pOleProcesser->SetVisibleInside(bInClientRc ? TRUE : FALSE);

		//����
		if (bInUpdateRc || bInClientRc)
		{
			bHasMatched = true;

			rcPaint.left = ptObjPos.x;
			rcPaint.right = ptObjPos.x + li_Width;
			rcPaint.top = ptObjPos.y;
			rcPaint.bottom = ptObjPos.y + li_Height;

			bool bNeedClip = false;
			if (rcPaint.left < rcClient.left || rcPaint.right > rcClient.right ||
				rcPaint.top < rcClient.top || rcPaint.bottom > rcClient.bottom)
			{
				bNeedClip = true;
				rcClip.left = max(rcPaint.left, rcClient.left);
				rcClip.right = min(rcPaint.right, rcClient.right);
				rcClip.top = max(rcPaint.top, rcClient.top);
				rcClip.bottom = min(rcPaint.bottom, rcClient.bottom);
			}

			//��¼���һ���ɼ�ole����
			m_nCurEndVisibleIndex = i;

			//�����鴦��ѡ������,��ԭ������������ı���ɫ(����ole����������·�ѡ)
			if (charrange.cpMax - charrange.cpMin > 1)
			{
				if (reObject.cp >= charrange.cpMin
					&& reObject.cp < charrange.cpMax)
				{
					::InvertRect(hDC, bNeedClip?&rcClip:&rcPaint);
				}
			}

			//��������
			pOleProcesser->OnPaint(hDC, &rcPaint, m_bOlePlayAni, m_uAniFrameTick, bNeedClip?&rcClip:NULL, m_bForbidSnapshot);

			//���ƷŴ���ʾ��ť
			if (pOleProcesser->IsEnableAutoSize())
			{
				DUIRICHEDIT_STATE eRichEditState = DUIRICHEDIT_STATE_NORMAL;
				if (m_dwHostScaleButton == reObject.dwUser)
				{
					bResetScaleBtnState = FALSE;
					eRichEditState = DUIRICHEDIT_STATE_HOT;
				}

				SIZE szOriginal = pOleProcesser->GetSize();
				if (pOleProcesser->GetType() == OleProcesser_Gif && 
					((CIMGifProcesser*)pOleProcesser)->IsExistFileURL())
				{
					int nURLWidth = ((CIMGifProcesser*)pOleProcesser)->GetFileURLImageWidth();
					int nURLHeight = ((CIMGifProcesser*)pOleProcesser)->GetFileURLImageHeight();
					szOriginal.cx = (nURLWidth > 0 && nURLHeight > 0) ? nURLWidth : szOriginal.cx;
					szOriginal.cy = (nURLWidth > 0 && nURLHeight > 0) ? nURLHeight : szOriginal.cy;
				}

				if (szOriginal.cx > li_Width && m_pImgScaleButton[eRichEditState] && 
					m_pDrawScaleButton && m_pDrawScaleButton->GetValue2())
				{
					CRect rcScaleIcon;
					m_pImgScaleButton[eRichEditState]->GetRect(&rcScaleIcon);

					rcScaleIcon.OffsetRect(-rcScaleIcon.left, -rcScaleIcon.top);
					rcScaleIcon.OffsetRect(rcPaint.right - rcScaleIcon.Width() - 2, rcPaint.bottom - rcScaleIcon.Height() - 2);
					if (bNeedClip)
					{
						rcScaleIcon.IntersectRect(&rcScaleIcon, &rcClip);
					}

					m_pImgScaleButton[eRichEditState]->Draw(hDC, rcScaleIcon);
				}
			}

			//�����鴦��ѡ������,��ѡ������������
			if (1 == charrange.cpMax - charrange.cpMin)
			{
				if (reObject.cp == charrange.cpMin)
				{
					if (bNeedClip)
					{
						HPEN hPen = ::CreatePen(PS_ALTERNATE|PS_COSMETIC, 1, 0);
						HPEN hOldPen = (HPEN)::SelectObject(hDC, hPen);

						//���Ͻ�--->���Ͻ�
						if (rcClip.top > rcClient.top)
						{
							::MoveToEx(hDC, max(rcClip.left,rcClient.left), rcClip.top, NULL);
							::LineTo(hDC, min(rcClip.right,rcClient.right), rcClip.top);
						}

						//���Ͻ�--->���½�
						if (rcClip.right < rcClient.right)
						{
							::MoveToEx(hDC, rcClip.right, max(rcClip.top,rcClient.top), NULL);
							::LineTo(hDC, rcClip.right, min(rcClip.bottom,rcClient.bottom));
						}

						//���½�--->���½�
						if (rcClip.bottom < rcClient.bottom)
						{
							::MoveToEx(hDC, min(rcClip.right, rcClient.right), rcClip.bottom, NULL);
							::LineTo(hDC, max(rcClip.left, rcClient.left), rcClip.bottom);
						}

						//���½�--->���Ͻ�
						if (rcClip.left >= rcClient.left)
						{
							::MoveToEx(hDC, rcClip.left, min(rcClip.bottom,rcClient.bottom), NULL);
							::LineTo(hDC, rcClip.left, max(rcClip.top,rcClient.top));
						}

						::SelectObject(hDC, hOldPen);
						::DeleteObject(hPen);
					}
					else
					{
						HBRUSH hbrush = ::CreateSolidBrush(0);
						::FrameRect(hDC, &rcPaint, hbrush);
						::DeleteObject(hbrush);
					}
				}
			}
			else if (charrange.cpMax - charrange.cpMin > 1)
			{
				if (reObject.cp >= charrange.cpMin
					&& reObject.cp < charrange.cpMax)
				{
					::InvertRect(hDC, bNeedClip?&rcClip:&rcPaint);
				}
			}
		}
	}

	//���¼�����ƶ���
	bHasMatched = false;
	memset(&rcPaint, 0, sizeof(rcPaint));
	memset(&rcClip, 0, sizeof(rcClip));
	for (int i = nEndIndex + 1; i < nCount; i++)
	{
		if (!GetOleObjPos(pReo, reObject, i, ptObjPos, xPerInch, yPerInch, li_Width, li_Height))
		{
			return 0;
		}

		//ole��������Ч��������
		if (ptObjPos.x < rcUpdate.right && ptObjPos.x + li_Width > rcUpdate.left && 
			ptObjPos.y < rcUpdate.bottom  && ptObjPos.y + li_Height > rcUpdate.top)
		{
			bInUpdateRc = true;
		}
		else
		{
			bInUpdateRc = false;
		}

		//ole�����ڵ�ǰ�ͻ�����
		if (ptObjPos.x < rcClient.right && ptObjPos.x + li_Width > rcClient.left && 
			ptObjPos.y < rcClient.bottom && ptObjPos.y + li_Height > rcClient.top)
		{
			bInClientRc = true;
		}
		else
		{
			bInClientRc = false;
		}

		if (!bInClientRc)
		{
			//���ö��������д��ڿɼ����������¼���
			if (bHasMatched && 
				(ptObjPos.y == rcPaint.top || ptObjPos.y + li_Height == rcPaint.bottom))
			{
				//do nothing
			}
			else
			{
				break;
			}
		}

		IOleProcesser* pOleProcesser = GetOleProcesser(reObject.dwUser);
		if (!pOleProcesser)
		{
			continue;
		}

		//����ole����ɼ�״̬
		pOleProcesser->SetVisibleInside(bInClientRc ? TRUE : FALSE);

		//����
		if (bInUpdateRc || bInClientRc)
		{
			bHasMatched = true;

			rcPaint.left = ptObjPos.x;
			rcPaint.right = ptObjPos.x + li_Width;
			rcPaint.top = ptObjPos.y;
			rcPaint.bottom = ptObjPos.y + li_Height;

			bool bNeedClip = false;
			if (rcPaint.left < rcClient.left || rcPaint.right > rcClient.right ||
				rcPaint.top < rcClient.top || rcPaint.bottom > rcClient.bottom)
			{
				bNeedClip = true;
				rcClip.left = max(rcPaint.left, rcClient.left);
				rcClip.right = min(rcPaint.right, rcClient.right);
				rcClip.top = max(rcPaint.top, rcClient.top);
				rcClip.bottom = min(rcPaint.bottom, rcClient.bottom);
			}

			//��¼���һ���ɼ�ole����
			m_nCurEndVisibleIndex = i;

			//�����鴦��ѡ������,��ԭ������������ı���ɫ(����ole����������·�ѡ)
			if (charrange.cpMax - charrange.cpMin > 1)
			{
				if (reObject.cp >= charrange.cpMin
					&& reObject.cp < charrange.cpMax)
				{
					::InvertRect(hDC, bNeedClip?&rcClip:&rcPaint);
				}
			}

			//��������
			pOleProcesser->OnPaint(hDC, &rcPaint, m_bOlePlayAni, m_uAniFrameTick, bNeedClip?&rcClip:NULL, m_bForbidSnapshot);

			//���ƷŴ�ť
			if (pOleProcesser->IsEnableAutoSize())
			{
				DUIRICHEDIT_STATE eRichEditState = DUIRICHEDIT_STATE_NORMAL;
				if (m_dwHostScaleButton == reObject.dwUser)
				{
					bResetScaleBtnState = FALSE;
					eRichEditState = DUIRICHEDIT_STATE_HOT;
				}

				SIZE szOriginal = pOleProcesser->GetSize();
				if (pOleProcesser->GetType() == OleProcesser_Gif && 
					((CIMGifProcesser*)pOleProcesser)->IsExistFileURL())
				{
					int nURLWidth = ((CIMGifProcesser*)pOleProcesser)->GetFileURLImageWidth();
					int nURLHeight = ((CIMGifProcesser*)pOleProcesser)->GetFileURLImageHeight();
					szOriginal.cx = (nURLWidth > 0 && nURLHeight > 0) ? nURLWidth : szOriginal.cx;
					szOriginal.cy = (nURLWidth > 0 && nURLHeight > 0) ? nURLHeight : szOriginal.cy;
				}

				if (szOriginal.cx > li_Width && m_pImgScaleButton[eRichEditState] && 
					m_pDrawScaleButton && m_pDrawScaleButton->GetValue2())
				{
					CRect rcScaleIcon;
					m_pImgScaleButton[eRichEditState]->GetRect(&rcScaleIcon);

					rcScaleIcon.OffsetRect(-rcScaleIcon.left, -rcScaleIcon.top);
					rcScaleIcon.OffsetRect(rcPaint.right - rcScaleIcon.Width() - 2, rcPaint.bottom - rcScaleIcon.Height() - 2);
					if (bNeedClip)
					{
						rcScaleIcon.IntersectRect(&rcScaleIcon, &rcClip);
					}

					m_pImgScaleButton[eRichEditState]->Draw(hDC, rcScaleIcon);
				}
			}

			//�����鴦��ѡ������,��ѡ������������
			if (1 == charrange.cpMax - charrange.cpMin)
			{
				if (reObject.cp == charrange.cpMin)
				{
					if (bNeedClip)
					{
						HPEN hPen = ::CreatePen(PS_ALTERNATE|PS_COSMETIC, 1, 0);
						HPEN hOldPen = (HPEN)::SelectObject(hDC, hPen);

						//���Ͻ�--->���Ͻ�
						if (rcClip.top > rcClient.top)
						{
							::MoveToEx(hDC, max(rcClip.left,rcClient.left), rcClip.top, NULL);
							::LineTo(hDC, min(rcClip.right,rcClient.right), rcClip.top);
						}

						//���Ͻ�--->���½�
						if (rcClip.right < rcClient.right)
						{
							::MoveToEx(hDC, rcClip.right, max(rcClip.top,rcClient.top), NULL);
							::LineTo(hDC, rcClip.right, min(rcClip.bottom,rcClient.bottom));
						}

						//���½�--->���½�
						if (rcClip.bottom < rcClient.bottom)
						{
							::MoveToEx(hDC, min(rcClip.right, rcClient.right), rcClip.bottom, NULL);
							::LineTo(hDC, max(rcClip.left, rcClient.left), rcClip.bottom);
						}

						//���½�--->���Ͻ�
						if (rcClip.left >= rcClient.left)
						{
							::MoveToEx(hDC, rcClip.left, min(rcClip.bottom,rcClient.bottom), NULL);
							::LineTo(hDC, rcClip.left, max(rcClip.top,rcClient.top));
						}

						::SelectObject(hDC, hOldPen);
						::DeleteObject(hPen);
					}
					else
					{
						HBRUSH hbrush = ::CreateSolidBrush(0);
						::FrameRect(hDC, &rcPaint, hbrush);
						::DeleteObject(hbrush);
					}
				}
			}
			else if (charrange.cpMax - charrange.cpMin > 1)
			{
				if (reObject.cp >= charrange.cpMin
					&& reObject.cp < charrange.cpMax)
				{
					::InvertRect(hDC, bNeedClip?&rcClip:&rcPaint);
				}
			}
		}
	}

	//���ø���ole����ɼ�״̬
	RichOleMap::iterator it_ole = m_richOleMap.begin();
	for (; it_ole != m_richOleMap.end(); ++it_ole)
	{
		if (it_ole->second.pProcesser)
		{
			it_ole->second.pProcesser->SyncVisible();
		}
	}

	//����ͼƬ���Ű�ť״̬
	if (bResetScaleBtnState)
	{
		m_dwHostScaleButton = -1;
	}

	m_bPainting = false;

	return S_OK;
}

bool CUIShowRichEdit::OnHitTestExtraElement(UINT nHitMessage, CPoint& pt)
{
    CRect rcResultOle(0,0,0,0);
	int nEleIndex = GetExtraElementByPoint(pt, rcResultOle);
	if (-1 == nEleIndex)
	{
		return false;
	}

    DWORD dwResultOleID = GetExtraElementOleID(nEleIndex);

    BOOL bRetInvalidate = FALSE;
    BOOL bSetHandCuror = FALSE;
    BOOL bHitRet = FALSE;
    switch (nHitMessage)
    {
    case WM_LBUTTONUP:
        {
            BOOL bMouse = FALSE;
            CRichElementBase* pOleLButtonUp = NULL;
            if (dwResultOleID != -1)
            {
                IOleProcesser* pOleProsser = GetExtralOleControl(dwResultOleID);
                if (pOleProsser && pOleProsser->GetType() == OleProcesser_Control)
                {
                    bHitRet = TRUE;

                    CIMControlProcesser* pOleControl = (CIMControlProcesser*)pOleProsser;

                    CPoint ptHitOle = pt;
                    ptHitOle.Offset(-rcResultOle.left, -rcResultOle.top);

                    CRichElementBase* pOleMouseLeave = NULL;
                    pOleControl->OnLButtonUp(ptHitOle, bRetInvalidate, &pOleLButtonUp, &pOleMouseLeave);

                    if (pOleMouseLeave)
                    {
                        OnMouseLeaveOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
                            pOleMouseLeave, pOleControl->GetUserData());
                    }
                    if (pOleLButtonUp)
                    {
                        if (pOleLButtonUp->IsDisposeMouse() && 
                            pOleLButtonUp->IsEnabled() &&
                            pOleLButtonUp->GetParentElement())
                        {
                            bMouse = TRUE;
                        }

                        OnLButtonUpOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
                            pOleLButtonUp, pOleControl->GetUserData());
                    }
                }
            }

            //�������
            if (!m_bHasCaptureState && bMouse)
            {
                bSetHandCuror = TRUE;
            }
        }
        break;
    case WM_RBUTTONUP:
        {
            if (dwResultOleID != -1)
            {
                IOleProcesser* pOleProsser = GetExtralOleControl(dwResultOleID);
                if (pOleProsser && pOleProsser->GetType() == OleProcesser_Control)
                {
					CIMControlProcesser* pOleControl = (CIMControlProcesser*)pOleProsser;

					CPoint ptHitOle = pt;
					ptHitOle.Offset(-rcResultOle.left, -rcResultOle.top);

					CRichElementBase* pOleLButtonDown = NULL;
					CRichElementBase* pOleMouseLeave = NULL;
					pOleControl->OnLButtonDown(ptHitOle, bRetInvalidate, &pOleLButtonDown, &pOleMouseLeave);

					if (pOleLButtonDown)
					{
						bHitRet = TRUE;
						OnRButtonUpOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
							pOleLButtonDown, pOleControl->GetUserData());
					}

					bHitRet = pOleLButtonDown ? TRUE : FALSE;
                }
            }
        }
        break;
    case WM_MOUSEMOVE:
        {
            //MouseLeave
            if (dwResultOleID != m_dwMouseHotOleID && m_dwMouseHotOleID != -1)
            {
                IOleProcesser* pOleMouseLeave = GetExtralOleControl(m_dwMouseHotOleID);
                if (pOleMouseLeave && pOleMouseLeave->GetType() == OleProcesser_Control)
                {
                    CIMControlProcesser* pOleControl = (CIMControlProcesser*)pOleMouseLeave;

                    CRichElementBase* pRetElement = NULL;
                    pOleControl->OnMouseLeave(bRetInvalidate, &pRetElement);

                    if (pRetElement)
                    {
                        OnMouseLeaveOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
                            pRetElement, pOleControl->GetUserData());
                    }
                }
            }

            //����MouseHot��
            m_dwMouseHotOleID = dwResultOleID;

            //MouseEnter
            CRichElementBase* pRetHitElement = NULL;
            if (m_dwMouseHotOleID != -1)
            {
                IOleProcesser* pOleMouseHot = GetExtralOleControl(m_dwMouseHotOleID);
                if (pOleMouseHot && pOleMouseHot->GetType() == OleProcesser_Control)
                {
                    bHitRet = TRUE;

                    CIMControlProcesser* pOleControl = (CIMControlProcesser*)pOleMouseHot;

                    CPoint ptHitOle = pt;
                    ptHitOle.Offset(-rcResultOle.left, -rcResultOle.top);

                    CRichElementBase* pRetHotElement = NULL;
                    CRichElementBase* pRetLeaveElement = NULL;
                    pOleControl->OnMouseMove(ptHitOle, bRetInvalidate, &pRetHotElement, &pRetLeaveElement, &pRetHitElement);

                    if (pRetLeaveElement)
                    {
                        OnMouseLeaveOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
                            pRetLeaveElement, pOleControl->GetUserData());
                    }
                    if (pRetHotElement)
                    {
                        OnMouseEnterOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
                            pRetHotElement, pOleControl->GetUserData());
                    }
                }
            }

            //�������
            while (pRetHitElement)
            {
                if (pRetHitElement->IsDisposeMouse() && 
                    pRetHitElement->IsEnabled())
                {
                    break;
                }

                pRetHitElement = pRetHitElement->GetParentElement();
            }
            if (!m_bHasCaptureState && pRetHitElement)
            {
                bSetHandCuror = TRUE;
            }
        }
        break;
    case WM_LBUTTONDOWN:
        {
            CRichElementBase* pOleLButtonDown = NULL;
            if (dwResultOleID != -1)
            {
                IOleProcesser* pOleProsser = GetExtralOleControl(dwResultOleID);
                if (pOleProsser && pOleProsser->GetType() == OleProcesser_Control)
                {
                    bHitRet = FALSE;

                    CIMControlProcesser* pOleControl = (CIMControlProcesser*)pOleProsser;

                    CPoint ptHitOle = pt;
                    ptHitOle.Offset(-rcResultOle.left, -rcResultOle.top);

                    CRichElementBase* pOleMouseLeave = NULL;
                    pOleControl->OnLButtonDown(ptHitOle, bRetInvalidate, &pOleLButtonDown, &pOleMouseLeave);

                    if (pOleMouseLeave)
                    {
                        OnMouseLeaveOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
                            pOleMouseLeave, pOleControl->GetUserData());
                    }
                    if (pOleLButtonDown)
                    {
                        bHitRet = TRUE;
                        OnLButtonDownOleControlElement(dwResultOleID, pOleControl->GetControlElementName(),
                            pOleLButtonDown, pOleControl->GetUserData());
                    }
                }
            }

            //�������
            while (pOleLButtonDown)
            {
                if (pOleLButtonDown->IsDisposeMouse() && 
                    pOleLButtonDown->IsEnabled())
                {
                    break;
                }

                pOleLButtonDown = pOleLButtonDown->GetParentElement();
            }
            if (pOleLButtonDown)
            {
                bSetHandCuror = TRUE;
            }
        }
        break;
    case WM_RBUTTONDOWN:
        {
			// do nothing
        }
        break;
    case WM_SETCURSOR:
        {
            //do nothing
        }
        break;
    default:
        break;
    }

    if (bSetHandCuror)
    {
        if (NULL == m_hCursorLink)
        {
            m_hCursorLink = ::LoadCursor(NULL, IDC_HAND);
        }
        if (m_hCursorLink)
        {
            ::SetCursor(m_hCursorLink);
        }
    }

    if (bRetInvalidate)
    {
        DirectRedraw2(NULL);
    }

    return bHitRet ? true : false;
}

int CUIShowRichEdit::GetExtraElementByPoint(CPoint& pt, CRect& rcResultOle)
{
	int nExtraEleCount = m_ExtraEleColl.size();
	if (nExtraEleCount <= 0)
	{
		return -1;
	}

    rcResultOle.SetRectEmpty();
	RECT rcClient = GetRect();

	int nSomeDrawEleIndex = GetExtraElementInRect(rcClient, rcClient);
	if (-1 == nSomeDrawEleIndex)
	{
		return -1;
	}

	if (nSomeDrawEleIndex >= nExtraEleCount)
	{
		return -1;
	}

	//���ϱ���ƥ��
	CRect rcElement(0,0,0,0);
	for (int i = nSomeDrawEleIndex; i >= 0; --i)
	{
		rcElement = GetExtraElementRect(i, rcClient);
		if (rcElement.top > rcClient.bottom || rcElement.bottom < rcClient.top || 
			rcElement.left > rcClient.right || rcElement.right < rcClient.left)
		{
			break;
		}

		if (rcElement.PtInRect(pt))
		{
			rcResultOle.left = rcElement.left;
			rcResultOle.right = rcElement.right;
			rcResultOle.top = rcElement.top;
			rcResultOle.bottom = rcElement.bottom;
			return i;
		}
	}

	//���±���ƥ��
	for (int i = nSomeDrawEleIndex + 1; i < nExtraEleCount; ++i)
	{
		rcElement = GetExtraElementRect(i, rcClient);
		if (rcElement.top > rcClient.bottom || rcElement.bottom < rcClient.top || 
			rcElement.left > rcClient.right || rcElement.right < rcClient.left)
		{
			break;
		}

		if (rcElement.PtInRect(pt))
		{
            rcResultOle.left = rcElement.left;
            rcResultOle.right = rcElement.right;
            rcResultOle.top = rcElement.top;
            rcResultOle.bottom = rcElement.bottom;

			return i;
		}
	}

	return -1;
}

LRESULT CUIShowRichEdit::DrawExtraElement(HDC hDC, const RECT& rcClient, const RECT& rcUpdate)
{
	int nExtraEleCount = m_ExtraEleColl.size();
	if (nExtraEleCount <= 0)
	{
		return -1;
	}

	RECT rcDraw = rcClient;

	//���ٶ�λһ���ڿɼ��������չԪ��
	int nSomeDrawEleIndex = GetExtraElementInRect(rcDraw, rcDraw);
	if (-1 == nSomeDrawEleIndex)
	{
		return -1;
	}

	if (nSomeDrawEleIndex >= nExtraEleCount)
	{
		return -1;
	}

	RECT rcElement, rcClip;
	memset(&rcElement, 0, sizeof(rcElement));
	memset(&rcClip, 0, sizeof(rcClip));

	//�Զ�λ��Ԫ��Ϊ���,����׷������һ���ɼ���չԪ��
	//��ע:��չԪ�����ڴ����ص���Ƕ�׹�ϵ,���Ի���ʱ��Ҫ�����ϸ��˳��,�������»���
	int nDrawBeginIndex = nSomeDrawEleIndex;
	int nUpDelta = 0;
	for (int i = nSomeDrawEleIndex; i >= 0; --i)
	{
		rcElement = GetExtraElementRect(i, rcClient);

		if (rcElement.top > rcDraw.bottom || rcElement.bottom < rcDraw.top || 
			rcElement.left > rcDraw.right || rcElement.right < rcDraw.left)
		{
			//���϶�׷��5��Ԫ��,����A����B,A��B֮ǰ,B��A���ϰ벿��,A�°벿���ڻ�������,��Bû�������е����
			if (nUpDelta >= 5)
			{
				break;
			}
			nUpDelta += 1;
		}

		nDrawBeginIndex = i;
	}

	//�����ϸ��˳��,�������»�����չԪ��
	int nDownDelta = 0;
	for (int i = nDrawBeginIndex; i < nExtraEleCount; ++i)
	{
		rcElement = GetExtraElementRect(i, rcClient);

		if (rcElement.top > rcDraw.bottom || rcElement.bottom < rcDraw.top || 
			rcElement.left > rcDraw.right || rcElement.right < rcDraw.left)
		{
			//���¶�׷��5��Ԫ��,����A����B,A��B֮ǰ,B��A���°벿��,A�ϰ벿���ڻ�������,��Bû�������е����
			if (nDownDelta >= 5 + nUpDelta)
			{
				break;
			}
			nDownDelta += 1;
		}
		else
		{
			nDownDelta = 0;

			bool bNeedClip = false;
			if (rcElement.left < rcDraw.left || rcElement.right > rcDraw.right ||
				rcElement.top < rcDraw.top || rcElement.bottom > rcDraw.bottom)
			{
				bNeedClip = true;
				rcClip.left = max(rcElement.left, rcDraw.left);
				rcClip.right = min(rcElement.right, rcDraw.right);
				rcClip.top = max(rcElement.top, rcDraw.top);
				rcClip.bottom = min(rcElement.bottom, rcDraw.bottom);
			}

			UpdateExtraElementAlign(i, rcClient);

            ExtralOleControlMap::iterator it_ole = m_extraOleControlMap.find(m_ExtraEleColl[i].GetOleID());
            if (it_ole != m_extraOleControlMap.end() && it_ole->second)
            {
                it_ole->second->SetSize(rcElement.right - rcElement.left, rcElement.bottom - rcElement.top);
                it_ole->second->OnPaint(hDC, &rcElement, m_bExtraPlayAni, m_uAniFrameTick, bNeedClip?&rcClip:NULL, false);
            }			
		}
	}

	return S_OK;
}

int CUIShowRichEdit::GetExtraElementInRect(const RECT& rcClip, const RECT& rcClient)
{
	int nExtraEleCount = m_ExtraEleColl.size();
	if (nExtraEleCount <= 0)
	{
		return -1;
	}

	//���ֱ�����������λ
	//Ϊ���⼫�����, �˴�����ƽ�������ȶ���2�ַ��������ұȽϺ���
	int nHalfPathBegin = 0;
	int nHalfPathEnd = nExtraEleCount - 1;
	int nLineCount =m_FreeWindowlessRE.GetLineCount();
	CRect rcOffset(0,0,0,0);

	//���ֲ���ĩβ��������Ļ�Ϸ�, ������������ν�Ĳ���
	CRect rcElement = GetExtraElementRect(nHalfPathEnd, rcClient);
	if (rcElement.bottom <= rcClip.top)
	{
		return -1;
	}

	//ĩβ��������Ļ��, ������������ν�Ĳ���
	if (rcElement.top < rcClip.bottom && rcElement.bottom > rcClip.top && 
		rcElement.left < rcClip.right && rcElement.right > rcClip.left)
	{
		return nHalfPathEnd;
	}

	//���ֲ�����ʼ��������Ļ�·�, ������������ν�Ĳ���
	rcElement = GetExtraElementRect(nHalfPathBegin, rcClient);
	if (rcElement.top >= rcClip.bottom)
	{
		return -1;
	}

	//��ʼ��������Ļ��, ������������ν�Ĳ���
	if (rcElement.top < rcClip.bottom && rcElement.bottom > rcClip.top && 
		rcElement.left < rcClip.right && rcElement.right > rcClip.left)
	{
		return nHalfPathBegin;
	}

	//��ʼ���ֲ��ҹ���
	int nVisibleIndex = 0;
	while (nHalfPathBegin + 1 < nHalfPathEnd)
	{
		int nHalfPathNew = nHalfPathBegin + (nHalfPathEnd - nHalfPathBegin)/2;

		rcElement = GetExtraElementRect(nHalfPathNew, rcClient);
		if (rcElement.top < rcClip.bottom && rcElement.bottom > rcClip.top && 
			rcElement.left < rcClip.right && rcElement.right > rcClip.left)
		{
			return nHalfPathNew;
		}
		else
		{
			//���ֽڵ㴦��ole�����ڵ�ǰ��Ļ�·�
			if (rcElement.top >= rcClip.bottom)
			{
				nHalfPathEnd = nHalfPathNew;
			}
			//���ֽڵ��ole�����ڵ�ǰ��Ļ�Ϸ�
			else if (rcElement.bottom <= rcClip.top)
			{
				nHalfPathBegin = nHalfPathNew;
			}
			else
			{
				//������������ߵ�����
				return -1;
			}
		}
	}

	return -1;
}

RECT CUIShowRichEdit::GetExtraElementRect(int nEleIndex, const RECT& rcClient)
{
	RECT rcElement;
	memset(&rcElement, 0, sizeof(rcElement));
	if (nEleIndex < 0)
	{
		return rcElement;
	}

	if (nEleIndex >= (int)m_ExtraEleColl.size())
	{
		return rcElement;
	}

	//Ԫ��ƫ��
	CRect rcOffset = m_ExtraEleColl[nEleIndex].GetOffset();

	//Ԫ�ر߾�
	int nLeftClientIndent = m_ExtraEleColl[nEleIndex].GetLeftClientIndent();
	int nRightClientIndent = m_ExtraEleColl[nEleIndex].GetRightClientIndent();

	//Ԫ��λ��
	if (m_ExtraEleColl[nEleIndex].IsAutoSize())
	{
		rcElement.left = -1;
		rcElement.top = -1;
		rcElement.right = -1;
		rcElement.bottom = -1;

		int nLineCount = m_FreeWindowlessRE.GetLineCount();

		int nBeginLine = m_FreeWindowlessRE.LineFromChar(m_ExtraEleColl[nEleIndex].GetBeginCharIndex());
		int nEndLine = m_FreeWindowlessRE.LineFromChar(m_ExtraEleColl[nEleIndex].GetEndCharIndex());
		for (int i = nBeginLine; i <= nEndLine; ++i)
		{
			if (i >= nLineCount)
			{
				int nCurLineFirstChar = m_FreeWindowlessRE.LineIndex(i);
				if (nCurLineFirstChar < m_ExtraEleColl[nEleIndex].GetBeginCharIndex())
				{
					nCurLineFirstChar = m_ExtraEleColl[nEleIndex].GetBeginCharIndex();
				}

				if (nCurLineFirstChar != -1)
				{
					CPoint ptBeginPos = m_FreeWindowlessRE.PosFromChar(nCurLineFirstChar);
					if (-1 == rcElement.left || rcElement.left > ptBeginPos.x)
					{
						rcElement.left = ptBeginPos.x;
					}
					if (-1 == rcElement.top || rcElement.top > ptBeginPos.y)
					{
						rcElement.top = ptBeginPos.y;
					}
				}

				if (-1 == rcElement.right || rcElement.right < rcClient.right)
				{
					rcElement.right = rcClient.right;
				}

				if (-1 == rcElement.bottom || rcElement.bottom < rcClient.bottom)
				{
					rcElement.bottom = rcClient.bottom;
				}
			}
			else
			{
				int nCurLineFirstChar = m_FreeWindowlessRE.LineIndex(i);
				if (nCurLineFirstChar < m_ExtraEleColl[nEleIndex].GetBeginCharIndex())
				{
					nCurLineFirstChar = m_ExtraEleColl[nEleIndex].GetBeginCharIndex();
				}
				if (nCurLineFirstChar != -1)
				{
					CPoint ptBeginPos = m_FreeWindowlessRE.PosFromChar(nCurLineFirstChar);
					if (-1 == rcElement.left || rcElement.left > ptBeginPos.x)
					{
						rcElement.left = ptBeginPos.x;
					}
					if (-1 == rcElement.top || rcElement.top > ptBeginPos.y)
					{
						rcElement.top = ptBeginPos.y;
					}
				}

				int nNextLineFirstChar = m_FreeWindowlessRE.LineIndex(i + 1);
				if (nNextLineFirstChar != -1)
				{
					CPoint ptNextLinePos = m_FreeWindowlessRE.PosFromChar(nNextLineFirstChar);
					if (-1 == rcElement.bottom || rcElement.bottom < ptNextLinePos.y)
					{
						rcElement.bottom = ptNextLinePos.y;
					}
				}

				int nCurLineEndChar = nNextLineFirstChar - 1;
				if (nCurLineEndChar != -1)
				{
					WTL::CString strEndChar;
					strEndChar.GetBuffer(10);
					m_FreeWindowlessRE.GetTextRange(nCurLineEndChar, nCurLineEndChar + 1, strEndChar);
					strEndChar.ReleaseBuffer();
					if (strEndChar != _T("\r") && strEndChar != _T("\r\n") && 
						strEndChar != _T("\n"))
					{
						rcElement.right = rcClient.right;
					}
					else
					{
						CPoint ptEndPos = m_FreeWindowlessRE.PosFromChar(nCurLineEndChar);
						if (-1 == rcElement.right || rcElement.right < ptEndPos.x)
						{
							rcElement.right = ptEndPos.x;
						}
					}
				}
			}
		}

		if (rcElement.left < rcClient.left + nLeftClientIndent || m_ExtraEleColl[nEleIndex].IsFullFillLayout())
		{
			rcElement.left = rcClient.left + nLeftClientIndent;
		}
		rcElement.left += rcOffset.left;
		if (rcElement.left < rcClient.left)
		{
			rcElement.left = rcClient.left;
		}

		if (rcElement.right + nRightClientIndent > rcClient.right || m_ExtraEleColl[nEleIndex].IsFullFillLayout())
		{
			rcElement.right = rcClient.right - nRightClientIndent;
		}
		rcElement.right += rcOffset.right;
		if (rcElement.right > rcClient.right)
		{
			rcElement.right = rcClient.right;
		}

		rcElement.top += rcOffset.top;
		rcElement.bottom += rcOffset.bottom;
	}
	else
	{
		CPoint ptBeginPos = m_FreeWindowlessRE.PosFromChar(m_ExtraEleColl[nEleIndex].GetBeginCharIndex());

		int nOffsetYBase = 0;
		E_RICHEDIT_ELEMENT_VALIGN eValign = m_ExtraEleColl[nEleIndex].GetVAlign();
		switch (eValign)
		{
		case RICHEDIT_ELEMENT_VCENTER:
			{
				int nCurLine = m_FreeWindowlessRE.LineFromChar(m_ExtraEleColl[nEleIndex].GetBeginCharIndex());
				if (nCurLine != -1)
				{
					int nLineHeight = 30;
					int nNextLineFirstChar = m_FreeWindowlessRE.LineIndex(nCurLine + 1);
					if (nNextLineFirstChar != -1)
					{
						nLineHeight = m_FreeWindowlessRE.PosFromChar(nNextLineFirstChar).y - ptBeginPos.y;
					}

					nOffsetYBase = nLineHeight/2 - m_ExtraEleColl[nEleIndex].GetHeight()/2;
				}
			}
			break;
		case RICHEDIT_ELEMENT_VBOTTOM:
			{
				int nCurLine = m_FreeWindowlessRE.LineFromChar(m_ExtraEleColl[nEleIndex].GetBeginCharIndex());
				if (nCurLine != -1)
				{
					int nLineHeight = 30;
					int nNextLineFirstChar = m_FreeWindowlessRE.LineIndex(nCurLine + 1);
					if (nNextLineFirstChar != -1)
					{
						nLineHeight = m_FreeWindowlessRE.PosFromChar(nNextLineFirstChar).y - ptBeginPos.y;
					}

					nOffsetYBase = nLineHeight - m_ExtraEleColl[nEleIndex].GetHeight();
				}
			}
			break;
		default:
			{
				nOffsetYBase = 0;
			}
			break;
		}

		if (rcElement.left < rcClient.left + nLeftClientIndent)
		{
			rcElement.left = rcClient.left + nLeftClientIndent;
		}
		rcElement.left = ptBeginPos.x + rcOffset.left;
		if (rcElement.left < rcClient.left)
		{
			rcElement.left = rcClient.left;
		}

		if (rcElement.right + nRightClientIndent > rcClient.right)
		{
			rcElement.right = rcClient.right - nRightClientIndent;
		}
		rcElement.right = rcElement.left + m_ExtraEleColl[nEleIndex].GetWidth();
		if (rcElement.right > rcClient.right)
		{
			rcElement.right = rcClient.right;
		}

		rcElement.top = ptBeginPos.y + nOffsetYBase + rcOffset.top;
		rcElement.bottom = rcElement.top + m_ExtraEleColl[nEleIndex].GetHeight();
	}

	//������
	int nWidth = rcElement.right - rcElement.left;
	if (m_ExtraEleColl[nEleIndex].GetMinWidth() > nWidth)
	{
		if (PFA_RIGHT == m_ExtraEleColl[nEleIndex].GetREContentAlign())
		{
			rcElement.left = rcElement.right - m_ExtraEleColl[nEleIndex].GetMinWidth();
		}
		else if (PFA_CENTER == m_ExtraEleColl[nEleIndex].GetREContentAlign())
		{
			int nCenterX = (rcElement.right + rcElement.left) / 2;
			rcElement.left = nCenterX - m_ExtraEleColl[nEleIndex].GetMinWidth() / 2;
			rcElement.right = nCenterX + m_ExtraEleColl[nEleIndex].GetMinWidth() / 2;
		}
		else
		{
			rcElement.right = rcElement.left + m_ExtraEleColl[nEleIndex].GetMinWidth();
		}
	}
	else if (m_ExtraEleColl[nEleIndex].GetMaxWidth() < nWidth)
	{
		if (PFA_RIGHT == m_ExtraEleColl[nEleIndex].GetREContentAlign())
		{
			rcElement.left = rcElement.right - m_ExtraEleColl[nEleIndex].GetMaxWidth();
		}
		else if (PFA_CENTER == m_ExtraEleColl[nEleIndex].GetREContentAlign())
		{
			int nCenterX = (rcElement.right + rcElement.left) / 2;
			rcElement.left = nCenterX - m_ExtraEleColl[nEleIndex].GetMaxWidth() / 2;
			rcElement.right = nCenterX + m_ExtraEleColl[nEleIndex].GetMaxWidth() / 2;
		}
		else
		{
			rcElement.right = rcElement.left + m_ExtraEleColl[nEleIndex].GetMaxWidth();
		}
	}

	//���߶�
	int nHeight = rcElement.bottom - rcElement.top;
	if (m_ExtraEleColl[nEleIndex].GetMinHeight() > nHeight)
	{
		rcElement.bottom = rcElement.top + m_ExtraEleColl[nEleIndex].GetMinHeight();
	}
	else if (m_ExtraEleColl[nEleIndex].GetMaxHeight() < nHeight)
	{
		rcElement.bottom = rcElement.top + m_ExtraEleColl[nEleIndex].GetMaxHeight();
	}

	return rcElement;
}

void CUIShowRichEdit::CheckExtraElementByAdd(LONG lInserChar, LONG lCharCount, bool bReplaceMode)
{
	int nExtraEleCount = m_ExtraEleColl.size();
	if (nExtraEleCount <= 0)
	{
		return;
	}

	//���´�������չԪ�ص���ʼλ��
	for (int i = 0; i < (int)m_vecExtraEleInsertBegin.size(); ++i)
	{
		if (m_vecExtraEleInsertBegin[i].nInsertPosBegin != -1)
		{
			if (m_vecExtraEleInsertBegin[i].nInsertPosBegin > lInserChar)
			{
				m_vecExtraEleInsertBegin[i].nInsertPosBegin += lCharCount;
			}
		}
	}    

	//�����Ѳ�����չԪ�ص���ʼ�ͽ���λ��
	for (int i = 0; i < nExtraEleCount; ++i)
	{
		int nBeginCharIndex = m_ExtraEleColl[i].GetBeginCharIndex();
		if (nBeginCharIndex > lInserChar)
		{
			m_ExtraEleColl[i].SetBeginCharIndex(nBeginCharIndex + lCharCount);
		}
		else if (nBeginCharIndex == lInserChar)
		{
			if (!m_ExtraEleColl[i].GetInsertingFlag() && !bReplaceMode)
			{
				m_ExtraEleColl[i].SetBeginCharIndex(nBeginCharIndex + lCharCount);
			}
		}

		int nEndCharIndex = m_ExtraEleColl[i].GetEndCharIndex();
		if (nEndCharIndex > lInserChar)
		{
			m_ExtraEleColl[i].SetEndCharIndex(nEndCharIndex + lCharCount);
		}
		else if (nEndCharIndex == lInserChar)
		{
			if (!m_ExtraEleColl[i].GetInsertingFlag() && !bReplaceMode)
			{
				m_ExtraEleColl[i].SetEndCharIndex(nEndCharIndex + lCharCount);
			}
		}
	}
}

void CUIShowRichEdit::CheckExtraElementByDel(LONG lStartChar, LONG lEndChar)
{
	int nExtraEleCount = m_ExtraEleColl.size();
	if (nExtraEleCount <= 0)
	{
		return;
	}

	//���´�������չԪ����ʼλ��
	for (int i = 0; i < (int)m_vecExtraEleInsertBegin.size(); ++i)
	{
		if (m_vecExtraEleInsertBegin[i].nInsertPosBegin != -1)
		{
			if (m_vecExtraEleInsertBegin[i].nInsertPosBegin >= lStartChar && m_vecExtraEleInsertBegin[i].nInsertPosBegin <= lEndChar)
			{
				m_vecExtraEleInsertBegin[i].nInsertPosBegin = -1;
			}
			else if (m_vecExtraEleInsertBegin[i].nInsertPosBegin >= lEndChar)
			{
				m_vecExtraEleInsertBegin[i].nInsertPosBegin -= (lEndChar - lStartChar + 1);
			}
		}
	}

	//������������Ч������, ɾ���ڵ�ʱ��Ҫע������
	int nIndex = 0;
	for (int i = 0; i < nExtraEleCount; ++i)
	{
		//Ԫ����ȫ����ɾ��������
		if (m_ExtraEleColl[i].GetBeginCharIndex() >= lStartChar && 
			m_ExtraEleColl[i].GetEndCharIndex() <= lEndChar)
		{
			UINT uDelEleID = m_ExtraEleColl[i].GetOleID();
            ExtralOleControlMap::iterator it_ole = m_extraOleControlMap.find(uDelEleID);
            if (it_ole != m_extraOleControlMap.end())
            {
                IOleProcesser* pProcesser = it_ole->second;
                SAFE_DELETE(pProcesser);
                m_extraOleControlMap.erase(it_ole);
            }
			m_ExtraEleColl[i].Destroy();

			//���´��ڲ���״̬����չԪ��λ������
			InsertingExtraEleList::iterator it_inserting = m_insertProcess.insertingExtraEleList.begin();
			for (; it_inserting != m_insertProcess.insertingExtraEleList.end();)
			{
				if ((*it_inserting) == i)
				{
					m_insertProcess.insertingExtraEleList.erase(it_inserting++);
					continue;
				}

				if ((*it_inserting) > i)
				{
					(*it_inserting) -= 1;
				}
			}

			DUICtrlNotifyInfo UINotifyInfo;
			memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
			UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_OLE_CONTROL_DEL;
			UINotifyInfo.lParam1 = (DWORD_PTR)(this);
			UINotifyInfo.lParam2 = (DWORD_PTR)uDelEleID;
			::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
		}
		//Ԫ����ȫ����ɾ������
		else if (m_ExtraEleColl[i].GetBeginCharIndex() <= lStartChar && 
			m_ExtraEleColl[i].GetEndCharIndex() >= lEndChar)
		{
			if (nIndex < i)
			{
				m_ExtraEleColl[nIndex] = m_ExtraEleColl[i];
			}

			LONG nNewEndCharIndex = m_ExtraEleColl[nIndex].GetEndCharIndex() - (lEndChar - lStartChar + 1);
			if (nNewEndCharIndex < m_ExtraEleColl[i].GetBeginCharIndex())
			{
				nNewEndCharIndex = m_ExtraEleColl[i].GetBeginCharIndex();
			}
			m_ExtraEleColl[nIndex].SetEndCharIndex(nNewEndCharIndex);

			//���¼��㲼��
			m_ExtraEleColl[nIndex].ResetREAlignResult();

			nIndex += 1;
		}
		//Ԫ����ɾ�������Ϸ��ཻ
		else if (m_ExtraEleColl[i].GetBeginCharIndex() <= lStartChar && 
			m_ExtraEleColl[i].GetEndCharIndex() >= lStartChar)
		{
			if (nIndex < i)
			{
				m_ExtraEleColl[nIndex] = m_ExtraEleColl[i];
			}

			LONG nNewEndCharIndex = lStartChar - 1;
			if (nNewEndCharIndex < m_ExtraEleColl[i].GetBeginCharIndex())
			{
				nNewEndCharIndex = m_ExtraEleColl[i].GetBeginCharIndex();
			}
			m_ExtraEleColl[nIndex].SetEndCharIndex(nNewEndCharIndex);

			//���¼��㲼��
			m_ExtraEleColl[nIndex].ResetREAlignResult();

			nIndex += 1;
		}
		//Ԫ����ɾ�������·��ཻ
		else if (m_ExtraEleColl[i].GetBeginCharIndex() <= lEndChar && 
			m_ExtraEleColl[i].GetEndCharIndex() >= lEndChar)
		{
			if (nIndex < i)
			{
				m_ExtraEleColl[nIndex] = m_ExtraEleColl[i];
			}

			LONG nNewBeginCharIndex = lStartChar;
			if (nNewBeginCharIndex < 0)
			{
				nNewBeginCharIndex = 0;
			}

			LONG nNewEndCharIndex = m_ExtraEleColl[nIndex].GetEndCharIndex() - (lEndChar - lStartChar + 1);
			if (nNewEndCharIndex < nNewBeginCharIndex)
			{
				nNewEndCharIndex = nNewBeginCharIndex;
			}

			m_ExtraEleColl[nIndex].SetBeginCharIndex(nNewBeginCharIndex);
			m_ExtraEleColl[nIndex].SetEndCharIndex(nNewEndCharIndex);

			//���¼��㲼��
			m_ExtraEleColl[nIndex].ResetREAlignResult();

			nIndex += 1;
		}
		//Ԫ����ɾ��������ȫ���ཻ
		else
		{
			if (nIndex < i)
			{
				m_ExtraEleColl[nIndex] = m_ExtraEleColl[i];
			}

			LONG nNewBeginCharIndex = m_ExtraEleColl[nIndex].GetBeginCharIndex();
			LONG nNewEndCharIndex = m_ExtraEleColl[nIndex].GetEndCharIndex();
			if (nNewBeginCharIndex > lEndChar)
			{
				nNewBeginCharIndex -= (lEndChar - lStartChar + 1);
				nNewEndCharIndex -= (lEndChar - lStartChar + 1);

				m_ExtraEleColl[nIndex].SetBeginCharIndex(nNewBeginCharIndex);
				m_ExtraEleColl[nIndex].SetEndCharIndex(nNewEndCharIndex);
			}

			nIndex += 1;
		}
	}

	//�ı�������С, ���ڴ�ռ���Ȼ����
	if (nIndex < nExtraEleCount)
	{
		m_ExtraEleColl.erase(m_ExtraEleColl.begin() + nIndex, m_ExtraEleColl.end());
	}
}

void CUIShowRichEdit::DeleteExtraElement(int nIndex)
{
	int nExtraEleCount = m_ExtraEleColl.size();
	if (nExtraEleCount <= 0)
	{
		return;
	}

	std::vector<CExtraElement>::iterator it = m_ExtraEleColl.begin();
	std::advance(it, min(nIndex + 1, nExtraEleCount));
	if (it != m_ExtraEleColl.end())
	{
		UINT uDelEleID = (*it).GetOleID();
        ExtralOleControlMap::iterator it_ole = m_extraOleControlMap.find(uDelEleID);
        if (it_ole != m_extraOleControlMap.end())
        {
            IOleProcesser* pProcesser = it_ole->second;
            SAFE_DELETE(pProcesser);
            m_extraOleControlMap.erase(it_ole);
        }
		(*it).Destroy();
		m_ExtraEleColl.erase(it);

		DUICtrlNotifyInfo UINotifyInfo;
		memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
		UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_OLE_CONTROL_DEL;
		UINotifyInfo.lParam1 = (DWORD_PTR)(this);
		UINotifyInfo.lParam2 = (DWORD_PTR)uDelEleID;
		::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
	}
}

void CUIShowRichEdit::UpdateExtraElementAlign(int nIndex, const RECT& rcClient)
{
	int nExtraEleCount = m_ExtraEleColl.size();
	if (nIndex < 0 || nIndex >= nExtraEleCount)
	{
		return;
	}

	//������չԪ����RichEdit���ݲ���
	//��ע: ���ǵ����ܿ���, ���ֵ�����1���͵�2��ֻ�ڱ�Ҫ�������ִ��
	if (m_ExtraEleColl[nIndex].IsREContentAlignInHalf())
	{
		//��¼ԭѡ������
		LONG nCurSelBegin = 0, nCurSelEnd = 0;
		GetSel(nCurSelBegin, nCurSelEnd);

		//�������ֵ�2��
		UpdateExtraElementAlignStep2(nIndex, rcClient);

		//��ԭԭѡ������
		if (nCurSelBegin != m_ExtraEleColl[nIndex].GetBeginCharIndex() || 
			nCurSelEnd != m_ExtraEleColl[nIndex].GetEndCharIndex())
		{
			SetSel(nCurSelBegin, nCurSelEnd);
		}
	}
	else if (m_ExtraEleColl[nIndex].CheckREAlign(&rcClient))
	{
		//��¼ԭѡ������
		LONG nCurSelBegin = 0, nCurSelEnd = 0;
		GetSel(nCurSelBegin, nCurSelEnd);

		//�������ֵ�1��
		UpdateExtraElementAlignStep1(nIndex, rcClient);

		//�������ֵ�2��
		UpdateExtraElementAlignStep2(nIndex, rcClient);

		//��ԭԭѡ������
		if (nCurSelBegin != m_ExtraEleColl[nIndex].GetBeginCharIndex() || 
			nCurSelEnd != m_ExtraEleColl[nIndex].GetEndCharIndex())
		{
			SetSel(nCurSelBegin, nCurSelEnd);
		}
	}
}

void CUIShowRichEdit::UpdateExtraElememtAlign(const RECT& rcClient)
{
	int nExtraEleCount = m_ExtraEleColl.size();
	if (nExtraEleCount <= 0)
	{
		return;
	}

	//������չԪ����RichEdit���ݲ���
	//��ע: ���ǵ����ܿ���, ���ֵ�����1���͵�2��ֻ�ڱ�Ҫ�������ִ��

	//��¼ԭѡ������
	LONG nCurSelBegin = 0, nCurSelEnd = 0;
	GetSel(nCurSelBegin, nCurSelEnd);

	//������ִ�е�1������
	for (int i = 0; i < nExtraEleCount; ++i)
	{
		if (m_ExtraEleColl[i].CheckREAlign(&rcClient))
		{
			UpdateExtraElementAlignStep1(i, rcClient);
		}
	}

	//�ɼ���ִ�е�2������
	int nSomeDrawEleIndex = GetExtraElementInRect(rcClient, rcClient);
	if (nSomeDrawEleIndex >= 0 && nSomeDrawEleIndex < nExtraEleCount)
	{
		RECT rcElement, rcClip;
		memset(&rcElement, 0, sizeof(rcElement));
		memset(&rcClip, 0, sizeof(rcClip));

		//�������ؿɼ���
		for (int i = nSomeDrawEleIndex; i >= 0; --i)
		{
			rcElement = GetExtraElementRect(i, rcClient);

			if (rcElement.top > rcClient.bottom || rcElement.bottom < rcClient.top || 
				rcElement.left > rcClient.right || rcElement.right < rcClient.left)
			{
				break;
			}

			UpdateExtraElementAlignStep2(i, rcClient);
		}

		//���������ɼ���
		for (int i = nSomeDrawEleIndex + 1; i < nExtraEleCount; ++i)
		{
			rcElement = GetExtraElementRect(i, rcClient);

			if (rcElement.top > rcClient.bottom || rcElement.bottom < rcClient.top || 
				rcElement.left > rcClient.right || rcElement.right < rcClient.left)
			{
				break;
			}

			UpdateExtraElementAlignStep2(i, rcClient);
		}
	}

	//��ԭԭѡ������
	SetSel(nCurSelBegin, nCurSelEnd);
}

void CUIShowRichEdit::UpdateExtraElementAlignStep1(int nIndex, const RECT& rcClient)
{
	int nExtraEleCount = m_ExtraEleColl.size();
	if (nIndex < 0 || nIndex >= nExtraEleCount)
	{
		return;
	}

	if (m_ExtraEleColl[nIndex].GetREContentAlign() != PFA_RIGHT && 
		m_ExtraEleColl[nIndex].GetREContentAlign() != PFA_CENTER)
	{
		return;
	}

	if (m_ExtraEleColl[nIndex].IsREContentAlignInHalf())
	{
		return;
	}

	m_ExtraEleColl[nIndex].SetREContentAlignInHalf(true);

	//////////////////////////////////////////////////////////////////////////////////////////////
	//����ѡ������
	LONG nCurSelBegin = 0, nCurSelEnd = 0;
	GetSel(nCurSelBegin, nCurSelEnd);
	if (nCurSelBegin != m_ExtraEleColl[nIndex].GetBeginCharIndex() || 
		nCurSelEnd != m_ExtraEleColl[nIndex].GetEndCharIndex())
	{
		SetSel(m_ExtraEleColl[nIndex].GetBeginCharIndex(), m_ExtraEleColl[nIndex].GetEndCharIndex());
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	//������Ϊ�Ҷ���
	if (PFA_RIGHT == m_ExtraEleColl[nIndex].GetREContentAlign())
	{
		PARAFORMAT2 paraFormat;
		paraFormat.dwMask = PFM_ALIGNMENT|PFM_STARTINDENT|PFM_RIGHTINDENT;
		paraFormat.wAlignment = PFA_RIGHT;
		paraFormat.dxStartIndent = m_ExtraEleColl[nIndex].GetREContentLeftIndent();
		paraFormat.dxRightIndent = m_ExtraEleColl[nIndex].GetREContentRightIndent();
		SetParaFormat(paraFormat);
	}
	else
	{
		PARAFORMAT2 paraFormat;
		paraFormat.dwMask = PFM_ALIGNMENT|PFM_STARTINDENT|PFM_RIGHTINDENT;
		paraFormat.wAlignment = PFA_CENTER;
		paraFormat.dxStartIndent = m_ExtraEleColl[nIndex].GetREContentLeftIndent();
		paraFormat.dxRightIndent = m_ExtraEleColl[nIndex].GetREContentRightIndent();
		SetParaFormat(paraFormat);
	}
}

void CUIShowRichEdit::UpdateExtraElementAlignStep2(int nIndex, const RECT& rcClient)
{
	int nExtraEleCount = m_ExtraEleColl.size();
	if (nIndex < 0 || nIndex >= nExtraEleCount)
	{
		return;
	}

	if (m_ExtraEleColl[nIndex].GetREContentAlign() != PFA_RIGHT && 
		m_ExtraEleColl[nIndex].GetREContentAlign() != PFA_CENTER)
	{
		return;
	}

	if (!m_ExtraEleColl[nIndex].IsREContentAlignInHalf())
	{
		return;
	}

	m_ExtraEleColl[nIndex].SetREContentAlignInHalf(false);

	//////////////////////////////////////////////////////////////////////////////////////////////
	//����ѡ������
	LONG nCurSelBegin = 0, nCurSelEnd = 0;
	GetSel(nCurSelBegin, nCurSelEnd);
	if (nCurSelBegin != m_ExtraEleColl[nIndex].GetBeginCharIndex() || 
		nCurSelEnd != m_ExtraEleColl[nIndex].GetEndCharIndex())
	{
		SetSel(m_ExtraEleColl[nIndex].GetBeginCharIndex(), m_ExtraEleColl[nIndex].GetEndCharIndex());
	}

	//////////////////////////////////////////////////////////////////////////////////////////////
	//����"�Ҷ���"��"���ж���"������, ���ַ�λ�����ж��Ƿ�ʹ������������
	//��ע:����ʵ�ֵ�Ч����"���������"��"���������", ��֪�Ƿ����������ø��򵥵Ĵ�����ʽ
	do 
	{
		//���е�����²���Ҫ����"���������"��"���������"����
		int nBeginLine = m_FreeWindowlessRE.LineFromChar(m_ExtraEleColl[nIndex].GetBeginCharIndex());
		int nEndLine = m_FreeWindowlessRE.LineFromChar(m_ExtraEleColl[nIndex].GetEndCharIndex());
		if (nBeginLine == nEndLine)
		{
			break;
		}

		//��ȡ����DC
		HDC hDC = ::GetDC(m_hWndDirectUI);
		if (NULL == hDC)
		{
			break;
		}

		//1Ӣ����������ˮƽ��������
		LONG xPerInch = GetDeviceCaps(hDC, LOGPIXELSX);
		if (0 == xPerInch)
		{
			xPerInch = LOGPIXELSX;
		}

		//�ͷ�DC
		::ReleaseDC(m_hWndDirectUI, hDC);

		//ת��������λ
		LONG nLeftMargin = -1;
		for (int i = nBeginLine; i <= nEndLine; ++i)
		{
			int nFirstChar = m_FreeWindowlessRE.LineIndex(i);
			CPoint ptFirstChar = m_FreeWindowlessRE.PosFromChar(nFirstChar);
			if (-1 == nLeftMargin || nLeftMargin > ptFirstChar.x)
			{
				nLeftMargin = ptFirstChar.x;
			}
		}
		LONG nStartIndent = (nLeftMargin - rcClient.left) * LY_PER_INCH / xPerInch;

		//����Ϊ�����
		PARAFORMAT2 paraFormat;
		paraFormat.dwMask = PFM_ALIGNMENT|PFM_OFFSETINDENT|PFM_STARTINDENT|PFM_RIGHTINDENT;
		paraFormat.wAlignment = PFA_LEFT;
		paraFormat.dxStartIndent = nStartIndent;
		paraFormat.dxRightIndent = m_ExtraEleColl[nIndex].GetREContentRightIndent();
		SetParaFormat(paraFormat);

	} while (0);
}

void CUIShowRichEdit::ClearExtraElement(BOOL bNotify)
{
	int nExtraEleCount = m_ExtraEleColl.size();
	if (nExtraEleCount <= 0)
	{
		return;
	}

	//���ò�����չԪ����ʼλ��
	m_vecExtraEleInsertBegin.clear();

    ExtralOleControlMap::iterator it_ole = m_extraOleControlMap.begin();
    for (; it_ole != m_extraOleControlMap.end(); ++it_ole)
    {
        IOleProcesser* pProcesser = it_ole->second;
        SAFE_DELETE(pProcesser);
    }
    m_extraOleControlMap.clear();

	//�����Ѳ�����չԪ��
	for (int i = 0; i < nExtraEleCount; ++i)
	{
		m_ExtraEleColl[i].Destroy();
	}
	m_ExtraEleColl.clear();
}

DWORD CUIShowRichEdit::GetExtraElementOleID(int nElementIndex)
{
    int nExtraEleCount = m_ExtraEleColl.size();
    if (nExtraEleCount <= 0)
    {
        return 0;
    }
    if (nElementIndex < 0 || (nElementIndex > nExtraEleCount - 1))
    {
        return 0;
    }
    return m_ExtraEleColl[nElementIndex].GetOleID();
}

void CUIShowRichEdit::CheckPartByAdd(LONG lInserChar, LONG lCharCount, bool bReplaceMode)
{
    int nExtraEleCount = m_mapMsgPart.size();
    if (nExtraEleCount <= 0)
    {
        return;
    }    

    //�����Ѳ���������ʼ�ͽ���λ��
    for (MsgPartMap::iterator it = m_mapMsgPart.begin(); it != m_mapMsgPart.end(); ++it)
    {
        int nBeginCharIndex = it->second.lCharStart;
        if (nBeginCharIndex >= lInserChar)
        {
            it->second.lCharStart = nBeginCharIndex + lCharCount;
        }

        int nEndCharIndex = it->second.lCharEnd;
        if (nEndCharIndex >= lInserChar)
        {
            it->second.lCharEnd = nEndCharIndex + lCharCount;
        }
    }
}

void CUIShowRichEdit::CheckPartByDel(LONG lStartChar, LONG lEndChar)
{
    int nMsgPartCount = m_mapMsgPart.size();
    if (nMsgPartCount <= 0)
    {
        return;
    }

    int nIndex = 0;
    for (MsgPartMap::iterator it = m_mapMsgPart.begin(); it != m_mapMsgPart.end();)
    {
        if (it->second.lCharStart >= lStartChar && 
            it->second.lCharEnd <= lEndChar)
        {
            it = m_mapMsgPart.erase(it);
        }
        //Ԫ����ȫ����ɾ������
        else if (it->second.lCharStart <= lStartChar && 
            it->second.lCharEnd >= lEndChar)
        {
            LONG nNewEndCharIndex = it->second.lCharEnd - (lEndChar - lStartChar + 1);
            if (nNewEndCharIndex < it->second.lCharStart)
            {
                nNewEndCharIndex = it->second.lCharStart;
            }
            it->second.lCharStart = nNewEndCharIndex;
            
            ++it;
        }
        //Ԫ����ɾ�������Ϸ��ཻ
        else if (it->second.lCharStart <= lStartChar && 
            it->second.lCharEnd >= lStartChar)
        {

            LONG nNewEndCharIndex = lStartChar - 1;
            if (nNewEndCharIndex < it->second.lCharStart)
            {
                nNewEndCharIndex = it->second.lCharStart;
            }

            it->second.lCharEnd = nNewEndCharIndex;

            ++it;
        }
        //Ԫ����ɾ�������·��ཻ
        else if (it->second.lCharStart <= lEndChar && 
            it->second.lCharEnd >= lEndChar)
        {
            LONG nNewBeginCharIndex = lStartChar;
            if (nNewBeginCharIndex < 0)
            {
                nNewBeginCharIndex = 0;
            }

            LONG nNewEndCharIndex = it->second.lCharEnd - (lEndChar - lStartChar + 1);
            if (nNewEndCharIndex < nNewBeginCharIndex)
            {
                nNewEndCharIndex = nNewBeginCharIndex;
            }

            it->second.lCharStart = nNewBeginCharIndex;
            it->second.lCharEnd = nNewEndCharIndex;

            ++it;
        }
        //Ԫ����ɾ��������ȫ���ཻ
        else
        {
            LONG nNewBeginCharIndex = it->second.lCharStart;
            LONG nNewEndCharIndex = it->second.lCharEnd;
            if (nNewBeginCharIndex > lEndChar)
            {
                nNewBeginCharIndex -= (lEndChar - lStartChar + 1);
                nNewEndCharIndex -= (lEndChar - lStartChar + 1);

                it->second.lCharStart = nNewBeginCharIndex;
                it->second.lCharEnd = nNewEndCharIndex;
            }

            ++it;
        }
    }
}

void CUIShowRichEdit::ClearPartElement(BOOL bNotify)
{
    m_mapMsgPart.clear();
}

void CUIShowRichEdit::ClearAllOleEleExModal()
{
	for (int i = 0; i < OLE_ELEEX_MODAL_MAX; ++i)
	{
		m_pOleElementExModalArray[i].strEleName = _T("");
		m_pOleElementExModalArray[i].pEditProp = NULL;
		SAFE_DELETE(m_pOleElementExModalArray[i].pElement);
	}
}

CRichElementBase* CUIShowRichEdit::GetOleEleExModalByName(LPCTSTR lpEleName)
{
	if (!lpEleName)
	{
		return NULL;
	}

	for (int i = 0; i < OLE_ELEEX_MODAL_MAX; ++i)
	{
		if (lpEleName == m_pOleElementExModalArray[i].strEleName)
		{
			return m_pOleElementExModalArray[i].pElement;
		}
	}

	return NULL;
}

CRichElementBase* CUIShowRichEdit::GetOleEleExModalByIndex(int nIndex)
{
	if (nIndex < 0 || nIndex >= OLE_ELEEX_MODAL_MAX)
	{
		return NULL;
	}

	return m_pOleElementExModalArray[nIndex].pElement;
}

void CUIShowRichEdit::CloneOleEleExModal(int nIndex, CRichElementBase* pElementFrom)
{
	if (nIndex < 0 || nIndex >= OLE_ELEEX_MODAL_MAX)
	{
		return;
	}

	if (!pElementFrom)
	{
		return;
	}

	if (m_pOleElementExModalArray[nIndex].pElement)
	{
		SAFE_DELETE(m_pOleElementExModalArray[nIndex].pElement);
	}

	m_pOleElementExModalArray[nIndex].pElement = pElementFrom->Clone();
	m_pOleElementExModalArray[nIndex].strEleName = pElementFrom->GetName();
}

BOOL CUIShowRichEdit::AccessOleEleExModalConfig(XMLNodePtr pXmlNode, int nIndex, BOOL bRead)
{
	if (nIndex < 0 || nIndex >= OLE_ELEEX_MODAL_MAX)
	{
		return FALSE;
	}

	if(NULL == pXmlNode)
	{
		return FALSE;
	}

	char szXmlEleName[256] = {0};
#if (_MSC_VER > 1310) && !defined(_MSVCVER60) // VS2005
	sprintf_s(szXmlEleName, "ItemElementInfo%d", nIndex);
#else
	sprintf(szXmlEleName, "ItemElementInfo%d", nIndex);
#endif

	XMLNodePtr pItemEleXMLInfo = (XMLNodePtr)pXmlNode->FirstChild(szXmlEleName);
	if (NULL == pItemEleXMLInfo && GetDUIRes() && GetDUIRes()->IsDesignStatus())
	{
		pItemEleXMLInfo = new TiXmlElement(szXmlEleName);
		pXmlNode->InsertEndChild(*pItemEleXMLInfo);
	}
	if (NULL == pItemEleXMLInfo)
	{
		return FALSE;
	}

	if (bRead)
	{
		TiXmlNode* pNodeChild = pItemEleXMLInfo->FirstChild();
		if (NULL == pNodeChild)
		{
			return FALSE;
		}

		XMLNodePtr pItemEleMainNode = pNodeChild->ToElement();
		if (NULL == pItemEleMainNode)
		{
			return FALSE;
		}

		if (m_pOleElementExModalArray[nIndex].pElement)
		{
			SAFE_DELETE(m_pOleElementExModalArray[nIndex].pElement);
		}
		m_pOleElementExModalArray[nIndex].pElement = CRichElementBase::CreateElementByXml(GetDUIRes(), pItemEleMainNode);
		if (NULL == m_pOleElementExModalArray[nIndex].pElement)
		{
			return FALSE;
		}

		CUITextStyleCom* pTextStyle = NULL;
		if (m_pOleElementExModalArray[nIndex].pEleTextStyle)
		{
			pTextStyle = m_pOleElementExModalArray[nIndex].pEleTextStyle->GetValue2();
		}
		m_pOleElementExModalArray[nIndex].pElement->AccessConfig(pTextStyle, pItemEleMainNode, TRUE);

		m_pOleElementExModalArray[nIndex].strEleName = m_pOleElementExModalArray[nIndex].pElement->GetName();
	}
	else
	{
		TiXmlNode* pNodeChild = pItemEleXMLInfo->FirstChild();
		while (pNodeChild)
		{
			pItemEleXMLInfo->RemoveChild(pNodeChild);
			pNodeChild = pItemEleXMLInfo->FirstChild();
		}

		if (NULL == m_pOleElementExModalArray[nIndex].pElement)
		{
			return FALSE;
		}

		XMLNodePtr pItemEleMainNode = new TiXmlElement(m_pOleElementExModalArray[nIndex].pElement->GetName());
		pItemEleXMLInfo->InsertEndChild(*pItemEleMainNode);

		if (NULL == pItemEleMainNode)
		{
			return FALSE;
		}

		CUITextStyleCom* pTextStyle = NULL;
		if (m_pOleElementExModalArray[nIndex].pEleTextStyle)
		{
			pTextStyle = m_pOleElementExModalArray[nIndex].pEleTextStyle->GetValue2();
		}
		m_pOleElementExModalArray[nIndex].pElement->AccessConfig(pTextStyle, pItemEleMainNode, FALSE);
	}

	return TRUE;
}

void CUIShowRichEdit::EditOleEleExModal(int nIndex, LPTSTR lpResultEleName, int nMaxCount, BOOL& bResult)
{
#ifndef _EXCLUDE_RESOURCE
	if (lpResultEleName)
	{
		memset(lpResultEleName, 0, sizeof(TCHAR)*nMaxCount);
	}

	if (nIndex < 0 || nIndex >= OLE_ELEEX_MODAL_MAX)
	{
		return;
	}

	//��Ϣ�������
	bResult = TRUE;

	//��ǰԪ�ص�����
	CUITextStyleCom* pItemTextStyle = NULL;
	if (m_pOleElementExModalArray[nIndex].pEleTextStyle)
	{
		pItemTextStyle = m_pOleElementExModalArray[nIndex].pEleTextStyle->GetValue2();
	}

	//��ǰԪ�ظ߶�
	int nItemHeight = 60;
	if (m_pOleElementExModalArray[nIndex].pEleHeight)
	{
		nItemHeight = m_pOleElementExModalArray[nIndex].pEleHeight->GetValue();
	}

	//���õ�ǰԪ�����ݵ��༭����
	CRichTreeItemElementEditDlg dlg;
	dlg.SetUIRes(GetDUIRes());
	dlg.SetTextStyle(pItemTextStyle);
	dlg.SetItemHeight(nItemHeight);
	if (m_pOleElementExModalArray[nIndex].pElement)
	{
		dlg.SetRootElement(m_pOleElementExModalArray[nIndex].pElement->Clone());
	}
	else
	{
		dlg.SetRootElement(NULL);
	}

	//���±༭�������ǰԪ����
	if (IDOK == dlg.DoModal())
	{
		// ɾ��ԭ���ĸ��ڵ�Ԫ��ģ��
		SAFE_DELETE(m_pOleElementExModalArray[nIndex].pElement);

		// �����µĸ��ڵ�Ԫ��ģ��
		CRichElementBase* pResultElement = dlg.GetResultElement();
		if (pResultElement)
		{
			m_pOleElementExModalArray[nIndex].pElement = pResultElement->Clone();
		}
		else
		{
			m_pOleElementExModalArray[nIndex].pElement = NULL;
		}

		AccessOleEleExModalConfig((XMLNodePtr)GetXMLNode(), nIndex, FALSE);
	}

	//����Ԫ�����Ƶ��༭������
	WTL::CString strItemPropDesc = _T("None");
	if (m_pOleElementExModalArray[nIndex].pElement)
	{
		strItemPropDesc = m_pOleElementExModalArray[nIndex].pElement->GetName();
	}
	_tcsncpy(lpResultEleName, strItemPropDesc, nMaxCount);
#endif
}

void CUIShowRichEdit::SaveOleEleExModalXmlNode()
{
	for (int i = 0; i < OLE_ELEEX_MODAL_MAX; ++i)
	{
		AccessOleEleExModalConfig((XMLNodePtr)GetXMLNode(), i, FALSE);
	}
}

LRESULT CUIShowRichEdit::OnGetClipBoardData(WPARAM wParam, LPARAM lParam)
{
	stClipBoardData* pData = (stClipBoardData*)wParam;
	if (!pData)
	{
		return -1;
	}

	switch(pData->m_reco)
	{
	case RECO_CUT:
	case RECO_COPY:
		{
			//�ڶ�ջ���������ռ䣬������COM�������ﲻ�е��ͷŹ�����������detach�ö���ʱ���Զ�����release�ӿ�
			IDataObject* pDataObject = NULL;
			CreateOleDataObject(m_fmtetc, m_stgmed, 4, &pDataObject);

			if (GetAsyncKeyState(VK_LBUTTON) & 0x8000) // ��ק
			{
				if (OnCopy(pDataObject, *(pData->m_lpchrg), false))
				{
					*pData->m_lplpdataobj = (LPDATAOBJECT)pDataObject;
				}
			}
			else
			{
				CHARRANGE cr;
				GetSel(cr);
				OnCopy(pDataObject, cr);
			}
			return 0;
		}
		break;
	default:
		break;
	}

	return 0;
}

bool CUIShowRichEdit::OpenURL(LPCTSTR lpURLPath)
{
	if (!lpURLPath)
	{
		return false;
	}

	BOOL bCanOpen = TRUE;
	DUICtrlNotifyInfo duiNotifyInfo;
	memset(&duiNotifyInfo, 0, sizeof(DUICtrlNotifyInfo));
	duiNotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_PRE_OPEN_URL;
	duiNotifyInfo.lParam1 = (DWORD_PTR)this;
	duiNotifyInfo.lParam2 = (DWORD_PTR)(LPCTSTR)lpURLPath;
	duiNotifyInfo.lParam3 = (DWORD_PTR)(&bCanOpen);
	::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&duiNotifyInfo, 0);

	if (!bCanOpen)
	{
		return false;
	}

	HINSTANCE hResult = ShellExecute(NULL, _T("open"), lpURLPath, NULL, NULL, SW_SHOWNORMAL);
	if ((int)(hResult) <= 32)//���ش�����ָ����ie��
	{
		hResult = ShellExecute(NULL, _T("open"),_T("IExplore.EXE"), lpURLPath, NULL, SW_SHOWNORMAL);
		if ((int)(hResult) <= 32)
		{
			return false;
		}
	}

	return true;
}

bool CUIShowRichEdit::OnHitTestLink(UINT nHitMessage, CPoint& pt)
{
	//������������꾭������Ϣ�Ƿ�����������
	LONG lHtCharPos = CharFromPos(pt);
	list_LinkCallBacks::iterator it_url = m_listLinksCallBack.begin();
	for (; it_url != m_listLinksCallBack.end(); ++it_url)
	{
		if (lHtCharPos > it_url->lBeginPos && lHtCharPos < it_url->lEndPos)
		{
			break;
		}
	}

	if (m_listLinksCallBack.end() == it_url)
	{
		return false;
	}

	//����������Ӧ
	WTL::CString strLinkChar;
	switch (nHitMessage)
	{
	case WM_LBUTTONUP:
		{
			//��������״̬���������
			if (NULL == m_hCursorLink)
			{
				m_hCursorLink = ::LoadCursor(NULL, IDC_HAND);
			}
			if (m_hCursorLink)
			{
				::SetCursor(m_hCursorLink);
			}

			//��鵱ǰ����Ƿ��ڵ�ǰѡ������(���絥��ѡ�����򼴷�ѡ)
			LONG lCurSelBeginChar = 0;
			LONG lCurSelEndChar = 0;
			GetSel(lCurSelBeginChar, lCurSelEndChar);
			if (lCurSelBeginChar != lCurSelEndChar && lHtCharPos >= lCurSelBeginChar && lHtCharPos <= lCurSelEndChar)
			{
				return false;
			}

			//������
			if (HYPER_LINK_FUNC == it_url->m_pFuncLBtn)
			{
				WTL::CString strSafeSite = it_url->strInfoLBtn;
				if (m_bSafeSiteCheck)
				{
					WTL::CString strSiteCheckPage = _T("");
					m_sysHelper.GetSafeCheckSite(strSiteCheckPage);
					if (!strSiteCheckPage.IsEmpty())
					{
						strSafeSite.Format(_T("%s?url=%s"),strSiteCheckPage,it_url->strInfoLBtn);
					}
				}
				OpenURL(strSafeSite);
			}
			//�ཷɻ�Ʊ
			else if (TICKET_LINK_FUNC == it_url->m_pFuncLBtn)
			{
				DUICtrlNotifyInfo duiNotifyInfo;
				memset(&duiNotifyInfo, 0, sizeof(DUICtrlNotifyInfo));
				duiNotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_TICKET_LINK;
				duiNotifyInfo.lParam1 = (DWORD_PTR)(this);
				duiNotifyInfo.lParam2 = (DWORD_PTR)(LPCTSTR)it_url->strInfoLBtn;
				duiNotifyInfo.lParam3 = (DWORD_PTR)(LPCTSTR)it_url->m_dwValueLBtn;
				::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&duiNotifyInfo, 0);
			}
			else if (CUSTOM_LINK_FUNC == it_url->m_pFuncLBtn)
			{
				DUICtrlNotifyInfo duiNotifyInfo;
				memset(&duiNotifyInfo, 0, sizeof(DUICtrlNotifyInfo));
				duiNotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_CUSTOM_LINK_CLICK;
				duiNotifyInfo.lParam1 = (DWORD_PTR)(this);
				duiNotifyInfo.lParam2 = (DWORD_PTR)(LPCTSTR)it_url->strInfoLBtn;
				duiNotifyInfo.lParam3 = (DWORD_PTR)(LPCTSTR)it_url->m_dwValueLBtn;
				::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&duiNotifyInfo, 0);
			}
			//At
			else if (AT_LINK_FUNC == it_url->m_pFuncLBtn)
			{
				DUICtrlNotifyInfo duiNotifyInfo;
				memset(&duiNotifyInfo, 0, sizeof(DUICtrlNotifyInfo));
				duiNotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_AT_LCLICK;
				duiNotifyInfo.lParam1 = (DWORD_PTR)(this);
				duiNotifyInfo.lParam2 = (DWORD_PTR)(LPCTSTR)it_url->strInfoLBtn;
				duiNotifyInfo.lParam3 = (DWORD_PTR)(LPCTSTR)it_url->m_dwValueLBtn;
				::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&duiNotifyInfo, 0);
			}
			//�Զ���ص�
			else if (it_url->m_pFuncLBtn)
			{
				it_url->m_pFuncLBtn(it_url->strInfoLBtn, it_url->m_dwValueLBtn);
			}
		}
		break;
	case WM_RBUTTONUP:
		{
			//��������״̬���������
			if (NULL == m_hCursorLink)
			{
				m_hCursorLink = ::LoadCursor(NULL, IDC_HAND);
			}
			if (m_hCursorLink)
			{
				::SetCursor(m_hCursorLink);
			}

			//��鵱ǰ����Ƿ��ڵ�ǰѡ������(���絥��ѡ�����򼴷�ѡ)
			LONG lCurSelBeginChar = 0;
			LONG lCurSelEndChar = 0;
			GetSel(lCurSelBeginChar, lCurSelEndChar);
			if (lCurSelBeginChar != lCurSelEndChar && lHtCharPos >= lCurSelBeginChar && lHtCharPos <= lCurSelEndChar)
			{
				return false;
			}

			if (it_url->m_pFuncRBtn)
			{
				if (it_url->m_pFuncRBtn != HYPER_LINK_FUNC)
				{
					it_url->m_pFuncRBtn(it_url->strInfoRBtn, it_url->m_dwValueRBtn);
				}
			}
			else
			{
				SetSel(it_url->lBeginPos, it_url->lEndPos);
				return false;
			}
		}
		break;
	case WM_MOUSEMOVE:
		{
			if (!m_bHasCaptureState)
			{
				if (NULL == m_hCursorLink)
				{
					m_hCursorLink = ::LoadCursor(NULL, IDC_HAND);
				}
				if (m_hCursorLink)
				{
					::SetCursor(m_hCursorLink);
				}
			}
		}
		break;
	case WM_LBUTTONDOWN:
	case WM_RBUTTONDOWN:
		{
			if (NULL == m_hCursorLink)
			{
				m_hCursorLink = ::LoadCursor(NULL, IDC_HAND);
			}
			if (m_hCursorLink)
			{
				::SetCursor(m_hCursorLink);
			}
		}
		break;
	case WM_SETCURSOR:
		{
			if (!m_bHasCaptureState)
			{
				if (NULL == m_hCursorLink)
				{
					m_hCursorLink = ::LoadCursor(NULL, IDC_HAND);
				}
				if (m_hCursorLink)
				{
					::SetCursor(m_hCursorLink);
				}
			}
		}
		break;
	default:
		break;
	}

	return true;
}

LRESULT CUIShowRichEdit::OnRButtonUp(int nFlags, CPoint pt)
{
	//��鲢ͬ��������λ��
	SyncScrollPos();

	if (OnHitTestOleControl(WM_RBUTTONUP, pt))
	{
		return 0;
	}

	if (OnHitTestLink(WM_RBUTTONUP, pt))
	{
		return 0;
	}

	if (OnHitTestExtraElement(WM_RBUTTONUP, pt))
	{
		return 0;
	}

	if (!m_bEnableRPopupMenu)
	{
		return 0;
	}

	if (NULL == m_pPopupMenu)
	{
		m_pPopupMenu = (CUIPopupMenuCom*) (GetDUIRes()->GetResObject(DUIControlType_PopupMenu, _T("PopupMenu_Check"), NULL, TRUE));
	}

	if (m_pPopupMenu)
	{
		CPoint ptMenu = pt;
		::ClientToScreen(m_hWndDirectUI,&ptMenu);
		m_pPopupMenu->RemoveAllMenu();

		int nOverChar = CharFromPos(pt) - 1;
		if (nOverChar >= 0 && TestClickOnImage(pt))
		{
			CHARRANGE cr;
			cr.cpMin = nOverChar;
			cr.cpMax = nOverChar + 1;
			GetSendImagePath(cr);

			m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_COPY,_T("MenuCommon_Copy"),_T("MenuCommon_Copy"),-1,MENUITEMSTYLE_NORMAL, FALSE,TRUE);
			m_pPopupMenu->AppendMenu2(-1,_T(""),_T(""),-1,MENUITEMSTYLE_SEPARATOR,FALSE,TRUE);
			m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_SEL_ALL,_T("MenuCommon_SelAll"),_T("MenuCommon_SelAll"),-1,MENUITEMSTYLE_NORMAL,FALSE,TRUE);
			m_pPopupMenu->AppendMenu2(-2,_T(""),_T(""),-1,MENUITEMSTYLE_SEPARATOR,FALSE,TRUE);
			m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_SAVE_AS,_T("MenuCommon_SaveAs"),_T("MenuCommon_SaveAs"),-1,MENUITEMSTYLE_NORMAL,FALSE,TRUE);

			//��ʱ����"���ӵ�����"�˵���
			//m_pPopupMenu->AppendMenu2(ID_MENU_EDIT_ADD_TO_FACE,_T("���ӵ�����"),_T("���ӵ�����"),-1,MENUITEMSTYLE_NORMAL,FALSE,TRUE);

			//CHARRANGE cr;
			//GetSel(cr);
			//if (GetSendImagePath(cr))
			//{
			//m_pPopupMenu->EnableMenuItem(ID_MENU_EDIT_ADD_TO_FACE,FALSE,FALSE);
			//}
		}
		else
		{
			m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_COPY,_T("MenuCommon_Copy"),_T("MenuCommon_Copy"),-1,MENUITEMSTYLE_NORMAL,FALSE, TRUE);
			if(m_bCanClrOrLockScr)
			{
				m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_CLEAR,_T("MenuCommon_Clear"),_T("MenuCommon_Clear"),-1,MENUITEMSTYLE_NORMAL,FALSE, TRUE);
				if (m_bLockScr)
				{
					m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_LOCK_SCREEN,_T("MenuCommon_UnlockScreen"),_T("MenuCommon_UnlockScreen"),-1,MENUITEMSTYLE_NORMAL,FALSE,TRUE);
				}
				else
				{
					m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_LOCK_SCREEN,_T("MenuCommon_LockScreen"),_T("MenuCommon_LockScreen"),-1,MENUITEMSTYLE_NORMAL,FALSE,TRUE);
				}
			}
			m_pPopupMenu->AppendMenu2(-1,_T(""),_T(""),-1,MENUITEMSTYLE_SEPARATOR,FALSE,TRUE);
			m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_SEL_ALL,_T("MenuCommon_SelAll"),_T("MenuCommon_SelAll"),-1,MENUITEMSTYLE_NORMAL,FALSE,TRUE);

			BOOL bSel=((GetSelectionType() != SEL_EMPTY) ? TRUE : FALSE) ;
			m_pPopupMenu->EnableMenuItem(ID_MENU_EDIT_COPY,FALSE,bSel);

			if (m_bVisableShieldFaceMsgMenu)
			{
				m_pPopupMenu->SetAutoCheck(TRUE);
				m_pPopupMenu->AppendMenu2(-1, _T(""), _T(""), -1, MENUITEMSTYLE_SEPARATOR, FALSE, TRUE);
				m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_SHIELD_FACE, _T("MenuCommon_ShiledEmotion"), _T("MenuCommon_ShiledEmotion"), -1, MENUITEMSTYLE_CHECK, FALSE, TRUE);
				CUIMenuCheckItemCom *pCheckItem = (CUIMenuCheckItemCom*)m_pPopupMenu->GetMenu(ID_MENU_EDIT_SHIELD_FACE, FALSE, MENUITEMSTYLE_CHECK);
				if (pCheckItem)
				{
					if (!m_bDisplaySysFace)
					{
						pCheckItem->SetCheck(MENUITEMVALUE_CHECKED);
					}
					else
					{
						pCheckItem->SetCheck(MENUITEMVALUE_UNCHECK);
					}
				}
				m_pPopupMenu->AppendMenuByTextCaption(ID_MENU_EDIT_SHIELD_MSG, _T("MenuCommon_ShiedAllMesssage"), _T("MenuCommon_ShiedAllMesssage"), -1, MENUITEMSTYLE_CHECK, FALSE, TRUE);
				pCheckItem = (CUIMenuCheckItemCom*)m_pPopupMenu->GetMenu(ID_MENU_EDIT_SHIELD_MSG, FALSE, MENUITEMSTYLE_CHECK);
				if (pCheckItem)
				{
					if (!m_bDisplayChannelMsg)
					{
						pCheckItem->SetCheck(MENUITEMVALUE_CHECKED);
					}
					else
					{
						pCheckItem->SetCheck(MENUITEMVALUE_UNCHECK);
					}
				}
			}
		}

		//�Ҽ��˵���չ��
		int nMenuExtraCount = (int)m_RMenuExtraItemColl.size();
		for (int i = 0; i < nMenuExtraCount; ++i)
		{
			BOOL bItemVisible = TRUE;
			BOOL bItemEnabled = TRUE;
			TCHAR tszMenuText[MAX_PATH + 1] = {0};
			_tcsncpy(tszMenuText, m_RMenuExtraItemColl[i].strMenuItemText, MAX_PATH);

			DUICtrlNotifyInfo duiNotifyInfo;
			memset(&duiNotifyInfo, 0, sizeof(DUICtrlNotifyInfo));
			duiNotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_EXTRA_RMENU_PREPROCESS;
			duiNotifyInfo.lParam1 = (DWORD_PTR)this;
			duiNotifyInfo.lParam2 = (DWORD_PTR)m_RMenuExtraItemColl[i].uMenuItemID;
			duiNotifyInfo.lParam3 = (DWORD_PTR)&bItemVisible;
			duiNotifyInfo.lParam4 = (DWORD_PTR)&bItemEnabled;
			duiNotifyInfo.lParam5 = (DWORD_PTR)tszMenuText;
			duiNotifyInfo.lParam6 = (DWORD_PTR)MAX_PATH;
			::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&duiNotifyInfo, 0);

			DUI_MENUITEM_STYLE menuStyle = (DUI_MENUITEM_STYLE)m_RMenuExtraItemColl[i].byMenuStyle;
			if (menuStyle != MENUITEMSTYLE_SEPARATOR && 
				menuStyle != MENUITEMSTYLE_CHECK && 
				menuStyle != MENUITEMSTYLE_RADIO)
			{
				menuStyle = MENUITEMSTYLE_NORMAL;
			}

			m_pPopupMenu->AppendMenu2(m_RMenuExtraItemColl[i].uMenuItemID, tszMenuText, tszMenuText, -1, menuStyle, FALSE, TRUE);
			m_pPopupMenu->EnableMenuItem(m_RMenuExtraItemColl[i].uMenuItemID, FALSE, bItemEnabled);
			m_pPopupMenu->SetItemVisible(m_RMenuExtraItemColl[i].uMenuItemID, FALSE, bItemVisible);

			if (MENUITEMSTYLE_CHECK == m_RMenuExtraItemColl[i].byMenuStyle || 
				MENUITEMSTYLE_RADIO == m_RMenuExtraItemColl[i].byMenuStyle)
			{
				CUIMenuCheckItemCom* pCheckItem = (CUIMenuCheckItemCom*)m_pPopupMenu->GetMenu(m_RMenuExtraItemColl[i].uMenuItemID, FALSE, menuStyle);
				if (pCheckItem)
				{
					if (m_RMenuExtraItemColl[i].bChecked)
					{
						pCheckItem->SetCheck(MENUITEMVALUE_CHECKED);
					}
					else
					{
						pCheckItem->SetCheck(MENUITEMVALUE_UNCHECK);
					}
				}
			}
		}

		m_pPopupMenu->TrackPopupMenu(DUI_TPM_LEFTALIGN,(SHORT)ptMenu.x,(SHORT)ptMenu.y,m_hWndDirectUI,this);
	}

	return 0;
}

LRESULT CUIShowRichEdit::OnLButtonDown(int nFlags, CPoint pt)
{
	int nHitTest = -1;

	if (OnHitTestOleControl(WM_LBUTTONDOWN, pt))
	{
		nHitTest = 0;
		SetLButtonDownHitOleControl(TRUE);
	}
	else
	{
		SetLButtonDownHitOleControl(FALSE);
	}

	if (OnHitTestLink(WM_LBUTTONDOWN, pt))
	{
		SetLButtonDownHitLink(TRUE);
	}
	else
	{
		SetLButtonDownHitLink(FALSE);
	}

	if (OnHitTestExtraElement(WM_LBUTTONDOWN, pt))
	{
		nHitTest = 0;
		SetLButtonDownHitElement(TRUE);
	}
	else
	{
		SetLButtonDownHitElement(FALSE);
	}

	return nHitTest;
}

LRESULT CUIShowRichEdit::OnLButtonUp(int nFlags, CPoint pt)
{
	if (IsLButtonDownHitOleControl() && OnHitTestOleControl(WM_LBUTTONUP, pt))
	{
		return 0;
	}

	if (IsLButtonDownHitLink() && OnHitTestLink(WM_LBUTTONUP, pt))
	{
		return 0;
	}

	if (IsLButtonDownHitElement() && OnHitTestExtraElement(WM_LBUTTONUP, pt))
	{
		return 0;
	}

	int nOverChar = CharFromPos(pt) - 1;
	if (-1 == nOverChar)
	{
		return 0;
	}

	DWORD dwImageUserData = -1;
	BOOL bOnScaleButton = FALSE;
	if (TestClickOnImage(pt, &dwImageUserData, NULL, &bOnScaleButton))
	{
		if (!bOnScaleButton)
		{
			return 0;
		}

		CHARRANGE cr;
		cr.cpMin = nOverChar;
		cr.cpMax = nOverChar + 1;
		GetSendImagePath(cr);

		DUICtrlNotifyInfo duiNotifyInfo;
		memset(&duiNotifyInfo, 0, sizeof(DUICtrlNotifyInfo));
		duiNotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_VIEW_IMAGE;
		duiNotifyInfo.lParam1 = (DWORD_PTR)(this);
		duiNotifyInfo.lParam2 = (DWORD_PTR)m_imgProcessData.bSysFace?1:0;
		if (m_imgProcessData.bSysFace)
		{
			int nIndex = m_imgProcessData.strImagePath.Find(_T("eim_sysFace_"));
			if (nIndex != -1)
			{
				DWORD dwFaceID = _tcstoul(m_imgProcessData.strImagePath.Mid(nIndex+12, m_imgProcessData.strImagePath.GetLength()-1), 0, 10);
				duiNotifyInfo.lParam3 = (DWORD_PTR)dwFaceID;
			}
			else
			{
				duiNotifyInfo.lParam3 = (DWORD_PTR)0;
			}
		}
		else
		{
			duiNotifyInfo.lParam3 = (DWORD_PTR)(LPCTSTR)m_imgProcessData.strImagePath;
			duiNotifyInfo.lParam4 = (DWORD_PTR)(LPCTSTR)m_imgProcessData.strImageURL;
		}
		::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&duiNotifyInfo, 0);
	}

	return 0;
}

LRESULT CUIShowRichEdit::OnLButtonDbClick(int nFlags, CPoint pt)
{
	int nOverChar = CharFromPos(pt) - 1;
	if (-1 == nOverChar)
	{
		return -1;
	}

	if (TestClickOnImage(pt))
	{
		CHARRANGE cr;
		cr.cpMin = nOverChar;
		cr.cpMax = nOverChar + 1;
		GetSendImagePath(cr);

		DUICtrlNotifyInfo duiNotifyInfo;
		memset(&duiNotifyInfo, 0, sizeof(DUICtrlNotifyInfo));
		duiNotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_VIEW_IMAGE;
		duiNotifyInfo.lParam1 = (DWORD_PTR)(this);
		duiNotifyInfo.lParam2 = (DWORD_PTR)m_imgProcessData.bSysFace?1:0;
		if (m_imgProcessData.bSysFace)
		{
			int nIndex = m_imgProcessData.strImagePath.Find(_T("eim_sysFace_"));
			if (nIndex != -1)
			{
				DWORD dwFaceID = _tcstoul(m_imgProcessData.strImagePath.Mid(nIndex+12, m_imgProcessData.strImagePath.GetLength()-1), 0, 10);
				duiNotifyInfo.lParam3 = (DWORD_PTR)dwFaceID;
			}
			else
			{
				duiNotifyInfo.lParam3 = (DWORD_PTR)0;
			}
		}
		else
		{
			duiNotifyInfo.lParam3 = (DWORD_PTR)(LPCTSTR)m_imgProcessData.strImagePath;
			duiNotifyInfo.lParam4 = (DWORD_PTR)(LPCTSTR)m_imgProcessData.strImageURL;
		}
		::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&duiNotifyInfo, 0);

		return 0;
	}

	return -1;
}

LRESULT CUIShowRichEdit::OnMenuCommond(UINT nID)
{
	switch(nID)
	{
	case ID_MENU_EDIT_COPY:
		{
			OnMenuCopy();
		}
		break;
	case ID_MENU_EDIT_SEL_ALL:
		{
			OnMenuSelAll();
		}
		break;
	case ID_MENU_EDIT_CLEAR:
		{
			OnMenuClear();
		}
		break;
	case ID_MENU_EDIT_SAVE_AS:
		{
			OnMenuSaveAs();
		}
		break;
	case ID_MENU_EDIT_ADD_TO_FACE:
		{
			OnMenuAddFace();
		}
		break;
	case ID_MENU_EDIT_LOCK_SCREEN:
		{
			OnMenuLockScreen();
		}
		break;
	case ID_MENU_EDIT_SHIELD_FACE:
		{
			OnMenuShieldChannelFace();
		}
		break;
	case ID_MENU_EDIT_SHIELD_MSG:
		{
			OnMenuShieldChannelMsg();
		}
		break;
	default:
		{
			if (nID >= ID_MENU_EDIT_EXTRA_BEGIN && nID <= ID_MENU_EDIT_EXTRA_END)
			{
				DUICtrlNotifyInfo duiNotifyInfo;
				memset(&duiNotifyInfo, 0, sizeof(DUICtrlNotifyInfo));
				duiNotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_EXTRA_RMENU_COMMAND;
				duiNotifyInfo.lParam1 = (DWORD_PTR)this;
				duiNotifyInfo.lParam2 = (DWORD_PTR)nID; //�˵�
				::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&duiNotifyInfo, 0);
			}
		}
		break;
	}
	return 0;
}

LRESULT CUIShowRichEdit::OnMouseMove(UINT nFlags, CPoint point)
{
	if (this->IsLButtonDowned())
	{
		if(!IsLButtonDownHitLink() || !IsLButtonDownHitOleControl() || !IsLButtonDownHitElement())
		{
			return -1;
		}
	}

	///////////////////////////////////////////////////////////
	//����OleControl����
	BOOL bHitOleControl = FALSE;
	if (OnHitTestOleControl(WM_MOUSEMOVE, point))
	{
		bHitOleControl = TRUE;
	}

	///////////////////////////////////////////////////////////
	//������
	BOOL bHitLink = FALSE;
	if (!bHitOleControl)
	{
		bHitLink = OnHitTestLink(WM_MOUSEMOVE, point);
	}

	///////////////////////////////////////////////////////////
	//��չԪ��
	BOOL bHitExtraEle = FALSE;
	if (!bHitOleControl && !bHitLink)
	{
		bHitExtraEle = OnHitTestExtraElement(WM_MOUSEMOVE, point);
	}

	///////////////////////////////////////////////////////////
	//MouseMoveʱ��
	m_bKeepMouseMoving = true;
	if (GetDirectUI() && -1 == m_nIDActionInMouseMove)
	{
		m_nIDActionInMouseMove = GetDirectUI()->SetTimer(this, 100, NULL);
	}

	if (!bHitOleControl && !bHitLink && !bHitLink)
	{
		return -1;
	}

	return 0;
}

LRESULT CUIShowRichEdit::OnSetCursor(WPARAM wParam, LPARAM lParam, CPoint point)
{
	bool bHitTest = false;
	if (OnHitTestOleControl(WM_SETCURSOR, point))
	{
		bHitTest = true;
	}

	if (!bHitTest)
	{
		bHitTest = OnHitTestLink(WM_SETCURSOR, point);
	}
	
	if (!bHitTest)
	{
		bHitTest = OnHitTestExtraElement(WM_SETCURSOR, point);
	}

	return bHitTest ? 0 : -1;
}

LRESULT CUIShowRichEdit::OnEnChange()
{
	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_EN_CHANGE;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);

	return 0;
}

LRESULT CUIShowRichEdit::OnEnUpdate()
{
	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_EN_UPDATE;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);

	return 0;
}

LRESULT CUIShowRichEdit::OnMouseWheel(short zDelta)
{
	if (!m_pScrollBarImplVert || !IsScrollBarExist(FALSE))
	{
		if (zDelta > 0)
		{
			DUICtrlNotifyInfo UINotifyInfo;
			memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
			UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_TRY_DROPDOWN_MORE;
			UINotifyInfo.lParam1 = (DWORD_PTR)(this);
			UINotifyInfo.lParam2 = (DWORD_PTR)1; // from top
			::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&UINotifyInfo, 0);
		}

		return 0;
	}

	m_pScrollBarImplVert->StartMouseWheel(zDelta);

	if (zDelta > 0 && IsScrollAtTop(FALSE))
	{
		DUICtrlNotifyInfo UINotifyInfo;
		memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
		UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_TRY_DROPDOWN_MORE;
		UINotifyInfo.lParam1 = (DWORD_PTR)(this);
		UINotifyInfo.lParam2 = (DWORD_PTR)1; // from top
		::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&UINotifyInfo, 0);
		return 0;
	}

	if (zDelta < 0 && IsScrollAtBottom(FALSE))
	{
		DUICtrlNotifyInfo UINotifyInfo;
		memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
		UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_TRY_DROPDOWN_MORE;
		UINotifyInfo.lParam1 = (DWORD_PTR)(this);
		UINotifyInfo.lParam2 = (DWORD_PTR)0; // from bottom
		::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&UINotifyInfo, 0);
		return 0;
	}

	return 0;
}

void CUIShowRichEdit::OnMenuCopy()
{
	OnRichEditMsgProc(WM_COPY, 0, 0);
}

void CUIShowRichEdit::OnMenuClear()
{ 
	SetSel(0, -1); 
	Clear();

	CUIEngineCom* pDirectUI = GetDirectUI();
	if (pDirectUI && pDirectUI->GetFocusObject() == this)
	{
		pDirectUI->KillFocus();
	}
}

void CUIShowRichEdit::OnMenuLockScreen()
{
	LockScreen();
}

void CUIShowRichEdit::OnMenuSelAll() 
{ 
	SetSel(0, -1); 
}

void CUIShowRichEdit::OnMenuSaveAs()
{
	SaveImageAs();
}

void CUIShowRichEdit::OnMenuAddFace()
{
	AddImageToMgr();
}

void CUIShowRichEdit::OnMenuShieldChannelFace()
{
	m_bDisplaySysFace = !m_bDisplaySysFace;

	if (!m_bDisplaySysFace)
	{
		SetDisplayChannelMsg(true);
		AddNotifyPng2(_T("����ѡ���ˡ�����������Ϣ�еı��顿��"), m_sysHelper.GetSysHintImageID(IMAGE_TYPE_NORMAL_HINT_PNG), TRUE);
	}
	else
	{
		AddNotifyPng2(_T("����ȡ���ˡ�����������Ϣ�еı��顿��"), m_sysHelper.GetSysHintImageID(IMAGE_TYPE_NORMAL_HINT_PNG), TRUE);
	}
}

void CUIShowRichEdit::OnMenuShieldChannelMsg()
{
	m_bDisplayChannelMsg = !m_bDisplayChannelMsg;

	if (!m_bDisplayChannelMsg)
	{
		SetDisplaySysFace(true);
		AddNotifyPng2(_T("����ѡ���ˡ���������������Ϣ����"), m_sysHelper.GetSysHintImageID(IMAGE_TYPE_NORMAL_HINT_PNG), TRUE);
	}
	else
	{
		AddNotifyPng2(_T("����ȡ���ˡ���������������Ϣ����"), m_sysHelper.GetSysHintImageID(IMAGE_TYPE_NORMAL_HINT_PNG), TRUE);
	}
}

bool CUIShowRichEdit::OnCopy(IDataObject* pOleDataSource, CHARRANGE& cr, bool bCopyToClipBoard)
{
	WTL::CString string;
	bool bHaseImage = GetEncodeUBB(string, cr.cpMin, cr.cpMax);
	WTL::CString strUBB = string.Mid(70, string.GetLength()-70);

	if (bHaseImage)
	{
		/******************************Ole˽�м��а�**************************************/
		DoCopyInfo(pOleDataSource, strUBB);

		/**********************************��ͳ���а�**************************************/
		std::string strHtml = "";
		WTL::CString strUniText = _T("");
		GetClipBoardUBB(strHtml, strUniText, cr.cpMin, cr.cpMax);

		int nDataCount = strHtml.length() + 1;
		int nDataSize = nDataCount * sizeof(BYTE);

		HGLOBAL hText = ::GlobalAlloc(GMEM_NODISCARD, nDataSize);
		if (hText)
		{
			LPVOID pData = ::GlobalLock(hText);
			if (pData)
			{
				memset(pData, 0, nDataSize);
				strncpy((LPSTR)pData, strHtml.c_str(), nDataCount);
				::GlobalUnlock(hText);
			}
		}

		m_stgmed[2].hGlobal = hText;
		pOleDataSource->SetData(&(m_fmtetc[2]), &(m_stgmed[2]), FALSE);

		//ʹ�ú���չ�������
		::GlobalFree(m_stgmed[2].hGlobal);
		m_stgmed[2].hGlobal = NULL;

		/**********************************��������,Ϊ�����ı�**************************************/
		// С�ڿ�͸�ʽ����
		strUniText.Replace(_T("\n"), _T("\r\n"));
		nDataSize = (strUniText.GetLength()+1) * sizeof(TCHAR); 

		hText = ::GlobalAlloc(GMEM_NODISCARD, nDataSize);
		if (hText)
		{
			LPVOID pData = ::GlobalLock(hText);
			if (pData)
			{
				memset(pData, 0, nDataSize);
				_tcsncpy((TCHAR*)pData, strUniText, strUniText.GetLength()+1);
				::GlobalUnlock(hText);
			}
		}

		m_stgmed[3].hGlobal = hText;
		pOleDataSource->SetData(&(m_fmtetc[3]), &(m_stgmed[3]), FALSE);

		//ʹ�ú���չ�������
		::GlobalFree(m_stgmed[3].hGlobal);
		m_stgmed[3].hGlobal = NULL;
	}
	else
	{
		/**********************************����ֻ������**************************************/
		// С�ڿ�͸�ʽ����
		strUBB.Replace(_T("\n"), _T("\r\n"));
		int nDataSize = (strUBB.GetLength()+1) * sizeof(TCHAR);

		HGLOBAL hText = ::GlobalAlloc(GMEM_NODISCARD, nDataSize);
		if (hText)
		{
			LPVOID pData = ::GlobalLock(hText);
			if (pData)
			{
				memset(pData, 0, nDataSize);
				_tcsncpy( (TCHAR*)pData, strUBB, strUBB.GetLength()+1 );
				::GlobalUnlock(hText);
			}
		}

		m_stgmed[3].hGlobal = hText;
		pOleDataSource->SetData(&(m_fmtetc[3]), &(m_stgmed[3]), FALSE);

		//ʹ�ú���չ�������
		::GlobalFree(m_stgmed[3].hGlobal);
		m_stgmed[3].hGlobal = NULL;
	}

	if (bCopyToClipBoard)
	{
		::OleSetClipboard((LPDATAOBJECT)pOleDataSource);
		pOleDataSource->Release();
	}

	return true;
}

DWORD CUIShowRichEdit::CStringFormatToRTF(DWORD dwCookie, LPBYTE pbBuff, LONG cb, LONG *pcb)
{
	return 0;
}

DWORD CUIShowRichEdit::RTFFormatToCString(DWORD dwCookie, LPBYTE pbBuff, LONG cb, LONG *pcb)
{
	return 0;
}

BOOL CUIShowRichEdit::AddMsg(
							 BOOL bUrlLink,
							 BOOL bDefaultLinkType,
							 WTL::CString strMsg,
							 COLORREF crNewColor,
							 BOOL bUnderLine,
							 BOOL bBold,
							 BOOL bItalic,
							 LONG lHeight,
							 BYTE byCharSet,
							 BYTE byPitchAndFamily,
							 LPCTSTR lptszFaceName/* = _T("΢���ź�")*/,
							 const stLinkCallBackData* pData/* = NULL*/,
							 int nYOffset/* = 20*/)
{
	if (!IsDoingInsert())
	{
		return FALSE;
	}

	//ѡ���������ַ�����
	long lPos = UpdateCurInsertSel();

	//��������
	long lDelCount = 0;
	if (bUrlLink)
	{
		//���ó������ı���ʽ
		CHARFORMAT2 cf2;
		memset(&cf2, 0, sizeof(CHARFORMAT2));
		cf2.cbSize = sizeof(CHARFORMAT2);
		cf2.dwMask = CFM_CHARSET | CFM_COLOR | CFM_BOLD | CFM_UNDERLINE | CFM_ITALIC | CFM_LCID | CFM_FACE | CFM_PROTECTED | CFM_SIZE | CFM_OFFSET;
		cf2.bCharSet = byCharSet;
		cf2.yOffset = nYOffset;
		cf2.bPitchAndFamily = byPitchAndFamily;
		cf2.bCharSet = DEFAULT_CHARSET;
		if (lptszFaceName)
		{
			_tcsncpy(cf2.szFaceName, lptszFaceName, LF_FACESIZE);
		}
		else
		{
			_tcsncpy(cf2.szFaceName, DEAULT_FONT_NAME, LF_FACESIZE);
		}
		cf2.yHeight = lHeight;

		if (bDefaultLinkType && m_pColorLink)
		{
			cf2.crTextColor = m_pColorLink->GetValue();
		}
		else
		{
			cf2.crTextColor = crNewColor;
		}

		cf2.dwEffects = 0;
		if (bDefaultLinkType && 
			m_pUnderlineLink && m_pUnderlineLink->GetValue2())
		{
			cf2.dwEffects |= CFE_UNDERLINE;
		}
		else if (bUnderLine)
		{
			cf2.dwEffects |= CFE_UNDERLINE;
		}
		cf2.dwEffects |= bBold ? CFE_BOLD : cf2.dwEffects;
		cf2.dwEffects |= bItalic ? CFE_ITALIC : cf2.dwEffects;
		cf2.lcid = GetLinkIndex();
		lDelCount = ReplaceSel2((LPCTSTR)strMsg, cf2);
	}
	else
	{
		CHARFORMAT cf;
		memset(&cf, 0, sizeof(CHARFORMAT));
		cf.cbSize = sizeof(CHARFORMAT);
		cf.dwMask = CFM_CHARSET | CFM_COLOR | CFM_BOLD | CFM_UNDERLINE | CFM_ITALIC | CFM_FACE | CFM_SIZE | CFM_OFFSET | CFM_STRIKEOUT;
		cf.bCharSet = byCharSet;
		cf.yOffset = nYOffset;
		cf.bPitchAndFamily = byPitchAndFamily;
		cf.bCharSet = DEFAULT_CHARSET;
		if (lptszFaceName)
		{
			_tcsncpy(cf.szFaceName, lptszFaceName, LF_FACESIZE);
		}
		else
		{
			_tcsncpy(cf.szFaceName, DEAULT_FONT_NAME, LF_FACESIZE);
		}
		cf.yHeight = lHeight;
		cf.crTextColor = crNewColor;
		cf.dwEffects = 0;
		cf.dwEffects |= bUnderLine ? CFE_UNDERLINE : cf.dwEffects;
		cf.dwEffects |= bBold ? CFE_BOLD : cf.dwEffects;
		cf.dwEffects |= bItalic ? CFE_ITALIC : cf.dwEffects;
		lDelCount = ReplaceSel2((LPCTSTR)strMsg, cf);
	}

	if (lDelCount > 0 && lDelCount > lPos)
	{
		return TRUE;
	}

	if (lDelCount > 0 && lPos != 0 && lPos != -1)
	{
		lPos -= lDelCount;
	}

	//��¼����������
	if (bUrlLink && pData)
	{
		//int nIndex = cf2.lcid;//�»����²���Ҫ����������
		stLinkCallBackData data;
		data.lBeginPos = lPos;
		data.lEndPos = lPos + strMsg.GetLength();
		data.m_pFuncLBtn = (LinkCallBackFunc)pData->m_pFuncLBtn;
		data.strInfoLBtn = pData->strInfoLBtn;
		data.m_dwValueLBtn = pData->m_dwValueLBtn;
		data.m_pFuncRBtn = (LinkCallBackFunc)pData->m_pFuncRBtn;
		data.strInfoRBtn = pData->strInfoRBtn;
		data.m_dwValueRBtn = pData->m_dwValueRBtn;
		m_listLinksCallBack.push_back(data);
	}

	// ���ͼƬ����
	CheckImageLoadingTimer();

	return TRUE;
}

bool CUIShowRichEdit::TestClickOnImage(CPoint point, DWORD* dwImageUserData, CRect* pImageRc, BOOL* pOverScaleButton)
{
	if (dwImageUserData)
	{
		*dwImageUserData = -1;
	}

	if (pOverScaleButton)
	{
		*pOverScaleButton = FALSE;
	}

	DWORD dwResultOleID = -1;
	CRect rcResultOle(0,0,0,0);
	bool bRet = HitTestOleByPoint(point, dwResultOleID, rcResultOle);
	if (!bRet)
	{
		return false;
	}

	IOleProcesser* pOleProcesser = GetOleProcesser(dwResultOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Gif)
	{
		return false;
	}

	//ͼƬ���Ű�ť����
	BOOL bInScaleButton = FALSE;
	do 
	{
		if (!pOverScaleButton)
		{
			break;
		}

		if (!m_pDrawScaleButton || !m_pDrawScaleButton->GetValue2() || 
			!m_pImgScaleButton[DUIRICHEDIT_STATE_NORMAL])
		{
			break;
		}

		if (!pOleProcesser->IsEnableAutoSize())
		{
			break;
		}

		SIZE szOriginal = pOleProcesser->GetSize();
		if (szOriginal.cx > rcResultOle.Width())
		{
			CRect rcScaleIcon(0,0,0,0);
			m_pImgScaleButton[DUIRICHEDIT_STATE_NORMAL]->GetRect(&rcScaleIcon);

			rcScaleIcon.OffsetRect(-rcScaleIcon.left, -rcScaleIcon.top);
			rcScaleIcon.OffsetRect(rcResultOle.right - rcScaleIcon.Width() - 2, rcResultOle.bottom - rcScaleIcon.Height() - 2);
			if (rcScaleIcon.PtInRect(point))
			{
				bInScaleButton = TRUE;
				*pOverScaleButton = TRUE;
			}
		}

	} while (0);

	//ͼƬ��������
	if (bInScaleButton || rcResultOle.PtInRect(point))
	{
		//����ole����������Ϣ
		if (pImageRc)
		{
			*pImageRc = rcResultOle;
		}

		//����ole������Ϣ
		if (dwImageUserData)
		{
			*dwImageUserData = dwResultOleID;
		}

		return true;
	}

	return false;
}

bool CUIShowRichEdit::GetEncodeUBB(WTL::CString& string, int first, int last)
{
	bool bHasImage = false;
	WTL::CString text;
	GetContent(text);
	WTL::CString textW;
	if (first >= 0 && last >= first)
	{
		textW = text.Mid(first,last-first);
	}
	else if (last == -1)
	{
		textW = text;
	}
	else
	{
		//�쳣
	}

	//��Ϊ����ı�ǻ�ı�Ole�Ķ������ʱλ����Ϣ����ÿ��һ����Ҫ�ۼ�һ��ƫ��ֵ
	int oleObjOffset = 0;
	CComPtr<IRichEditOle> pRichOleObj;
	GetIRichEditOle(&pRichOleObj);
	if (!pRichOleObj)
	{
		return false;
	}

	//��������Ole����
	for (int i = 0; i < pRichOleObj->GetObjectCount(); i++)
	{
		REOBJECT object;
		memset(&object,0,sizeof(REOBJECT));
		object.cbStruct = sizeof(REOBJECT);
		pRichOleObj->GetObject(i,&object,REO_GETOBJ_NO_INTERFACES);

		//���󳬹���ѡ��ķ�Χ��ֱ������
		if (last != -1 && object.cp > last)
		{
			break;
		}
		//����ȸ÷�Χ����С
		else if (last != -1)
		{
			if (object.cp < first || object.cp >= last)
			{
				continue;
			}
		}

		//ƫ�ƺ��Ole�����λ��Ϊ��ԭ����λ��-��Χ��ʼ��+���ƫ��
		int oleObjPos = object.cp + oleObjOffset - first;

		//���
		WTL::CString strTag = _T("");
		IOleProcesser* pOleProcesser = GetOleProcesser(object.dwUser);
		if (pOleProcesser && OleProcesser_Gif == pOleProcesser->GetType())
		{
			CIMGifProcesser* pGifProcesser = (CIMGifProcesser*)pOleProcesser;
			if (pGifProcesser->IsLoadFromRes())
			{
				strTag.Format(PARSE_RESOURCE_PIC_FORMAT, pGifProcesser->GetResID());
			}
			else if (pGifProcesser->GetFilePathName())
			{
				BOOL bExistURL = pGifProcesser->IsExistFileURL();
				int nImgWidth = bExistURL ? pGifProcesser->GetFileURLImageWidth() : (int)pGifProcesser->GetSize().cx;
				int nImgHeight = bExistURL ? pGifProcesser->GetFileURLImageHeight() : (int)pGifProcesser->GetSize().cy;

				strTag.Format(PARSE_COPYDATA_PIC_FORMAT, pGifProcesser->GetFilePathName(), 
					bExistURL ? pGifProcesser->GetFileURL() : _T(""), nImgWidth, nImgHeight);
			}
		}
		else
		{
			strTag = _T(" ");
		}

		textW.Delete(oleObjPos);//ɾ��ƫ�ƺ��Ole�����λ�õĿո��ַ�
		textW.Insert(oleObjPos, strTag);//�������ַ�
		oleObjOffset += strTag.GetLength() - 1;	//�ۼ�ƫ��ֵ

		bHasImage = true;
	}

	//����32 �ֺ� ��ɫ 8 002244 cf.bCharSet 3, cf.bPitchAndFamily 3 cf.dwEffects 10 cf.dwMask 10   %s   ,text
	CHARFORMAT cf;
	GetDefaultCharFormat(cf);
	WTL::CString str(textW);
	string.Format(_T("%32s%4d%8d%3d%3d%10d%10d"),
		cf.szFaceName,
		cf.yHeight,
		cf.crTextColor,
		cf.bCharSet,
		cf.bPitchAndFamily,
		cf.dwEffects,
		cf.dwMask);
	string += str;

	return bHasImage;
}

bool CUIShowRichEdit::GetClipBoardUBB(std::string& strHtml, WTL::CString& strUnitext, int first, int last)
{
	strHtml = "";
	strUnitext = _T("");

	bool bHasImage = false;
	WTL::CString text;
	GetContent(text);
	WTL::CString textW;
	if (first >= 0 && last >= first)
	{
		textW = text.Mid(first,last-first);
	}
	else if (last == -1)
	{
		textW = text;
	}
	else
	{
		//�쳣
	}

	if (!m_htmlFormatParser.BeginProduceHtml())
	{
		return false;
	}

	//��Ϊ����ı�ǻ�ı�Ole�Ķ������ʱλ����Ϣ����ÿ��һ����Ҫ�ۼ�һ��ƫ��ֵ
	int oleObjOffset = 0;
	CComPtr<IRichEditOle> pRichOleObj;
	GetIRichEditOle(&pRichOleObj);
	if (!pRichOleObj)
	{
		return false;
	}
	//��������Ole����
	for (int i = 0; i < pRichOleObj->GetObjectCount(); i++)
	{
		REOBJECT object;
		memset(&object,0,sizeof(REOBJECT));
		object.cbStruct = sizeof(REOBJECT);
		pRichOleObj->GetObject(i,&object,REO_GETOBJ_NO_INTERFACES);

		//���󳬹���ѡ��ķ�Χ��ֱ������
		if (last != -1 && object.cp > last)
		{
			break;
		}
		//����ȸ÷�Χ����С
		else if (last != -1)
		{
			if (object.cp < first || object.cp >= last)
			{
				continue;
			}
		}

		//ƫ�ƺ��Ole�����λ��Ϊ��ԭ����λ��-��Χ��ʼ��+���ƫ��
		int oleObjPos = object.cp + oleObjOffset - first;

		//����Ole����֮ǰ����������
		m_htmlFormatParser.AddTextToHtml(textW.Left(oleObjPos));

		//����Ole��������
		IOleProcesser* pOleProcesser = GetOleProcesser(object.dwUser);
		if (pOleProcesser && OleProcesser_Gif == pOleProcesser->GetType())
		{
			CIMGifProcesser* pGifProcesser = (CIMGifProcesser*)pOleProcesser;
			if (pGifProcesser->IsLoadFromRes())
			{
				TCHAR tszDirPath[MAX_PATH+1] = {0};
				GetTempPath(MAX_PATH, tszDirPath);

				UINT nResID = pGifProcesser->GetResID();
				if (m_sysHelper.SysImgIsPng(nResID))
				{
					IXXImageEx* pImage = CSysHelper::GetXXImageDll().CreateImageObj();
					if (pImage)
					{
						pImage->LoadAnimation(m_sysHelper.GetRcFaceDll(), nResID, "PNG");
						if (!pImage->IsNull())
						{
							WTL::CString strFileName = _T("");
							strFileName.Format(_T("%seim_sysimage_%u.png"), tszDirPath, nResID);

							char szFile[MAX_PATH+1] = {0};
							WideCharToMultiByte(CP_OEMCP, NULL, strFileName, -1, szFile, MAX_PATH+1, NULL, FALSE);
							pImage->Save(szFile, XXIMAGE_FORMAT_PNG);
							m_htmlFormatParser.AddImageToHtmlBySrc(strFileName, true, nResID);
							pImage->Destroy();
						}
						pImage->Release();
					}
				}
				else
				{
					IXXImageEx* pImage = CSysHelper::GetXXImageDll().CreateImageObj();
					if (pImage)
					{
						pImage->LoadAnimation(m_sysHelper.GetRcFaceDll(), nResID, "GIF");
						if (!pImage->IsNull())
						{
							WTL::CString strFileName = _T("");
							strFileName.Format(_T("%seim_sysface_%u.gif"), tszDirPath, nResID);

							char szFile[MAX_PATH+1] = {0};
							WideCharToMultiByte(CP_OEMCP, NULL, strFileName, -1, szFile, MAX_PATH+1, NULL, FALSE);
							pImage->Save(szFile, XXIMAGE_FORMAT_GIF);
							m_htmlFormatParser.AddImageToHtmlBySrc(strFileName, true, nResID);
							pImage->Destroy();
						}
						pImage->Release();
					}
				}
			}
			else if (pGifProcesser->IsExistFileURL())
			{
				m_htmlFormatParser.AddImageToHtmlByURL(pGifProcesser->GetFileURL());
			}
			else
			{
				m_htmlFormatParser.AddImageToHtmlBySrc(pGifProcesser->GetFilePathName());
			}
		}
		else
		{
			//�쳣
		}

		strUnitext += textW.Left(oleObjPos) + ' ';
		textW.Delete(0, oleObjPos+1);	//ɾ����������ַ�
		oleObjOffset -= oleObjPos+1;	//�ۼ�ƫ��ֵ

		bHasImage = true;
	}

	if (bHasImage)
	{
		strUnitext += textW;
		m_htmlFormatParser.AddTextToHtml(textW);
		if (m_htmlFormatParser.EndProduceHtmlA(strHtml))
		{
			return bHasImage;
		}
		else
		{
			return false;
		}	
	}
	else
	{
		strUnitext = textW;
	}

	return bHasImage;
}

long CUIShowRichEdit::SelEnd(bool bHideCaret)
{
	SetSel(-1, -1);

	long nStartChar, nEndChar;
	GetSel(nStartChar, nEndChar);
	//SetSel(nEndChar, nEndChar);

	return nEndChar;
}

DWORD CUIShowRichEdit::InsertLoadingImg()
{
    WTL::CString strLoadingControl;                    
    if (m_pLoadingElementName)
    {
        TCHAR tszElement[MAX_PATH] = _T("");
        m_pLoadingElementName->GetValue(tszElement,MAX_PATH);
        strLoadingControl = tszElement;
    }
    if (strLoadingControl.GetLength() > 0)
    {
        int nLoadingWidth = 20;
        int nLoadingHeight = 20;
        if (m_pLoadingElementWidth)
        {
            nLoadingWidth = m_pLoadingElementWidth->GetValue();
        }
        if (m_pLoadingElementHeight)
        {
            nLoadingHeight = m_pLoadingElementHeight->GetValue();
        }
        return InsertOleControl(strLoadingControl, nLoadingWidth, nLoadingHeight);
    }

	return InsertSystemFace(m_sysHelper.GetSysHintImageID(IMAGE_TYPE_LOADING_GIF));
}

DWORD CUIShowRichEdit::InsertOverTimeImg()
{
    WTL::CString strErrorControl;                    
    if (m_pErrorElementName)
    {
        TCHAR tszElement[MAX_PATH] = _T("");
        m_pErrorElementName->GetValue(tszElement,MAX_PATH);
        strErrorControl = tszElement;
    }
    if (strErrorControl.GetLength() > 0)
    {
        int nErrorWidth = 20;
        int nErrorHeight = 20;
        if (m_pErrorElementWidth)
        {
            nErrorWidth = m_pErrorElementWidth->GetValue();
        }
        if (m_pErrorElementHeight)
        {
            nErrorHeight = m_pErrorElementHeight->GetValue();
        }
        return InsertOleControl(strErrorControl, nErrorWidth, nErrorHeight);
    }

	return InsertSystemPng(m_sysHelper.GetSysHintImageID(IMAGE_TYPE_NO_IMAGE_PNG), true);
}

DWORD CUIShowRichEdit::InsertBlockImageImg()
{
	return InsertSystemFace(m_sysHelper.GetSysHintImageID(IMAGE_TYPE_BLOCKIMAGE_GIF));
}

void CUIShowRichEdit::OnAddChar(int nCharInsert, int nCharCount, bool bReplaceMode)
{
	if (nCharCount <= 0)
	{
		return;
	}

	//���OleԪ��
	CheckOlesByAdd(nCharInsert, nCharCount);

	//�����չԪ��
	CheckExtraElementByAdd(nCharInsert, nCharCount, bReplaceMode);

    //������
    CheckPartByAdd(nCharInsert, nCharCount, bReplaceMode);

	//��鳬������Ϣ
	CheckLinkByAdd(nCharInsert, nCharCount);

	//���ͼƬ�ȴ��¼�
	tDelayImageInfo::iterator it = m_tWaitImageQueue.begin();
	for (; it != m_tWaitImageQueue.end(); ++it)
	{
		if (it->pos >= (DWORD)nCharInsert)
		{
			it->pos += nCharCount;
		}
	}

	//����������֮ǰ��ѡ������
	if (m_insertProcess.orgSel.cpMin >= nCharInsert)
	{
		m_insertProcess.orgSel.cpMin += nCharCount;
	}
	if (m_insertProcess.orgSel.cpMax >= nCharInsert)
	{
		m_insertProcess.orgSel.cpMax += nCharCount;
	}

	//����������λ��
	if (m_insertProcess.nInsertBeginPos > nCharInsert)
	{
		m_insertProcess.nInsertBeginPos += nCharCount;
	}
	if (m_insertProcess.nInsertEndPos > nCharInsert)
	{
		m_insertProcess.nInsertEndPos += nCharCount;
	}
}

void CUIShowRichEdit::OnDelChar(int nCharBegin, int nCharEnd)
{
	if (nCharEnd < nCharBegin)
	{
		return;
	}

	int nCharCount = nCharEnd - nCharBegin + 1;

	//���OleԪ��
	CheckOlesByDel(nCharBegin, nCharEnd);

	//�����չԪ��
	CheckExtraElementByDel(nCharBegin, nCharEnd);

    // ������
    CheckPartByDel(nCharBegin, nCharEnd);

	//��鳬������Ϣ
	CheckLinkByDel(nCharBegin, nCharEnd);

	//���ͼƬ�ȴ��¼�
	tDelayImageInfo::iterator it = m_tWaitImageQueue.begin();
	for (; it != m_tWaitImageQueue.end(); ++it)
	{
		if (it->pos >= (DWORD)nCharBegin && it->pos <= (DWORD)nCharEnd)
		{
			it->imgStatus = eImageStatus_Removed;
			continue;
		}
		it->pos -= nCharCount;
	}

	//����������֮ǰ��ѡ������
	if (m_insertProcess.orgSel.cpMin >= nCharBegin)
	{
		m_insertProcess.orgSel.cpMin -= nCharCount;
		if (m_insertProcess.orgSel.cpMin < 0)
		{
			m_insertProcess.orgSel.cpMin = 0;
		}
	}
	if (m_insertProcess.orgSel.cpMax >= nCharBegin)
	{
		m_insertProcess.orgSel.cpMax -= nCharCount;
		if (m_insertProcess.orgSel.cpMax < 0)
		{
			m_insertProcess.orgSel.cpMax = 0;
		}
	}

	//����������λ��
	if (m_insertProcess.nInsertBeginPos >= nCharBegin)
	{
		m_insertProcess.nInsertBeginPos -= nCharCount;
		if (m_insertProcess.nInsertBeginPos < 0)
		{
			m_insertProcess.nInsertBeginPos = 0;
		}
	}
	if (m_insertProcess.nInsertEndPos >= nCharBegin)
	{
		m_insertProcess.nInsertEndPos -= nCharCount;
		if (m_insertProcess.nInsertEndPos < 0)
		{
			m_insertProcess.nInsertEndPos = 0;
		}
	}
}

void CUIShowRichEdit::AddImageToMgr()
{
	if (m_imgProcessData.bSysFace)
	{
		return;
	}

	//֪ͨ�ϲ�
	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_ADD_FACE;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	UINotifyInfo.lParam2 = (DWORD_PTR)(LPCTSTR)m_imgProcessData.strImagePath; //�Զ���ͼƬ·��
	UINotifyInfo.lParam3 = (DWORD_PTR)(LPCTSTR)m_imgProcessData.strImageURL;
	::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
}

void CUIShowRichEdit::SaveImageAs()
{
	//GIF�ļ�����IMG�ļ������⴦��
	if (m_imgProcessData.bSysFace)
	{
		int nIndex = m_imgProcessData.strImagePath.Find(_T("eim_sysFace_"));
		if (nIndex != -1)
		{
			DWORD dwFaceID = _tcstoul(m_imgProcessData.strImagePath.Mid(nIndex+12, m_imgProcessData.strImagePath.GetLength()-1), 0, 10);

			//֪ͨ�ϲ�
			DUICtrlNotifyInfo UINotifyInfo;
			memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
			UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_SAVE_PICTURE;
			UINotifyInfo.lParam1 = (DWORD_PTR)(this);
			UINotifyInfo.lParam2 = (DWORD_PTR)TRUE; //�Ƿ���ϵͳ����
			UINotifyInfo.lParam3 = (DWORD_PTR)m_sysHelper.GetSysFaceResouceID(dwFaceID);//������ԴID
			UINotifyInfo.lParam4 = (DWORD_PTR)(LPCTSTR)_T(""); //�Զ���ͼƬ·��
			::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
		}
	}
	//������ʽ�ļ��Ĵ���
	else
	{
		//֪ͨ�ϲ�
		DUICtrlNotifyInfo UINotifyInfo;
		memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
		UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_SAVE_PICTURE;
		UINotifyInfo.lParam1 = (DWORD_PTR)(this);
		UINotifyInfo.lParam2 = (DWORD_PTR)FALSE; //�Ƿ���ϵͳ����
		UINotifyInfo.lParam3 = (DWORD_PTR)0;//������ԴID
		UINotifyInfo.lParam4 = (DWORD_PTR)(LPCTSTR)m_imgProcessData.strImagePath; //�Զ���ͼƬ·��
		UINotifyInfo.lParam5 = (DWORD_PTR)(LPCTSTR)m_imgProcessData.strImageURL;
		::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
	}
}

void CUIShowRichEdit::DoCopyInfo(IDataObject* pOleDataSource, LPCTSTR text)
{
	if (pOleDataSource)
	{
		WTL::CString strUBB = text;
		int dataSize = (strUBB.GetLength()+1) * (sizeof(TCHAR)/sizeof(BYTE)); 

		HGLOBAL hText = ::GlobalAlloc(GMEM_NODISCARD, dataSize);
		LPVOID pData = ::GlobalLock(hText);
		_tcsncpy((TCHAR*)pData, strUBB, strUBB.GetLength()+1);
		::GlobalUnlock(hText);

		m_stgmed[1].hGlobal = hText;
		pOleDataSource->SetData(&(m_fmtetc[1]), &(m_stgmed[1]), FALSE);

		//ʹ�ú���չ�������
		::GlobalFree(m_stgmed[1].hGlobal);
		m_stgmed[1].hGlobal = NULL;
	}
}

bool CUIShowRichEdit::GetSendImagePath(CHARRANGE cr)
{
	//���û�������
	m_imgProcessData.bSysFace = false;
	m_imgProcessData.strImagePath = _T("");
	m_imgProcessData.strImageURL = _T("");
	m_imgProcessData.nImageURLWidth = 0;
	m_imgProcessData.nImageURLHeight = 0;

	//��õ�ǰѡ�еķ�Χ�ڵ�Ԫ�ر�����Ϣ
	WTL::CString string;
	GetEncodeUBB(string, cr.cpMin, cr.cpMax);
	WTL::CString strUBB = string.Mid(70,string.GetLength()-70);

	//������ͼƬ��ID,����ID�õ�ͼƬ·��������һ�ݵ�SRImageĿ¼��
	while (strUBB.GetLength() > 0)
	{
		CAtlRegExp<CAtlRECharTraits> reg;
		REParseError status = reg.Parse(PARSE_COPYDATA_PIC);
		if (REPARSE_ERROR_OK != status)
		{
			// Unexpected error.
			break ;
		}
		CAtlREMatchContext<CAtlRECharTraits> mc;
		if (!reg.Match(strUBB, &mc))
		{
			int nLength = strUBB.GetLength();
			WTL::CString strDef = strUBB.Mid(2,nLength - 3) + _T(".gif");
			WTL::CString tempPath;
			tempPath.Format(_T("eim_sysFace_"));
			m_imgProcessData.bSysFace = true;
			m_imgProcessData.strImagePath = tempPath + strDef;
			m_imgProcessData.strImageURL = _T("");
			m_imgProcessData.nImageURLWidth = 0;
			m_imgProcessData.nImageURLHeight = 0;
			return true;
		}

		const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szStart = strUBB;
		const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szMatch = 0;
		const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szEnd   = 0;
		mc.GetMatch(0, &szMatch, &szEnd);
		{
			ptrdiff_t nLength = szEnd - szMatch;
			ptrdiff_t nHead = szMatch - szStart;

			WTL::CString strFormat;
			strFormat.Format(_T("%%.%ds"), nLength);

			WTL::CString strImageInfo;
			strImageInfo.Format(strFormat, szMatch);

			//�õ�ImageFilePath
			WTL::CString strCopyImg = strImageInfo.Mid(2, nLength - 3);

			int nImgURLBegin = strCopyImg.Find(_T("<url_"));
			WTL::CString strImgFile = strCopyImg.Mid(0, nImgURLBegin);

			int nWidthBegin = strCopyImg.Find(_T("<width_"));
			WTL::CString strImgURL = strCopyImg.Mid(nImgURLBegin + 5, nWidthBegin - nImgURLBegin - 6);

			int nHeightBegin = strCopyImg.Find(_T("<height_"));
			WTL::CString strWidth = strCopyImg.Mid(nWidthBegin + 7, nHeightBegin - nWidthBegin - 8);
			WTL::CString strHeight = strCopyImg.Mid(nHeightBegin + 8, strCopyImg.GetLength() - nHeightBegin - 9);

			m_imgProcessData.bSysFace = false;
			m_imgProcessData.strImagePath = strImgFile;
			m_imgProcessData.strImageURL = strImgURL;
			m_imgProcessData.nImageURLWidth = _tcstol(strWidth, '\0', 0);
			m_imgProcessData.nImageURLHeight = _tcstol(strHeight, '\0', 0);

			//ʣ���UBB��Ϣ
			strUBB = szEnd;
			return true;
		}
	}

	return false;
}

void CUIShowRichEdit::CheckImage()
{
	CUIEngineCom* pDirectUI = GetDirectUI();
	if (!pDirectUI)
	{
		return;
	}

	/////////////////////////////////////////////////////////////
	//���ͼƬ�Ƿ����
	tDelayImageInfo::iterator it = m_tWaitImageQueue.begin();
	for (; it != m_tWaitImageQueue.end(); ++it)
	{
		//�����ѹ���
		if (eImageStatus_Removed == it->imgStatus)
		{
			continue;
		}

		//����ʧ��״̬
		if (eImageStatus_Failed == it->imgStatus)
		{
            continue;            
		}

		//���Լ���ͼƬ
		//_wfopen����ȫ,������Ϊ����ϵͳ���ַ����������������
		WTL::CString strPicRcvPath;
		m_sysHelper.GetSRPicPath(it->strFileName, strPicRcvPath);

		CRect rcClient = GetRect();
		FILE* pFileOpenTest = NULL;
		if ((pFileOpenTest = _wfopen(strPicRcvPath, _T("r"))) != NULL)
		{
			fclose(pFileOpenTest);

			//����ͼƬ
			InsertContentBegin(eInsertModeBack, FALSE);
			bool bScrollBottomBefore = IsScrollAtBottom();
			SetSel(it->pos, it->pos + 1);

			DWORD dwOleID = this->InsertUserDefPic2((LPCTSTR)strPicRcvPath);
			if (-1 == dwOleID)
			{
				it->imgStatus = eImageStatus_Failed;
				it->dwOleID = this->InsertOverTimeImg();
			}
			else
			{
				it->imgStatus = eImageStatus_Removed;

				IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
				if (pOleProcesser && OleProcesser_Gif == pOleProcesser->GetType())
				{
					CIMGifProcesser* pIMGifProcesser = (CIMGifProcesser*)pOleProcesser;
					pIMGifProcesser->SetFileURL(it->strFileURL);
					pIMGifProcesser->SetFileURLImageSize(it->nURLImgWidth, it->nURLImgHeight);
				}
			}
			InsertContentEnd(eScrollAuto);
		}
		else if (eImageStatus_Suspend == it->imgStatus)
		{
			IOleProcesser* pOleProcesser = GetOleProcesser(it->dwOleID);
			if (pOleProcesser)
			{
				it->uTickTime = ::GetTickCount();
				it->imgStatus = pOleProcesser->GetVisible() ? eImageStatus_Loading : eImageStatus_Suspend;
				if (pOleProcesser->GetVisible())
				{
					DUICtrlNotifyInfo UINotifyInfo;
					memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
					UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_TRY_DOWNLOAD_IMG;
					UINotifyInfo.lParam1 = (DWORD_PTR)(this);
					UINotifyInfo.lParam2 = (DWORD_PTR)it->dwOleID;
					UINotifyInfo.lParam3 = NULL;
					UINotifyInfo.lParam4 = (DWORD_PTR)(LPCTSTR)it->strFileName;            
					UINotifyInfo.lParam5 = (DWORD_PTR)(LPCTSTR)it->strFileURL;

					int nFileNamePos = it->strFileName.ReverseFind(_T('/'));
					if (-1 == nFileNamePos)
					{
						nFileNamePos = it->strFileName.ReverseFind(_T('\\'));
					}
					if (nFileNamePos != -1)
					{
						UINotifyInfo.lParam6 = (DWORD_PTR)(LPCTSTR)it->strFileName.Mid(nFileNamePos + 1, it->strFileName.GetLength() - nFileNamePos - 1);
					}
					else
					{
						UINotifyInfo.lParam6 = (DWORD_PTR)(LPCTSTR)it->strFileName;
					}
					::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&UINotifyInfo, 0);
				}
			}
			else
			{
				it->imgStatus = eImageStatus_Removed;
			}
			continue;
		}
		else
		{
			IOleProcesser* pOleProcesser = GetOleProcesser(it->dwOleID);
			if (pOleProcesser && !pOleProcesser->GetVisible())
			{
				it->uTickTime = ::GetTickCount();
				it->imgStatus =  eImageStatus_Suspend;
			}
			else if ((::GetTickCount() - it->uTickTime) > m_nLoadingTimeout*1000)
			{
				it->imgStatus = eImageStatus_Failed;

				//�������ʧ��ͼ
				InsertContentBegin(eInsertModeBack, FALSE);
				bool bScrollBottomBefore = IsScrollAtBottom();
				SetSel(it->pos, it->pos + 1);
				it->dwOleID = this->InsertOverTimeImg();
				InsertContentEnd(eScrollAuto);
			}
		}
	}

	/////////////////////////////////////////////////////////////
	//ɾ��������
    bool bHasLoadingImg = false;
	it = m_tWaitImageQueue.begin();
	for (; it != m_tWaitImageQueue.end();)
	{
		if (eImageStatus_Removed == it->imgStatus)
		{
			it = m_tWaitImageQueue.erase(it);
			continue;
		}
		
		if (eImageStatus_Loading == it->imgStatus)
		{
			bHasLoadingImg = true;
		}
		++it;
	}

	/////////////////////////////////////////////////////////////
	//���¼���ʱ��
	if (m_tWaitImageQueue.empty() || !bHasLoadingImg)
	{
		StopImageLoadingTimer();
	}
}

int CUIShowRichEdit::GetLinkIndex()
{
	static DWORD s_dwIndex = 0;
	if (s_dwIndex > 65535)
	{
		s_dwIndex = 0;
	}
	return ++s_dwIndex;
}

void CUIShowRichEdit::ProcessPicTipsOnTimer()
{
	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_PIC_OP_TIPS;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);

	//��ȡ��ǰ������ʾ״̬
	BYTE byShow = 0;
	UINotifyInfo.lParam2 = (DWORD_PTR)1;
	UINotifyInfo.lParam3 = (DWORD_PTR)&byShow;
	::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
	if (byShow)
	{
		//��ǰ����Ƿ���������ʾ��
		BYTE byCurInTips = 0;
		UINotifyInfo.lParam2 = (DWORD_PTR)2;
		UINotifyInfo.lParam3 = (DWORD_PTR)&byCurInTips;
		::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
		if (byCurInTips)
		{
			//�ж�������ʾ�ı����Ƿ񻹴��� �ɱ༭ʱ�����ɾ�������
			if (m_nlastOverImageChar >= 0)
			{
				CHARRANGE cr;
				cr.cpMin = m_nlastOverImageChar;
				cr.cpMax = m_nlastOverImageChar+1;

				GetSendImagePath(cr);
				if (m_imgProcessData.strImagePath.GetLength() <= 0)
				{
					//����������ʾ
					UINotifyInfo.lParam2 = (DWORD_PTR)3;
					::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
					if (GetDirectUI())
					{
						GetDirectUI()->KillTimer(m_nIDTPicTips);
						m_nIDTPicTips = -1;
					}
					m_nlastOverImageChar = -1;
				}
			}
		}
		else
		{
			CPoint ptCursor;
			GetCursorPos(&ptCursor);
			::ScreenToClient(m_hWndDirectUI, &ptCursor);

			if (!(TestClickOnImage(ptCursor)))
			{
				//����������ʾ
				UINotifyInfo.lParam2 = (DWORD_PTR)3;
				::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
				if (GetDirectUI())
				{
					GetDirectUI()->KillTimer(m_nIDTPicTips);
					m_nIDTPicTips = -1;
				}
				m_nlastOverImageChar = -1;
			}
		}
	}
	else
	{
		if (GetDirectUI())
		{
			GetDirectUI()->KillTimer(m_nIDTPicTips);
			m_nIDTPicTips = -1;
		}
		m_nlastOverImageChar = -1;
	}
}

void CUIShowRichEdit::ScaleSize(SIZE& szScale, LONG nMaxCX, LONG nMaxCY)
{
	if (m_pImgScaleMaxWidth && nMaxCX > m_pImgScaleMaxWidth->GetValue())
	{
		nMaxCX = m_pImgScaleMaxWidth->GetValue();
	}
	if (m_pImgScaleMaxHeight && nMaxCY > m_pImgScaleMaxHeight->GetValue())
	{
		nMaxCY = m_pImgScaleMaxHeight->GetValue();
	}

	if (szScale.cx > nMaxCX)
	{
		FLOAT fScale = ((FLOAT)nMaxCX)/((FLOAT)szScale.cx);
		szScale.cx = nMaxCX;
		szScale.cy = (int)((FLOAT)(fScale*((FLOAT)szScale.cy)));
	}

	if (szScale.cy > nMaxCY)
	{
		FLOAT fScale = ((FLOAT)nMaxCY)/((FLOAT)szScale.cy);
		szScale.cy = nMaxCY;
		szScale.cx = (int)((FLOAT)(fScale*((FLOAT)szScale.cx)));
	}
}

int CUIShowRichEdit::GetOleScalePercent(DWORD dwOleID, int nCurWidth, int nCurHeight)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser)
	{
		return 0;
	}

	SIZE szOriginal = pOleProcesser->GetSize();
	if (pOleProcesser->GetType() == OleProcesser_Gif && 
		((CIMGifProcesser*)pOleProcesser)->IsExistFileURL())
	{
		int nURLWidth = ((CIMGifProcesser*)pOleProcesser)->GetFileURLImageWidth();
		int nURLHeight = ((CIMGifProcesser*)pOleProcesser)->GetFileURLImageHeight();
		szOriginal.cx = (nURLWidth > 0 && nURLHeight > 0) ? nURLWidth : szOriginal.cx;
		szOriginal.cy = (nURLWidth > 0 && nURLHeight > 0) ? nURLHeight : szOriginal.cy;
	}

	FLOAT fPercent = (FLOAT)(((FLOAT)nCurWidth)/((FLOAT)szOriginal.cx))*((FLOAT)100);
	return (int)fPercent;
}

void CUIShowRichEdit::ForbidSnapshot(DWORD dwElapse)
{
	ForbidSnapshotTimeout(false);

	CUIEngineCom* pUIEngine = GetDirectUI();
	if (!pUIEngine)
	{
		return;
	}

	if (-1 == m_nIDForbidSnapshot)
	{
		m_bForbidSnapshot = true;
		m_nIDForbidSnapshot = pUIEngine->SetTimer(this, dwElapse, NULL);
	}
}

void CUIShowRichEdit::ForbidSnapshotTimeout(bool bUpdateClient)
{
	CUIEngineCom* pUIEngine = GetDirectUI();
	if (!pUIEngine)
	{
		return;
	}

	if (m_nIDForbidSnapshot != -1)
	{
		pUIEngine->KillTimer(m_nIDForbidSnapshot);
		m_nIDForbidSnapshot = -1;
	}

	m_bForbidSnapshot = false;

	if (bUpdateClient)
	{
		OnRichEditInsideRedraw();
	}
}

void CUIShowRichEdit::DoActionInMouseMove()
{
	if (!m_bKeepMouseMoving)
	{
		if (GetDirectUI() && m_nIDActionInMouseMove != -1)
		{
			GetDirectUI()->KillTimer(m_nIDActionInMouseMove);
			m_nIDActionInMouseMove = -1;
		}
		return;
	}
	m_bKeepMouseMoving = false;

	if (!m_hWndDirectUI)
	{
		return;
	}

	if (!m_bMouseEnter)
	{
		return;
	}

	CPoint ptCurPos;
	GetCursorPos(&ptCurPos);
	::ScreenToClient(m_hWndDirectUI, &ptCurPos);

	//���û�����κ��ַ���
	int nOverChar = CharFromPos(ptCurPos) - 1;
	if (-1 == nOverChar)
	{
		m_nlastOverImageChar = -1;

		if (m_dwHostScaleButton != -1)
		{
			m_dwHostScaleButton = -1;
			OnRichEditInsideRedraw(true);
		}
		return;
	}

	//��겻���κ�ole������
	CRect rcImage;
	rcImage.SetRectEmpty();
	DWORD dwImageUserData = -1;
	BOOL bOnScaleButton = FALSE;
	if (!TestClickOnImage(ptCurPos, &dwImageUserData, &rcImage, &bOnScaleButton))
	{
		if (m_dwHostScaleButton != -1)
		{
			m_dwHostScaleButton = -1;
			OnRichEditInsideRedraw(true);
		}
		return;
	}

	//����ole��������찴ť״̬
	if (bOnScaleButton)
	{
		if (m_dwHostScaleButton != dwImageUserData)
		{
			m_dwHostScaleButton = dwImageUserData;
			OnRichEditInsideRedraw(true);
		}
	}
	else
	{
		if (m_dwHostScaleButton != -1)
		{
			m_dwHostScaleButton = -1;
			OnRichEditInsideRedraw(true);
		}
	}

	//����ʾ����������ʾ
	if (!m_bShowFaceTip)
	{
		return;
	}

	//��ǰ�������ole�������ϴ�����ole����ʱͬһ��
	if (nOverChar == m_nlastOverImageChar)
	{
		return;
	}

	//���ole����·��
	CHARRANGE cr;
	cr.cpMin = nOverChar;
	cr.cpMax = nOverChar + 1;
	GetSendImagePath(cr);

	//֪ͨӦ�ò�
	DUICtrlNotifyInfo duiNotifyInfo;
	memset(&duiNotifyInfo, 0, sizeof(DUICtrlNotifyInfo));
	duiNotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_PIC_OP_TIPS;
	duiNotifyInfo.lParam1 = (DWORD_PTR)(this);
	duiNotifyInfo.lParam2 = (DWORD_PTR)0; //��ʾ������ʾ
	duiNotifyInfo.lParam3 = (DWORD_PTR)&rcImage;
	duiNotifyInfo.lParam4 = (DWORD_PTR)m_imgProcessData.bSysFace ? 1 : 0;
	if (m_imgProcessData.bSysFace)
	{
		int nIndex = m_imgProcessData.strImagePath.Find(_T("eim_sysFace_"));
		if (nIndex != -1)
		{
			DWORD dwFaceID = _tcstoul(m_imgProcessData.strImagePath.Mid(nIndex+12, m_imgProcessData.strImagePath.GetLength()-1), 0, 10);
			duiNotifyInfo.lParam5 = (DWORD_PTR)dwFaceID;
		}
		else
		{
			duiNotifyInfo.lParam5 = (DWORD_PTR)0;
		}
		::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&duiNotifyInfo, 0);
	}
	else
	{
		duiNotifyInfo.lParam5 = (DWORD_PTR)(LPCTSTR)m_imgProcessData.strImagePath;
		duiNotifyInfo.lParam6 = (DWORD_PTR)(LPCTSTR)m_imgProcessData.strImageURL;
		::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&duiNotifyInfo, 0);
	}

	//������ʾ
	int nPercentValue = GetOleScalePercent(dwImageUserData, rcImage.Width(), rcImage.Height());
	if (nPercentValue < 100)
	{
		WTL::CString strImageText;
		strImageText.Format(_T("��ʾ������%d%%��˫���鿴ԭͼ"), nPercentValue);
		::SendMessage(m_hWndDirectUI, WM_SETTOOPTIP, (WPARAM)(LPCTSTR)strImageText, (LPARAM)this);
	}

	m_nlastOverImageChar = nOverChar;

	CUIEngineCom* pUIEngine = GetDirectUI();
	if (pUIEngine && -1 == m_nIDTPicTips)
	{
		m_nIDTPicTips = pUIEngine->SetTimer(this, 500, NULL);
	}
}

int CUIShowRichEdit::CheckCharLimit()
{
	//����Ϊ������Ҫ����RichEdit�ַ�����
	int nLineCount = GetLineCount();
	if (0 == nLineCount)
	{
		return 0;
	}

	//�����������ַ�����ɾ��ָ����������,��ֹ����RichEdit�ַ���������
	if (nLineCount > m_nMaxLinCout || GetTextLength() >= RICHEDIT_TEXT_ALLOW_COUNT)
	{
		//��ȡ��0����ʼ�ַ�λ��
		int nDelLineBegin = 0;
		if (nDelLineBegin > nLineCount - 1)
		{
			nDelLineBegin = nLineCount - 1;
		}
		int nCharBegin = LineIndex(nDelLineBegin);
		if (-1 == nCharBegin)
		{
			return 0;
		}

		//��ȡɾ������ʼ�ַ�λ��(������1,��Ϊ����Ľ�������һ�е���ʼ�ַ�λ��)
		int nDelLineEnd = nDelLineBegin + m_nBufferLinCout + 1;
		if (nDelLineEnd > nLineCount - 1)
		{
			nDelLineEnd = nLineCount - 1;
		}
		int nCharEnd = LineIndex(nDelLineEnd);
		if (-1 == nCharEnd)
		{
			return 0;
		}

		//����ɾ��nCharBegin��ʼ��(nCharEnd-nCharBegin)���ַ�
		OnDelChar(nCharBegin, nCharEnd - 1);

		//���1����ʼ�ַ�λ�õĶ�������
		CPoint ptEndPos = PosFromChar(nCharEnd);

		//���ù�����λ��
		LONG nScrollPos = 0;
		if (m_pScrollBarImplVert)
		{
			nScrollPos = m_pScrollBarImplVert->GetScrollPos();
		}

		//ɾ�����ݵĸ߶�
		int nDelHeight = 0;
		if (ptEndPos.y < 0)
		{
			nDelHeight = nScrollPos - abs(ptEndPos.y);
		}
		else
		{
			nDelHeight = nScrollPos + ptEndPos.y;
		}
		nScrollPos -= nDelHeight;

		//��ȡ��ǰѡ������
		LONG nCurSelBegin = 0;
		LONG nCurSelEnd = 0;
		GetSel(nCurSelBegin, nCurSelEnd);

		//ɾ��nCharBegin��ʼ��(nCharEnd-nCharBegin)���ַ�
		//��ʹ��ReplaceSel2,��ֹ�ݹ���ѭ��
		SetSel(nCharBegin, nCharEnd);
		m_FreeWindowlessRE.ReplaceSel(_T(""), FALSE);

		//�ָ���ǰѡ������
		if (nCurSelBegin != 0 && nCurSelBegin != -1)
		{
			nCurSelBegin -= (nCharEnd - nCharBegin);
			if (nCurSelBegin < 0)
			{
				nCurSelBegin = 0;
			}
		}
		if (nCurSelEnd != 0 && nCurSelEnd != -1)
		{
			nCurSelEnd -= (nCharEnd - nCharBegin);
			if (nCurSelEnd < 0)
			{
				nCurSelEnd = 0;
			}
		}
		SetSel(nCurSelBegin, nCurSelEnd);

		//���µ�ǰ���ݵĲ���λ��
		UpdateCurInsertSel();

		//������Ϣ�������ǲ���CFreeScrollWnd::SetScrollPos��
		nScrollPos = max(0, nScrollPos);
		if (m_pScrollBarImplVert)
		{
			m_pScrollBarImplVert->SetScrollPos(nScrollPos,TRUE);
		}

		return nCharEnd - nCharBegin;
	}

	return 0;
}

void CUIShowRichEdit::UpdateRegExpression()
{
	//��Դ��̬����ͼƬ
	WTL::CString strBaseExp = PARSE_RESOURCE_PIC;

	//������ͼƬ
	strBaseExp += PARSE_ANCHOR;
	strBaseExp += PARSE_COPYDATA_PIC;

	//����ͼƬ
	strBaseExp += PARSE_ANCHOR;
	if (m_regExpImgFile.strRegExpString.GetLength() > 0)
	{
		strBaseExp += m_regExpImgFile.strRegExpString;
	}
	else
	{
		m_regExpImgFile.nRegBeginCharCount = 2;
		m_regExpImgFile.nRegEndCharCount = 1;
		m_regExpImgFile.strRegExpString = PARSE_DEFAULT_PIC;
		m_regExpImgFile.strRegExpFormat = PARSE_DEFAULT_PIC_FORMAT;
		strBaseExp += PARSE_DEFAULT_PIC;
	}

	//URLͼƬ
	if (m_regExpImgURL.strRegExpString.GetLength() > 0)
	{
		strBaseExp += PARSE_ANCHOR;
		strBaseExp += m_regExpImgURL.strRegExpString;
	}

	//����
	if (m_regExpFace.strRegExpString.GetLength() > 0)
	{
		strBaseExp += PARSE_ANCHOR;
		strBaseExp += m_regExpFace.strRegExpString;
	}

	//������
	strBaseExp += PARSE_ANCHOR;
	strBaseExp += PARSE_HYPER_LINK;

	//At����
	if (m_regExpAt.strRegExpString.GetLength() > 0)
	{
		strBaseExp += PARSE_ANCHOR;
		strBaseExp += m_regExpAt.strRegExpString;
	}

	UpdateRegExppressionAll(strBaseExp);
	UpdateRegExpressionExcludeTick(strBaseExp);
	UpdateRegExpressionLinkAndTick();
}

void CUIShowRichEdit::UpdateRegExppressionAll(const WTL::CString& strBaseExp)
{
	m_strParseAllElement = strBaseExp;

	//�ɻ�Ʊ
	m_strParseAllElement += PARSE_ANCHOR;
	m_strParseAllElement += PARSE_TICKET_LINK;

	std::map<int, WTL::CString>::iterator it = m_customRegMap.begin();
	for(; it != m_customRegMap.end(); ++it)
	{
		m_strParseAllElement += PARSE_ANCHOR + it->second;
	}
	
}

void CUIShowRichEdit::UpdateRegExpressionExcludeTick(const WTL::CString& strBaseExp)
{
	m_strParseExcludeTicket = strBaseExp;

	std::map<int, WTL::CString>::iterator it = m_customRegMap.begin();
	for(; it != m_customRegMap.end(); ++it)
	{
		m_strParseExcludeTicket += PARSE_ANCHOR + it->second;
	}
}

void CUIShowRichEdit::UpdateRegExpressionLinkAndTick()
{
	//������
	m_strParseHyperlinkAndTicket = PARSE_HYPER_LINK;

	//�ɻ�Ʊ
	m_strParseHyperlinkAndTicket += PARSE_ANCHOR;
	m_strParseHyperlinkAndTicket += PARSE_TICKET_LINK;
}

void CUIShowRichEdit::DestroyAllTimer()
{
	if (!GetDirectUI())
	{
		return;
	}

	if (m_nIDTPicTips != -1)
	{
		GetDirectUI()->KillTimer(m_nIDTPicTips);
		m_nIDTPicTips = -1;
	}

	if (m_nIDTCaret != -1)
	{
		GetDirectUI()->KillTimer(m_nIDTCaret);
		m_nIDTCaret = -1;
	}

	if (m_nIDForbidSnapshot != -1)
	{
		GetDirectUI()->KillTimer(m_nIDForbidSnapshot);
		m_nIDForbidSnapshot = -1;
	}

	if (m_nIDActionInMouseMove)
	{
		GetDirectUI()->KillTimer(m_nIDActionInMouseMove);
		m_nIDActionInMouseMove = -1;
	}

	if (m_nIDTAniDrawTick != -1)
	{
		GetDirectUI()->KillTimer(m_nIDTAniDrawTick);
		m_nIDTAniDrawTick = -1;
	}

	if (m_nIDTScrollHide)
	{
		GetDirectUI()->KillTimer(m_nIDTScrollHide);
		m_nIDTScrollHide = -1;
	}

	StopImageLoadingTimer();
	StopDrawTimer();
}

LONG CUIShowRichEdit::GetRichEditFontHeight(LONG nPound)
{
	const LONG dTwipsPerInch = 1440;
	return MulDiv(nPound, dTwipsPerInch, 72);
}

void CUIShowRichEdit::InitCharFormat()
{
	//ѡ���������ַ�����
	bool bResetFocus = false;
	if (m_bHasFocus)
	{
		bResetFocus = true;
	}

	SelEnd(false);

	PARAFORMAT2 paraFormat;
	memset(&paraFormat, 0, sizeof(paraFormat));
	paraFormat.cbSize = sizeof(paraFormat);
	paraFormat.dwMask = PFM_ALIGNMENT|PFM_STARTINDENT|PFM_RIGHTINDENT|PFM_OFFSETINDENT|PFM_SPACEAFTER|PFM_SPACEBEFORE;
	paraFormat.wAlignment = PFA_LEFT;
	paraFormat.dxStartIndent = 50;
	paraFormat.dxRightIndent = 50;
	paraFormat.dySpaceAfter = 0;
	paraFormat.dySpaceBefore = 0;
	SetParaFormat(paraFormat);

	CHARFORMAT charFormat;
	memset(&paraFormat, 0, sizeof(charFormat));
	charFormat.cbSize = sizeof(charFormat);
	GetDefaultCharFormat(charFormat);
	charFormat.dwMask = CFM_BOLD | CFM_CHARSET | CFM_COLOR | CFM_ITALIC | CFM_SIZE | CFM_UNDERLINE | CFM_FACE;
	charFormat.crTextColor = RGB(0x99,0x99,0x99);
	charFormat.yHeight = GetRichEditFontHeight(10);
	charFormat.dwEffects = 0;
	charFormat.bPitchAndFamily = FF_DONTCARE;
	charFormat.bCharSet = DEFAULT_CHARSET;
	_tcsncpy(charFormat.szFaceName, _T("΢���ź�"), LF_FACESIZE);
	SetSelectionCharFormat(charFormat);
	SetDefaultCharFormat(charFormat);

	if (bResetFocus)
	{
		SetRichEditFocus();
	}
}

void CUIShowRichEdit::CheckImageLoadingTimer()
{
	if (m_tWaitImageQueue.size() > 0)
	{
		StartImageLoadingTimer();
	}
}

void CUIShowRichEdit::StartImageLoadingTimer()
{
	CUIEngineCom* pDirectUI = GetDirectUI();
	if (!pDirectUI)
	{
		return;
	}

	if (m_nIDDelayPicCheckForLoading != -1)
	{
		return;
	}
	m_nIDDelayPicCheckForLoading = pDirectUI->SetTimer(this, IMAGE_CHECK_FOR_LOADING_ELAPSE,NULL);
}

void CUIShowRichEdit::StopImageLoadingTimer()
{
	CUIEngineCom* pDirectUI = GetDirectUI();
	if (!pDirectUI)
	{
		return;
	}

	if (m_nIDDelayPicCheckForLoading != -1)
	{
		pDirectUI->KillTimer(m_nIDDelayPicCheckForLoading);
		m_nIDDelayPicCheckForLoading = -1;
	}
}

void CUIShowRichEdit::BufferedReDraw()
{
	m_bNeedReDraw = TRUE;
	UpdateDrawTimer();
}

void CUIShowRichEdit::UpdateDrawTimer()
{
	CUIEngineCom* pDirectUI = GetDirectUI();
	if (!pDirectUI)
	{
		return;
	}

	if (-1 == m_nIDTDraw)
	{
		m_nIDTDraw = pDirectUI->SetTimer(this, 200, NULL);
	}
}

void CUIShowRichEdit::StopDrawTimer()
{
	CUIEngineCom* pDirectUI = GetDirectUI();
	if (!pDirectUI)
	{
		return;
	}

	m_bNeedReDraw = FALSE;
	m_nDrawIdleTick = 0;
	if (m_nIDTDraw != -1)
	{
		pDirectUI->KillTimer(m_nIDTDraw);
		m_nIDTDraw = -1;
	}
}

void CUIShowRichEdit::OnDrawTimerProc()
{
	if (!m_bNeedReDraw)
	{
		m_nDrawIdleTick += 1;
		if (m_nDrawIdleTick > 10)
		{
			StopDrawTimer();
		}
		return;
	}

	m_nDrawIdleTick = 0;
	m_bNeedReDraw = FALSE;
	DirectRedraw2(NULL);
}

void CUIShowRichEdit::UpdateAniDrawTickTimer()
{
	if (m_bOlePlayAni || m_bExtraPlayAni)
	{
		OpenAniDrawTickTimer();
	}
	else
	{
		StopAniDrawTickTimer();
	}
}

void CUIShowRichEdit::OpenAniDrawTickTimer()
{
	CUIEngineCom* pDirectUI = GetDirectUI();
	if (!pDirectUI)
	{
		return;
	}

	if (-1 == m_nIDTAniDrawTick)
	{
		m_nIDTAniDrawTick = pDirectUI->SetTimer(this, 100, NULL);
	}
}

void CUIShowRichEdit::StopAniDrawTickTimer()
{
	CUIEngineCom* pDirectUI = GetDirectUI();
	if (!pDirectUI)
	{
		return;
	}

	if (m_nIDTAniDrawTick != -1)
	{
		pDirectUI->KillTimer(m_nIDTAniDrawTick);
		m_nIDTAniDrawTick = -1;
	}
}

void CUIShowRichEdit::OnAniDrawTimerProc()
{
	m_uAniFrameTick += 1;
	if (m_uAniFrameTick > 10000)
	{
		m_uAniFrameTick = 0;
	}
	OnRichEditInsideRedraw(true);
}

void CUIShowRichEdit::CreateVertScrollBar()
{
	if (m_pScrollBarImplVert != NULL) return;

	int nCount = GetChildCount();
	for (SHORT i=0;i<nCount;i++)
	{
		CUIControlBaseCom* pSubObj = (CUIControlBaseCom*)GetSubObject(i);
		TCHAR strName[MAX_PATH];
		pSubObj->GetControlTypeName(strName,MAX_PATH);
		if (_wcsicmp(strName,_T("ScrollBar")) == 0)
		{
			if (!((CUIScrollBarCom*)pSubObj)->IsHorz())
			{
				m_pScrollBarImplVert = (CUIScrollBarCom*)pSubObj;
				break;
			}
		}
	}

	if (m_pScrollBarImplVert == NULL) return;

	m_pScrollBarImplVert->SetOwnerCtrl(this);

	m_pScrollBarImplVert->Dock2(UIDock_Right, TRUE);
	UIPosition objPos = GetPosition(m_pScrollBarImplVert);
	objPos.horzPos.nWidth_Height = GetScrollSize();
	objPos.vertPos.nLeft_Top = 0;
	objPos.vertPos.nWidth_Height = 0;
	SetPosition(objPos,m_pScrollBarImplVert);
	m_pScrollBarImplVert->SetHorz(FALSE);
	m_pScrollBarImplVert->SetVisible2(FALSE, FALSE, FALSE);
	m_pScrollBarImplVert->SetMouseWheelParam(8, 10, 20, 10, 50);
	ResizeThis();
}

void CUIShowRichEdit::CreateHorzScrollBar()
{
	if (m_pScrollBarImplHorz != NULL) return;

	int nCount = GetChildCount();
	for (SHORT i=0;i<nCount;i++)
	{
		CUIControlBaseCom* pSubObj = (CUIControlBaseCom*)GetSubObject(i);
		TCHAR strName[MAX_PATH];
		pSubObj->GetControlTypeName(strName,MAX_PATH);
		if (_wcsicmp(strName,_T("ScrollBar")) == 0)
		{
			if (((CUIScrollBarCom*)pSubObj)->IsHorz())
			{
				m_pScrollBarImplHorz = (CUIScrollBarCom*)pSubObj;
				break;
			}		
		}
	}

	if (m_pScrollBarImplHorz == NULL) return;

	m_pScrollBarImplHorz->SetOwnerCtrl(this);

	m_pScrollBarImplHorz->Dock2(UIDock_Bottom, TRUE);
	UIPosition objPos = GetPosition(m_pScrollBarImplHorz);
	objPos.vertPos.nWidth_Height = GetScrollSize();
	objPos.horzPos.nLeft_Top = 0;
	objPos.horzPos.nWidth_Height = 0;
	SetPosition(objPos,m_pScrollBarImplHorz);
	m_pScrollBarImplHorz->SetHorz(TRUE);
	m_pScrollBarImplHorz->SetMouseWheelParam(8, 10, 20, 10, 50);
	ResizeThis();
}

long CUIShowRichEdit::GetScrollSize()
{
	if (m_pScrollBarImplVert)
	{
		CRect rcScroll = m_pScrollBarImplVert->GetRect();
		return rcScroll.Width();
	}

	if (m_pScrollBarImplHorz)
	{
		CRect rcScroll = m_pScrollBarImplHorz->GetRect();
		return rcScroll.Height();
	}

	return 0;
}

LONG CUIShowRichEdit::GetScrollPos(BOOL bHorz/* = FALSE*/)
{
	LONG nPos = 0;
	if (bHorz)
	{
		if (NULL == m_pScrollBarImplHorz)
		{
			return 0;
		}

		if (m_pScrollBarImplHorz->IsVisible())
		{
			nPos = m_pScrollBarImplHorz->GetScrollPos();
		}
	}
	else
	{
		if (NULL == m_pScrollBarImplVert)
		{
			return 0;
		}

		nPos = m_pScrollBarImplVert->GetScrollPos();
	}

	return nPos;
}

LONG CUIShowRichEdit::SetScrollPos(LONG nPos,BOOL bRedraw,BOOL bHorz/* = FALSE*/)
{
	LONG nResult = 0;

	if (bHorz)
	{
		if (m_pScrollBarImplHorz == NULL) return nResult;
		nResult = m_pScrollBarImplHorz->SetScrollPos(nPos,bRedraw);
	}
	else
	{
		if (m_pScrollBarImplVert == NULL) return nResult;
		nResult = m_pScrollBarImplVert->SetScrollPos(nPos,bRedraw);
	}

	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_SCROLL_POS_CHANGE;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	UINotifyInfo.lParam2 = (DWORD_PTR)nPos;
	UINotifyInfo.lParam3 = (DWORD_PTR)(bHorz ? SB_HORZ : SB_VERT);
	::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&UINotifyInfo, 0);

	return nResult;
}
LONG CUIShowRichEdit::GetScrollLimit(BOOL bHorz/* = FALSE*/)
{
	LONG nLimit = 0;

	if (bHorz)
	{
		if (m_pScrollBarImplHorz == NULL) return 0;

		nLimit = m_pScrollBarImplHorz->GetScrollLimit();
	}
	else
	{
		if (m_pScrollBarImplVert == NULL) return 0;

		nLimit = m_pScrollBarImplVert->GetScrollLimit();
	}

	return nLimit;
}

BOOL CUIShowRichEdit::GetScrollInfo(DUISCROLLINFO *pSBInfo,DUISB_MASK sifMask,BOOL bHorz/* = FALSE*/)
{
	BOOL bResult = FALSE;

	if (bHorz)
	{
		if (m_pScrollBarImplHorz == NULL) return FALSE;

		bResult = m_pScrollBarImplHorz->GetScrollInfo(pSBInfo,sifMask);
	}
	else
	{
		if (m_pScrollBarImplVert == NULL) return FALSE;

		bResult = m_pScrollBarImplVert->GetScrollInfo(pSBInfo,sifMask);
	}

	return bResult;
}

BOOL CUIShowRichEdit::SetScrollInfo(DUISCROLLINFO *pSBInfo,BOOL bRedraw,BOOL bHorz/* = FALSE*/)
{
	BOOL bResult = FALSE;
	if (bHorz)
	{
		if (m_pScrollBarImplHorz == NULL) return FALSE;

		bResult = m_pScrollBarImplHorz->SetScrollInfo(pSBInfo,bRedraw);
	}
	else
	{
		if (m_pScrollBarImplVert == NULL) return FALSE;

		bResult = m_pScrollBarImplVert->SetScrollInfo(pSBInfo,bRedraw);
	}

	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_SCROLL_INFO;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	UINotifyInfo.lParam2 = (DWORD_PTR)pSBInfo;
	UINotifyInfo.lParam3 = (DWORD_PTR)(bHorz ? SB_HORZ : SB_VERT);
	::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);

	return bResult;
}

void CUIShowRichEdit::ShowScrollBar(BOOL bShow,BOOL bRedraw,BOOL bHorz/* = FALSE*/)
{
	if (IsScrollBarVisible(bHorz) == bShow) return;
	if (bHorz)
	{
		if (m_pScrollBarImplHorz == NULL) return;
		m_pScrollBarImplHorz->SetVisible2(bShow, bRedraw, FALSE);
	}
	else
	{
		if (m_pScrollBarImplVert == NULL) return;
		m_pScrollBarImplVert->SetVisible2(bShow,bRedraw, FALSE);
	}

	if (bShow)
	{
		if (GetDirectUI() && -1 == m_nIDTScrollHide)
		{
			m_nIDTScrollHide = GetDirectUI()->SetTimer(this, 500, NULL);
		}
	}
	else
	{
		if (GetDirectUI() && m_nIDTScrollHide != -1)
		{
			GetDirectUI()->KillTimer(m_nIDTScrollHide);
			m_nIDTScrollHide = -1;
		}
	}
}

BOOL CUIShowRichEdit::IsScrollBarVisible(BOOL bHorz/* = FALSE*/)
{
	BOOL bVisible = FALSE;
	if (bHorz)
	{
		if (m_pScrollBarImplHorz == NULL) return FALSE;
		bVisible = m_pScrollBarImplHorz->IsVisible();
	}
	else
	{
		if (m_pScrollBarImplVert == NULL) return FALSE;
		bVisible = m_pScrollBarImplVert->IsVisible();
	}

	return bVisible;
}

void CUIShowRichEdit::EnableScrollBarCtrl(BOOL bEnabled,BOOL bRedraw,BOOL bHorz/* = FALSE*/)
{
	if (bHorz)
	{
		if (m_pScrollBarImplHorz == NULL) return;
		m_pScrollBarImplHorz->EnableScrollBar(bEnabled);
		if (bRedraw) m_pScrollBarImplHorz->Redraw();
	}
	else
	{
		if (m_pScrollBarImplVert == NULL) return;
		m_pScrollBarImplVert->EnableScrollBar(bEnabled);
		if (bRedraw) m_pScrollBarImplVert->Redraw();
	}

}

BOOL CUIShowRichEdit::IsScrollBarExist(BOOL bHorz/* = FALSE*/)
{
	BOOL bResult = FALSE;

	if (bHorz)
	{
		return m_bHorzScrollBarExist;
	}
	else
	{
		return m_bVertScrollBarExist;
	}

	return bResult;
}

BOOL CUIShowRichEdit::IsScrollBarDragging(BOOL bHorz/* = FALSE*/)
{
	CUIScrollBarCom* pScrollBar = NULL;
	if (bHorz)
	{
		pScrollBar = m_pScrollBarImplHorz;
	}
	else
	{
		pScrollBar = m_pScrollBarImplVert;
	}

	if (!pScrollBar)
	{
		return FALSE;
	}

	if (!pScrollBar->IsScrollBarDragging())
	{
		return FALSE;
	}

	if (!(GetAsyncKeyState(VK_LBUTTON) & 0x8000))
	{
		return FALSE;
	}

	return TRUE;
}

void CUIShowRichEdit::OnScrollHideTimerProc()
{
	// ����ڿؼ�����
	CPoint ptCursor(0,0);
	GetCursorPos(&ptCursor);
	ScreenToClient(m_hWndDirectUI, &ptCursor);

	CRect rcControl = GetRect();
	if (rcControl.PtInRect(ptCursor))
	{
		return;
	}

	// ������������ק״̬
	if (IsScrollBarDragging(FALSE))
	{
		return;
	}

	ShowScrollBar(FALSE, TRUE, FALSE);
}

void CUIShowRichEdit::SyncScrollPos()
{
	//��鲢ͬ������λ��
	//remark1:���ole����ʱ,RichEdit�ڲ����Զ�����������λ��,ȴû��֪ͨ��Ӧ�ò�
	//remark2:ͨ��ͬ����ǰ������λ�õ�RichEdit,�ﵽ����RichEdit�����Ե�Ч��
	CPoint ptScrollEditPos(0,0);
	m_FreeWindowlessRE.GetScrollPos(ptScrollEditPos);

	LONG nScrollBarPos = GetScrollPos(FALSE);
	if (ptScrollEditPos.y != nScrollBarPos)
	{
		OnRichEditMsgProc(WM_VSCROLL, MAKEWPARAM(DUI_SB_THUMBPOSITION, (WORD)nScrollBarPos), NULL);
	}
}

/***********************************************�����ӿ�***********************************************/
//////////////////////////////////////////////////////////////////////////
void CUIShowRichEdit::CreateProps()
{
	//Scale
	m_pScaleProp = CreateGroupProp(NULL, _T("Scale"), TRUE);
	m_pDrawScaleButton = (CUIBOOLProp*)CreateProp(m_pScaleProp,_PROPTYPE_BOOL,_T("IsDrawScaleButton"),_T(""),TRUE,NULL);
	if (m_pDrawScaleButton)
	{
		m_pDrawScaleButton->SetValue2(FALSE);
	}

	tstringex strKey[] = {_T("Normal"), _T("Disabled"), _T("Hot")};
	for (int i = 0; i < DUIRICHEDIT_STATE_LAST; ++i)
	{
		m_pDrawProp[i] = CreateGroupProp(m_pScaleProp, strKey[i].c_str(), TRUE);
		m_pImgScaleButton[i] = (CUIImageSecProp*)CreateProp(m_pDrawProp[i],_PROPTYPE_IMAGESECTION,_T("Image"),_T(""),TRUE,NULL);
	}

	m_pImgScaleMaxWidth = (CUINumberLongProp*)CreateProp(m_pScaleProp, _PROPTYPE_LONG, _T("ScaleMaxWidth"), _T(""), TRUE, NULL);
	if (m_pImgScaleMaxWidth)
	{
		m_pImgScaleMaxWidth->SetValue(1000);
	}
	m_pImgScaleMaxHeight = (CUINumberLongProp*)CreateProp(m_pScaleProp, _PROPTYPE_LONG, _T("ScaleMaxHeight"), _T(""), TRUE, NULL);
	if (m_pImgScaleMaxHeight)
	{
		m_pImgScaleMaxHeight->SetValue(1000);
	}

	//Link
	m_pLinkProp = CreateGroupProp(NULL, _T("Link"), TRUE);
	m_pColorLink = (CUIColorProp*)CreateProp(m_pLinkProp, _PROPTYPE_COLOR, _T("Color"), _T(""), TRUE, NULL);
	if (m_pColorLink)
	{
		m_pColorLink->SetValue((OLE_COLOR)RGB(0, 114, 193));
	}
	m_pUnderlineLink = (CUIBOOLProp*)CreateProp(m_pLinkProp, _PROPTYPE_BOOL, _T("Underline"), _T(""), TRUE, NULL);
	if (m_pUnderlineLink)
	{
		m_pUnderlineLink->SetValue2(TRUE);
	}

	//RichElement
	m_pOleElementExModalProp = CreateGroupProp(NULL, _T("RichElement"), TRUE);

	WTL::CString strModalText = _T("");
	for (int i = 0; i < OLE_ELEEX_MODAL_MAX; ++i)
	{
		//item height
		strModalText.Format(_T("ItemHeight%d"), i + 1);
		m_pOleElementExModalArray[i].pEleHeight = (CUINumberLongProp*)CreateProp(m_pOleElementExModalProp, _PROPTYPE_LONG, strModalText, _T(""), TRUE, NULL);

		//item text style
		strModalText.Format(_T("ItemTextStyle%d"), i + 1);
		m_pOleElementExModalArray[i].pEleTextStyle = (CUITextStyleProp*)CreateProp(m_pOleElementExModalProp, _PROPTYPE_TEXTSTYLE, strModalText, _T(""), TRUE, NULL);

		//item modal
		strModalText.Format(_T("ItemModal%d"), i + 1);
		m_pOleElementExModalArray[i].pEditProp = (CUIPluginProp*)CreateProp(m_pOleElementExModalProp, _PROPTYPE_PLUGIN, strModalText, _T(""), TRUE, NULL);
		m_pOleElementExModalArray[i].pEditProp->SetPropID(ID_OLE_ELEMENTEX_EDIT_BEGIN + i);
	}

    m_pGroupProp = CreateGroupProp(NULL,_T("Image"), TRUE);
    
    m_pImgTimeout = (CUINumberLongProp*)CreateProp(m_pGroupProp,_PROPTYPE_LONG,_T("Timeout"),_T(""),TRUE,NULL);
    m_pImgTimeout->SetValue(15);

    m_pImgLoading = CreateGroupProp(m_pGroupProp, _T("ImgLoading"), TRUE);
    m_pLoadingElementName = (CUIStrProp*)CreateProp(m_pImgLoading,_PROPTYPE_STRING,_T("LoadingName"),_T(""),TRUE,NULL);
    m_pLoadingElementWidth = (CUINumberLongProp*)CreateProp(m_pImgLoading,_PROPTYPE_LONG,_T("LoadingWidth"),_T(""),TRUE,NULL);
    m_pLoadingElementHeight = (CUINumberLongProp*)CreateProp(m_pImgLoading,_PROPTYPE_LONG,_T("LoadingHeight"),_T(""),TRUE,NULL);

    m_pImgError = CreateGroupProp(m_pGroupProp, _T("ImgError"), TRUE);
    m_pErrorElementName = (CUIStrProp*)CreateProp(m_pImgError,_PROPTYPE_STRING,_T("ErrorName"),_T(""),TRUE,NULL);
    m_pErrorElementWidth = (CUINumberLongProp*)CreateProp(m_pImgError,_PROPTYPE_LONG,_T("ErrorWidth"),_T(""),TRUE,NULL);
    m_pErrorElementHeight = (CUINumberLongProp*)CreateProp(m_pImgError,_PROPTYPE_LONG,_T("ErrorHeight"),_T(""),TRUE,NULL);
    
}

BOOL CUIShowRichEdit::DrawObject(CUIObjectDraw* pObjDraw,RECT sknrc)
{
	if (!pObjDraw)
	{
		return FALSE;
	}

	if (!CanUpdateNow())
	{
		return FALSE;
	}

	//���ƶ���ʱ�Ӳ���
	m_bOlePlayAni = false;
	m_bExtraPlayAni = false;

	//�ж��Ƿ���Ҫ����
	RECT rcDUI = GetRect();
	CRect rcClient = CRect(rcDUI.left, rcDUI.top, rcDUI.right, rcDUI.bottom);
	long nScrollWidth = IsScrollBarExist(FALSE)?GetScrollSize():0;
	rcClient.right -= nScrollWidth;

	CRect rcControlPaint;
	if (!rcControlPaint.IntersectRect(&rcClient, &sknrc))
	{
		return FALSE;
	}

	//����DC
	HDC hDrawDC = pObjDraw->GetDC(FALSE);

	//���òü�����
	CRgn rgnOriginal;
	int nSetRgnResult = ::GetClipRgn(hDrawDC, (HRGN)rgnOriginal);
	if (nSetRgnResult != -1)
	{
		RECT rcUpdateClient;
		::IntersectRect(&rcUpdateClient, &rcControlPaint, &rcClient);

		if (m_hClipRgn)
		{
			CRect rcClip(0, 0, 0, 0);
			::GetRgnBox(m_hClipRgn, &rcClip);
			if (!::EqualRect(&rcUpdateClient, &rcClip))
			{
				::DeleteObject(m_hClipRgn);
				m_hClipRgn = NULL;
			}
		}

		if (!m_hClipRgn)
		{
			m_hClipRgn = ::CreateRectRgn(rcUpdateClient.left, rcUpdateClient.top, rcUpdateClient.right, rcUpdateClient.bottom);
		}
		::SelectClipRgn(hDrawDC, m_hClipRgn);
	}

	//����
	m_FreeWindowlessRE.WindowlessREProc(WM_PAINT, (WPARAM)hDrawDC, (LPARAM)&rcControlPaint);

	//��鶯������ʱ��
	UpdateAniDrawTickTimer();

	//��ԭ�ü�����
	switch (nSetRgnResult)
	{
	case 0: //ԭ��û�вü�����
		{
			::SelectClipRgn(hDrawDC, NULL);
		}
		break;
	case 1: //ԭ���вü�����
		{
			::SelectClipRgn(hDrawDC, (HRGN)rgnOriginal);
		}
		break;
	default:
		break;
	}

	return TRUE;
}

BOOL CUIShowRichEdit::EventNotify(UINotify *peVentNotify)
{
	BOOL bResult = FALSE;

	switch (peVentNotify->eWinMsgId)
	{
	case WM_SETCURSOR:
		{
			if (m_hWndDirectUI)
			{
				CPoint ptCursor;
				::GetCursorPos(&ptCursor);
				::ScreenToClient(m_hWndDirectUI, &ptCursor);
				CRect rcClient = GetRect();
				long nScrollWidth = IsScrollBarExist(FALSE)?GetScrollSize():0;
				rcClient.right -= nScrollWidth;

				CUIEngineCom* pUIEngine = GetDirectUI();
				if (rcClient.PtInRect(ptCursor) && pUIEngine && 
					pUIEngine->GetFocusObject() == this && 
					pUIEngine->GetHotObject() == this)
				{
					LRESULT lHitTest = OnSetCursor((WPARAM)peVentNotify->lParam1, (LPARAM)peVentNotify->lParam2, ptCursor);
					if (lHitTest != -1)
					{
						bResult = TRUE;
						return bResult;
					}

					OnRichEditMsgProc(WM_SETCURSOR, (WPARAM)peVentNotify->lParam1, (LPARAM)peVentNotify->lParam2);
					bResult = FALSE;
					return bResult;
				}
			}
			bResult = TRUE;
			return bResult;
		}
		break;
	case WM_MOUSEWHEEL:
		{
			CUIEngineCom* pUIEngine = GetDirectUI();
			if (pUIEngine && pUIEngine->GetHotObject() == this)
			{
				CheckImageLoadingTimer();

				short zDelta = HIWORD(peVentNotify->lParam1);
				OnMouseWheel(zDelta);
			}

			bResult = TRUE;
		}
		break;
	case WM_LBUTTONDOWN:
		{
			m_bValidLButtonUp = true;
			CPoint pt(LOWORD(peVentNotify->lParam2), HIWORD(peVentNotify->lParam2));
			CRect rcDUI = GetRect();
			long nScrollWidth = IsScrollBarExist(FALSE)?GetScrollSize():0;
			rcDUI.right -= nScrollWidth;

			CUIEngineCom* pUIEngine = GetDirectUI();
			if (rcDUI.PtInRect(pt) && pUIEngine && pUIEngine->GetHotObject() == this)
			{
				int nHitTest = OnLButtonDown((int)peVentNotify->lParam1, pt);
				if (-1 == nHitTest)
				{
					OnRichEditMsgProc(WM_LBUTTONDOWN, (WPARAM)peVentNotify->lParam1, (LPARAM)peVentNotify->lParam2);
				}

				//��鲢ͬ��������λ��
				SyncScrollPos();
			}

			bResult = TRUE;
			return bResult;
		}
		break;
	case WM_LBUTTONUP:
		{
			CUIEngineCom* pUIEngine = GetDirectUI();
			if (pUIEngine && pUIEngine->GetFocusObject() == this)
			{
				bool bMouseHitTest = false;
				CPoint ptCursor(LOWORD(peVentNotify->lParam2), HIWORD(peVentNotify->lParam2));
				CRect rcSkinClient = GetRect();
				if (m_bValidLButtonUp && rcSkinClient.PtInRect(ptCursor))
				{
					bMouseHitTest = true;
				}

				bool bMouseCapured = false;
				if (m_bValidLButtonUp && m_bHasCaptureState && IsVisible())
				{
					bMouseCapured = true;
				}

				m_bValidLButtonUp = false;

				if (bMouseHitTest || bMouseCapured)
				{
					OnLButtonUp((int)peVentNotify->lParam1, ptCursor);
					OnRichEditMsgProc(WM_LBUTTONUP, (WPARAM)peVentNotify->lParam1, (LPARAM)peVentNotify->lParam2);
				}
			}

			bResult = TRUE;
			return bResult;
		}
		break;
	case WM_MOUSEMOVE:
		{
			CPoint pt(LOWORD(peVentNotify->lParam2), HIWORD(peVentNotify->lParam2));
			CRect rcDUI = GetRect();
			long nScrollWidth = IsScrollBarExist(FALSE)?GetScrollSize():0;
			rcDUI.right -= nScrollWidth;

			CUIEngineCom* pUIEngine = GetDirectUI();
			if (rcDUI.PtInRect(pt) && pUIEngine && pUIEngine->GetHotObject() == this)
			{
				//��������ʱ�����ڿؼ������������޷��յ�UISM_MOUSEENTER���Ӷ�û�м���WM_MOUSEWHEEL������
				if (!m_bRegisterMessage)
				{
					m_bRegisterMessage = true;
					pUIEngine->RegisterMessage(WM_MOUSEWHEEL,this,FALSE);
				}

				LRESULT lHitTest = OnMouseMove((WPARAM)peVentNotify->lParam1, (LPARAM)peVentNotify->lParam2);
				if (lHitTest != -1)
				{
					bResult = TRUE;
					return bResult;
				}
			}

			OnRichEditMsgProc(WM_MOUSEMOVE, (WPARAM)peVentNotify->lParam1, (LPARAM)peVentNotify->lParam2);
			bResult = TRUE;
			return bResult;
		}
		break;
	case WM_CAPTURECHANGED:
		{
			if((HWND)peVentNotify->lParam2 != m_hWndDirectUI)
			{
				if (m_bHasCaptureState)
				{
					m_FreeWindowlessRE.GetWinHost()->TxSetCapture(FALSE);
				}
			}

			bResult = TRUE;
			return bResult;
		}
		break;
	case UISM_SBMSG_VSCROLL:
		{
			CheckImageLoadingTimer();
			OnRichEditMsgProc(WM_VSCROLL, MAKEWPARAM((WORD)peVentNotify->lParam1, (WORD)peVentNotify->lParam2), NULL);

			bResult = FALSE;
			return bResult;
		}
		break;
	case UISM_SBMSG_HSCROLL:
		{
			//���������������
		}
		break;
	case UISM_PM_COMMAND:
		{
			OnMenuCommond((UINT)peVentNotify->lParam1);
		}
		break;
	case WM_IME_STARTCOMPOSITION:
	case WM_IME_COMPOSITION:
	case WM_IME_ENDCOMPOSITION:
		{
			if (m_bHasFocus)
			{
				if(OnRichEditMsgProc(peVentNotify->eWinMsgId, (WPARAM)peVentNotify->lParam1, (LPARAM)peVentNotify->lParam2) == S_OK)
					return FALSE;
			}
			return TRUE;
		}
		break;
	default:
		break;
	}

	switch(peVentNotify->eDuiMsgId)
	{
	case UISM_TIMER:
		{
			UINT nIDEvent = (UINT)peVentNotify->lParam1;

			//�������
			if (nIDEvent == m_nIDTDraw)
			{
				OnDrawTimerProc();
			}
			//�����˸
			else if (nIDEvent == m_nIDTCaret)
			{
				m_FreeWindowlessRE.UpdateCaretInTimer();
			}
			//��չԪ�ػ�������ʱ��
			else if (nIDEvent == m_nIDTAniDrawTick)
			{
				OnAniDrawTimerProc();
			}
			//���ͼƬ
			else if (nIDEvent == m_nIDDelayPicCheckForLoading)
			{
				CheckImage();
			}
			else if (nIDEvent == m_nIDTPicTips)
			{
				ProcessPicTipsOnTimer();
			}
			else if (nIDEvent == m_nIDForbidSnapshot)
			{
				ForbidSnapshotTimeout(true);
			}
			else if (nIDEvent == m_nIDActionInMouseMove)
			{
				DoActionInMouseMove();
			}
			else if (nIDEvent == m_nIDTScrollHide)
			{
				OnScrollHideTimerProc();
			}

			bResult = FALSE;
		}
		break;

	case UISM_SIZE:
		{
			bResult = FALSE;

			CRect rcDUIClientNew = GetRect();
			long nScrollWidth = IsScrollBarExist(FALSE) ? GetScrollSize() : 0;
			rcDUIClientNew.right -= nScrollWidth;

			OnRichEditMsgProc(WM_SIZE, 0, MAKELPARAM(rcDUIClientNew.Width(), rcDUIClientNew.Height()));

			//���ݿͻ������С�����ڹ�������������������CPU
			if (m_pScrollBarImplVert)
			{
				if (rcDUIClientNew.Height() <= 300)
				{
					m_pScrollBarImplVert->SetMouseWheelParam(8, 10, 20, 10, 50);
				}
				else if (rcDUIClientNew.Height() <= 600)
				{
					m_pScrollBarImplVert->SetMouseWheelParam(20, 20, 12, 5, 30);
				}
				else if (rcDUIClientNew.Height() <= 1280)
				{
					m_pScrollBarImplVert->SetMouseWheelParam(30, 50, 10, 3, 15);
				}
				else
				{
					m_pScrollBarImplVert->SetMouseWheelParam(30, 100, 15, 3, 20);
				}
			}

			//���ͼƬ����ʱ��
			CheckImageLoadingTimer();
		}
		break;

	case UISM_ONSETFOCUS:
		{
			LONG x = peVentNotify->lParam1;
			LONG y = peVentNotify->lParam2;
			LONG* pnResult = (LONG*)peVentNotify->lParam3;

			SetFocus();

			bResult = FALSE;
		}
		break;

	case UISM_SETFOCUS:
		{
			//����ֵ
			BOOL *pbSetFocusResult = (BOOL*)peVentNotify->lParam1;
			*pbSetFocusResult = FALSE;
			bResult = FALSE;

			OnRichEditMsgProc(WM_SETFOCUS, NULL, 0);

			m_bHasFocus = true;
		}
		break;

	case UISM_ONKILLFOCUS:
		{
			bResult = FALSE;

			m_FreeWindowlessRE.ShowCaret(false);

			OnRichEditMsgProc(WM_KILLFOCUS, NULL, 0);

			m_bHasFocus = false;
		}
		break;

	case UISM_MOUSELEAVE:
		{
			LONG* pnResult = (LONG*)peVentNotify->lParam1;
			CUIEngineCom* pDirectUI = GetDirectUI();
			if (pDirectUI && m_bRegisterMessage)
			{
				pDirectUI->UnRegisterMessage(WM_MOUSEWHEEL,this);
				m_bRegisterMessage = false;
			}

			if (!m_bHasCaptureState)
			{
				OnRichEditMsgProc(WM_MOUSELEAVE, 0, 0);
			}

			m_bMouseEnter = false;

			if (m_dwHostScaleButton != -1)
			{
				m_dwHostScaleButton = -1;
				OnRichEditInsideRedraw(true);
			}

			bResult = FALSE;
		}
		break;

	case UISM_LBUTTONUP:
		{
			LONG nHitTest = peVentNotify->lParam1;
			LONG x = peVentNotify->lParam2;
			LONG y = peVentNotify->lParam3;
			LONG* pnResult = (LONG*)peVentNotify->lParam4;

			bResult = FALSE;
		}
		break;

	case UISM_LBUTTONDBCLICK:
		{
			LONG nHitTest = peVentNotify->lParam1;
			LONG x = peVentNotify->lParam2;
			LONG y = peVentNotify->lParam3;
			LONG* pnResult = (LONG*)peVentNotify->lParam4;

			LPARAM lParam = MAKELPARAM(x, y);
			if (-1 == OnLButtonDbClick((WPARAM)nHitTest, (LPARAM)lParam))
			{
				OnRichEditMsgProc(WM_LBUTTONDBLCLK, (WPARAM)nHitTest, (LPARAM)lParam);
			}

			bResult = FALSE;
		}
		break;

	case UISM_LBUTTONDOWN:
		{
			LONG nHitTest = peVentNotify->lParam1;
			LONG x = peVentNotify->lParam2;
			LONG y = peVentNotify->lParam3;
			LONG* pnResult = (LONG*)peVentNotify->lParam4;

			bResult = FALSE;
		}
		break;

	case UISM_RBUTTONDOWN:
		{
			LONG nHitTest = peVentNotify->lParam1;
			LONG x = peVentNotify->lParam2;
			LONG y = peVentNotify->lParam3;
			LONG* pnResult = (LONG*)peVentNotify->lParam4;

			LPARAM lParam = MAKELPARAM(x, y);
			OnRichEditMsgProc(WM_RBUTTONDOWN, (WPARAM)nHitTest, (LPARAM)lParam);

			OnHitTestOleControl(WM_RBUTTONDOWN, CPoint(x, y));
			OnHitTestLink(WM_RBUTTONDOWN, CPoint(x, y));
			OnHitTestExtraElement(WM_RBUTTONDOWN, CPoint(x, y));

			bResult = FALSE;
		}
		break;

	case UISM_RBUTTONUP:
		{
			LONG nHitTest = peVentNotify->lParam1;
			LONG x = peVentNotify->lParam2;
			LONG y = peVentNotify->lParam3;
			LONG* pnResult = (LONG*)peVentNotify->lParam4;

			LPARAM lParam = MAKELPARAM(x, y);
			OnRichEditMsgProc(WM_RBUTTONUP, (WPARAM)nHitTest, (LPARAM)lParam);

			OnRButtonUp(nHitTest, CPoint(x,y));

			bResult = FALSE;
		}
		break;

	case UISM_MOUSEENTER:
		{
			LONG nHitTest = peVentNotify->lParam1;
			LONG x = peVentNotify->lParam2;
			LONG y = peVentNotify->lParam3;
			LONG* pnResult = (LONG*)peVentNotify->lParam4;

			CUIEngineCom* pDirectUI = GetDirectUI();
			if (pDirectUI && !m_bRegisterMessage)
			{
				m_bRegisterMessage = true;
				pDirectUI->RegisterMessage(WM_MOUSEWHEEL,this,FALSE);
			}

			m_bMouseEnter = true;
			m_dwHostScaleButton = -1;

			if (m_bVertScrollBarExist)
			{
				ShowScrollBar(TRUE, TRUE, FALSE);
			}

			bResult = FALSE;
		}
		break;

	case UISM_MOUSEMOVE:
		{
			LONG nHitTest = peVentNotify->lParam1;
			LONG x = peVentNotify->lParam2;
			LONG y = peVentNotify->lParam3;
			LONG* pnResult = (LONG*)peVentNotify->lParam4;

			bResult = FALSE;
		}
		break;

	case UISM_DRAWPREVIEW:
		{
			bResult = FALSE;
		}
		break;

	case UISM_PROPCHANGEDNOTIFY:
		{
			CUIPropBase* pProp = (CUIPropBase*)peVentNotify->lParam1;
			bResult = FALSE;
		}
		break;

	case UISM_ISDRAGABLED:
		{
			BOOL* pbIsDragabled = (BOOL*)peVentNotify->lParam1;

			*pbIsDragabled = FALSE;

			bResult = TRUE;
		}
		break;

	case UISM_IMPORTCONFIG:
		{
			bResult = FALSE;
		}
		break;

	case UISM_FINALCREATE:
		{
			CUIEngineCom* pDirectUI = GetDirectUI();
			if (pDirectUI)
			{
				m_hWndDirectUI = pDirectUI->GetWindowHandle();
				//ע����ƺ��¼�
				pDirectUI->RegistFinalPaintObject(this);

				//ע��WM_SETCURSOR��Ϣ
				pDirectUI->RegisterMessage(WM_SETCURSOR, this,FALSE);

				//ע��WM_LBUTTONDOWN��Ϣ
				pDirectUI->RegisterMessage(WM_LBUTTONDOWN,this,FALSE);

				//ע��WM_LBUTTONUP��Ϣ
				pDirectUI->RegisterMessage(WM_LBUTTONUP,this,FALSE);

				//ע��WM_MOUSEMOVE��Ϣ
				pDirectUI->RegisterMessage(WM_MOUSEMOVE,this,FALSE);

				//ע��WM_CAPTURECHANGED��Ϣ
				pDirectUI->RegisterMessage(WM_CAPTURECHANGED,this,FALSE);

				//ע��WM_IME_STARTCOMPOSITION��Ϣ
				pDirectUI->RegisterMessage(WM_IME_STARTCOMPOSITION,this,FALSE);
				pDirectUI->RegisterMessage(WM_IME_COMPOSITION,this,FALSE);
				pDirectUI->RegisterMessage(WM_IME_ENDCOMPOSITION,this,FALSE);

			}

			CreateVertScrollBar();
			CreateHorzScrollBar();

			//����xml��oleԪ����չ����
			for (int i = 0; i < OLE_ELEEX_MODAL_MAX; ++i)
			{
				AccessOleEleExModalConfig((XMLNodePtr)GetXMLNode(), i, TRUE);

#ifndef _EXCLUDE_RESOURCE
				if (!m_pOleElementExModalArray[i].pEditProp)
				{
					continue;
				}

				if (m_pOleElementExModalArray[i].pElement)
				{
					m_pOleElementExModalArray[i].pEditProp->SetValue2(m_pOleElementExModalArray[i].pElement->GetName());
				}
				else
				{
					m_pOleElementExModalArray[i].pEditProp->SetValue2(_T("None"));
				}
#endif
			}

			//��ʼ��
			InitRichEdit(DEFAULT_EDIT_OPT);

            if (m_pImgTimeout)
            {
                m_nLoadingTimeout = m_pImgTimeout->GetValue();
            }

			bResult = TRUE;
		}
		break;

	case UISM_DESIGNSTATUSCHANGED:
		{
			BOOL bDesign = (BOOL)peVentNotify->lParam1;

			bResult = FALSE;
		}
		break;

	case UISM_CALLPROP:
		{
			long lPropId = peVentNotify->lParam1;
			LPTSTR pstrResult = (LPTSTR)peVentNotify->lParam2;
			int nMaxCount = (int)peVentNotify->lParam3;

			EditOleEleExModal(lPropId - ID_OLE_ELEMENTEX_EDIT_BEGIN, pstrResult, nMaxCount, bResult);
		}
		break;

	case UISM_DESTROYBMPPERPIXEL:
		{
			bResult = TRUE;
		}
		break;

	case UISM_GETDRAGCURSOR:
		{
			bResult = TRUE;
		}
		break;

	case UISM_GETCONTROLICON:
		{
			bResult = TRUE;
		}
		break;

	case UISM_GETCATEGORYNAME:
		{
			LPTSTR pstrResult = (LPTSTR)peVentNotify->lParam1;
			_stprintf(pstrResult,_T("UIControls"));
			bResult = TRUE;
		}
		break;

	case UISM_GETAUTHORINFO:
		{
			AuthorInfo* pAI = (AuthorInfo*)peVentNotify->lParam1;
			_stprintf(pAI->strAuthorName,_T("DirectUI_EIM"));
			_stprintf(pAI->strCompany,_T("EIMSoft"));
			_stprintf(pAI->strUrl,_T("eim.soft.com"));
			_stprintf(pAI->strVersion,_T("1.0.0"));
			bResult = TRUE;
		}
		break;

	case UISM_INITOBJECT:
		{
			CUIEngineCom* pDirectUI = GetDirectUI();
			if (pDirectUI)
			{
				m_hWndDirectUI = pDirectUI->GetWindowHandle();
			}

			//��ʼ��
			InitRichEdit(DEFAULT_EDIT_OPT);

			bResult = TRUE;
		}
		break;

	case UISM_INITDIALOG:
		{
			//��ʼ��
			InitRichEdit(DEFAULT_EDIT_OPT);
		}
		break;

	case UISM_ACCESSCONFIGED:
		{
			CUIEngineCom* pDirectUI = GetDirectUI();
			if (pDirectUI)
			{
				m_hWndDirectUI = pDirectUI->GetWindowHandle();
			}
			BOOL bRead = (BOOL)peVentNotify->lParam1;

			//��ʼ��
			InitRichEdit(DEFAULT_EDIT_OPT);
		}
		break;

	case UISM_CLONE_END:
		{
			CUIShowRichEdit* pUIShowRichEdit = (CUIShowRichEdit*)peVentNotify->lParam1;
			if (pUIShowRichEdit)
			{
				for (int i = 0; i < OLE_ELEEX_MODAL_MAX; ++i)
				{
					this->CloneOleEleExModal(i, pUIShowRichEdit->GetOleEleExModalByIndex(i));
#ifndef _EXCLUDE_RESOURCE
					this->SaveOleEleExModalXmlNode();
#endif
				}
			}
		}
		break;

	case UISM_DESTROYING:
		{
			CUIEngineCom* pDirectUI = GetDirectUI();
			if (pDirectUI)
			{
				DestroyAllTimer();

				SetCanUpdateNow(false);

				ClearOleDatas();

				ClearExtraElement(FALSE);

                ClearPartElement(FALSE);

				if (m_hCursor)
				{
					DestroyCursor(m_hCursor);
				}

				//ȡ�����ƺ��¼���ע��
				pDirectUI->UnRegistFinalPaintObject(this);

				//ȡ��WM_SETCURSOR��Ϣע��
				pDirectUI->UnRegisterMessage(WM_SETCURSOR, this);

				//ȡ��WM_MOUSEWHEELע��
				if (m_bRegisterMessage)
				{
					pDirectUI->UnRegisterMessage(WM_MOUSEWHEEL,this);
				}

				//ȡ��WM_LBUTTONDOWNע��
				pDirectUI->UnRegisterMessage(WM_LBUTTONDOWN,this);

				//ȡ��WM_LBUTTONUPע��
				pDirectUI->UnRegisterMessage(WM_LBUTTONUP,this);

				//ȡ��WM_MOUSEMOVEע��
				pDirectUI->UnRegisterMessage(WM_MOUSEMOVE,this);

				//ȡ��WM_CAPTURECHANGEDע��
				pDirectUI->UnRegisterMessage(WM_CAPTURECHANGED,this);

				//ȡ��WM_IME_STARTCOMPOSITIONע��
				pDirectUI->UnRegisterMessage(WM_IME_STARTCOMPOSITION,this);
				pDirectUI->UnRegisterMessage(WM_IME_COMPOSITION,this);
				pDirectUI->UnRegisterMessage(WM_IME_ENDCOMPOSITION,this);
			}
		}
		break;

	case UISM_GETTABINFO://��ȡTab��Ϣ
		{
			//ָ���ؼ��Ƿ�TabStop
			BOOL *pbTabStop = (BOOL*)peVentNotify->lParam1;
			*pbTabStop = TRUE;

			//ָ���ؼ��Ƿ����Tab���
			BOOL *pbTabDraw = (BOOL*)peVentNotify->lParam2;
			*pbTabDraw = TRUE;

			bResult = TRUE;
		}
		break;

	case UISM_CHAR:
		{
			UINT nChar = peVentNotify->lParam1;
			UINT nRepCnt = peVentNotify->lParam2;
			UINT nFlags = peVentNotify->lParam3;

			OnRichEditMsgProc(WM_CHAR, nChar, MAKELPARAM((WORD)nRepCnt, (WORD)nFlags));

			bResult = TRUE;
		}
		break;
	case UISM_KEYDOWN:
		{
			UINT nChar = peVentNotify->lParam1;
			UINT nRepCnt = peVentNotify->lParam2;
			UINT nFlags = peVentNotify->lParam3;

			OnRichEditMsgProc(WM_KEYDOWN, nChar, MAKELPARAM((WORD)nRepCnt, (WORD)nFlags));

			bResult = TRUE;
		}
		break;
	default:
		break;
	}

	return bResult;
}


void CUIShowRichEdit::InitRichEdit(DWORD dwFlags/* = DEFAULT_EDIT_OPT*/)
{
	if (!m_hWndDirectUI || !::IsWindow(m_hWndDirectUI))
	{
		return;
	}

	if (!m_bInit)
	{
		m_hCursor = ::LoadCursor(GetModuleHandle(0), IDC_ARROW);

		m_FreeWindowlessRE.SetRichEditMsgProc((IRichEditMsgProc*)this);
		m_FreeWindowlessRE.SetREParentHwnd(m_hWndDirectUI);

		m_rcDUIClient = GetRect();
		RECT rcRichEdit;
		rcRichEdit.left = m_rcDUIClient.left;
		rcRichEdit.right = m_rcDUIClient.right;
		rcRichEdit.top = m_rcDUIClient.top;
		rcRichEdit.bottom = m_rcDUIClient.bottom;
		m_FreeWindowlessRE.CreateHost(dwFlags, rcRichEdit);

		m_IRichEditOleCallback.SetHwnd(m_hWndDirectUI);
		m_IRichEditOleCallback.SetRichEditMsgProc((IRichEditMsgProc*)this);
		m_FreeWindowlessRE.SetOLECallback(&m_IRichEditOleCallback);

		//ȱʡ����ַ�����Ϊ64000
		m_FreeWindowlessRE.LimitText(RICHEDIT_TEXT_MAX_COUNT);

		m_hParent = m_hWndDirectUI;

		m_bInit = true;

		SetEventMask(ENM_CHANGE | ENM_LINK);
		InitCharFormat();

		//ֻ��
		SetReadOnly(TRUE);
	}
}

bool CUIShowRichEdit::IsRichEditInited()
{
	return m_bInit;
}

void CUIShowRichEdit::SetRichEditFocus()
{
	if (!m_bInit) return;

	SetFocus();
	m_FreeWindowlessRE.SetFocus();

	//OnRichEditMsgProc(WM_SETFOCUS, 0, 0);
}

void CUIShowRichEdit::SetReadOnly(BOOL bReadOnly/* = TRUE*/)
{
	if (!m_bInit) return;

	m_bReadOnly = bReadOnly;

	m_FreeWindowlessRE.SetReadOnly(bReadOnly);
}

void CUIShowRichEdit::Clear()
{
	if (!m_bInit)
	{
		return;
	}

	m_FreeWindowlessRE.Clear();
	InitCharFormat();

	ClearOleDatas();
	ClearExtraElement(TRUE);
    ClearPartElement(TRUE);
	ClearLink();
	m_tWaitImageQueue.clear();

	DUICtrlNotifyInfo duiNotifyInfo;
	memset(&duiNotifyInfo, 0, sizeof(DUICtrlNotifyInfo));
	duiNotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_CONTENT_CLEARED;
	duiNotifyInfo.lParam1 = (DWORD_PTR)(this);
	::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&duiNotifyInfo, 0);
}

void CUIShowRichEdit::SetShowUserDefImageFlag(bool bFlag)
{
	m_bShowUserDefImage = bFlag;
}

BOOL CUIShowRichEdit::InsertContentBegin(InsertMode eInsertMode, BOOL bAutoAddSpliterLine)
{
	if (!m_bInit)
	{
		return FALSE;
	}

	//error:��ǰ���ڲ�������
	if (m_insertProcess.bInsertDoing)
	{
		InsertContentEnd(eScrollAuto);
	}
	m_insertProcess.bInsertDoing = true;
	m_insertProcess.eInsertMode = eInsertMode;
	m_insertProcess.bAutoAddSpliterLine = bAutoAddSpliterLine;
	m_insertProcess.insertingExtraEleList.clear();

	//��¼��������ǰ������λ��
	m_bScrollBtmBeforeInsert = IsScrollAtBottom();

	//��¼��ǰ������λ��
	m_insertProcess.nOrgScrollMax = -1;
	m_insertProcess.nOrgScrollPos = -1;
	if (eInsertModeFront == m_insertProcess.eInsertMode)
	{
		//��¼��������ǰ�Ƿ��õ�
		DUISCROLLINFO si;
		si.ulSize = sizeof(DUISCROLLINFO);
		if (GetScrollInfo(&si, DUISB_SIF_ALL, FALSE))
		{
			m_insertProcess.nOrgScrollMax = si.nMax;
			m_insertProcess.nOrgScrollPos = si.nPos;
		}
	}

	//���������ڼ��ֹ����������
	UINT uOption = GetOptions();
	if ((uOption & ECO_AUTOVSCROLL) != 0)
	{
		SetOptions(ECOOP_SET, GetOptions() & ~ECO_AUTOVSCROLL);
	}
	if ((uOption & ECO_NOHIDESEL) == 0)
	{
		SetOptions(ECOOP_OR, ECO_NOHIDESEL);
	}
	SetEnableSetScrollPos(false);

	//���������ڼ��ֹ����
	SetCanUpdateNow(false);

	//��¼��ǰѡ������
	m_insertProcess.orgSel.cpMin = 0;
	m_insertProcess.orgSel.cpMax = 0;
	GetSel(m_insertProcess.orgSel);

	if (m_insertProcess.orgSel.cpMin < m_insertProcess.orgSel.cpMax && 
		m_insertProcess.orgSel.cpMax > SelEnd(false))
	{
		m_insertProcess.orgSel.cpMax = -1;
	}

	//��¼��ǰ����λ��
	m_insertProcess.curSel.cpMin = -1;
	m_insertProcess.curSel.cpMax = -1;
	switch (eInsertMode)
	{
	case eInsertModeFront:
		{
			SetSel(0, 0);
			m_insertProcess.nInsertBeginPos = 0;
			m_insertProcess.curSel.cpMin = 0;
			m_insertProcess.curSel.cpMax = 0;

			if (bAutoAddSpliterLine)
			{
				ChangeLine();
				SetSel(0, 0);
			}
		}
		break;
	case eInsertModeBack:
		{
			SetSel(-1, -1);
			CHARRANGE rangeBegin = {0,0};
			GetSel(rangeBegin);

			m_insertProcess.nInsertBeginPos = rangeBegin.cpMax;
			m_insertProcess.curSel.cpMin = -1;
			m_insertProcess.curSel.cpMax = -1;
		}
		break;
	case eInsertModeReplaceSel:
		{
			m_insertProcess.nInsertBeginPos = m_insertProcess.orgSel.cpMin;
			m_insertProcess.curSel.cpMin = m_insertProcess.orgSel.cpMin;
			m_insertProcess.curSel.cpMax = m_insertProcess.orgSel.cpMax;
			SetSel(m_insertProcess.orgSel.cpMin, m_insertProcess.orgSel.cpMax);
			ReplaceSel2(_T(""), FALSE);
		}
		break;
	default:
		{
			SetSel(-1, -1);
			CHARRANGE rangeBegin = {0,0};
			GetSel(rangeBegin);

			m_insertProcess.nInsertBeginPos = rangeBegin.cpMax;
			m_insertProcess.curSel.cpMin = -1;
			m_insertProcess.curSel.cpMax = -1;
		}
		break;
	}

	return TRUE;
}

BOOL CUIShowRichEdit::InsertContentContinue(stInsertProcess& orgInsertProcess)
{
	if (!m_bInit)
	{
		return FALSE;
	}

	//error:��ǰ���ڲ�������
	if (m_insertProcess.bInsertDoing)
	{
		InsertContentEnd(eScrollAuto);
	}
	m_insertProcess.bInsertDoing = TRUE;
	m_insertProcess.eInsertMode = orgInsertProcess.eInsertMode;
	m_insertProcess.nInsertBeginPos = 0;
	m_insertProcess.nInsertEndPos = 0;
	m_insertProcess.nOrgScrollMax = orgInsertProcess.nOrgScrollMax;
	m_insertProcess.nOrgScrollPos = orgInsertProcess.nOrgScrollPos;
	m_insertProcess.bAutoAddSpliterLine = orgInsertProcess.bAutoAddSpliterLine;

	//��¼��������ǰ������λ��
	m_bScrollBtmBeforeInsert = IsScrollAtBottom();

	//���������ڼ��ֹ����������
	UINT uOption = GetOptions();
	if ((uOption & ECO_AUTOVSCROLL) != 0)
	{
		SetOptions(ECOOP_SET, GetOptions() & ~ECO_AUTOVSCROLL);
	}
	if ((uOption & ECO_NOHIDESEL) == 0)
	{
		SetOptions(ECOOP_OR, ECO_NOHIDESEL);
	}
	SetEnableSetScrollPos(false);

	//���������ڼ��ֹ����
	SetCanUpdateNow(false);

	//��¼��ǰѡ������
	m_insertProcess.orgSel = orgInsertProcess.orgSel;
	if (m_insertProcess.orgSel.cpMin < m_insertProcess.orgSel.cpMax && 
		m_insertProcess.orgSel.cpMax >= SelEnd(false))
	{
		m_insertProcess.orgSel.cpMin = -1;
		m_insertProcess.orgSel.cpMax = -1;
	}

	//��¼��ǰ����λ��
	m_insertProcess.curSel = orgInsertProcess.curSel;
	switch (orgInsertProcess.eInsertMode)
	{
	case eInsertModeFront:
		{
			SetSel(m_insertProcess.curSel, false);
			m_insertProcess.nInsertBeginPos = m_insertProcess.curSel.cpMax;
		}
		break;
	case eInsertModeBack:
		{
			SetSel(-1, -1);
			CHARRANGE rangeBegin = {0,0};
			GetSel(rangeBegin);

			m_insertProcess.nInsertBeginPos = rangeBegin.cpMax;
			m_insertProcess.curSel.cpMin = -1;
			m_insertProcess.curSel.cpMax = -1;
		}
		break;
	case eInsertModeReplaceSel:
		{
			SetSel(m_insertProcess.curSel, false);
			m_insertProcess.nInsertBeginPos = m_insertProcess.curSel.cpMin;
		}
		break;
	default:
		{
			SetSel(-1, -1);
			CHARRANGE rangeBegin = {0,0};
			GetSel(rangeBegin);

			m_insertProcess.nInsertBeginPos = rangeBegin.cpMax;
			m_insertProcess.curSel.cpMin = -1;
			m_insertProcess.curSel.cpMax = -1;
		}
		break;
	}

	return TRUE;
}

DWORD CUIShowRichEdit::InsertContentEnd(OLE_SCROLL_POS eScrollPos)
{
	if (!m_bInit)
	{
		return -1;
	}

	if (!m_insertProcess.bInsertDoing)
	{
		return -1;
	}

	//�Զ�����
	switch (m_insertProcess.eInsertMode)
	{
	case eInsertModeFront:
		{
			CHARRANGE rangeEnd = {0,0};
			GetSel(rangeEnd);
			m_insertProcess.nInsertEndPos = rangeEnd.cpMin;
		}
		break;
	case eInsertModeBack:
		{
			if (m_insertProcess.bAutoAddSpliterLine)
			{
				ChangeLine();
			}

			CHARRANGE rangeEnd = {0,0};
			GetSel(rangeEnd);
			m_insertProcess.nInsertEndPos = rangeEnd.cpMax;
		}
		break;
	case eInsertModeReplaceSel:
		{
			CHARRANGE rangeEnd = {0,0};
			GetSel(rangeEnd);
			m_insertProcess.nInsertEndPos = rangeEnd.cpMax;
		}
		break;
	default:
		{
			CHARRANGE rangeEnd = {0,0};
			GetSel(rangeEnd);
			m_insertProcess.nInsertEndPos = rangeEnd.cpMax;
		}
		break;
	}

	//������չԪ�ز���״̬
	InsertingExtraEleList::iterator it_inserting = m_insertProcess.insertingExtraEleList.begin();
	for (; it_inserting != m_insertProcess.insertingExtraEleList.end(); ++it_inserting)
	{
		int nIndex = *it_inserting;
		if ((int)m_ExtraEleColl.size() <= nIndex || nIndex < 0)
		{
			continue;
		}

		m_ExtraEleColl[nIndex].SetInsertingFlag(false);
	}
	m_insertProcess.insertingExtraEleList.clear();

	//����ѡ��ԭ��ѡ������
	SetSel(m_insertProcess.orgSel, true);
	m_insertProcess.orgSel.cpMin = -1;
	m_insertProcess.orgSel.cpMax = -1;

	//���õ�ǰѡ������
	m_insertProcess.curSel.cpMin = -1;
	m_insertProcess.curSel.cpMax = -1;

	//�����ǰ�ò��뷽ʽ,��Ҫ����������λ����ȷ����ǰ��Ļ���ݲ�����
	LONG nCurSrollPos = -1;
	if (eInsertModeFront == m_insertProcess.eInsertMode && 
		m_insertProcess.nOrgScrollMax != -1 && 
		m_insertProcess.nOrgScrollPos != -1)
	{
		DUISCROLLINFO si;
		si.ulSize = sizeof(DUISCROLLINFO);
		if (GetScrollInfo(&si, DUISB_SIF_ALL, FALSE))
		{
			LONG nScrollMaxChange = si.nMax - m_insertProcess.nOrgScrollMax;
			nCurSrollPos = m_insertProcess.nOrgScrollPos + nScrollMaxChange;
			if (nCurSrollPos > (LONG)(si.nMax - si.ulPage))
			{
				nCurSrollPos = si.nMax - si.ulPage;
			}
			else if (nCurSrollPos < 0)
			{
				nCurSrollPos = 0;
			}
		}
	}

	//����������Ϣ
	m_insertProcess.bInsertDoing = FALSE;
	m_insertProcess.eInsertMode = eInsertModeBack;
	m_insertProcess.bAutoAddSpliterLine = FALSE;

	//ȡ�����û��Ʊ��
	SetCanUpdateNow(true);

	//ȡ���������������
	SetEnableSetScrollPos(true);

	//����ˢ��
	OnRichEditInsideRedraw(true);

	//��λ������λ��
	switch(eScrollPos)
	{
	case eScrollAuto:
		{
			//����û������϶������������õ�
			if (m_bScrollBtmBeforeInsert && !m_bLockScr)
			{
				OnRichEditMsgProc(WM_VSCROLL, SB_BOTTOM, 0);
			}
			else if (-1 == nCurSrollPos)
			{
				// do nothing
			}
			else if (0 == nCurSrollPos)
			{
				OnRichEditMsgProc(WM_VSCROLL, SB_TOP, 0);
			}
			else
			{
				OnRichEditMsgProc(WM_VSCROLL, MAKEWPARAM((WORD)SB_THUMBPOSITION, (WORD)nCurSrollPos), NULL);
			}
		}
		break;
	case eScrollTop:
		{
			if (!m_bLockScr)
			{
				OnRichEditMsgProc(WM_VSCROLL, SB_TOP, 0);
			}
		}
		break;
	case eScrollBottom:
		{
			if (!m_bLockScr)
			{
				OnRichEditMsgProc(WM_VSCROLL, SB_BOTTOM, 0);
			}
		}
		break;
	default:
		break;
	}


	m_dwPartID++;
	stMsgPart stPart;
	stPart.lCharStart = m_insertProcess.nInsertBeginPos < m_insertProcess.nInsertEndPos ? m_insertProcess.nInsertBeginPos: m_insertProcess.nInsertEndPos;
	stPart.lCharEnd = m_insertProcess.nInsertBeginPos < m_insertProcess.nInsertEndPos ? m_insertProcess.nInsertEndPos: m_insertProcess.nInsertBeginPos;
	m_mapMsgPart.insert(std::make_pair(m_dwPartID, stPart));

	return m_dwPartID;
}

BOOL CUIShowRichEdit::UpdateContentBegin(DWORD dwContentID)
{
	if (!m_bInit)
	{
		return FALSE;
	}

	MsgPartMap::iterator it_part = m_mapMsgPart.find(dwContentID);
	if (it_part == m_mapMsgPart.end())
	{
		return FALSE;
	}

	//ɾ��ԭ������
	stMsgPart oldPart = it_part->second;
	DeleteContent(dwContentID);

	//error:��ǰ���ڲ�������
	if (m_insertProcess.bInsertDoing)
	{
		InsertContentEnd(eScrollAuto);
	}
	m_insertProcess.bInsertDoing = true;
	m_insertProcess.eInsertMode = eInsertModeReplaceSel;
	m_insertProcess.bAutoAddSpliterLine = FALSE;
	m_insertProcess.insertingExtraEleList.clear();

	//��¼��������ǰ������λ��
	m_bScrollBtmBeforeInsert = IsScrollAtBottom();

	//��¼��ǰ������λ��
	m_insertProcess.nOrgScrollMax = -1;
	m_insertProcess.nOrgScrollPos = -1;
	if (eInsertModeFront == m_insertProcess.eInsertMode)
	{
		//��¼��������ǰ�Ƿ��õ�
		DUISCROLLINFO si;
		si.ulSize = sizeof(DUISCROLLINFO);
		if (GetScrollInfo(&si, DUISB_SIF_ALL, FALSE))
		{
			m_insertProcess.nOrgScrollMax = si.nMax;
			m_insertProcess.nOrgScrollPos = si.nPos;
		}
	}

	//���������ڼ��ֹ����������
	UINT uOption = GetOptions();
	if ((uOption & ECO_AUTOVSCROLL) != 0)
	{
		SetOptions(ECOOP_SET, GetOptions() & ~ECO_AUTOVSCROLL);
	}
	if ((uOption & ECO_NOHIDESEL) == 0)
	{
		SetOptions(ECOOP_OR, ECO_NOHIDESEL);
	}
	SetEnableSetScrollPos(false);

	//���������ڼ��ֹ����
	SetCanUpdateNow(false);

	//��¼��ǰѡ������
	m_insertProcess.orgSel.cpMin = 0;
	m_insertProcess.orgSel.cpMax = 0;
	GetSel(m_insertProcess.orgSel);

	if (m_insertProcess.orgSel.cpMin < m_insertProcess.orgSel.cpMax && 
		m_insertProcess.orgSel.cpMax > SelEnd(false))
	{
		m_insertProcess.orgSel.cpMax = -1;
	}

	//���ӻ���
	m_insertProcess.nInsertBeginPos = oldPart.lCharStart;
	m_insertProcess.curSel.cpMin = oldPart.lCharStart;
	m_insertProcess.curSel.cpMax = oldPart.lCharStart;
	SetSel(m_insertProcess.curSel.cpMin, m_insertProcess.curSel.cpMax);
	ReplaceSel2(_T("\r\n\r\n"));

	//��¼��ǰ����λ��
	m_insertProcess.nInsertBeginPos = oldPart.lCharStart + 1;
	m_insertProcess.curSel.cpMin = oldPart.lCharStart + 1;
	m_insertProcess.curSel.cpMax = oldPart.lCharStart + 1;
	SetSel(m_insertProcess.curSel.cpMin, m_insertProcess.curSel.cpMax);

	return TRUE;
}

BOOL CUIShowRichEdit::UpdateContentEnd(DWORD dwContentID)
{
	if (!m_bInit || !m_insertProcess.bInsertDoing)
	{
		return FALSE;
	}

	//��¼����Ľ���λ��
	CHARRANGE rangeEnd = {0,0};
	GetSel(rangeEnd);
	m_insertProcess.nInsertEndPos = rangeEnd.cpMax;

	//������չԪ�ز���״̬
	InsertingExtraEleList::iterator it_inserting = m_insertProcess.insertingExtraEleList.begin();
	for (; it_inserting != m_insertProcess.insertingExtraEleList.end(); ++it_inserting)
	{
		int nIndex = *it_inserting;
		if ((int)m_ExtraEleColl.size() <= nIndex || nIndex < 0)
		{
			continue;
		}

		m_ExtraEleColl[nIndex].SetInsertingFlag(false);
	}
	m_insertProcess.insertingExtraEleList.clear();

	//����ѡ��ԭ��ѡ������
	SetSel(m_insertProcess.orgSel, true);
	m_insertProcess.orgSel.cpMin = -1;
	m_insertProcess.orgSel.cpMax = -1;

	//���õ�ǰѡ������
	m_insertProcess.curSel.cpMin = -1;
	m_insertProcess.curSel.cpMax = -1;

	//����������Ϣ
	m_insertProcess.bInsertDoing = FALSE;
	m_insertProcess.eInsertMode = eInsertModeReplaceSel;
	m_insertProcess.bAutoAddSpliterLine = FALSE;

	//ȡ�����û��Ʊ��
	SetCanUpdateNow(true);

	//ȡ���������������
	SetEnableSetScrollPos(true);

	//����ˢ��
	OnRichEditInsideRedraw(true);

	//��λ������λ��
	if (m_bScrollBtmBeforeInsert && !m_bLockScr)
	{
		//����û������϶������������õ�
		OnRichEditMsgProc(WM_VSCROLL, SB_BOTTOM, 0);
	}

	//���·ֶ���Ϣ
	MsgPartMap::iterator it_part = m_mapMsgPart.find(dwContentID);
	if (it_part != m_mapMsgPart.end())
	{
		return FALSE;
	}

	stMsgPart msgPart;
	msgPart.lCharStart = m_insertProcess.nInsertBeginPos < m_insertProcess.nInsertEndPos ? m_insertProcess.nInsertBeginPos: m_insertProcess.nInsertEndPos;
	msgPart.lCharEnd = m_insertProcess.nInsertBeginPos < m_insertProcess.nInsertEndPos ? m_insertProcess.nInsertEndPos: m_insertProcess.nInsertBeginPos;
	m_mapMsgPart.insert(std::make_pair(dwContentID, msgPart));

	return TRUE;
}

void CUIShowRichEdit::DeleteContent(DWORD dwContentID)
{
	MsgPartMap::iterator it = m_mapMsgPart.find(dwContentID);
	if (it != m_mapMsgPart.end())
	{
		CHARRANGE crCurSel = {0,0};
		GetSel(crCurSel);

		SetSel(it->second.lCharStart, it->second.lCharEnd);

		InsertContentBegin(eInsertModeReplaceSel, FALSE);
		ReplaceSel2(_T(""));

		if (crCurSel.cpMin >= it->second.lCharStart && crCurSel.cpMin <= it->second.lCharEnd)
		{
			crCurSel.cpMin = it->second.lCharStart;
		}
		else if (crCurSel.cpMin > it->second.lCharEnd)
		{
			crCurSel.cpMin -= it->second.lCharEnd - it->second.lCharStart + 1;
		}

		if (crCurSel.cpMax >= it->second.lCharStart && crCurSel.cpMax <= it->second.lCharEnd)
		{
			crCurSel.cpMax = it->second.lCharStart;
		}
		else if (crCurSel.cpMax > it->second.lCharEnd)
		{
			crCurSel.cpMax -= it->second.lCharEnd - it->second.lCharStart + 1;
		}
		InsertContentEnd(eScrollAuto);

		SetSel(crCurSel, false);

		it = m_mapMsgPart.find(dwContentID);
		if (it != m_mapMsgPart.end())
		{
			m_mapMsgPart.erase(it);
		}
	}
}

BOOL CUIShowRichEdit::IsDoingInsert()
{
	return m_insertProcess.bInsertDoing;
}

DWORD CUIShowRichEdit::HittestContentByCursor()
{
	CPoint ptCursor(0,0);
	GetCursorPos(&ptCursor);

	ScreenToClient(m_hWndDirectUI, &ptCursor);
	long charIndex = m_FreeWindowlessRE.CharFromPos(ptCursor);
	if (-1 == charIndex)
	{
		return -1;
	}

	MsgPartMap::iterator it_part = m_mapMsgPart.begin();
	for (; it_part != m_mapMsgPart.end(); ++it_part)
	{
		if (charIndex >= it_part->second.lCharStart && charIndex <= it_part->second.lCharEnd)
		{
			return it_part->first;
		}
	}

	return -1;
}

BOOL CUIShowRichEdit::SetStartIndent(LONG nStartIndent)
{
	if (!IsDoingInsert())
	{
		return FALSE;
	}

	PARAFORMAT2   PF_his ; 
	PF_his.dwMask = PFM_ALIGNMENT | PFM_STARTINDENT | PFM_OFFSETINDENT | PFM_RIGHTINDENT;
	PF_his.wAlignment = PFA_LEFT;
	PF_his.dxStartIndent = nStartIndent; 
	PF_his.dxRightIndent = nStartIndent;
	SetParaFormat(PF_his);

	return TRUE;
}

BOOL CUIShowRichEdit::ChangeLine()
{
	if (!IsDoingInsert())
	{
		return FALSE;
	}

	UpdateCurInsertSel();
	ReplaceSel2(_T("\r\n"));
	UpdateCurInsertSel();

	return TRUE;
}

BOOL CUIShowRichEdit::DeleteLine(int nLineIndex)
{
	if (nLineIndex < 0)
	{
		return FALSE;
	}

	int nLineCount = GetLineCount();
	if (nLineIndex >= nLineCount)
	{
		return FALSE;
	}
	
	int nNextLine = nLineIndex + 1;
	if (nNextLine >= nLineCount)
	{
		nNextLine = -1;
	}

	//��ȡ��ǰѡ������
	LONG nCurSelBegin = 0;
	LONG nCurSelEnd = 0;
	GetSel(nCurSelBegin, nCurSelEnd);
	
	//ɾ���������ʼ�ַ�
	int nDelBegin = LineIndex(nLineIndex);

	//ɾ������Ľ����ַ�
	int nDelEnd = -1;
	if (-1 == nNextLine)
	{
		nDelEnd = SelEnd(false);
	}
	else
	{
		nDelEnd = LineIndex(nNextLine) - 1;
	}

	//ɾ��nCharBegin��ʼ��(nCharEnd-nCharBegin)���ַ�
	//��ʹ��ReplaceSel2,��ֹ�ݹ���ѭ��
	OnDelChar(nDelBegin, nDelEnd);
	SetSel(nDelBegin, nDelEnd + 1);
	m_FreeWindowlessRE.ReplaceSel(_T(""), FALSE);

	//�ָ���ǰѡ������
	if (nCurSelBegin < nDelBegin)
	{
		if (nCurSelEnd < nDelBegin)
		{
			//do nothing
		}
		else if (nCurSelEnd >= nDelBegin && nCurSelEnd <= nDelEnd)
		{
			nCurSelEnd = nDelBegin - 1;
		}
		else
		{
			nCurSelEnd -= (nDelEnd - nDelBegin + 1);
		}
	}
	else if (nCurSelBegin >= nDelBegin && nCurSelBegin <= nDelEnd)
	{
		nCurSelBegin = nCurSelBegin;

		if (nCurSelEnd <= nDelEnd)
		{
			nCurSelEnd = nCurSelBegin;
		}
		else
		{
			nCurSelEnd -= (nDelEnd - nDelBegin + 1);
		}
	}
	else
	{
		nCurSelBegin -= (nDelEnd - nDelBegin + 1);
		nCurSelEnd -= (nDelEnd - nDelBegin + 1);
	}

	if (nCurSelBegin < 0)
	{
		nCurSelBegin = 0;
	}
	if (nCurSelEnd < 0)
	{
		nCurSelEnd = 0;
	}
	int nCurEnd = SelEnd(false);
	if (nCurSelBegin > nCurEnd)
	{
		nCurSelBegin = nCurEnd;
	}
	if (nCurSelEnd > nCurEnd)
	{
		nCurSelEnd = nCurEnd;
	}
	SetSel(nCurSelBegin, nCurSelEnd);

	//���µ�ǰ���ݵĲ���λ��
	if (IsDoingInsert())
	{
		UpdateCurInsertSel();
	}

	return TRUE;
}

BOOL CUIShowRichEdit::InsertBlankLine(int nLineHeight/* = -1*/)
{
	if (!IsDoingInsert())
	{
		return FALSE;
	}

	UpdateCurInsertSel();
	ReplaceSel2(_T("\r\n"));

	if (nLineHeight != -1)
	{
		CHARFORMAT cf;
		memset(&cf, 0, sizeof(CHARFORMAT));
		cf.cbSize = sizeof(CHARFORMAT);
		cf.dwMask = CFM_SIZE;
		cf.yHeight = nLineHeight;
		m_FreeWindowlessRE.SetSelectionCharFormat(&cf);
		ReplaceSel2(_T(" "));
	}

	UpdateCurInsertSel();

	return TRUE;
}

int CUIShowRichEdit::ReplaceSel2(LPCTSTR lpszNewText, CHARFORMAT& cf, BOOL bCanUndo/* = FALSE*/)
{
	cf.cbSize = sizeof(CHARFORMAT);
	return RelaceSelDo(lpszNewText, (CHARFORMAT*)&cf, bCanUndo);
}

int CUIShowRichEdit::ReplaceSel2(LPCTSTR lpszNewText, CHARFORMAT2& cf, BOOL bCanUndo/* = FALSE*/)
{
	cf.cbSize = sizeof(CHARFORMAT2);
	return RelaceSelDo(lpszNewText, (CHARFORMAT*)&cf, bCanUndo);
}

int CUIShowRichEdit::ReplaceSel2(LPCTSTR lpszNewText, BOOL bCanUndo)
{
	return RelaceSelDo(lpszNewText, NULL, bCanUndo);
}

int CUIShowRichEdit::RelaceSelDo(LPCTSTR lpszNewText, CHARFORMAT* pcf, BOOL bCanUndo)
{
	if (!m_bInit || !GetWinHost())
	{
		return 0;
	}

	if (!IsDoingInsert())
	{
		return 0;
	}

	// ��¼ԭʼѡ������
	LONG lStart = 0;
	LONG lEnd = 0;
	GetSel(lStart, lEnd);

	// ��������
	if (pcf)
	{
		m_FreeWindowlessRE.SetSelectionCharFormat(pcf);
	}

	// ��ѡ�������������ݣ�������ɾ��ԭ�����ݵ��¼����������ڸ���ole�ȸ��ı�����Ĺ�����Ϣ
	bool bReplaceMode = false;
	if (lEnd > lStart)
	{
		bReplaceMode = true;
		OnDelChar(lStart, lEnd - 1);
	}

	// ����ѡ����������
	m_FreeWindowlessRE.ReplaceSel(lpszNewText, bCanUndo);

	// ��¼�µ�ѡ������
	LONG lStart2 = 0;
	LONG lEnd2 = 0;
	GetSel(lStart2, lEnd2);

	// �ٴ��������壬������������ַ�����ʾ��������������ʾ��С��ܴ�Ĺ������⣬�÷�ʽ�ɹ۲�õ�
	if (pcf)
	{
		// ѡ��������������
		SetSel(lStart,lEnd2);

		// ��������"@Bangtang"֮������壬ͳһ�滻��"@΢���ź�"��"@Microsoft Yahei"������Զ��������岻�ܿ�����
		if ((pcf->dwMask & CFM_FACE) && '@' == pcf->szFaceName[0])
		{
			WTL::CString strOrgFont = pcf->szFaceName;
			WTL::CString strNewFont = _T("");
			if (GetWinHost()->IsSupportMicroYaheiFontEnglish())
			{
				strNewFont += MICRO_YAHEI_ENGLISH;
			}
			else if (GetWinHost()->IsSupportMicroYaheiFontChinese())
			{
				strNewFont += MICRO_YAHEI_CHINESE;
			}
			else
			{
				strNewFont += _T("����");
			}
			_tcsncpy(pcf->szFaceName, strNewFont, LF_FACESIZE-1);
			pcf->szFaceName[LF_FACESIZE-1] = _T('\0');
			m_FreeWindowlessRE.SetSelectionCharFormat(pcf);

			_tcsncpy(pcf->szFaceName, strOrgFont, LF_FACESIZE-1);
			pcf->szFaceName[LF_FACESIZE-1] = _T('\0');
		}

		// �������������ݵ�����
		m_FreeWindowlessRE.SetSelectionCharFormat(pcf);
	}

	// ��ѡ�������������ݣ�����Ҫ���������ݵ��¼����������ڸ���ole�ȸ��ı�����Ĺ�����Ϣ
	LONG lCurEnd = SelEnd(false);
	if (lEnd2 < lCurEnd)
	{
		OnAddChar(lStart, lEnd2 - lStart, bReplaceMode);
	}

	// ��ԭ��ǰѡ������
	SetSel(lStart2,lEnd2);

	// ����������ޣ��ﵽһ�����޺�ɾ��ǰN������
	return CheckCharLimit();
}

int CUIShowRichEdit::UpdateCurInsertSel()
{
	if (!m_insertProcess.bInsertDoing)
	{
		return -1;
	}

	GetSel(m_insertProcess.curSel);
	switch (m_insertProcess.eInsertMode)
	{
	case eInsertModeFront:
		{
			//���ù���ڵ�ǰѡ�������ĩβ
			m_insertProcess.curSel.cpMin = m_insertProcess.curSel.cpMax;
		}
		break;
	case eInsertModeBack:
		{
			//���ù�굽ĩβ
			m_insertProcess.curSel.cpMin = -1;
			m_insertProcess.curSel.cpMax = -1;
		}
		break;
	case eInsertModeReplaceSel:
		{
			//���ù���ڵ�ǰѡ�������ĩβ
			m_insertProcess.curSel.cpMin = m_insertProcess.curSel.cpMax;
		}
		break;
	default:
		{
			//���ù���ڵ�ǰѡ�������ĩβ
			m_insertProcess.curSel.cpMin = m_insertProcess.curSel.cpMax;
		}
		break;
	}
	SetSel(m_insertProcess.curSel, false);

	//���ص�ǰ���λ��
	LONG lCharStart = -1;
	LONG lCharEnd = -1;
	GetSel(lCharStart, lCharEnd);
	return lCharEnd;
}

DWORD CUIShowRichEdit::InsertUserDefPic2(LPCTSTR lpszPicPath, bool bUpdate)
{
	if (!m_bShowUserDefImage)
	{
		return -1;
	}

	if (!IsDoingInsert())
	{
		return -1;
	}

	DWORD dwOleIDRet = InsertImage(lpszPicPath, GetOleID());
	if (-1 == dwOleIDRet)
	{
		return -1;
	}

	OnRichEditInsideRedraw(bUpdate);

	return dwOleIDRet;
}

DWORD CUIShowRichEdit::InsertSystemFace(DWORD faceID, bool bUpdate)
{
	if (!IsDoingInsert())
	{
		return -1;
	}

	UINT uResID = m_sysHelper.GetSysFaceResouceID(faceID);
	DWORD dwOleIDRet = InsertImage(m_sysHelper.GetRcFaceDll(), uResID, "GIF", GetOleID());
	if (-1 == dwOleIDRet)
	{
		return -1;
	}

	OnRichEditInsideRedraw(bUpdate);

	return dwOleIDRet;
}

DWORD CUIShowRichEdit::InsertSystemBmp(DWORD faceID, bool bUpdate)
{
	if (!IsDoingInsert())
	{
		return -1;
	}

	UINT uResID = m_sysHelper.GetSysFaceResouceID(faceID);
	DWORD dwOleIDRet = InsertImage(m_sysHelper.GetRcFaceDll(), uResID, RT_FREE_BITMAP, GetOleID());
	if (-1 == dwOleIDRet)
	{
		return -1;
	}

	OnRichEditInsideRedraw(bUpdate);

	return dwOleIDRet;
}

DWORD CUIShowRichEdit::InsertSystemPng(DWORD faceID, bool bUpdate)
{
	if (!IsDoingInsert())
	{
		return -1;
	}

	UINT uResID = m_sysHelper.GetSysFaceResouceID(faceID);
	DWORD dwOleIDRet = InsertImage(m_sysHelper.GetRcFaceDll(), uResID, "PNG", GetOleID());
	if (-1 == dwOleIDRet)
	{
		return -1;
	}

	OnRichEditInsideRedraw(bUpdate);

	return dwOleIDRet;
}

BOOL CUIShowRichEdit::AddMsgUBB2(
								 UINT64 dwUserData,
								 LPCTSTR strMsg,
								 LONG nStartIndent,
								 LONG nRightIndent,
								 BOOL bForceParseTicket/* = FALSE*/,
								 WORD wAlignment/* = PFA_LEFT*/)
{
	if (!IsDoingInsert())
	{
		return FALSE;
	}

	WTL::CString strMsgNew = strMsg;
	int nMsgLen = strMsgNew.GetLength();
	if (nMsgLen < 70)
	{
		return FALSE;
	}

	//�ַ���ʽ
	CHARFORMAT charFormat;
	charFormat.cbSize = sizeof(CHARFORMAT);

	WTL::CString strTemp = strMsgNew.Mid(0,32);
	strTemp.TrimRight();
	strTemp.TrimLeft();
	_tcsncpy(charFormat.szFaceName, strTemp, LF_FACESIZE);

	strTemp = strMsgNew.Mid(32,4);
	strTemp.TrimRight();
	strTemp.TrimLeft();
	charFormat.yHeight = _ttoi(strTemp);

	strTemp = strMsgNew.Mid(36,8);
	strTemp.TrimRight();
	strTemp.TrimLeft();
	charFormat.crTextColor = _ttoi(strTemp);

	strTemp = strMsgNew.Mid(44,3);
	strTemp.TrimRight();
	strTemp.TrimLeft();
	charFormat.bCharSet = _ttoi(strTemp);

	strTemp = strMsgNew.Mid(47,3);
	strTemp.TrimRight();
	strTemp.TrimLeft();
	charFormat.bPitchAndFamily = _ttoi(strTemp);

	strTemp = strMsgNew.Mid(50,10);
	strTemp.TrimRight();
	strTemp.TrimLeft();
	charFormat.dwEffects = _ttoi(strTemp);

	strTemp = strMsgNew.Mid(60,10);
	strTemp.TrimRight();
	strTemp.TrimLeft();
	charFormat.dwMask = _ttoi(strTemp);

	charFormat.yOffset = 0;

	//�����ʽ
	PARAFORMAT2 paraFormat; 
	paraFormat.dwMask = PFM_ALIGNMENT|PFM_STARTINDENT|PFM_OFFSETINDENT|PFM_RIGHTINDENT;
	paraFormat.wAlignment = wAlignment;
	paraFormat.dxStartIndent = nStartIndent;
	paraFormat.dxRightIndent = nRightIndent;

	return AddMsgUBB(dwUserData, strMsgNew.Mid(70, nMsgLen - 70), paraFormat, charFormat, bForceParseTicket);
}

BOOL CUIShowRichEdit::AddMsgUBB3(
								 UINT64 dwUserData,
								 LPCTSTR strMsg,
								 CHARFORMAT& charFormat,
								 LONG nStartIndent,
								 LONG nRightIndent,
								 BOOL bForceParseTicket /* = FALSE */,
								 WORD wAlignment/* = PFA_LEFT*/)
{
	if (!IsDoingInsert())
	{
		return FALSE;
	}

	WTL::CString strMsgNew = strMsg;
	if (0 == strMsgNew.GetLength())
	{
		return FALSE;
	}

	//�����ʽ
	PARAFORMAT2 paraFormat; 
	paraFormat.dwMask = PFM_ALIGNMENT|PFM_STARTINDENT|PFM_OFFSETINDENT|PFM_RIGHTINDENT;
	paraFormat.wAlignment = wAlignment;
	paraFormat.dxStartIndent = nStartIndent;
	paraFormat.dxRightIndent = nRightIndent;

	return AddMsgUBB(dwUserData, strMsgNew, paraFormat, charFormat, bForceParseTicket);
}

BOOL CUIShowRichEdit::AddMsgUBB(
								UINT64 dwUserData,
								WTL::CString& strMsg,
								PARAFORMAT2 paraFormat,
								CHARFORMAT& charFormat,
								BOOL bForceParseTicket)
{
	if (!IsDoingInsert())
	{
		return FALSE;
	}

	//ѡ��ĩβ
	UpdateCurInsertSel();

	//���ö����ʽ
	SetParaFormat(paraFormat);

	//�����ַ���ʽ
	SetSelectionCharFormat(charFormat);

	//���ı��������ʽ
	WTL::CString strParse = _T("");
	if (m_bEnableTicket || bForceParseTicket)
	{
		strParse = m_strParseAllElement;
	}
	else
	{
		strParse = m_strParseExcludeTicket;
	}

	//��¼ǰһ���������Ƿ�Ϊ�ɻ�Ʊ
	bool bPreTicket = false;

	WTL::CString strParseText = _T("");
	while(strMsg.GetLength() > 0)
	{
		// �й��������ʽ�����ⲻҪ����,�Լ���MSDN:
		//ms-help://MS.MSDNQTR.v80.chs/MS.MSDN.v80/MS.VisualStudio.v80.chs/dv_vclib/html/7423717b-b3d5-42a7-af98-46b0e6356449.htm
		CAtlRegExp<CAtlRECharTraits> reg;
		REParseError status = reg.Parse(strParse);
		if (REPARSE_ERROR_OK != status)
		{
			// Unexpected error.
			break ;
		}
		CAtlREMatchContext<CAtlRECharTraits> mc;
		if (!reg.Match(strMsg, &mc))
		{
			ReplaceSel2((LPCTSTR)strMsg, charFormat);
			break;
		}
		
		//��Դ��ͼƬ
		int nMcIndex = 0;
		bool bMatched = AddUBBRegResPicture(mc, strMsg, nMcIndex, charFormat);
		if (bMatched)
		{
			bPreTicket = false;
			continue;
		}

		//������ͼƬ
		nMcIndex += 1;
		bMatched = AddUBBRegCopyDataPicture(mc, strMsg, nMcIndex, charFormat);
		if (bMatched)
		{
			bPreTicket = false;
			continue;
		}

		//����ͼƬ
		nMcIndex += 1;
		bMatched = AddUBBRegPathPicture(mc, strMsg, nMcIndex, charFormat);
		if (bMatched)
		{
			bPreTicket = false;
			continue;
		}

		//URLͼƬ
		if (m_regExpImgURL.strRegExpString.GetLength() > 0)
		{
			nMcIndex += 1;
			bMatched = AddUBBRegURLPicture(mc, strMsg, nMcIndex, charFormat);
			if (bMatched)
			{
				bPreTicket = false;
				continue;
			}
		}

		//����
		if (m_regExpFace.strRegExpString.GetLength() > 0)
		{
			nMcIndex += 1;
			bMatched = AddUBBRegFace(mc, strMsg, nMcIndex, charFormat);
			if (bMatched)
			{
				bPreTicket = false;
				continue;
			}
		}

		//������
		nMcIndex += 1;
		bMatched = AddUBBRegHyperLink(mc, strMsg, nMcIndex, charFormat);
		if (bMatched)
		{
			bPreTicket = false;
			continue;
		}

		//At����
		if (m_regExpAt.strRegExpString.GetLength() > 0)
		{
			nMcIndex += 1;
			bMatched = AddUBBRegAt(mc, strMsg, nMcIndex, charFormat, dwUserData);
			if (bMatched)
			{
				bPreTicket = false;
				continue;
			}
		}

		//�ɻ�Ʊ
		if (m_bEnableTicket || bForceParseTicket)
		{
			nMcIndex += 1;
			bMatched = AddUBBRegTicket(mc, strMsg, nMcIndex, charFormat, bPreTicket);
			if (bMatched)
			{
				bPreTicket = true;
				continue;
			}
		}

		std::map<int, WTL::CString>::iterator it = m_customRegMap.begin();
		for(; it != m_customRegMap.end(); ++it)
		{
			bMatched = AddUBBCustomLinkReg(mc, strMsg, ++nMcIndex, charFormat, it->first);
			if (bMatched)
			{
				bPreTicket = false;
				break;
			}
		}
	}

	// ���ͼƬ����
	CheckImageLoadingTimer();

	return TRUE;
}

bool CUIShowRichEdit::AddUBBRegHyperLink(CAtlREMatchContext<CAtlRECharTraits>& mc, WTL::CString& strContent, int mcIndex, CHARFORMAT& charFormat)
{
	if (mcIndex < 0)
	{
		return false;
	}

	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szStart = strContent;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szMatch = 0;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szEnd   = 0;
	mc.GetMatch(mcIndex, &szMatch, &szEnd);
	if (0 == szMatch)
	{
		return false;
	}

	ptrdiff_t nLength = szEnd - szMatch;
	ptrdiff_t nHead = szMatch - szStart;

	WTL::CString strFormat;
	strFormat.Format(_T("%%.%ds"), nLength);

	WTL::CString strHyper;
	strHyper.Format(strFormat, szMatch);

	WTL::CString strParseText = strContent.Mid(0, nHead);
	ReplaceSel2((LPCTSTR)strParseText, charFormat);

	stLinkCallBackData data;
	data.strInfoLBtn = strHyper;
	data.strInfoRBtn = _T("");
	data.m_pFuncLBtn = HYPER_LINK_FUNC;
	data.m_pFuncRBtn = NULL;
	data.m_dwValueLBtn = 0;
	data.m_dwValueRBtn = 0;
	data.lBeginPos = 0;
	data.lEndPos = 0;
	AddMsg(TRUE, TRUE, strHyper, charFormat.crTextColor,
		((charFormat.dwEffects)&CFE_UNDERLINE),
		((charFormat.dwEffects)&CFE_BOLD),
		((charFormat.dwEffects)&CFE_ITALIC),
		charFormat.yHeight, charFormat.bCharSet,
		charFormat.bPitchAndFamily, charFormat.szFaceName,
		&data);
	UpdateCurInsertSel();

	strContent.Format(_T("%s"), szEnd);
	return true;
}

bool CUIShowRichEdit::AddUBBRegResPicture(CAtlREMatchContext<CAtlRECharTraits>& mc, WTL::CString& strContent, int mcIndex, CHARFORMAT& charFormat)
{
	if (mcIndex < 0)
	{
		return false;
	}

	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szStart = strContent;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szMatch = 0;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szEnd   = 0;
	mc.GetMatch(mcIndex, &szMatch, &szEnd);
	if (0 == szMatch)
	{
		return false;
	}

	ptrdiff_t nLength = szEnd - szMatch;
	ptrdiff_t nHead = szMatch - szStart;

	WTL::CString strFormat;
	strFormat.Format(_T("%%.%ds"), nLength);

	WTL::CString strEmot;
	strEmot.Format(strFormat, szMatch);

	WTL::CString strParseText = strContent.Mid(0, nHead);
	ReplaceSel2((LPCTSTR)strParseText, charFormat);

	WTL::CString strNum = strEmot.Mid(2, nLength-3);
	int nIndex = (int)_tcstoul(strNum, '\0', 10);

	BOOL bRet = FALSE;
	if (m_sysHelper.SysImgIsPng(nIndex))
	{
		//����ϵͳλͼ
		this->InsertSystemPng(nIndex, true);
	}
	else if (m_bDisplaySysFace)
	{
		//����ϵͳ����
		this->InsertSystemFace(nIndex, false);
	}
	else
	{
		//��ȡ����ת������
		BYTE byResult = 0;
		TCHAR tszFaceText[MAX_PATH+1] = {0};
		DUICtrlNotifyInfo UINotifyInfo;
		memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
		UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_GET_EMOTION_EXPRESSION;
		UINotifyInfo.lParam1 = (DWORD_PTR)(this);
		UINotifyInfo.lParam2 = (DWORD_PTR)nIndex; //����ID
		UINotifyInfo.lParam3 = (DWORD_PTR)tszFaceText; //����ת�����ֽ��տռ�
		UINotifyInfo.lParam4 = (DWORD_PTR)MAX_PATH;
		UINotifyInfo.lParam5 = (DWORD_PTR)&byResult;
		::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);

		if (byResult != 0)
		{
			ReplaceSel2((LPCTSTR)tszFaceText, charFormat);
		}
		else
		{
			ReplaceSel2((LPCTSTR)_T("[���飺XX]"), charFormat);
		}
	}

	strContent.Format(_T("%s"), szEnd);
	return true;
}

bool CUIShowRichEdit::AddUBBRegCopyDataPicture(CAtlREMatchContext<CAtlRECharTraits>& mc, WTL::CString& strContent, int mcIndex, CHARFORMAT& charFormat)
{
	if (mcIndex < 0)
	{
		return false;
	}

	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szStart = strContent;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szMatch = 0;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szEnd   = 0;
	mc.GetMatch(mcIndex, &szMatch, &szEnd);
	if (0 == szMatch)
	{
		return false;
	}

	ptrdiff_t nLength = szEnd - szMatch;
	ptrdiff_t nHead = szMatch - szStart;

	WTL::CString strFormat;
	strFormat.Format(_T("%%.%ds"), nLength);

	WTL::CString strImage;
	strImage.Format(strFormat, szMatch);

	WTL::CString strCopyDataPic = strImage.Mid(2, nLength - 3);

	WTL::CString strParseText = strContent.Mid(0, nHead);
	ReplaceSel2((LPCTSTR)strParseText, charFormat);

	int nURLBegin = strCopyDataPic.Find(_T("<url_"));
	WTL::CString strPicFullPath = strCopyDataPic.Mid(0, nURLBegin);

	int nWidthBegin = strCopyDataPic.Find(_T("<width_"));
	WTL::CString strPicURL = strCopyDataPic.Mid(nURLBegin + 5, nWidthBegin - nURLBegin - 6);

	int nHeightBegin = strCopyDataPic.Find(_T("<height_"));
	WTL::CString strWidth = strCopyDataPic.Mid(nWidthBegin + 7, nHeightBegin - nWidthBegin - 8);
	WTL::CString strHeight = strCopyDataPic.Mid(nHeightBegin + 8, strCopyDataPic.GetLength() - nHeightBegin - 9);

	DWORD dwOleID = this->InsertUserDefPic2((LPCTSTR)strPicFullPath, false);
	if (dwOleID != -1)
	{
		IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
		if (pOleProcesser && OleProcesser_Gif == pOleProcesser->GetType())
		{
			CIMGifProcesser* pIMGifProcesser = (CIMGifProcesser*)pOleProcesser;
			pIMGifProcesser->SetFileURL(strPicURL);
			pIMGifProcesser->SetFileURLImageSize(_tcstol(strWidth, '\0', 10), _tcstol(strHeight, '\0', 10));
		}
	}

	strContent.Format(_T("%s"), szEnd);
	return true;
}

bool CUIShowRichEdit::AddUBBRegPathPicture(CAtlREMatchContext<CAtlRECharTraits>& mc, WTL::CString& strContent, int mcIndex, CHARFORMAT& charFormat)
{
	if (mcIndex < 0)
	{
		return false;
	}

	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szStart = strContent;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szMatch = 0;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szEnd   = 0;
	mc.GetMatch(mcIndex, &szMatch, &szEnd);
	if (0 == szMatch)
	{
		return false;
	}

	ptrdiff_t nLength = szEnd - szMatch;
	ptrdiff_t nHead = szMatch - szStart;

	WTL::CString strFormat;
	strFormat.Format(_T("%%.%ds"), nLength);

	WTL::CString strImage;
	strImage.Format(strFormat, szMatch);

	WTL::CString strPathFileResult = strImage.Mid(m_regExpImgFile.nRegBeginCharCount, 
		nLength - m_regExpImgFile.nRegBeginCharCount - m_regExpImgFile.nRegEndCharCount);

	WTL::CString strFilePathName = _T("");
	if (m_expImgFileSize.strExpWidthBegin.GetLength() > 0 && m_expImgFileSize.strExpWidthEnd.GetLength() && 
		m_expImgFileSize.strExpHeightBegin.GetLength() > 0 && m_expImgFileSize.strExpHeightEnd.GetLength())
	{
		int nWidthBegin = strPathFileResult.Find(m_expImgFileSize.strExpWidthBegin);
		strFilePathName = strPathFileResult.Mid(0, nWidthBegin);
	}
	else
	{
		strFilePathName = strPathFileResult;
	}

	WTL::CString strParseText = strContent.Mid(0, nHead);
	ReplaceSel2((LPCTSTR)strParseText, charFormat);

	//�����Զ���ͼƬ
	DWORD dwIndex = this->InsertUserDefPic2((LPCTSTR)strFilePathName, false);
	if (-1 == dwIndex)
	{
		// ����ѡ���
		if (m_bBlockImage)
		{
			InsertBlockImageImg();
		}
		//ϣ���ȴ�ͼƬ�ĵ���
		else
		{
			DWORD dwOleID = InsertLoadingImg();

			//��ȡ�ȴ�ͼƬ����λ��
			UpdateCurInsertSel();
			CHARRANGE curEndRange = {0,0};
			m_FreeWindowlessRE.GetSel(curEndRange);

			//����ͼƬ��λ��
			DWORD dwInsertPos = 0;
			if (curEndRange.cpMax > 0)
			{
				dwInsertPos = curEndRange.cpMax - 1;
			}

			//����ȴ�������
			stWaitImageInfo waitImage;
			waitImage.strFileName = strFilePathName;
			waitImage.strFileURL = _T("");
			waitImage.pos = dwInsertPos;
			waitImage.imgStatus = eImageStatus_Loading;
			waitImage.dwOleID = dwOleID;
			waitImage.uTickTime = ::GetTickCount();
			m_tWaitImageQueue.push_back(waitImage);

			//�������ͼƬ�Ƿ񵽴�ļ�ʱ��
			StartImageLoadingTimer();
		}
	}

	strContent.Format(_T("%s"), szEnd);
	return true;
}

bool CUIShowRichEdit::AddUBBRegURLPicture(CAtlREMatchContext<CAtlRECharTraits>& mc, WTL::CString& strContent, int mcIndex, CHARFORMAT& charFormat)
{
	if (mcIndex < 0)
	{
		return false;
	}

	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szStart = strContent;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szMatch = 0;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szEnd   = 0;
	mc.GetMatch(mcIndex, &szMatch, &szEnd);
	if (0 == szMatch)
	{
		return false;
	}

	ptrdiff_t nLength = szEnd - szMatch;
	ptrdiff_t nHead = szMatch - szStart;

	WTL::CString strFormat;
	strFormat.Format(_T("%%.%ds"), nLength);

	WTL::CString strImage;
	strImage.Format(strFormat, szMatch);

	WTL::CString strPathFileResult = strImage.Mid(m_regExpImgURL.nRegBeginCharCount, 
		nLength - m_regExpImgURL.nRegBeginCharCount - m_regExpImgURL.nRegEndCharCount);

	WTL::CString strImgURL = _T("");
	int nImgURLWidth = 0;
	int nImgURLHeight = 0;
	if (m_expImgURLSize.strExpWidthBegin.GetLength() > 0 && m_expImgURLSize.strExpWidthEnd.GetLength() && 
		m_expImgURLSize.strExpHeightBegin.GetLength() > 0 && m_expImgURLSize.strExpHeightEnd.GetLength())
	{
		int nWidthBegin = strPathFileResult.Find(m_expImgURLSize.strExpWidthBegin);
		strImgURL = strPathFileResult.Mid(0, nWidthBegin);

		int nHeightBegin = strPathFileResult.Find(m_expImgURLSize.strExpHeightBegin);

		int nWidthExpBeginCount = (int)m_expImgURLSize.strExpWidthBegin.GetLength();
		int nWidthExpEndCount = (int)m_expImgURLSize.strExpWidthEnd.GetLength();
		int nHeightExpBeginCount = (int)m_expImgURLSize.strExpHeightBegin.GetLength();
		int nHeightExpEndCount = (int)m_expImgURLSize.strExpHeightEnd.GetLength();

		WTL::CString strWidth = strPathFileResult.Mid(nWidthBegin + nWidthExpBeginCount, nHeightBegin - nWidthBegin - nWidthExpBeginCount - nWidthExpEndCount);
		WTL::CString strHeight = strPathFileResult.Mid(nHeightBegin + nHeightExpBeginCount, strPathFileResult.GetLength() - nHeightBegin - nHeightExpBeginCount - nHeightExpEndCount);

		nImgURLWidth = (int)_tcstol(strWidth, '\0', 10);
		nImgURLHeight = (int)_tcstol(strHeight, '\0', 10);
	}
	else
	{
		strImgURL = strPathFileResult;
		nImgURLWidth = 0;
		nImgURLHeight = 0;
	}

	WTL::CString strParseText = strContent.Mid(0, nHead);
	ReplaceSel2((LPCTSTR)strParseText, charFormat);

	WTL::CString strPicRcvPath;
	WTL::CString strFileName = strImgURL.Mid(strImgURL.ReverseFind('/') + 1, strImgURL.GetLength());
	WTL::CString strPreviewFileName = IMG_PREVIEW_PREFIX;
	strPreviewFileName += strFileName;
	m_sysHelper.GetSRPicPath(strPreviewFileName,strPicRcvPath);

	//�����Զ���ͼƬ
	DWORD dwOleID = this->InsertUserDefPic2((LPCTSTR)strPicRcvPath, false);
	if (dwOleID != -1)
	{
		IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
		if (pOleProcesser && OleProcesser_Gif == pOleProcesser->GetType())
		{
			CIMGifProcesser* pIMGifProcesser = (CIMGifProcesser*)pOleProcesser;
			pIMGifProcesser->SetFileURL(strImgURL);
			pIMGifProcesser->SetFileURLImageSize(nImgURLWidth, nImgURLHeight);
		}
	}
	else if (m_bBlockImage)
	{
		// ����ѡ���
		InsertBlockImageImg();
	}
	else
	{
		//ϣ���ȴ�ͼƬ�ĵ���
		DWORD dwOleID = InsertLoadingImg();

		//��ȡ�ȴ�ͼƬ����λ��
		UpdateCurInsertSel();
		CHARRANGE curEndRange = {0,0};
		m_FreeWindowlessRE.GetSel(curEndRange);

		//����ͼƬ��λ��
		DWORD dwInsertPos = 0;
		if (curEndRange.cpMax > 0)
		{
			dwInsertPos = curEndRange.cpMax - 1;
		}

		//����ȴ�������
		stWaitImageInfo waitImage;
		waitImage.strFileName = strPreviewFileName;
		waitImage.strFileURL = strImgURL;
		waitImage.nURLImgWidth = nImgURLWidth;
		waitImage.nURLImgHeight = nImgURLHeight;
		waitImage.pos = dwInsertPos;
		waitImage.imgStatus = eImageStatus_Suspend;
		waitImage.dwOleID = dwOleID;
		waitImage.uTickTime = ::GetTickCount();
		m_tWaitImageQueue.push_back(waitImage);

		//�������ͼƬ�Ƿ񵽴�ļ�ʱ��
		StartImageLoadingTimer();
	}

	strContent.Format(_T("%s"), szEnd);
	return true;
}

bool CUIShowRichEdit::AddUBBRegTicket(CAtlREMatchContext<CAtlRECharTraits>& mc, WTL::CString& strContent, int mcIndex, CHARFORMAT& charFormat, bool bPreTicket)
{
	if (mcIndex < 0)
	{
		return false;
	}

	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szStart = strContent;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szMatch = 0;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szEnd   = 0;
	mc.GetMatch(mcIndex, &szMatch, &szEnd);
	if (0 == szMatch)
	{
		return false;
	}

	// 5 Ϊ "DD//:"
	ptrdiff_t nLength = szEnd - (szMatch + 5);
	ptrdiff_t nHead = szMatch - szStart;

	WTL::CString strFormat;
	strFormat.Format(_T("%%.%ds"), nLength);

	WTL::CString strHyper;
	strHyper.Format(strFormat, szMatch + 5);

	WTL::CString strParseText = strContent.Mid(0, nHead);
	ReplaceSel2((LPCTSTR)strParseText, charFormat);

	if (!strParseText.IsEmpty())
	{
		bPreTicket = false;
	}

	if (bPreTicket)
	{
		ReplaceSel2(_T(" "));	
	}
	stLinkCallBackData data;
	data.strInfoLBtn = strHyper;
	data.strInfoRBtn = _T("");
	data.m_pFuncLBtn = TICKET_LINK_FUNC;
	data.m_pFuncRBtn = NULL;
	data.m_dwValueLBtn = 0;
	data.m_dwValueRBtn = 0;
	data.lBeginPos = 0;
	data.lEndPos = 0;
	AddMsg(TRUE, TRUE, strHyper, charFormat.crTextColor,
		((charFormat.dwEffects)&CFE_UNDERLINE),
		((charFormat.dwEffects)&CFE_BOLD),
		((charFormat.dwEffects)&CFE_ITALIC),
		charFormat.yHeight, charFormat.bCharSet,
		charFormat.bPitchAndFamily, charFormat.szFaceName,
		&data);
	UpdateCurInsertSel();

	strContent.Format( _T( "%s" ), szEnd );
	return true;
}

bool CUIShowRichEdit::AddUBBRegFace(CAtlREMatchContext<CAtlRECharTraits>& mc, WTL::CString& strContent, int mcIndex, CHARFORMAT& charFormat)
{
	if (mcIndex < 0)
	{
		return false;
	}

	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szStart = strContent;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szMatch = 0;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szEnd   = 0;
	mc.GetMatch(mcIndex, &szMatch, &szEnd);
	if (0 == szMatch)
	{
		return false;
	}

	ptrdiff_t nLength = szEnd - szMatch;
	ptrdiff_t nHead = szMatch - szStart;

	WTL::CString strFormat;
	strFormat.Format(_T("%%.%ds"), nLength);

	WTL::CString strEmot;
	strEmot.Format(strFormat, szMatch);

	FaceIDExpressionMap::iterator it_face = m_faceIDExpressionMap.find(strEmot);
	if (it_face != m_faceIDExpressionMap.end())
	{
		WTL::CString strParseText = strContent.Mid(0, nHead);
		ReplaceSel2((LPCTSTR)strParseText, charFormat);

		UINT nFaceResID = it_face->second;
		if (m_sysHelper.SysImgIsPng(nFaceResID))
		{
			//����ϵͳλͼ
			this->InsertSystemPng(nFaceResID, true);
		}
		else if (m_bDisplaySysFace)
		{
			//����ϵͳ����
			this->InsertSystemFace(nFaceResID, false);
		}
		else
		{
			//��ȡ����ת������
			BYTE byResult = 0;
			TCHAR tszFaceText[MAX_PATH+1] = {0};
			DUICtrlNotifyInfo UINotifyInfo;
			memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
			UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_GET_EMOTION_EXPRESSION;
			UINotifyInfo.lParam1 = (DWORD_PTR)(this);
			UINotifyInfo.lParam2 = (DWORD_PTR)nFaceResID; //����ID
			UINotifyInfo.lParam3 = (DWORD_PTR)tszFaceText; //����ת�����ֽ��տռ�
			UINotifyInfo.lParam4 = (DWORD_PTR)MAX_PATH;
			UINotifyInfo.lParam5 = (DWORD_PTR)&byResult;
			::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);

			if (byResult != 0)
			{
				ReplaceSel2((LPCTSTR)tszFaceText, charFormat);
			}
			else
			{
				ReplaceSel2((LPCTSTR)_T("[���飺XX]"), charFormat);
			}
		}
	}
	else
	{
		WTL::CString strParseText = strContent.Mid(0, nHead + nLength);
		ReplaceSel2((LPCTSTR)strParseText, charFormat);
	}

	strContent.Format(_T("%s"), szEnd);
	return true;
}

bool CUIShowRichEdit::AddUBBCustomLinkReg(CAtlREMatchContext<CAtlRECharTraits>& mc, WTL::CString& strContent, int mcIndex, CHARFORMAT& charFormat, int customRegIdx)
{
	if (mcIndex < 0)
	{
		return false;
	}

	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szStart = strContent;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szMatch = 0;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szEnd   = 0;
	mc.GetMatch(mcIndex, &szMatch, &szEnd);
	if (0 == szMatch)
	{
		return false;
	}

	WTL::CString preMatch = strContent.Mid(szMatch-szStart, (szEnd - szMatch));
	DWORD bMatch = 0;

	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo, 0, sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_CUSTOM_LINK_PRE_PARSE;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	UINotifyInfo.lParam2 = (DWORD_PTR)(LPCTSTR)preMatch;
	UINotifyInfo.lParam3 = (DWORD_PTR)&bMatch;
	UINotifyInfo.lParam4 = (DWORD_PTR)customRegIdx;
	::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&UINotifyInfo, 0);

	if (!bMatch)
	{
		ReplaceSel2((LPCTSTR)strContent.Mid(0, szEnd - szStart), charFormat);
		strContent.Format( _T( "%s" ), szEnd);
		return false;
	}

	if (szMatch > szStart)
	{
		WTL::CString preText = strContent.Mid(0, szMatch - szStart);
		ReplaceSel2((LPCTSTR)preText, charFormat);
	}

	stLinkCallBackData data;
	data.strInfoLBtn = preMatch;
	data.strInfoRBtn = _T("");
	data.m_pFuncLBtn = CUSTOM_LINK_FUNC;
	data.m_pFuncRBtn = NULL;
	data.m_dwValueLBtn = customRegIdx;
	data.m_dwValueRBtn = 0;
	data.lBeginPos = 0;
	data.lEndPos = 0;

	AddMsg(TRUE, TRUE, preMatch, charFormat.crTextColor,
		((charFormat.dwEffects)&CFE_UNDERLINE),
		((charFormat.dwEffects)&CFE_BOLD),
		((charFormat.dwEffects)&CFE_ITALIC),
		charFormat.yHeight, charFormat.bCharSet,
		charFormat.bPitchAndFamily, charFormat.szFaceName,
		&data);
	UpdateCurInsertSel();

	strContent.Format( _T( "%s" ), szEnd);
	return true;
}

bool CUIShowRichEdit::AddUBBRegAt(CAtlREMatchContext<CAtlRECharTraits>& mc, WTL::CString& strContent, int mcIndex, CHARFORMAT& charFormat, UINT64 dwUserData)
{
	if (mcIndex < 0)
	{
		return false;
	}

	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szStart = strContent;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szMatch = 0;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szEnd   = 0;
	mc.GetMatch(mcIndex, &szMatch, &szEnd);
	if (0 == szMatch)
	{
		return false;
	}

	ptrdiff_t nLength = szEnd - szMatch;
	ptrdiff_t nHead = szMatch - szStart;

	WTL::CString strFormat;
	strFormat.Format(_T("%%.%ds"), nLength);

	WTL::CString strAtContent;
	strAtContent.Format(strFormat, szMatch);

	WTL::CString strParseText = strContent.Mid(0, nHead);
	ReplaceSel2((LPCTSTR)strParseText, charFormat);

	TCHAR tszResult[MAX_PATH + 1] = {0};
	_tcsncpy(tszResult, strAtContent, MAX_PATH);

	DWORD clrAtDesc = m_pColorLink ? m_pColorLink->GetValue() : charFormat.crTextColor;

	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_AT_DESC;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	UINotifyInfo.lParam2 = (DWORD_PTR)(LPCTSTR)strAtContent;
	UINotifyInfo.lParam3 = (DWORD_PTR)tszResult;
	UINotifyInfo.lParam4 = (DWORD_PTR)MAX_PATH;
	UINotifyInfo.lParam5 = (DWORD_PTR)&dwUserData;
	UINotifyInfo.lParam6 = (DWORD_PTR)&clrAtDesc;
	::SendMessage(m_hWndDirectUI, UISM_RICHEDIT_NOTIFY, (WPARAM)&UINotifyInfo, 0);

	stLinkCallBackData data;
	data.strInfoLBtn = tszResult;
	data.strInfoRBtn = _T("");
	data.m_pFuncLBtn = AT_LINK_FUNC;
	data.m_pFuncRBtn = NULL;
	data.m_dwValueLBtn = 0;
	data.m_dwValueRBtn = 0;
	data.lBeginPos = 0;
	data.lEndPos = 0;

	AddMsg(TRUE, FALSE, tszResult, clrAtDesc,
		((charFormat.dwEffects)&CFE_UNDERLINE),
		((charFormat.dwEffects)&CFE_BOLD),
		((charFormat.dwEffects)&CFE_ITALIC),
		charFormat.yHeight, charFormat.bCharSet,
		charFormat.bPitchAndFamily, charFormat.szFaceName,
		&data);
	UpdateCurInsertSel();

	strContent.Format(_T("%s"), szEnd);
	return true;
}

BOOL CUIShowRichEdit::AddMsg2(LPCTSTR strMsg, OLE_COLOR crNewColor, BOOL bUnderLine, BOOL bBold, BOOL bUrlLink, OLE_LINKCALLBACKDATA* pData, int nYOffset/* = 20*/)
{
	if (!IsDoingInsert())
	{
		return FALSE;
	}

	WTL::CString strMsgNew = strMsg;
	if (pData)
	{
		stLinkCallBackData dataNew;
		dataNew.strInfoLBtn = pData->strInfoLBtn;
		dataNew.strInfoRBtn = pData->strInfoRBtn;
		dataNew.m_dwValueLBtn = pData->m_dwValueLBtn;
		dataNew.m_dwValueRBtn = pData->m_dwValueRBtn;
		dataNew.m_pFuncLBtn = (LinkCallBackFunc)pData->m_pFuncLBtn;
		dataNew.m_pFuncRBtn = (LinkCallBackFunc)pData->m_pFuncRBtn;
		dataNew.lBeginPos = pData->dwPos;
		dataNew.lEndPos = pData->dwPos + strMsgNew.GetLength();

		return AddMsg(bUrlLink, FALSE, strMsgNew, crNewColor, bUnderLine, bBold, FALSE, MSG_YHEIGHT, 0, 32, DEAULT_FONT_NAME, &dataNew, nYOffset);
	}
	else
	{
		return AddMsg(bUrlLink, FALSE, strMsgNew, crNewColor, bUnderLine, bBold, FALSE, MSG_YHEIGHT, 0, 32, DEAULT_FONT_NAME, NULL, nYOffset);
	}

	return FALSE;
}

BOOL CUIShowRichEdit::AddMsgParseLink2(LPCTSTR strMsg, OLE_COLOR crNewColor,BOOL bUnderLine,BOOL bBold)
{
	if (!IsDoingInsert())
	{
		return FALSE;
	}

	UpdateCurInsertSel();

	WTL::CString string = strMsg;

	WTL::CString strParse = _T("");
	if (m_bEnableTicket)
	{
		strParse = m_strParseHyperlinkAndTicket;
	}
	else
	{
		strParse = PARSE_HYPER_LINK;
	}

	bool bPreTicket = false;	// ��¼ǰһ���������Ƿ�Ϊ�ɻ�Ʊ
	std::vector<DWORD> vecInsertImg; 
	std::vector<DWORD> vecInsertWaitImg; 
	WTL::CString strText;
	while( string.GetLength()>0)
	{
		// �й��������ʽ�����ⲻҪ����,�Լ���MSDN:
		//ms-help://MS.MSDNQTR.v80.chs/MS.MSDN.v80/MS.VisualStudio.v80.chs/dv_vclib/html/7423717b-b3d5-42a7-af98-46b0e6356449.htm
		CAtlRegExp<CAtlRECharTraits> reg;
		REParseError status = reg.Parse(strParse);
		if (REPARSE_ERROR_OK != status)
		{
			// Unexpected error.
			break ;
		}
		CAtlREMatchContext<CAtlRECharTraits> mc;
		if (!reg.Match(string, &mc))
		{
			AddMsg(FALSE, FALSE, string, crNewColor, bUnderLine, bBold, FALSE, MSG_YHEIGHT, 0, 32, DEAULT_FONT_NAME);
			break;
		}
		
		//������
		int bMatched = AddMsgRegHyperLink(mc, string, 0, crNewColor, bUnderLine, bBold, bPreTicket);
		if (bMatched)
		{
			bPreTicket = false;
			continue;
		}

		// �ɻ�Ʊ
		if (m_bEnableTicket)
		{
			bMatched = AddMsgRegTicket(mc, string, 1, crNewColor, bUnderLine, bBold, bPreTicket);
			if (bMatched)
			{
				bPreTicket = true;
				continue;
			}
		}
	}

	return TRUE;
}

bool CUIShowRichEdit::AddMsgRegHyperLink(CAtlREMatchContext<CAtlRECharTraits>& mc, WTL::CString& strContent, int mcIndex, OLE_COLOR crNewColor, BOOL bUnderLine, BOOL bBold, bool bPreTicket)
{
	if (mcIndex < 0)
	{
		return false;
	}

	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szStart = strContent;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szMatch = 0;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szEnd   = 0;
	mc.GetMatch(mcIndex, &szMatch, &szEnd);
	if (0 == szMatch)
	{
		return false;
	}

	ptrdiff_t nLength = szEnd - szMatch;
	ptrdiff_t nHead = szMatch - szStart;

	WTL::CString strFormat;
	strFormat.Format(_T("%%.%ds"), nLength);

	WTL::CString strHyper;
	strHyper.Format(strFormat, szMatch);

	WTL::CString strText = strContent.Mid(0, nHead);
	AddMsg(FALSE, FALSE, strText, crNewColor, bUnderLine, bBold, FALSE, MSG_YHEIGHT, 0, 32, DEAULT_FONT_NAME);

	if (bPreTicket)
	{
		AddMsg(FALSE, FALSE, _T(" "), crNewColor, bUnderLine, bBold, FALSE, MSG_YHEIGHT, 0, 32, DEAULT_FONT_NAME);
	}
	stLinkCallBackData data;
	data.strInfoLBtn = strHyper;
	data.strInfoRBtn = _T("");
	data.m_pFuncLBtn = HYPER_LINK_FUNC;
	data.m_pFuncRBtn = NULL;
	data.m_dwValueLBtn = 0;
	data.m_dwValueRBtn = 0;
	data.lBeginPos = 0;
	data.lEndPos = 0;
	AddMsg(TRUE, TRUE, strHyper, crNewColor, bUnderLine, bBold, FALSE, MSG_YHEIGHT, 0, 32, DEAULT_FONT_NAME, &data);
	UpdateCurInsertSel();

	strContent.Format( _T( "%s" ), szEnd);
	return true;
}

bool CUIShowRichEdit::AddMsgRegTicket(CAtlREMatchContext<CAtlRECharTraits>& mc, WTL::CString& strContent, int mcIndex, OLE_COLOR crNewColor, BOOL bUnderLine, BOOL bBold, bool bPreTicket)
{
	if (mcIndex < 0)
	{
		return false;
	}

	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szStart = strContent;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szMatch = 0;
	const CAtlREMatchContext<CAtlRECharTraits>::RECHAR* szEnd   = 0;
	mc.GetMatch(mcIndex, &szMatch, &szEnd);
	if (0 == szMatch)
	{
		return false;
	}

	// 5 Ϊ "DD//:"
	ptrdiff_t nLength = szEnd - (szMatch+5);
	ptrdiff_t nHead = szMatch - szStart;

	WTL::CString strFormat;
	strFormat.Format(_T("%%.%ds"), nLength);

	WTL::CString strHyper;
	strHyper.Format(strFormat, szMatch+5);

	WTL::CString strText = strContent.Mid(0, nHead);
	AddMsg(FALSE, FALSE, strText, crNewColor, bUnderLine, bBold, FALSE, MSG_YHEIGHT, 0, 32, DEAULT_FONT_NAME);

	if (!strText.IsEmpty())
	{
		bPreTicket = false;
	}

	if (bPreTicket)
	{
		AddMsg(FALSE, FALSE, _T(" "), crNewColor, bUnderLine, bBold, FALSE,MSG_YHEIGHT, 0, 32, DEAULT_FONT_NAME);
	}
	stLinkCallBackData data;
	data.strInfoLBtn = strHyper;
	data.strInfoRBtn = _T("");
	data.m_pFuncLBtn = TICKET_LINK_FUNC;
	data.m_pFuncRBtn = NULL;
	data.m_dwValueLBtn = 0;
	data.m_dwValueRBtn = 0;
	data.lBeginPos = 0;
	data.lEndPos = 0;
	AddMsg(TRUE, TRUE, strHyper, crNewColor, bUnderLine, bBold, FALSE, MSG_YHEIGHT, 0, 32, DEAULT_FONT_NAME, &data);
	UpdateCurInsertSel();

	strContent.Format( _T( "%s" ), szEnd );
	return true;
}

BOOL CUIShowRichEdit::AddNotifyEx2(LPCTSTR strNotify, LPCTSTR strHintPicPath,BOOL bChangeLineEnd)
{
	if (!IsDoingInsert())
	{
		return FALSE;
	}

	if (!bChangeLineEnd)
	{
		ChangeLine();
	}

	InsertUserDefPic2(strHintPicPath, true);
	AddMsg(FALSE, FALSE, strNotify, CHATMSG_SYSMSG_CLR, FALSE, FALSE, FALSE, MSG_YHEIGHT, 0, 32, DEAULT_FONT_NAME);
	if (bChangeLineEnd)
	{
		ChangeLine();
	}

	return TRUE;
}

BOOL CUIShowRichEdit::AddNotifyBmp2(LPCTSTR strNotify, UINT nHintPicResID,BOOL bChangeLineEnd)
{
	if (!IsDoingInsert())
	{
		return FALSE;
	}

	WTL::CString strNotifyNew = strNotify;

	if (!bChangeLineEnd)
	{
		ChangeLine();
	}

	InsertSystemBmp(nHintPicResID, true);
	AddMsg(FALSE, FALSE, strNotifyNew, CHATMSG_SYSMSG_CLR, FALSE, FALSE, FALSE, MSG_YHEIGHT, 0, 32, DEAULT_FONT_NAME);
	if (bChangeLineEnd)
	{
		ChangeLine();
	}

	return TRUE;
}

BOOL CUIShowRichEdit::AddNotifyImgEx2(LPCTSTR strHintPicPath)
{
	if (!IsDoingInsert())
	{
		return FALSE;
	}

	InsertUserDefPic2(strHintPicPath, true);

	return TRUE;
}

BOOL CUIShowRichEdit::AddNotifyImgBmp(UINT nHintResID)
{
	if (!IsDoingInsert())
	{
		return FALSE;
	}

	InsertSystemBmp(nHintResID, true);

	return TRUE;
}

BOOL CUIShowRichEdit::IsLinkExist(OLE_LINKCALLBACKDATA* pLinkData, int nLineOfLink/* = -1*/)
{
	if (!pLinkData)
	{
		return FALSE;
	}

	list_LinkCallBacks::iterator it_link = m_listLinksCallBack.begin();
	for (; it_link != m_listLinksCallBack.end(); ++it_link)
	{
		if (pLinkData->m_pFuncLBtn != (DWORD_PTR*)it_link->m_pFuncLBtn || 
			pLinkData->m_pFuncRBtn != (DWORD_PTR*)it_link->m_pFuncRBtn)
		{
			continue;
		}

		if (pLinkData->m_dwValueLBtn != it_link->m_dwValueLBtn || 
			pLinkData->m_dwValueRBtn != it_link->m_dwValueRBtn)
		{
			continue;
		}

		if (pLinkData->strInfoLBtn != it_link->strInfoLBtn || 
			pLinkData->strInfoRBtn != it_link->strInfoRBtn)
		{
			continue;
		}

		if (nLineOfLink != -1)
		{
			int nLineBegin = m_FreeWindowlessRE.LineFromChar(it_link->lBeginPos);
			int nLineEnd = m_FreeWindowlessRE.LineFromChar(it_link->lEndPos);
			if (nLineBegin != nLineOfLink && nLineEnd != nLineOfLink)
			{
				continue;
			}
		}

		return TRUE;
	}

	return FALSE;
}

BOOL CUIShowRichEdit::IsSystemFaceExist(DWORD dwOleID, int nLineOfOle/* = -1*/)
{
	if (!m_bInit)
	{
		return FALSE;
	}

	RichOleMap::iterator it_old = m_richOleMap.find(dwOleID);
	if (it_old == m_richOleMap.end())
	{
		return FALSE;
	}

	CComPtr<IRichEditOle> pReo;
	GetIRichEditOle(&pReo);
	if(NULL == pReo)
	{
		return FALSE;
	}

	if (-1 == nLineOfOle)
	{
		return TRUE;
	}

	REOBJECT reObject;
	int nOleCount = pReo->GetObjectCount();
	for (int i = 0; i < nOleCount; ++i)
	{
		memset(&reObject, 0, sizeof(REOBJECT));
		reObject.cbStruct = sizeof(REOBJECT);
		pReo->GetObject(i, &reObject, REO_GETOBJ_NO_INTERFACES);

		LONG nOleChar = reObject.cp;
		int nOleLine = m_FreeWindowlessRE.LineFromChar(nOleChar);
		if (nOleLine == nLineOfOle)
		{
			return TRUE;
		}
	}

	return FALSE;
}

void CUIShowRichEdit::SetPicLoadFailed(LPCTSTR fileName)
{
	CUIEngineCom* pDirectUI = GetDirectUI();
	if (!pDirectUI)
	{
		return;
	}

	/////////////////////////////////////////////////////////////
	//�Ȱѵ�ǰ������̱�������
	BOOL bIsDoingInsert = FALSE;
	stInsertProcess orgInsertProcess = m_insertProcess;
	if (IsDoingInsert())
	{
		bIsDoingInsert = TRUE;
		InsertContentEnd(eScrollAuto);
	}

	/////////////////////////////////////////////////////////////
	//�������ʧ����ʾͼƬ
	InsertContentBegin(eInsertModeBack, FALSE);
	WTL::CString strFileName = fileName;
	tDelayImageInfo::iterator it = m_tWaitImageQueue.begin();
	for (;it != m_tWaitImageQueue.end(); ++it)
	{
		//�����ѹ���
		if (eImageStatus_Removed == it->imgStatus)
		{
			continue;
		}

		//�������ʧ����ʾͼƬ
		if (strFileName != it->strFileName)
		{
			continue;
		}

		SetSel(it->pos, it->pos + 1);
		it->dwOleID = this->InsertOverTimeImg();
        it->imgStatus = eImageStatus_Failed;
	}
	InsertContentEnd(eScrollAuto);

	/////////////////////////////////////////////////////////////
	//����֮ǰ�Ĳ������
	if (bIsDoingInsert)
	{
		InsertContentContinue(orgInsertProcess);
	}
}

bool CUIShowRichEdit::IsScrollAtBottom(BOOL bHorz /* = FALSE */)
{
	if (m_pScrollBarImplVert)
	{
		if (!IsScrollBarExist(FALSE))
		{
			return true;
		}

		DUISCROLLINFO srcInfo;
		srcInfo.ulSize = sizeof(DUISCROLLINFO);
		if (m_pScrollBarImplVert->GetScrollInfo(&srcInfo, DUISB_SIF_ALL))
		{
			if (srcInfo.nPos + 40 >= srcInfo.nMax - (LONG)srcInfo.ulPage)
			{
				return true;
			}
		}
	}

	return false;
}

void CUIShowRichEdit::ScrollToBottom()
{
	OnRichEditMsgProc(WM_VSCROLL, SB_BOTTOM, 0);
}

bool CUIShowRichEdit::IsScrollAtTop(BOOL bHorz/* = FALSE*/)
{
	if (m_pScrollBarImplVert)
	{
		if (!IsScrollBarExist(FALSE))
		{
			return true;
		}

		DUISCROLLINFO srcInfo;
		srcInfo.ulSize = sizeof(DUISCROLLINFO);
		if (m_pScrollBarImplVert->GetScrollInfo(&srcInfo, DUISB_SIF_ALL))
		{
			if (srcInfo.nPos < 5)
			{
				return true;
			}
		}
	}

	return false;
}

void CUIShowRichEdit::ScrollToTop()
{
	OnRichEditMsgProc(WM_VSCROLL, SB_TOP, 0);
}

void CUIShowRichEdit::SetCanClrOrLockScr(bool bFlag)
{
	m_bCanClrOrLockScr = bFlag;
}

void CUIShowRichEdit::EnableTicket(bool bEnable)
{
	m_bEnableTicket = bEnable;
}

bool CUIShowRichEdit::GetBlockImage()
{
	return m_bBlockImage;
}

void CUIShowRichEdit::SetBlockImage(bool bBlock)
{
	m_bBlockImage = bBlock;
}

void CUIShowRichEdit::SetDisplaySysFace(bool bDisplay)
{
	m_bDisplaySysFace = bDisplay;
}

bool CUIShowRichEdit::IsDisplaySysFace()
{
	return m_bDisplaySysFace;
}

void CUIShowRichEdit::SetDisplayChannelMsg(bool bDisplay)
{
	m_bDisplayChannelMsg = bDisplay;
}

bool CUIShowRichEdit::IsDisplayChannelMsg()
{
	return m_bDisplayChannelMsg;
}

bool CUIShowRichEdit::IsLockScreen()
{
	return m_bLockScr;
}

void CUIShowRichEdit::LockScreen()
{
	m_bLockScr = !m_bLockScr;

	//֪ͨ�ϲ�
	DUICtrlNotifyInfo UINotifyInfo;
	memset(&UINotifyInfo,0,sizeof(DUICtrlNotifyInfo));
	UINotifyInfo.uMsgID = RICHEDIT_NOTIFYMSG_LOCK_SCREEN;
	UINotifyInfo.lParam1 = (DWORD_PTR)(this);
	UINotifyInfo.lParam2 = (DWORD_PTR)m_bLockScr?TRUE:FALSE;
	::SendMessage(m_hWndDirectUI,UISM_RICHEDIT_NOTIFY,(WPARAM)&UINotifyInfo,0);
}

void CUIShowRichEdit::SetSafeSiteCheck(bool bCheck)
{
	m_bSafeSiteCheck = bCheck;
}

void CUIShowRichEdit::SetSafeCheckSite2(LPCTSTR strSafeCheckSite)
{
	m_sysHelper.SetSafeCheckSite(strSafeCheckSite);
}

void CUIShowRichEdit::SetFontSize(LONG nPointSize)
{
	CHARFORMAT cf;
	GetCharFormat(cf, CFM_COLOR | CFM_FACE | CFM_SIZE | CFM_BOLD | CFM_ITALIC | CFM_UNDERLINE);
	nPointSize *= 20;
	cf.yHeight = nPointSize;
	cf.dwMask = CFM_SIZE;
	SetSelectionCharFormat(cf);
}

void CUIShowRichEdit::SetFontName2(LPCTSTR strFontName)
{
	WTL::CString sFontName = strFontName;

	CHARFORMAT cf;
	GetCharFormat(cf, CFM_COLOR | CFM_FACE | CFM_SIZE | CFM_BOLD | CFM_ITALIC | CFM_UNDERLINE);
	// Set the font name.
	for (int i = 0; i <= sFontName.GetLength()-1; i++)
		cf.szFaceName[i] = sFontName[i];
	cf.dwMask = CFM_FACE;
	SetSelectionCharFormat(cf);
}

void CUIShowRichEdit::SetCharStyle(LONG lMask, LONG lStyle, LONG nStart, LONG nEnd)
{
	CHARFORMAT cf;
	cf.cbSize = sizeof(CHARFORMAT);
	//cf.dwMask = MASK;
	GetSelectionCharFormat(cf);
	if (cf.dwMask & lMask)	// selection is all the same
	{
		cf.dwEffects ^= lStyle; 
	}
	else
	{
		cf.dwEffects |= lStyle;
	}
	cf.dwMask = lMask;
	SetSelectionCharFormat(cf);
}

void CUIShowRichEdit::GetContent(LPTSTR lpContent, int nMaxCount)
{
	m_FreeWindowlessRE.GetTextEx(lpContent, nMaxCount);
}

void CUIShowRichEdit::SetContent(LPCTSTR lpContent)
{
	m_FreeWindowlessRE.SetText(lpContent);
}

long CUIShowRichEdit::GetContentLength()
{
	return m_FreeWindowlessRE.GetTextLengthEx();
}

OLE_COLOR CUIShowRichEdit::GetContentColor()
{
	CHARFORMAT cf;
	GetCharFormat(cf, CFM_COLOR | CFM_FACE | CFM_SIZE | CFM_BOLD | CFM_ITALIC | CFM_UNDERLINE);
	return (OLE_COLOR)cf.crTextColor;
}

LONG CUIShowRichEdit::GetSelectionFontSize()
{
	CHARFORMAT cf;
	GetCharFormat(cf, CFM_COLOR | CFM_FACE | CFM_SIZE | CFM_BOLD | CFM_ITALIC | CFM_UNDERLINE);
	return cf.yHeight/20;
}

void CUIShowRichEdit::GetSelectionFontName(LPTSTR pFontName,int nMaxCount)
{
	if(NULL == pFontName)
		return;
	CHARFORMAT cf;
	GetCharFormat(cf, CFM_COLOR | CFM_FACE | CFM_SIZE | CFM_BOLD | CFM_ITALIC | CFM_UNDERLINE);

	memset(pFontName, 0, sizeof(TCHAR)*nMaxCount);
	_tcsncpy(pFontName, cf.szFaceName, nMaxCount-1);
}

void CUIShowRichEdit::SetRTF2(LPCTSTR strRTF)
{
	return;
}

void CUIShowRichEdit::GetRTF(LPTSTR pRTF,int nMaxCount)
{
	// 	WTL::CString sRTF = _T("");
	// 
	// 	*pRTF = sRTF.AllocSysString();
}

void CUIShowRichEdit::SetShowFaceTips(bool bShow)
{
	m_bShowFaceTip =  bShow;
}

void CUIShowRichEdit::SetSysImgParam(UINT nSysImgPngStart, UINT nSysImgPngEnd, UINT nSysImgGifStart, UINT nSysImgGifEnd)
{
	m_sysHelper.SetSysImgParam(nSysImgPngStart, nSysImgPngEnd, nSysImgGifStart, nSysImgGifEnd);
	m_htmlFormatParser.SetSysImgParam(nSysImgPngStart, nSysImgPngEnd, nSysImgGifStart, nSysImgGifEnd);
}

void CUIShowRichEdit::SetSysSpecialImgResID(UINT nResID_LoadingGif, UINT nResID_BlockingGif, UINT nResID_ImgNotExistPng, UINT nResID_CommonHintPng)
{
	m_sysHelper.SetSysSpecialImgResID(nResID_LoadingGif, nResID_BlockingGif, nResID_ImgNotExistPng, nResID_CommonHintPng);
}

void CUIShowRichEdit::SetSysFaceParam(BYTE bySysFaceType, UINT nSysFaceIDBase, UINT nSysFaceNum)
{
	m_sysHelper.SetSysFaceParam(bySysFaceType, nSysFaceIDBase, nSysFaceNum);
}

void CUIShowRichEdit::SetSysFaceResourceDll(HMODULE hFaceDll)
{
	m_sysHelper.SetRcFaceDll(hFaceDll);
}

void CUIShowRichEdit::SetSysFaceCharRegExpression(LPCTSTR lpRegExpression, int nRegBeginCharCount, int nRegEndCharCount)
{
	m_regExpFace.nRegBeginCharCount = nRegBeginCharCount;
	m_regExpFace.nRegEndCharCount = nRegEndCharCount;
	m_regExpFace.strRegExpString = lpRegExpression;
	UpdateRegExpression();
}

void CUIShowRichEdit::AddSysFaceTextExpression(UINT nSysFaceID, LPCTSTR lpTextExpression, LPCTSTR lpTextHint)
{
	FaceTextExpressionMap::iterator it_char = m_faceTextExpressionMap.find(nSysFaceID);
	if (it_char != m_faceTextExpressionMap.end())
	{
		it_char->second.strTextExpression = lpTextExpression;
		it_char->second.strTextHint = lpTextHint;
	}
	else
	{
		stFaceTextExpression data;
		data.strTextExpression = lpTextExpression;
		data.strTextHint = lpTextHint;
		m_faceTextExpressionMap.insert(std::make_pair(nSysFaceID, data));
	}

	FaceIDExpressionMap::iterator it_id = m_faceIDExpressionMap.find(lpTextExpression);
	if (it_id != m_faceIDExpressionMap.end())
	{
		it_id->second = nSysFaceID;
	}
	else
	{
		m_faceIDExpressionMap.insert(std::make_pair(lpTextExpression, nSysFaceID));
	}
}

void CUIShowRichEdit::SetAtCharRegExpression(LPCTSTR lpRegExpression, int nRegBeginCharCount, int nRegEndCharCount)
{
	m_regExpAt.nRegBeginCharCount = nRegBeginCharCount;
	m_regExpAt.nRegEndCharCount = nRegEndCharCount;
	m_regExpAt.strRegExpString = lpRegExpression;
	UpdateRegExpression();
}

void CUIShowRichEdit::SetImageFileExpFormat(LPCTSTR lpImgFileExpFormat)
{
	m_regExpImgFile.strRegExpFormat = lpImgFileExpFormat;
}

void CUIShowRichEdit::SetImageFileRegString(LPCTSTR lpImgFileRegString, int nRegBeginCharCount, int nRegEndCharCount, 
											LPCTSTR lpImgFileWidthBegin, LPCTSTR lpImgFileWidthEnd, LPCTSTR lpImgFileHeightBegin, LPCTSTR lpImgFileHeightEnd)
{
	m_regExpImgFile.nRegBeginCharCount = nRegBeginCharCount;
	m_regExpImgFile.nRegEndCharCount = nRegEndCharCount;
	m_regExpImgFile.strRegExpString = lpImgFileRegString;
	m_expImgFileSize.strExpWidthBegin = lpImgFileWidthBegin;
	m_expImgFileSize.strExpWidthEnd = lpImgFileWidthEnd;
	m_expImgFileSize.strExpHeightBegin = lpImgFileHeightBegin;
	m_expImgFileSize.strExpHeightEnd = lpImgFileHeightEnd;
	UpdateRegExpression();
}

void CUIShowRichEdit::SetImageURLExpFormat(LPCTSTR lpImgURLExpFormat)
{
	m_regExpImgURL.strRegExpFormat = lpImgURLExpFormat;
}

void CUIShowRichEdit::SetImageURLRegString(LPCTSTR lpImgURLRegString, int nRegBeginCharCount, int nRegEndCharCount, 
										   LPCTSTR lpImgURLWidthBegin, LPCTSTR lpImgURLWidthEnd, LPCTSTR lpImgURLHeightBegin, LPCTSTR lpImgURLHeightEnd)
{
	m_regExpImgURL.nRegBeginCharCount = nRegBeginCharCount;
	m_regExpImgURL.nRegEndCharCount = nRegEndCharCount;
	m_regExpImgURL.strRegExpString = lpImgURLRegString;
	m_expImgURLSize.strExpWidthBegin = lpImgURLWidthBegin;
	m_expImgURLSize.strExpWidthEnd = lpImgURLWidthEnd;
	m_expImgURLSize.strExpHeightBegin = lpImgURLHeightBegin;
	m_expImgURLSize.strExpHeightEnd = lpImgURLHeightEnd;
	UpdateRegExpression();
}

void CUIShowRichEdit::SetPicRcvPath2(LPCTSTR strPicPath)
{
	m_sysHelper.SetPicRcvPath(strPicPath);
}

void CUIShowRichEdit::EnableRPopupMenu(bool bEnable)
{
	m_bEnableRPopupMenu = bEnable;
}

void CUIShowRichEdit::SetShieldFaceMsgMenuVisable(bool bVisable)
{
	m_bVisableShieldFaceMsgMenu = bVisable;
}

LONG CUIShowRichEdit::GetLimitTextLength()
{
	return GetLimitText();
}

void CUIShowRichEdit::LimitTextLength(LONG nChars)
{
	LimitText(nChars);
}

long CUIShowRichEdit::GetTextLength()
{
	if (!m_bInit) return 0;

	return m_FreeWindowlessRE.GetTextLength();
}

void CUIShowRichEdit::AddNotifyPng2(LPCTSTR strNotify, UINT nHintPicResID, BOOL bChangeLineEnd)
{
	WTL::CString strNotifyNew = strNotify;

	if (!bChangeLineEnd)
	{
		ChangeLine();
	}
	else
	{
		strNotifyNew += _T("\r\n");
	}
	SetStartIndent(100);
	InsertSystemPng(nHintPicResID, true);
	AddMsg(FALSE, FALSE, strNotifyNew, CHATMSG_SYSMSG_CLR, FALSE, FALSE, FALSE, MSG_YHEIGHT, 0, 32, DEAULT_FONT_NAME);
}

void CUIShowRichEdit::SetGetExistSRImagePathFn( DWORD_PTR pFn )
{
	m_sysHelper.SetGetExistSRImagePathFn((FnGetExistSRImagePath)pFn);
}

void CUIShowRichEdit::EnableWordBreak(bool bEnable)
{
	if (!m_bInit) return;

	return m_FreeWindowlessRE.EnableWordBreak(bEnable);
}

DWORD CUIShowRichEdit::InsertOleControl(LPCTSTR lpOleEleName, int nWidth, int nHeight)
{
	return InsertOleControl(lpOleEleName, nWidth, nHeight, GetOleID());
}

LPCTSTR CUIShowRichEdit::GetOleControlElementNameByCursor(DWORD dwOleID)
{
	CPoint ptCursor(0, 0);
	::GetCursorPos(&ptCursor);
	return GetOleControlElementNameByPos(dwOleID, ptCursor);
}

LPCTSTR CUIShowRichEdit::GetOleControlElementNameByPos(DWORD dwOleID, POINT pt)
{
	CPoint ptHitTest = pt;

	DWORD dwResultOleID = -1;
	CRect rcResultOle(0,0,0,0);
	bool bRet = HitTestOleByPoint(ptHitTest, dwResultOleID, rcResultOle);
	if (!bRet)
	{
		return _T("");
	}

	if (dwResultOleID != dwOleID)
	{
		return _T("");
	}

	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return _T("");
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return _T("");
	}

	CRichElementBase* pMainElement = pOleControlProcesser->GetControlElement();
	if (NULL == pMainElement)
	{
		return _T("");
	}

	ptHitTest.Offset(-rcResultOle.left, -rcResultOle.top);

	CRichElementBase* pHitElement = pMainElement->HitTest(ptHitTest);
	if (NULL == pHitElement)
	{
		return _T("");
	}

	return pHitElement->GetName();
}

void CUIShowRichEdit::SetOleControlElementVisible(DWORD dwOleID, LPCTSTR lpName, BOOL bVisible)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return;
	}

	pOleControlProcesser->SetElementVisible(lpName, bVisible);

	BufferedReDraw();
}

BOOL CUIShowRichEdit::IsOleControlElementVisible(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	return pOleControlProcesser->IsElementVisible(lpName);
}

void CUIShowRichEdit::SetOleControlElementEnabled(DWORD dwOleID, LPCTSTR lpName, BOOL bEnabled)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return;
	}

	pOleControlProcesser->SetElementEnabled(lpName, bEnabled);

	BufferedReDraw();
}

BOOL CUIShowRichEdit::IsOleControlElementEnabled(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	return pOleControlProcesser->IsElementEnabled(lpName);
}

void CUIShowRichEdit::SetOleControlElementDisposeMouse(DWORD dwOleID, LPCTSTR lpName, BOOL bDispose)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return;
	}

	pOleControlProcesser->SetElementDisposeMouse(lpName, bDispose);

	BufferedReDraw();
}

BOOL CUIShowRichEdit::IsOleControlElementDisposeMouse(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	return pOleControlProcesser->IsElementDisposeMouse(lpName);
}

void CUIShowRichEdit::SetOleControlElementTooltip(DWORD dwOleID, LPCTSTR lpName, LPCTSTR lpTooltip)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return;
	}

	pOleControlProcesser->SetElementTooltip(lpName, lpTooltip);
}

void CUIShowRichEdit::SetOleControlElementTooltipByStringCaption(DWORD dwOleID, LPCTSTR lpName, LPCTSTR lpStringCaption)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return;
	}

	pOleControlProcesser->SetElementTooltipByStringCaption(lpName, lpStringCaption);
}

BOOL CUIShowRichEdit::IsOleControlElementStatic(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	return pOleControlProcesser->IsElementStatic(lpName);
}

BOOL CUIShowRichEdit::SetOleControlElementStaticText(DWORD dwOleID, LPCTSTR lpName, LPCTSTR lpText)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	BOOL bRet = pOleControlProcesser->SetElementStaticText(lpName, lpText);
	BufferedReDraw();
	return bRet;
}

BOOL CUIShowRichEdit::SetOleControlElementStaticTextByStringCaption(DWORD dwOleID, LPCTSTR lpName, LPCTSTR lpStringCaption)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
	if (NULL == pOleProcesser)
	{
		pOleProcesser = GetExtralOleControl(dwOleID);
	}
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	BOOL bRet = pOleControlProcesser->SetElementStaticTextByStringCaption(lpName, lpStringCaption);
	BufferedReDraw();
	return bRet;
}

LPCTSTR CUIShowRichEdit::GetOleControlElementStaticText(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return _T("");
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return _T("");
	}

	return pOleControlProcesser->GetElementStaticText(lpName);
}

BOOL CUIShowRichEdit::SetOleControlElementStaticTextColor(DWORD dwOleID, LPCTSTR lpName, COLORREF clrTextNormal, COLORREF clrTextHot, COLORREF clrTextPress, COLORREF clrTextDisabled)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	BOOL bRet = pOleControlProcesser->SetElementStaticTextColor(lpName, clrTextNormal, clrTextHot, clrTextPress, clrTextDisabled);
	BufferedReDraw();
	return bRet;
}

COLORREF CUIShowRichEdit::GetOleControlElementStaticTextNormalColor(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return 0;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return 0;
	}

	return pOleControlProcesser->GetElementStaticTextNormalColor(lpName);
}

COLORREF CUIShowRichEdit::GetOleControlElementStaticTextHotColor(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return 0;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return 0;
	}

	return pOleControlProcesser->GetElementStaticTextHotColor(lpName);
}

COLORREF CUIShowRichEdit::GetOleControlElementStaticTextPressColor(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return 0;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return 0;
	}

	return pOleControlProcesser->GetElementStaticTextPressColor(lpName);
}

COLORREF CUIShowRichEdit::GetOleControlElementStaticTextDisabledColor(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return 0;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return 0;
	}

	return pOleControlProcesser->GetElementStaticTextDisabledColor(lpName);
}

CUITextStyleCom* CUIShowRichEdit::GetOleControlElementStaticTextStyle(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return NULL;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return NULL;
	}

	return pOleControlProcesser->GetElementStaticTextStyle(lpName);
}

void CUIShowRichEdit::SetOleControlElementStaticTextStyle(DWORD dwOleID, LPCTSTR lpName, CUITextStyleCom* pTextStyle)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return;
	}

	pOleControlProcesser->SetElementStaticTextStyle(lpName, pTextStyle);
}

BOOL CUIShowRichEdit::IsOleControlElementLogo(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	return pOleControlProcesser->IsElementLogo(lpName);
}

BOOL CUIShowRichEdit::SetOleControlElementLogoImage(DWORD dwOleID, LPCTSTR lpName, CUIImageBaseCom* pLogo)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	BOOL bRet = pOleControlProcesser->SetElementLogoImage(lpName, pLogo);
	BufferedReDraw();
	return bRet;
}

CUIImageBaseCom* CUIShowRichEdit::GetOleControlElementLogoImageBase(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return NULL;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return NULL;
	}

	return pOleControlProcesser->GetElementLogoImageBase(lpName);
}

BOOL CUIShowRichEdit::SetOleControlElementLogoImage(DWORD dwOleID, LPCTSTR lpName, CUIImageListCom* pImagList, int nLogoIndex)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	BOOL bRet = pOleControlProcesser->SetElementLogoImage(lpName, pImagList, nLogoIndex);
	BufferedReDraw();
	return bRet;
}

CUIImageListCom* CUIShowRichEdit::GetOleControlElementLogoImageList(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return NULL;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return NULL;
	}

	return pOleControlProcesser->GetElementLogoImageList(lpName);
}

int CUIShowRichEdit::GetOleControlElementLogoImageIndex(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return -1;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return -1;
	}

	return pOleControlProcesser->GetElementLogoImageIndex(lpName);
}

BOOL CUIShowRichEdit::SetOleControlElementLogoImageBmp(DWORD dwOleID, LPCTSTR lpName, HBITMAP hBmpLogo, BOOL bTemporySource)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return FALSE;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return FALSE;
	}

	BOOL bRet = pOleControlProcesser->SetElementLogoImageBmp(lpName, (HBITMAP)hBmpLogo, bTemporySource);
	BufferedReDraw();
	return bRet;
}

HBITMAP CUIShowRichEdit::GetOleControlElementLogoImageBmp(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return NULL;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return NULL;
	}

	return pOleControlProcesser->GetItemElementLogoImageBmp(lpName);
}

void CUIShowRichEdit::SetOleControlElementFixedWidth(DWORD dwOleID, LPCTSTR lpName, int nWidth)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return;
	}

	pOleControlProcesser->SetElementFixedWidth(lpName, nWidth);
	BufferedReDraw();
}

int CUIShowRichEdit::GetOleControlElementFixedWidth(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return 0;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return 0;
	}

	return pOleControlProcesser->GetElementFixedWidth(lpName);
}

void CUIShowRichEdit::SetOleControlElementFixedHeight(DWORD dwOleID, LPCTSTR lpName, int nHeight)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return;
	}

	pOleControlProcesser->SetElementFixedHeight(lpName, nHeight);
	BufferedReDraw();
}

int CUIShowRichEdit::GetOleControlElementFixedHeight(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return 0;
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return 0;
	}

	return pOleControlProcesser->GetElementFixedHeight(lpName);
}

RECT CUIShowRichEdit::GetOleControlItemElementRect(DWORD dwOleID, LPCTSTR lpName)
{
	IOleProcesser* pOleProcesser = GetOleProcesser(dwOleID);
    if (NULL == pOleProcesser)
    {
        pOleProcesser = GetExtralOleControl(dwOleID);
    }
	if (!pOleProcesser || pOleProcesser->GetType() != OleProcesser_Control)
	{
		return CRect(0,0,0,0);
	}

	CIMControlProcesser* pOleControlProcesser = (CIMControlProcesser*)pOleProcesser;
	if (!pOleControlProcesser)
	{
		return CRect(0,0,0,0);
	}

	return pOleControlProcesser->GetItemElementRect(lpName);
}

int CUIShowRichEdit::GetOleControlVisibleArray(DWORD* pResultIndexArray, int nArrayCount)
{
	int nCurResultCount = 0;
	if (!pResultIndexArray || nArrayCount <= 0)
	{
		return nCurResultCount;
	}

	if (!m_bInit)
	{
		return nCurResultCount;
	}

	CComPtr<IRichEditOle> pReo;
	GetIRichEditOle(&pReo);
	if(pReo == NULL)
	{
		return nCurResultCount;
	}

	int nOleCount = pReo->GetObjectCount();
	if (nOleCount <= 0)
	{
		return nCurResultCount;
	}

	// ����DC
	HDC hDC = ::GetDC(m_hWndDirectUI);

	//���ȿ��ٶ�λһ���ɼ�ole����
	REOBJECT reObject;
	LONG xPerInch = GetDeviceCaps(hDC, LOGPIXELSX); 
	LONG yPerInch =	GetDeviceCaps(hDC, LOGPIXELSY); 

	int nEndIndex = 0;
	RECT rcClient = GetRect();
	GetOneOleUpdateIndex(pReo, reObject, xPerInch, yPerInch, rcClient, nOleCount, nEndIndex);

	//�ӵ�ǰ�ɼ�ole��������λ�ã������˷�ɢ��ʼ����
	CPoint ptObjPos = CPoint(0,0);
	LONG li_Width = 0, li_Height = 0;
	bool bInClientRc = false;

	//���ϼ�����ƶ���
	bool bHasMatched = false;
	RECT rcPaint, rcClip;
	memset(&rcPaint, 0, sizeof(rcPaint));
	for (int i = nEndIndex; i >= 0; i--)
	{
		if (!GetOleObjPos(pReo, reObject, i, ptObjPos, xPerInch, yPerInch, li_Width, li_Height))
		{
			break;
		}

		//ole�����ڵ�ǰ�ͻ�����
		if (ptObjPos.x < rcClient.right && ptObjPos.x + li_Width > rcClient.left && 
			ptObjPos.y < rcClient.bottom && ptObjPos.y + li_Height > rcClient.top)
		{
			bInClientRc = true;
		}
		else
		{
			bInClientRc = false;
		}

		if (!bInClientRc)
		{
			//���ö��������д��ڿɼ����������ϼ���
			if (bHasMatched && (ptObjPos.y == rcPaint.top || ptObjPos.y + li_Height == rcPaint.bottom))
			{
				//do nothing
			}
			else
			{
				break;
			}
		}

		IOleProcesser* pOleProcesser = GetOleProcesser(reObject.dwUser);
		if (pOleProcesser && OleProcesser_Control == pOleProcesser->GetType() && nCurResultCount < nArrayCount)
		{
			pResultIndexArray[nCurResultCount] = reObject.dwUser;
			nCurResultCount += 1;
		}

		if (nCurResultCount >= nArrayCount)
		{
			break;
		}

		if (bInClientRc)
		{
			bHasMatched = true;

			rcPaint.left = ptObjPos.x;
			rcPaint.right = ptObjPos.x + li_Width;
			rcPaint.top = ptObjPos.y;
			rcPaint.bottom = ptObjPos.y + li_Height;
		}
	}

	//���¼�����ƶ���
	bHasMatched = false;
	memset(&rcPaint, 0, sizeof(rcPaint));
	memset(&rcClip, 0, sizeof(rcClip));
	for (int i = nEndIndex + 1; i < nOleCount; i++)
	{
		if (!GetOleObjPos(pReo, reObject, i, ptObjPos, xPerInch, yPerInch, li_Width, li_Height))
		{
			break;
		}

		//ole�����ڵ�ǰ�ͻ�����
		if (ptObjPos.x < rcClient.right && ptObjPos.x + li_Width > rcClient.left && 
			ptObjPos.y < rcClient.bottom && ptObjPos.y + li_Height > rcClient.top)
		{
			bInClientRc = true;
		}
		else
		{
			bInClientRc = false;
		}

		if (!bInClientRc)
		{
			//���ö��������д��ڿɼ����������¼���
			if (bHasMatched && (ptObjPos.y == rcPaint.top || ptObjPos.y + li_Height == rcPaint.bottom))
			{
				//do nothing
			}
			else
			{
				break;
			}
		}

		IOleProcesser* pOleProcesser = GetOleProcesser(reObject.dwUser);
		if (pOleProcesser && OleProcesser_Control == pOleProcesser->GetType() && nCurResultCount < nArrayCount)
		{
			pResultIndexArray[nCurResultCount] = reObject.dwUser;
			nCurResultCount += 1;
		}

		if (nCurResultCount >= nArrayCount)
		{
			break;
		}

		if (bInClientRc)
		{
			bHasMatched = true;

			rcPaint.left = ptObjPos.x;
			rcPaint.right = ptObjPos.x + li_Width;
			rcPaint.top = ptObjPos.y;
			rcPaint.bottom = ptObjPos.y + li_Height;
		}
	}

	// �ͷ�DC
	::ReleaseDC(m_hWndDirectUI, hDC);

	// ����ʵ�ʽ������
	return nCurResultCount;
}

void CUIShowRichEdit::InsertExtraOleControlBegin()
{
	stExtraElementInsert data;
	data.nInsertPosBegin = UpdateCurInsertSel();
	m_vecExtraEleInsertBegin.push_back(data);
}

DWORD CUIShowRichEdit::InsertExtraOleControlEnd(
    bool bAutoSize,
    bool bFullFillLayout,
    int nWidth,
    int nHeight,
    LPCTSTR lpOleEleName,
    LPRECT lpRectOffset/* = NULL*/,
    E_RICHEDIT_ELEMENT_VALIGN eVAlign/* = RICHEDIT_ELEMENT_VTOP*/)
{
    if (NULL == lpOleEleName)
    {
        return -1;
    }
	int nInsertCount = (int)m_vecExtraEleInsertBegin.size();
	if (nInsertCount <= 0)
	{
		return -1;
	}

	//�ҵ��뱾��"�������"ƥ���"���뿪ʼ"
	std::vector<stExtraElementInsert>::iterator it = m_vecExtraEleInsertBegin.begin();
	std::advance(it, nInsertCount - 1);
	if (it == m_vecExtraEleInsertBegin.end())
	{
		m_vecExtraEleInsertBegin.clear();
		return -1;
	}

	//���뵽ָ��Ԫ��֮ǰ
	//��ע:Ԫ��A����Ԫ��Bʱ, AԪ�ص���ʼ����ʱ������BԪ����ʼ����ʱ��, ��BԪ�ز��������ʱ��ȴ����AԪ�ز������ʱ��,Ϊȷ������˳��A��B֮ǰ,�˴�������Ӧ����
	//ʾ��:��ʼ����A-->��ʼ����B-->��������B-->��������A
	int nExtraEleInsertPosBegin = it->nInsertPosBegin;
	m_vecExtraEleInsertBegin.erase(it);
	if (-1 == nExtraEleInsertPosBegin)
	{
		nExtraEleInsertPosBegin = UpdateCurInsertSel();
	}

	int nExtraEleInsertPosEnd = UpdateCurInsertSel();
	if (-1 == nExtraEleInsertPosEnd)
	{
		nExtraEleInsertPosEnd = nExtraEleInsertPosBegin;
	}

	//������˳�򱣴����Ԫ��
	CExtraElement extraFile(
		bAutoSize,
		bFullFillLayout,
		nWidth,
		nHeight,
		nExtraEleInsertPosBegin,
		nExtraEleInsertPosEnd,
		lpRectOffset,
		eVAlign);

	//��ǲ���״̬
	extraFile.SetInsertingFlag(IsDoingInsert()?true:false);

	// �������λ��
	int nExtraEleCount = m_ExtraEleColl.size();
	int nExtraEleInsertIndex = -1;
	if (nExtraEleCount <= 0)
	{
		nExtraEleInsertIndex = -1;
	}
	else if (IsDoingInsert() && eInsertModeFront == m_insertProcess.eInsertMode)
	{
		nExtraEleInsertIndex = -1;
		for (int i = 0; i < nExtraEleCount - 1; ++i)
		{
			//����Ԫ���ص�ʱ, ������Ԫ��������ʾ����һ����Ȳ����Ԫ�ش�, ���Ի���˳���Ϻ�����Ԫ������
			if (m_ExtraEleColl[i].GetBeginCharIndex() >= nExtraEleInsertPosBegin)
			{
				nExtraEleInsertIndex = i;
				break;
			}
		}
	}
	else
	{
		nExtraEleInsertIndex = 0;
		for (int i = nExtraEleCount - 1; i >= 0; --i)
		{
			//����Ԫ���ص�ʱ, ������Ԫ��������ʾ����һ����Ȳ����Ԫ�ش�, ���Ի���˳���Ϻ�����Ԫ������
			if (m_ExtraEleColl[i].GetBeginCharIndex() < nExtraEleInsertPosBegin)
			{
				nExtraEleInsertIndex = i + 1;
				break;
			}
		}
	}

    DWORD dwOleID = GetOleID();
    CIMControlProcesser* pOleControlProcesser = new CIMControlProcesser;
    if (NULL == pOleControlProcesser)
    {
        return -1;
    }
    pOleControlProcesser->EnableAutoSize(FALSE);
    pOleControlProcesser->SetSize(nWidth, nHeight);

    CRichElementBase* pOleControlEle = GetOleEleExModalByName(lpOleEleName);
    if (pOleControlEle)
    {
        pOleControlProcesser->SetControlElement(pOleControlEle);
    }
    extraFile.SetOleID(dwOleID);
    m_extraOleControlMap.insert(std::make_pair(dwOleID, pOleControlProcesser));

	// ����
	int nCurElementIndex = m_ExtraEleColl.size();
	if (nExtraEleInsertIndex < 0)
	{
		m_ExtraEleColl.push_back(extraFile);
		nCurElementIndex = (int)m_ExtraEleColl.size() - 1;
	}
	else
	{
		std::vector<CExtraElement>::iterator it = m_ExtraEleColl.begin();
		std::advance(it, min(nExtraEleInsertIndex, (int)m_ExtraEleColl.size()));
		if (it == m_ExtraEleColl.end())
		{
			m_ExtraEleColl.push_back(extraFile);
			nCurElementIndex = (int)m_ExtraEleColl.size() - 1;
		}
		else
		{
			m_ExtraEleColl.insert(it, extraFile);
			nCurElementIndex = nExtraEleInsertIndex;
		}
	}

	//���´��ڲ���״̬����չԪ��
	InsertingExtraEleList::iterator it_inserting = m_insertProcess.insertingExtraEleList.begin();
	for (; it_inserting != m_insertProcess.insertingExtraEleList.end(); ++it_inserting)
	{
		if ((*it_inserting) >= nCurElementIndex)
		{
			(*it_inserting) += 1;
		}
	}
	if (IsDoingInsert())
	{
		m_insertProcess.insertingExtraEleList.push_back(nCurElementIndex);
	}
	
	return dwOleID;
}

void CUIShowRichEdit::SetExtraOleControlClientIndent(DWORD dwOleID, int nLeftIndent, int nRightIndent)
{
    std::vector<CExtraElement>::reverse_iterator it = m_ExtraEleColl.rbegin();
    for (; it != m_ExtraEleColl.rend(); ++it)
    {
        if (it->GetOleID() == dwOleID)
        {
            it->SetClientIndent(nLeftIndent, nRightIndent);
            break;
        }
    }
}

void CUIShowRichEdit::SetExtraOleControlMinSize(DWORD dwOleID, int nMinWidth, int nMinHeight)
{
    std::vector<CExtraElement>::reverse_iterator it = m_ExtraEleColl.rbegin();
    for (; it != m_ExtraEleColl.rend(); ++it)
    {
        if (it->GetOleID() == dwOleID)
        {
            it->SetMinSize(nMinWidth, nMinHeight);
            break;
        }
    }
}

void CUIShowRichEdit::SetExtraOleControlMaxSize(DWORD dwOleID, int nMaxWidth, int nMaxHeight)
{
    std::vector<CExtraElement>::reverse_iterator it = m_ExtraEleColl.rbegin();
    for (; it != m_ExtraEleColl.rend(); ++it)
    {
        if (it->GetOleID() == dwOleID)
        {
            it->SetMaxSize(nMaxWidth, nMaxHeight);
            break;
        }
    }
}

void CUIShowRichEdit::SetExtraOleControlREContentAlign(DWORD dwOleID, WORD wREContentAlignment, int nREContentLeftIndent, int nREContentRightIndent)
{
    std::vector<CExtraElement>::reverse_iterator it = m_ExtraEleColl.rbegin();
    for (; it != m_ExtraEleColl.rend(); ++it)
    {
        if (it->GetOleID() == dwOleID)
        {
            it->SetREContentLeftIndent(nREContentLeftIndent);
            it->SetREContentRightIndent(nREContentRightIndent);
            it->SetREContentAlign(wREContentAlignment);
            break;
        }
    }
}

int CUIShowRichEdit::GetExtraOleControlVisibleArray(DWORD* pResultIndexArray, int nArrayCount)
{
    if (!pResultIndexArray || nArrayCount <= 0)
    {
        return 0;
    }

    int nExtraEleCount = m_ExtraEleColl.size();
    if (nExtraEleCount <= 0)
    {
        return 0;
    }

    RECT rcClient = GetRect();

    int nSomeDrawEleIndex = GetExtraElementInRect(rcClient, rcClient);
    if (-1 == nSomeDrawEleIndex)
    {
        return 0;
    }
    if (nSomeDrawEleIndex >= nExtraEleCount)
    {
        return 0;
    }

    RECT rcElement, rcClip;
    memset(&rcElement, 0, sizeof(rcElement));
    memset(&rcClip, 0, sizeof(rcClip));

    //���ϻ���
    int nResultIndex = 0;
    for (int i = nSomeDrawEleIndex; i >= 0 && nResultIndex < nArrayCount; --i)
    {
        rcElement = GetExtraElementRect(i, rcClient);

        if (rcElement.top > rcClient.bottom || rcElement.bottom < rcClient.top || 
            rcElement.left > rcClient.right || rcElement.right < rcClient.left)
        {
            break;
        }

        bool bNeedClip = false;
        if (rcElement.left < rcClient.left || rcElement.right > rcClient.right ||
            rcElement.top < rcClient.top || rcElement.bottom > rcClient.bottom)
        {
            bNeedClip = true;
            rcClip.left = max(rcElement.left, rcClient.left);
            rcClip.right = min(rcElement.right, rcClient.right);
            rcClip.top = max(rcElement.top, rcClient.top);
            rcClip.bottom = min(rcElement.bottom, rcClient.bottom);
        }

        pResultIndexArray[nResultIndex] = m_ExtraEleColl[i].GetOleID();
        nResultIndex += 1;
    }

    //���»���
    for (int i = nSomeDrawEleIndex + 1; i < nExtraEleCount && nResultIndex < nArrayCount; ++i)
    {
        rcElement = GetExtraElementRect(i, rcClient);

        if (rcElement.top > rcClient.bottom || rcElement.bottom < rcClient.top || 
            rcElement.left > rcClient.right || rcElement.right < rcClient.left)
        {
            break;
        }

        bool bNeedClip = false;
        if (rcElement.left < rcClient.left || rcElement.right > rcClient.right ||
            rcElement.top < rcClient.top || rcElement.bottom > rcClient.bottom)
        {
            bNeedClip = true;
            rcClip.left = max(rcElement.left, rcClient.left);
            rcClip.right = min(rcElement.right, rcClient.right);
            rcClip.top = max(rcElement.top, rcClient.top);
            rcClip.bottom = min(rcElement.bottom, rcClient.bottom);
        }
        pResultIndexArray[nResultIndex] = m_ExtraEleColl[i].GetOleID();
        nResultIndex += 1;

    }

    return nResultIndex;
}

UINT CUIShowRichEdit::InsertRMenuExtraItem(DUI_MENUITEM_STYLE eMenuStyle, bool bChecked, LPCTSTR lptszText)
{
	UINT uNewMenuItemID = ID_MENU_EDIT_EXTRA_ERROR;
	int nRMenuExtraItemCount = (int)m_RMenuExtraItemColl.size();

	//��ȡ�˵�ID������
	if (nRMenuExtraItemCount > 0)
	{
		for (UINT i = 0; i < 100; ++i)
		{
			bool bMenuIDUsed = false;
			UINT uCurMenuItemID = i + ID_MENU_EDIT_EXTRA_BEGIN;
			for (int j = 0; j < nRMenuExtraItemCount; ++j)
			{
				if (uCurMenuItemID == m_RMenuExtraItemColl[j].uMenuItemID)
				{
					bMenuIDUsed = true;
					break;
				}
			}

			if (!bMenuIDUsed)
			{
				uNewMenuItemID = uCurMenuItemID;
				break;
			}
		}
	}
	else
	{
		uNewMenuItemID = ID_MENU_EDIT_EXTRA_BEGIN;
	}

	//����˵�
	if (uNewMenuItemID != ID_MENU_EDIT_EXTRA_ERROR)
	{
		stRMenuExtraItem menuItem;
		menuItem.byMenuStyle = (UINT)eMenuStyle;
		menuItem.bChecked = bChecked;
		menuItem.uMenuItemID = uNewMenuItemID;
		menuItem.strMenuItemText = lptszText?lptszText:_T("");
		m_RMenuExtraItemColl.push_back(menuItem);
	}

	return uNewMenuItemID;
}

void CUIShowRichEdit::ModifyRMenuExtraItem(UINT uItemID, DUI_MENUITEM_STYLE eMenuStyle, bool bChecked, LPCTSTR lptszText)
{
	int nRMenuExtraItemCount = (int)m_RMenuExtraItemColl.size();
	for (int i = 0; i < nRMenuExtraItemCount; ++i)
	{
		if (uItemID == m_RMenuExtraItemColl[i].uMenuItemID)
		{
			m_RMenuExtraItemColl[i].byMenuStyle = (UINT)eMenuStyle;
			m_RMenuExtraItemColl[i].bChecked = bChecked;
			m_RMenuExtraItemColl[i].strMenuItemText = lptszText?lptszText:_T("");
			break;
		}
	}
}

void CUIShowRichEdit::EnablePicScale(bool bEnable)
{
	m_bEnablePicScale = bEnable;
}

void CUIShowRichEdit::SetImgLoadingOle(LPCTSTR lpOleEleName, int nWidth, int nHeight)
{
    if (m_pLoadingElementName)
    {
        m_pLoadingElementName->SetValue2(lpOleEleName);
    }
    if (m_pLoadingElementWidth)
    {
        m_pLoadingElementWidth->SetValue(nWidth);
    }
    if (m_pLoadingElementHeight)
    {
        m_pLoadingElementHeight->SetValue(nHeight);
    }
}

void CUIShowRichEdit::SetImgErrorOle(LPCTSTR lpOleEleName, int nWidth, int nHeight)
{
    if (m_pErrorElementName)
    {
        m_pErrorElementName->SetValue2(lpOleEleName);
    }
    if (m_pErrorElementWidth)
    {
        m_pErrorElementWidth->SetValue(nWidth);
    }
    if (m_pErrorElementHeight)
    {
        m_pErrorElementHeight->SetValue(nHeight);
    }
}

void CUIShowRichEdit::CheckLinkByAdd(LONG lInsertChar, LONG lCharCount)
{
	list_LinkCallBacks::iterator itLink = m_listLinksCallBack.begin();
	for (; itLink != m_listLinksCallBack.end(); ++itLink)
	{
		if (itLink->lBeginPos >= lInsertChar)
		{
			itLink->lBeginPos += lCharCount;
		}

		if (itLink->lEndPos > lInsertChar)
		{
			itLink->lEndPos += lCharCount;
		}
	}
}

void CUIShowRichEdit::CheckLinkByDel(LONG lStartChar, LONG lEndChar)
{
	list_LinkCallBacks::iterator itLink = m_listLinksCallBack.begin();
	for (; itLink != m_listLinksCallBack.end();)
	{
		if (itLink->lBeginPos <= lEndChar && itLink->lEndPos > lStartChar)
		{
			m_listLinksCallBack.erase(itLink++);
			continue;
		}
		
		if (itLink->lBeginPos > lEndChar)
		{
			itLink->lBeginPos -= (lEndChar - lStartChar + 1);
			itLink->lEndPos -= (lEndChar - lStartChar + 1);
		}
		
		++itLink;
	}
}

void CUIShowRichEdit::ClearLink()
{
	m_listLinksCallBack.clear();
}